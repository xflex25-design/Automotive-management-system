
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `auto_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `auto_db`;
DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `employee_id` bigint DEFAULT NULL,
  `action_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity_id` bigint DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `request_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recorded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_audit_employee` (`employee_id`),
  KEY `idx_audit_company_date` (`company_id`,`recorded_at`),
  KEY `idx_audit_entity` (`entity_type`,`entity_id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_action` (`action_type`),
  CONSTRAINT `fk_audit_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_audit_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ZMW',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `vat_rate` decimal(5,2) NOT NULL DEFAULT '16.00',
  `vat_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_branch` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_swift_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_data` longblob,
  `logo_content_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_company_registration` (`registration_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `customer_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INDIVIDUAL',
  `customer_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alternative_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `tax_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_customer_code` (`company_id`,`customer_code`),
  KEY `idx_customer_phone` (`phone`),
  KEY `idx_customer_name` (`last_name`,`first_name`),
  KEY `idx_customer_company_name` (`company_name`),
  CONSTRAINT `fk_customer_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_id` bigint NOT NULL,
  `department_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_department_code` (`workshop_id`,`department_code`),
  KEY `idx_department_company` (`company_id`),
  CONSTRAINT `fk_department_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_department_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `dispatch_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispatch_order_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `dispatch_order_id` bigint NOT NULL,
  `requisition_item_id` bigint DEFAULT NULL,
  `part_id` bigint NOT NULL,
  `stock_location_id` bigint NOT NULL,
  `description_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity_requested` decimal(12,2) DEFAULT NULL,
  `quantity_dispatched` decimal(12,2) DEFAULT NULL,
  `unit_of_measure` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_cost` decimal(14,2) DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `stock_reservation_id` bigint DEFAULT NULL,
  `unit_selling_price` decimal(14,2) DEFAULT NULL,
  `amount_sold` decimal(14,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dispatch_item_reservation` (`stock_reservation_id`),
  KEY `fk_dispatch_item_order` (`dispatch_order_id`),
  KEY `fk_dispatch_item_requisition` (`requisition_item_id`),
  KEY `fk_dispatch_item_part` (`part_id`),
  KEY `fk_dispatch_item_location` (`stock_location_id`),
  CONSTRAINT `fk_dispatch_item_location` FOREIGN KEY (`stock_location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `fk_dispatch_item_order` FOREIGN KEY (`dispatch_order_id`) REFERENCES `dispatch_orders` (`id`),
  CONSTRAINT `fk_dispatch_item_part` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`),
  CONSTRAINT `fk_dispatch_item_requisition` FOREIGN KEY (`requisition_item_id`) REFERENCES `parts_requisition_items` (`id`),
  CONSTRAINT `fk_dispatch_item_reservation` FOREIGN KEY (`stock_reservation_id`) REFERENCES `stock_reservations` (`id`),
  CONSTRAINT `chk_dispatch_quantity` CHECK ((`quantity_dispatched` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `dispatch_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispatch_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_id` bigint NOT NULL,
  `job_id` bigint NOT NULL,
  `requisition_id` bigint DEFAULT NULL,
  `dispatch_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dispatched_by_employee_id` bigint NOT NULL,
  `received_by_employee_id` bigint DEFAULT NULL,
  `department_id` bigint DEFAULT NULL,
  `dispatch_status` enum('DRAFT','PENDING_APPROVAL','APPROVED','REJECTED','DISPATCHED','ISSUED','RECEIVED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT 'DRAFT',
  `dispatch_date` datetime DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `customer_or_company_name_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number_snapshot` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by_employee_id` bigint DEFAULT NULL,
  `assigned_mechanic_employee_id` bigint DEFAULT NULL,
  `approved_by_employee_id` bigint DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `issued_at` datetime DEFAULT NULL,
  `rejection_reason` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dispatch_number` (`workshop_id`,`dispatch_number`),
  KEY `fk_dispatch_company` (`company_id`),
  KEY `fk_dispatch_requisition` (`requisition_id`),
  KEY `fk_dispatch_issuer` (`dispatched_by_employee_id`),
  KEY `fk_dispatch_receiver` (`received_by_employee_id`),
  KEY `fk_dispatch_department` (`department_id`),
  KEY `idx_dispatch_job` (`job_id`),
  KEY `fk_dispatch_created_by` (`created_by_employee_id`),
  KEY `fk_dispatch_assigned_mechanic` (`assigned_mechanic_employee_id`),
  KEY `fk_dispatch_approved_by` (`approved_by_employee_id`),
  CONSTRAINT `fk_dispatch_approved_by` FOREIGN KEY (`approved_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_dispatch_assigned_mechanic` FOREIGN KEY (`assigned_mechanic_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_dispatch_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_dispatch_created_by` FOREIGN KEY (`created_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_dispatch_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `fk_dispatch_issuer` FOREIGN KEY (`dispatched_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_dispatch_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_dispatch_receiver` FOREIGN KEY (`received_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_dispatch_requisition` FOREIGN KEY (`requisition_id`) REFERENCES `parts_requisitions` (`id`),
  CONSTRAINT `fk_dispatch_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `dispatch_signatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dispatch_signatures` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `dispatch_order_id` bigint NOT NULL,
  `signer_type` enum('AUTHORISED_BY','DISPATCHED_BY','RECEIVED_BY','ACCOUNTS_ACKNOWLEDGEMENT','CUSTOMER_ACKNOWLEDGEMENT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `signer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` bigint DEFAULT NULL,
  `signature_media_id` bigint DEFAULT NULL,
  `signed_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `fk_dispatch_signature_order` (`dispatch_order_id`),
  KEY `fk_dispatch_signature_employee` (`employee_id`),
  KEY `fk_dispatch_signature_media` (`signature_media_id`),
  CONSTRAINT `fk_dispatch_signature_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_dispatch_signature_media` FOREIGN KEY (`signature_media_id`) REFERENCES `media_files` (`id`),
  CONSTRAINT `fk_dispatch_signature_order` FOREIGN KEY (`dispatch_order_id`) REFERENCES `dispatch_orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `employee_departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_departments` (
  `employee_id` bigint NOT NULL,
  `department_id` bigint NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`employee_id`,`department_id`),
  KEY `fk_employee_department_department` (`department_id`),
  CONSTRAINT `fk_employee_department_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `fk_employee_department_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `employee_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employment_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `date_hired` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_employee_number` (`company_id`,`employee_number`),
  UNIQUE KEY `uk_employee_user` (`user_id`),
  KEY `idx_employee_workshop` (`workshop_id`),
  KEY `idx_employee_name` (`last_name`,`first_name`),
  CONSTRAINT `fk_employee_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_employee_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_employee_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `final_inspection_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `final_inspection_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `final_inspection_id` bigint NOT NULL,
  `responsible_department_id` bigint DEFAULT NULL,
  `checked_by_employee_id` bigint DEFAULT NULL,
  `item_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `check_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `comments` text COLLATE utf8mb4_unicode_ci,
  `reinspection_required` tinyint(1) NOT NULL DEFAULT '0',
  `checked_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `corrective_work_order_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_final_item_inspection` (`final_inspection_id`),
  KEY `idx_final_item_department` (`responsible_department_id`),
  KEY `fk_final_item_employee` (`checked_by_employee_id`),
  KEY `idx_final_item_corrective_work_order` (`corrective_work_order_id`),
  CONSTRAINT `fk_final_item_corrective_work_order` FOREIGN KEY (`corrective_work_order_id`) REFERENCES `work_orders` (`id`),
  CONSTRAINT `fk_final_item_department` FOREIGN KEY (`responsible_department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `fk_final_item_employee` FOREIGN KEY (`checked_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_final_item_inspection` FOREIGN KEY (`final_inspection_id`) REFERENCES `final_inspections` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `final_inspection_signoffs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `final_inspection_signoffs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `final_inspection_id` bigint NOT NULL,
  `department_id` bigint NOT NULL,
  `signed_by_employee_id` bigint DEFAULT NULL,
  `signoff_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `signoff_notes` text COLLATE utf8mb4_unicode_ci,
  `signed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_final_signoff_department` (`final_inspection_id`,`department_id`),
  KEY `idx_final_signoff_department` (`department_id`),
  KEY `fk_final_signoff_employee` (`signed_by_employee_id`),
  CONSTRAINT `fk_final_signoff_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `fk_final_signoff_employee` FOREIGN KEY (`signed_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_final_signoff_inspection` FOREIGN KEY (`final_inspection_id`) REFERENCES `final_inspections` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `final_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `final_inspections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `inspector_employee_id` bigint NOT NULL,
  `inspection_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IN_PROGRESS',
  `inspection_decision` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inspection_notes` text COLLATE utf8mb4_unicode_ci,
  `started_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `previous_inspection_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_final_inspection_number` (`inspection_number`),
  KEY `idx_final_inspection_job` (`job_id`,`started_at`),
  KEY `fk_final_inspection_inspector` (`inspector_employee_id`),
  KEY `idx_final_inspection_previous` (`previous_inspection_id`),
  CONSTRAINT `fk_final_inspection_inspector` FOREIGN KEY (`inspector_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_final_inspection_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_final_inspection_previous` FOREIGN KEY (`previous_inspection_id`) REFERENCES `final_inspections` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `inspection_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inspection_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inspection_id` bigint NOT NULL,
  `item_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condition_status` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observation` text COLLATE utf8mb4_unicode_ci,
  `requires_attention` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inspection_items` (`inspection_id`),
  CONSTRAINT `fk_inspection_item_record` FOREIGN KEY (`inspection_id`) REFERENCES `inspection_records` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `inspection_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inspection_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `inventory_card_id` bigint NOT NULL,
  `inspection_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INITIAL',
  `inspected_by_employee_id` bigint NOT NULL,
  `inspection_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `overall_condition` text COLLATE utf8mb4_unicode_ci,
  `inspection_notes` text COLLATE utf8mb4_unicode_ci,
  `inspection_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_inspection_inventory` (`inventory_card_id`),
  KEY `fk_inspection_employee` (`inspected_by_employee_id`),
  KEY `idx_inspection_job` (`job_id`),
  KEY `idx_inspection_date` (`inspection_date`),
  CONSTRAINT `fk_inspection_employee` FOREIGN KEY (`inspected_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_inspection_inventory` FOREIGN KEY (`inventory_card_id`) REFERENCES `vehicle_inventory_cards` (`id`),
  CONSTRAINT `fk_inspection_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `inventory_accessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_accessories` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inventory_card_id` bigint NOT NULL,
  `accessory_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_present` tinyint(1) NOT NULL DEFAULT '0',
  `condition_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_accessory_inventory` (`inventory_card_id`),
  CONSTRAINT `fk_accessory_inventory` FOREIGN KEY (`inventory_card_id`) REFERENCES `vehicle_inventory_cards` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `inventory_authorisations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_authorisations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inventory_card_id` bigint NOT NULL,
  `authorisation_type` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authorisation_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `authorisation_text` text COLLATE utf8mb4_unicode_ci,
  `authorised_by_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorised_by_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authorised_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inventory_authorisation_card` (`inventory_card_id`),
  CONSTRAINT `fk_inventory_authorisation_card` FOREIGN KEY (`inventory_card_id`) REFERENCES `vehicle_inventory_cards` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `inventory_received_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_received_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inventory_card_id` bigint NOT NULL,
  `item_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `quantity` int NOT NULL DEFAULT '1',
  `condition_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_received_items_inventory` (`inventory_card_id`),
  CONSTRAINT `fk_received_item_inventory` FOREIGN KEY (`inventory_card_id`) REFERENCES `vehicle_inventory_cards` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `inventory_signatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_signatures` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inventory_card_id` bigint NOT NULL,
  `authorisation_id` bigint DEFAULT NULL,
  `signer_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `signer_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_id` bigint DEFAULT NULL,
  `signature_media_id` bigint DEFAULT NULL,
  `signed_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `fk_inventory_signature_authorisation` (`authorisation_id`),
  KEY `fk_inventory_signature_employee` (`employee_id`),
  KEY `fk_inventory_signature_media` (`signature_media_id`),
  KEY `idx_inventory_signatures` (`inventory_card_id`),
  CONSTRAINT `fk_inventory_signature_authorisation` FOREIGN KEY (`authorisation_id`) REFERENCES `inventory_authorisations` (`id`),
  CONSTRAINT `fk_inventory_signature_card` FOREIGN KEY (`inventory_card_id`) REFERENCES `vehicle_inventory_cards` (`id`),
  CONSTRAINT `fk_inventory_signature_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_inventory_signature_media` FOREIGN KEY (`signature_media_id`) REFERENCES `media_files` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint NOT NULL,
  `item_type` enum('PART','LABOUR','SERVICE','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `part_id` bigint DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT '1.00',
  `unit_of_measure` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_price` decimal(14,2) NOT NULL,
  `discount_amount` decimal(14,2) DEFAULT '0.00',
  `tax_amount` decimal(14,2) DEFAULT '0.00',
  `line_total` decimal(14,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_invoice_item_part` (`part_id`),
  KEY `idx_invoice_items_invoice` (`invoice_id`),
  CONSTRAINT `fk_invoice_item_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`),
  CONSTRAINT `fk_invoice_item_part` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`),
  CONSTRAINT `chk_invoice_item_quantity` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_id` bigint NOT NULL,
  `job_id` bigint NOT NULL,
  `quotation_id` bigint DEFAULT NULL,
  `final_inspection_id` bigint DEFAULT NULL,
  `invoice_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_phone_snapshot` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_email_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_address_snapshot` text COLLATE utf8mb4_unicode_ci,
  `issued_by_employee_id` bigint NOT NULL,
  `invoice_status` enum('DRAFT','ISSUED','PARTIALLY_PAID','PAID','OVERDUE','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT 'DRAFT',
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci DEFAULT 'ZMW',
  `invoice_date` date NOT NULL,
  `due_date` date DEFAULT NULL,
  `subtotal` decimal(14,2) DEFAULT '0.00',
  `discount_amount` decimal(14,2) DEFAULT '0.00',
  `tax_amount` decimal(14,2) DEFAULT '0.00',
  `total_amount` decimal(14,2) DEFAULT '0.00',
  `amount_paid` decimal(14,2) DEFAULT '0.00',
  `balance_due` decimal(14,2) DEFAULT '0.00',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_invoice_number` (`workshop_id`,`invoice_number`),
  UNIQUE KEY `uq_invoice_quotation` (`quotation_id`),
  KEY `fk_invoice_company` (`company_id`),
  KEY `fk_invoice_issued_by` (`issued_by_employee_id`),
  KEY `idx_invoice_job` (`job_id`),
  KEY `idx_invoice_status` (`invoice_status`),
  KEY `fk_invoice_final_inspection` (`final_inspection_id`),
  CONSTRAINT `fk_invoice_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_invoice_final_inspection` FOREIGN KEY (`final_inspection_id`) REFERENCES `final_inspections` (`id`),
  CONSTRAINT `fk_invoice_issued_by` FOREIGN KEY (`issued_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_invoice_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_invoice_quotation` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`),
  CONSTRAINT `fk_invoice_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `job_activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_activity_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `employee_id` bigint DEFAULT NULL,
  `activity_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_description` text COLLATE utf8mb4_unicode_ci,
  `related_entity_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_entity_id` bigint DEFAULT NULL,
  `activity_data` json DEFAULT NULL,
  `is_customer_visible` tinyint(1) DEFAULT '0',
  `occurred_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_job_activity_user` (`user_id`),
  KEY `fk_job_activity_employee` (`employee_id`),
  KEY `idx_job_activity_job_date` (`job_id`,`occurred_at`),
  KEY `idx_job_activity_type` (`activity_type`),
  CONSTRAINT `fk_job_activity_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_job_activity_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_job_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `job_card_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_card_parts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_card_id` bigint NOT NULL,
  `part_id` bigint DEFAULT NULL,
  `source_quotation_item_id` bigint DEFAULT NULL,
  `part_category` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `part_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `part_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT '1.00',
  `unit_of_measure` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'UNIT',
  `required_for` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `part_catalog_linked_by_employee_id` bigint DEFAULT NULL,
  `part_catalog_linked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_job_card_quotation_item` (`source_quotation_item_id`),
  KEY `idx_job_card_parts` (`job_card_id`),
  KEY `idx_job_card_part_category` (`part_category`),
  KEY `idx_job_card_parts_catalog_part` (`part_id`),
  KEY `fk_job_card_parts_catalog_linker` (`part_catalog_linked_by_employee_id`),
  CONSTRAINT `fk_job_card_part` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`),
  CONSTRAINT `fk_job_card_parts_catalog_linker` FOREIGN KEY (`part_catalog_linked_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_job_card_parts_catalog_part` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`),
  CONSTRAINT `fk_job_card_quotation_item` FOREIGN KEY (`source_quotation_item_id`) REFERENCES `quotation_items` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `job_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_cards` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `approved_quotation_id` bigint NOT NULL,
  `job_card_number` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehicle_type_snapshot` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration_number_snapshot` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_name_snapshot` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `work_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_findings` text COLLATE utf8mb4_unicode_ci,
  `repair_instructions` text COLLATE utf8mb4_unicode_ci,
  `foreman_remarks` text COLLATE utf8mb4_unicode_ci,
  `job_card_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `prepared_by_employee_id` bigint NOT NULL,
  `confirmed_by_employee_id` bigint DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_job_card_job` (`job_id`),
  UNIQUE KEY `uk_job_card_number` (`job_card_number`),
  KEY `fk_job_card_quotation` (`approved_quotation_id`),
  KEY `fk_job_card_prepared_by` (`prepared_by_employee_id`),
  KEY `fk_job_card_confirmed_by` (`confirmed_by_employee_id`),
  KEY `idx_job_card_status` (`job_card_status`),
  CONSTRAINT `fk_job_card_confirmed_by` FOREIGN KEY (`confirmed_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_job_card_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_job_card_prepared_by` FOREIGN KEY (`prepared_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_job_card_quotation` FOREIGN KEY (`approved_quotation_id`) REFERENCES `quotations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `job_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_status_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `previous_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changed_by_user_id` bigint DEFAULT NULL,
  `changed_by_employee_id` bigint DEFAULT NULL,
  `change_reason` text COLLATE utf8mb4_unicode_ci,
  `changed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_job_status_history_user` (`changed_by_user_id`),
  KEY `fk_job_status_history_employee` (`changed_by_employee_id`),
  KEY `idx_job_status_history_job_date` (`job_id`,`changed_at`),
  CONSTRAINT `fk_job_status_history_employee` FOREIGN KEY (`changed_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_job_status_history_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_job_status_history_user` FOREIGN KEY (`changed_by_user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_id` bigint NOT NULL,
  `customer_id` bigint NOT NULL,
  `vehicle_id` bigint NOT NULL,
  `job_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name_snapshot` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehicle_registration_snapshot` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehicle_make_snapshot` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vehicle_type_snapshot` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brought_in_by_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brought_in_by_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `received_by_employee_id` bigint DEFAULT NULL,
  `job_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'REPAIR',
  `priority` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  `job_status` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RECEIVED',
  `reported_problem` text COLLATE utf8mb4_unicode_ci,
  `internal_notes` text COLLATE utf8mb4_unicode_ci,
  `date_received` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `estimated_completion_date` datetime DEFAULT NULL,
  `actual_completion_date` datetime DEFAULT NULL,
  `vehicle_released_at` datetime DEFAULT NULL,
  `created_by_user_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_job_number` (`workshop_id`,`job_number`),
  KEY `fk_job_company` (`company_id`),
  KEY `fk_job_received_by` (`received_by_employee_id`),
  KEY `fk_job_created_by` (`created_by_user_id`),
  KEY `idx_job_customer` (`customer_id`),
  KEY `idx_job_vehicle` (`vehicle_id`),
  KEY `idx_job_status` (`job_status`),
  KEY `idx_job_date_received` (`date_received`),
  KEY `idx_job_workshop_status` (`workshop_id`,`job_status`),
  CONSTRAINT `fk_job_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_job_created_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_job_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `fk_job_received_by` FOREIGN KEY (`received_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_job_vehicle` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`),
  CONSTRAINT `fk_job_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `legacy_final_inspection_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legacy_final_inspection_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `final_inspection_id` bigint NOT NULL,
  `inspection_category` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `check_item` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspection_result` enum('PASS','FAIL','NOT_APPLICABLE','PENDING') COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `observations` text COLLATE utf8mb4_unicode_ci,
  `requires_rework` tinyint(1) DEFAULT '0',
  `checked_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_final_inspection_items` (`final_inspection_id`),
  CONSTRAINT `fk_final_inspection_item` FOREIGN KEY (`final_inspection_id`) REFERENCES `legacy_final_inspections` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `legacy_final_inspections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `legacy_final_inspections` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `inspection_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inspected_by_employee_id` bigint NOT NULL,
  `inspection_status` enum('PENDING','IN_PROGRESS','PASSED','FAILED','REQUIRES_REWORK') COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `inspection_date` datetime DEFAULT NULL,
  `overall_remarks` text COLLATE utf8mb4_unicode_ci,
  `next_action` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_final_inspection_number` (`inspection_number`),
  KEY `fk_final_inspection_employee` (`inspected_by_employee_id`),
  KEY `idx_final_inspection_job` (`job_id`),
  CONSTRAINT `fk_final_inspection_employee` FOREIGN KEY (`inspected_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_legacy_final_inspection_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `media_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media_files` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `inventory_card_id` bigint DEFAULT NULL,
  `inspection_id` bigint DEFAULT NULL,
  `damage_record_id` bigint DEFAULT NULL,
  `work_order_id` bigint DEFAULT NULL,
  `uploaded_by_employee_id` bigint NOT NULL,
  `evidence_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storage_key` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint NOT NULL,
  `file_hash` char(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci,
  `captured_at` datetime DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_media_storage_key` (`storage_key`),
  KEY `fk_media_damage` (`damage_record_id`),
  KEY `fk_media_uploader` (`uploaded_by_employee_id`),
  KEY `idx_media_job` (`job_id`),
  KEY `idx_media_inventory` (`inventory_card_id`),
  KEY `idx_media_inspection` (`inspection_id`),
  KEY `idx_media_work_order` (`work_order_id`),
  KEY `idx_media_evidence_type` (`evidence_type`),
  CONSTRAINT `fk_media_damage` FOREIGN KEY (`damage_record_id`) REFERENCES `vehicle_damage_records` (`id`),
  CONSTRAINT `fk_media_inspection` FOREIGN KEY (`inspection_id`) REFERENCES `inspection_records` (`id`),
  CONSTRAINT `fk_media_inventory` FOREIGN KEY (`inventory_card_id`) REFERENCES `vehicle_inventory_cards` (`id`),
  CONSTRAINT `fk_media_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_media_uploader` FOREIGN KEY (`uploaded_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_media_work_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `part_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `part_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `category` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_of_measure` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'Piece',
  `barcode` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minimum_stock_level` decimal(12,2) DEFAULT '0.00',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_parts_company_code` (`company_id`,`part_code`),
  CONSTRAINT `fk_parts_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `parts_requisition_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parts_requisition_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `requisition_id` bigint NOT NULL,
  `part_id` bigint NOT NULL,
  `department_id` bigint DEFAULT NULL,
  `work_order_id` bigint DEFAULT NULL,
  `requested_quantity` decimal(12,2) NOT NULL,
  `approved_quantity` decimal(12,2) DEFAULT NULL,
  `fulfilled_quantity` decimal(12,2) DEFAULT '0.00',
  `unit_of_measure` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason_for_request` text COLLATE utf8mb4_unicode_ci,
  `item_status` enum('PENDING','APPROVED','PARTIALLY_FULFILLED','FULFILLED','REJECTED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_requisition_item_header` (`requisition_id`),
  KEY `fk_requisition_item_part` (`part_id`),
  KEY `fk_requisition_item_department` (`department_id`),
  KEY `idx_requisition_item_work_order` (`work_order_id`),
  CONSTRAINT `fk_requisition_item_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `fk_requisition_item_header` FOREIGN KEY (`requisition_id`) REFERENCES `parts_requisitions` (`id`),
  CONSTRAINT `fk_requisition_item_part` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`),
  CONSTRAINT `fk_requisition_item_work_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`),
  CONSTRAINT `chk_requisition_requested_quantity` CHECK ((`requested_quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `parts_requisitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parts_requisitions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_id` bigint NOT NULL,
  `job_id` bigint NOT NULL,
  `requisition_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requested_by_employee_id` bigint NOT NULL,
  `requisition_status` enum('DRAFT','SUBMITTED','PENDING_APPROVAL','APPROVED','PARTIALLY_FULFILLED','FULFILLED','REJECTED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT 'DRAFT',
  `priority` enum('LOW','NORMAL','HIGH','URGENT') COLLATE utf8mb4_unicode_ci DEFAULT 'NORMAL',
  `required_date` date DEFAULT NULL,
  `purpose` text COLLATE utf8mb4_unicode_ci,
  `submitted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `cancelled_by_employee_id` bigint DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_requisition_number` (`workshop_id`,`requisition_number`),
  KEY `fk_requisition_company` (`company_id`),
  KEY `fk_requisition_employee` (`requested_by_employee_id`),
  KEY `idx_requisition_job` (`job_id`),
  KEY `idx_requisition_status` (`requisition_status`),
  KEY `idx_parts_requisitions_cancelled_by` (`cancelled_by_employee_id`),
  CONSTRAINT `fk_parts_requisition_cancelled_by` FOREIGN KEY (`cancelled_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_requisition_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_requisition_employee` FOREIGN KEY (`requested_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_requisition_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_requisition_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint NOT NULL,
  `payment_reference` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `received_by_employee_id` bigint NOT NULL,
  `payment_method` enum('CASH','BANK_TRANSFER','MOBILE_MONEY','CARD','CHEQUE','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` enum('PENDING','COMPLETED','FAILED','REVERSED') COLLATE utf8mb4_unicode_ci DEFAULT 'COMPLETED',
  `amount` decimal(14,2) NOT NULL,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci DEFAULT 'ZMW',
  `transaction_reference` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_date` datetime NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_payment_employee` (`received_by_employee_id`),
  KEY `idx_payment_invoice` (`invoice_id`),
  KEY `idx_payment_date` (`payment_date`),
  CONSTRAINT `fk_payment_employee` FOREIGN KEY (`received_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_payment_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`),
  CONSTRAINT `chk_payment_amount` CHECK ((`amount` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_permission_name` (`permission_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint NOT NULL,
  `part_id` bigint NOT NULL,
  `requisition_item_id` bigint DEFAULT NULL,
  `description_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity_ordered` decimal(12,2) NOT NULL,
  `quantity_received` decimal(12,2) DEFAULT '0.00',
  `unit_price` decimal(14,2) NOT NULL,
  `tax_amount` decimal(14,2) DEFAULT '0.00',
  `line_total` decimal(14,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_po_item_order` (`purchase_order_id`),
  KEY `fk_po_item_part` (`part_id`),
  KEY `fk_po_item_requisition` (`requisition_item_id`),
  CONSTRAINT `fk_po_item_order` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`),
  CONSTRAINT `fk_po_item_part` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`),
  CONSTRAINT `fk_po_item_requisition` FOREIGN KEY (`requisition_item_id`) REFERENCES `parts_requisition_items` (`id`),
  CONSTRAINT `chk_po_ordered_quantity` CHECK ((`quantity_ordered` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_id` bigint NOT NULL,
  `supplier_id` bigint NOT NULL,
  `purchase_order_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requisition_id` bigint DEFAULT NULL,
  `created_by_employee_id` bigint NOT NULL,
  `approved_by_employee_id` bigint DEFAULT NULL,
  `purchase_order_status` enum('DRAFT','PENDING_APPROVAL','APPROVED','SENT_TO_SUPPLIER','PARTIALLY_RECEIVED','RECEIVED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT 'DRAFT',
  `order_date` date DEFAULT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci DEFAULT 'ZMW',
  `subtotal` decimal(14,2) DEFAULT '0.00',
  `tax_amount` decimal(14,2) DEFAULT '0.00',
  `total_amount` decimal(14,2) DEFAULT '0.00',
  `supplier_reference` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `approved_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_po_number` (`workshop_id`,`purchase_order_number`),
  KEY `fk_po_company` (`company_id`),
  KEY `fk_po_supplier` (`supplier_id`),
  KEY `fk_po_requisition` (`requisition_id`),
  KEY `fk_po_created_by` (`created_by_employee_id`),
  KEY `fk_po_approved_by` (`approved_by_employee_id`),
  CONSTRAINT `fk_po_approved_by` FOREIGN KEY (`approved_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_po_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_po_created_by` FOREIGN KEY (`created_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_po_requisition` FOREIGN KEY (`requisition_id`) REFERENCES `parts_requisitions` (`id`),
  CONSTRAINT `fk_po_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`),
  CONSTRAINT `fk_po_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `purchase_receipt_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_receipt_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `receipt_id` bigint NOT NULL,
  `purchase_order_item_id` bigint NOT NULL,
  `quantity_delivered` decimal(12,2) NOT NULL,
  `quantity_accepted` decimal(12,2) NOT NULL,
  `quantity_rejected` decimal(12,2) NOT NULL,
  `discrepancy_notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_purchase_receipt_item_receipt` (`receipt_id`),
  KEY `idx_purchase_receipt_item_order_item` (`purchase_order_item_id`),
  CONSTRAINT `fk_purchase_receipt_item_order_item` FOREIGN KEY (`purchase_order_item_id`) REFERENCES `purchase_order_items` (`id`),
  CONSTRAINT `fk_purchase_receipt_item_receipt` FOREIGN KEY (`receipt_id`) REFERENCES `purchase_receipts` (`id`),
  CONSTRAINT `chk_purchase_receipt_quantities_balance` CHECK (((`quantity_accepted` + `quantity_rejected`) = `quantity_delivered`)),
  CONSTRAINT `chk_purchase_receipt_quantities_nonnegative` CHECK (((`quantity_delivered` > 0) and (`quantity_accepted` >= 0) and (`quantity_rejected` >= 0)))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `purchase_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_receipts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `purchase_order_id` bigint NOT NULL,
  `receipt_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `received_by_employee_id` bigint NOT NULL,
  `stock_location_id` bigint NOT NULL,
  `supplier_delivery_reference` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `received_at` datetime NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_purchase_receipt_number` (`receipt_number`),
  KEY `idx_purchase_receipt_order` (`purchase_order_id`),
  KEY `idx_purchase_receipt_received_at` (`received_at`),
  KEY `fk_purchase_receipt_receiver` (`received_by_employee_id`),
  KEY `fk_purchase_receipt_location` (`stock_location_id`),
  CONSTRAINT `fk_purchase_receipt_location` FOREIGN KEY (`stock_location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `fk_purchase_receipt_order` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`),
  CONSTRAINT `fk_purchase_receipt_receiver` FOREIGN KEY (`received_by_employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `quotation_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_approvals` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint NOT NULL,
  `approval_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `customer_name_snapshot` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_phone_snapshot` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approval_method` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IN_PERSON',
  `approval_token_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_comments` text COLLATE utf8mb4_unicode_ci,
  `signature_media_id` bigint DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `rejected_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verified_by_employee_id` bigint DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `verification_notes` text COLLATE utf8mb4_unicode_ci,
  `notification_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NOT_SENT',
  `notification_channel` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification_sent_at` datetime DEFAULT NULL,
  `approval_token_expires_at` datetime DEFAULT NULL,
  `decision_submitted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_quotation_approval_signature` (`signature_media_id`),
  KEY `idx_quotation_approval` (`quotation_id`),
  KEY `idx_quotation_approval_status` (`approval_status`),
  KEY `fk_quotation_approvals_verified_by` (`verified_by_employee_id`),
  CONSTRAINT `fk_quotation_approval` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`),
  CONSTRAINT `fk_quotation_approval_signature` FOREIGN KEY (`signature_media_id`) REFERENCES `media_files` (`id`),
  CONSTRAINT `fk_quotation_approvals_verified_by` FOREIGN KEY (`verified_by_employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `quotation_item_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_item_approvals` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `approval_id` bigint NOT NULL,
  `quotation_item_id` bigint NOT NULL,
  `item_approval_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `customer_comments` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_approval_item` (`approval_id`,`quotation_item_id`),
  KEY `fk_item_approval_quotation_item` (`quotation_item_id`),
  KEY `idx_item_approval_status` (`item_approval_status`),
  CONSTRAINT `fk_item_approval_quotation_item` FOREIGN KEY (`quotation_item_id`) REFERENCES `quotation_items` (`id`),
  CONSTRAINT `fk_item_approval_record` FOREIGN KEY (`approval_id`) REFERENCES `quotation_approvals` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `quotation_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotation_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quotation_id` bigint NOT NULL,
  `item_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_code` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT '1.00',
  `unit_of_measure` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'UNIT',
  `unit_price` decimal(15,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(15,2) NOT NULL DEFAULT '0.00',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_quotation_items` (`quotation_id`),
  KEY `idx_quotation_item_type` (`item_type`),
  CONSTRAINT `fk_quotation_item` FOREIGN KEY (`quotation_id`) REFERENCES `quotations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `quotations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `quotation_number` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version_number` int NOT NULL DEFAULT '1',
  `prepared_by_employee_id` bigint NOT NULL,
  `quotation_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `issue_date` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ZMW',
  `subtotal` decimal(15,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `tax_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `total_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `estimated_completion_days` int DEFAULT NULL,
  `terms_and_conditions` text COLLATE utf8mb4_unicode_ci,
  `foreman_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_quotation_number` (`job_id`,`quotation_number`),
  UNIQUE KEY `uk_quotation_version` (`job_id`,`version_number`),
  KEY `fk_quotation_prepared_by` (`prepared_by_employee_id`),
  KEY `idx_quotation_status` (`quotation_status`),
  KEY `idx_quotation_job` (`job_id`),
  CONSTRAINT `fk_quotation_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_quotation_prepared_by` FOREIGN KEY (`prepared_by_employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `repair_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_plans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `job_card_id` bigint NOT NULL,
  `plan_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prepared_by_employee_id` bigint NOT NULL,
  `confirmed_by_employee_id` bigint DEFAULT NULL,
  `plan_status` enum('DRAFT','PENDING_CUSTOMER_APPROVAL','APPROVED','ACTIVE','COMPLETED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT 'DRAFT',
  `plan_notes` text COLLATE utf8mb4_unicode_ci,
  `confirmed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_repair_plan_number` (`plan_number`),
  KEY `fk_repair_plan_job_card` (`job_card_id`),
  KEY `fk_repair_plan_prepared_by` (`prepared_by_employee_id`),
  KEY `fk_repair_plan_confirmed_by` (`confirmed_by_employee_id`),
  KEY `idx_repair_plan_job` (`job_id`),
  CONSTRAINT `fk_repair_plan_confirmed_by` FOREIGN KEY (`confirmed_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_repair_plan_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_repair_plan_job_card` FOREIGN KEY (`job_card_id`) REFERENCES `job_cards` (`id`),
  CONSTRAINT `fk_repair_plan_prepared_by` FOREIGN KEY (`prepared_by_employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `repair_task_catalogue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_task_catalogue` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `department_id` bigint NOT NULL,
  `task_code` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `default_instructions` text COLLATE utf8mb4_unicode_ci,
  `estimated_hours` decimal(8,2) DEFAULT NULL,
  `requires_parts` tinyint(1) NOT NULL DEFAULT '0',
  `requires_evidence` tinyint(1) NOT NULL DEFAULT '1',
  `requires_final_inspection` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_repair_task_code` (`task_code`),
  KEY `idx_repair_task_department` (`department_id`),
  KEY `idx_repair_task_active` (`is_active`),
  CONSTRAINT `fk_repair_task_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `repair_task_dependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_task_dependencies` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `task_id` bigint NOT NULL,
  `depends_on_task_id` bigint NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_repair_task_dependency` (`task_id`,`depends_on_task_id`),
  KEY `idx_repair_task_dependency_prerequisite` (`depends_on_task_id`),
  CONSTRAINT `fk_repair_task_dependency_prerequisite` FOREIGN KEY (`depends_on_task_id`) REFERENCES `repair_task_catalogue` (`id`),
  CONSTRAINT `fk_repair_task_dependency_task` FOREIGN KEY (`task_id`) REFERENCES `repair_task_catalogue` (`id`),
  CONSTRAINT `chk_repair_task_no_self_dependency` CHECK ((`task_id` <> `depends_on_task_id`))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `repair_task_keywords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_task_keywords` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repair_task_id` bigint NOT NULL,
  `keyword` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_repair_task_keyword` (`repair_task_id`,`keyword`),
  KEY `idx_repair_keyword` (`keyword`),
  CONSTRAINT `fk_repair_keyword_task` FOREIGN KEY (`repair_task_id`) REFERENCES `repair_task_catalogue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `requisition_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `requisition_approvals` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `requisition_id` bigint NOT NULL,
  `reviewed_by_employee_id` bigint NOT NULL,
  `approval_status` enum('APPROVED','REJECTED','CHANGES_REQUESTED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `comments` text COLLATE utf8mb4_unicode_ci,
  `reviewed_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_requisition_approval_employee` (`reviewed_by_employee_id`),
  KEY `idx_requisition_approval` (`requisition_id`),
  CONSTRAINT `fk_requisition_approval_employee` FOREIGN KEY (`reviewed_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_requisition_approval_header` FOREIGN KEY (`requisition_id`) REFERENCES `parts_requisitions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `role_id` bigint NOT NULL,
  `permission_id` bigint NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `fk_role_permissions_permission` (`permission_id`),
  CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_name` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_role_name` (`role_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `roles` (`role_name`, `description`) VALUES
  ('Manager', 'Workshop manager; may approve or reject dispatch orders.'),
  ('Boss', 'Workshop boss; may approve or reject dispatch orders.'),
  ('Foreman', 'Workshop foreman; prepares job cards and dispatch orders.'),
  ('Stores', 'Stores employee; receives and issues workshop parts.'),
  ('Accounts', 'Accounts employee; acknowledges dispatch documents.');
DROP TABLE IF EXISTS `stock_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_balances` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `part_id` bigint NOT NULL,
  `stock_location_id` bigint NOT NULL,
  `quantity_on_hand` decimal(12,2) NOT NULL DEFAULT '0.00',
  `quantity_reserved` decimal(12,2) NOT NULL DEFAULT '0.00',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stock_part_location` (`part_id`,`stock_location_id`),
  KEY `fk_stock_balances_location` (`stock_location_id`),
  CONSTRAINT `fk_stock_balances_location` FOREIGN KEY (`stock_location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `fk_stock_balances_part` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`),
  CONSTRAINT `chk_stock_on_hand` CHECK ((`quantity_on_hand` >= 0)),
  CONSTRAINT `chk_stock_reserved` CHECK ((`quantity_reserved` >= 0)),
  CONSTRAINT `chk_stock_reserved_available` CHECK ((`quantity_reserved` <= `quantity_on_hand`))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `stock_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_locations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `workshop_id` bigint NOT NULL,
  `location_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stock_location_code` (`workshop_id`,`location_code`),
  CONSTRAINT `fk_stock_locations_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `stock_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_movements` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `part_id` bigint NOT NULL,
  `stock_location_id` bigint NOT NULL,
  `movement_type` enum('OPENING_BALANCE','PURCHASE_RECEIPT','ISSUE','RETURN','ADJUSTMENT_IN','ADJUSTMENT_OUT','TRANSFER_IN','TRANSFER_OUT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` decimal(12,2) NOT NULL,
  `unit_cost` decimal(14,2) DEFAULT NULL,
  `reference_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_id` bigint DEFAULT NULL,
  `performed_by_employee_id` bigint DEFAULT NULL,
  `movement_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_stock_movements_location` (`stock_location_id`),
  KEY `fk_stock_movements_employee` (`performed_by_employee_id`),
  KEY `idx_stock_movement_part` (`part_id`),
  KEY `idx_stock_movement_date` (`movement_date`),
  KEY `idx_stock_movement_reference` (`reference_type`,`reference_id`),
  CONSTRAINT `fk_stock_movements_employee` FOREIGN KEY (`performed_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_stock_movements_location` FOREIGN KEY (`stock_location_id`) REFERENCES `stock_locations` (`id`),
  CONSTRAINT `fk_stock_movements_part` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`),
  CONSTRAINT `chk_stock_movement_quantity` CHECK ((`quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `stock_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_reservations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_card_part_id` bigint NOT NULL,
  `stock_balance_id` bigint NOT NULL,
  `quantity_reserved` decimal(12,2) NOT NULL,
  `reservation_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `reserved_by_employee_id` bigint NOT NULL,
  `reserved_at` datetime NOT NULL,
  `released_by_employee_id` bigint DEFAULT NULL,
  `released_at` datetime DEFAULT NULL,
  `consumed_at` datetime DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_stock_reservation_job_part` (`job_card_part_id`),
  KEY `idx_stock_reservation_balance_status` (`stock_balance_id`,`reservation_status`),
  KEY `fk_stock_reservation_reserved_by` (`reserved_by_employee_id`),
  KEY `fk_stock_reservation_released_by` (`released_by_employee_id`),
  CONSTRAINT `fk_stock_reservation_balance` FOREIGN KEY (`stock_balance_id`) REFERENCES `stock_balances` (`id`),
  CONSTRAINT `fk_stock_reservation_job_card_part` FOREIGN KEY (`job_card_part_id`) REFERENCES `job_card_parts` (`id`),
  CONSTRAINT `fk_stock_reservation_released_by` FOREIGN KEY (`released_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_stock_reservation_reserved_by` FOREIGN KEY (`reserved_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `chk_stock_reservation_quantity` CHECK ((`quantity_reserved` > 0)),
  CONSTRAINT `chk_stock_reservation_status` CHECK ((`reservation_status` in (_utf8mb4'ACTIVE',_utf8mb4'RELEASED',_utf8mb4'CONSUMED')))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `supplier_parts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier_parts` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `supplier_id` bigint NOT NULL,
  `part_id` bigint NOT NULL,
  `supplier_part_code` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_purchase_price` decimal(14,2) DEFAULT NULL,
  `currency_code` char(3) COLLATE utf8mb4_unicode_ci DEFAULT 'ZMW',
  `estimated_lead_time_days` int DEFAULT NULL,
  `is_preferred_supplier` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_supplier_part` (`supplier_id`,`part_id`),
  KEY `fk_supplier_parts_part` (`part_id`),
  CONSTRAINT `fk_supplier_parts_part` FOREIGN KEY (`part_id`) REFERENCES `parts` (`id`),
  CONSTRAINT `fk_supplier_parts_supplier` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `supplier_code` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_person` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `tax_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_terms` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_suppliers_company_code` (`company_id`,`supplier_code`),
  CONSTRAINT `fk_suppliers_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `user_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_user_roles_role` (`role_id`),
  CONSTRAINT `fk_user_roles_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `fk_user_roles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_email` (`company_id`,`email`),
  KEY `idx_user_company` (`company_id`),
  CONSTRAINT `fk_user_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `vehicle_damage_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle_damage_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inspection_id` bigint NOT NULL,
  `inventory_card_id` bigint NOT NULL,
  `damage_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `damage_location` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `damage_description` text COLLATE utf8mb4_unicode_ci,
  `severity` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diagram_x` decimal(6,3) DEFAULT NULL,
  `diagram_y` decimal(6,3) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_damage_inspection` (`inspection_id`),
  KEY `idx_damage_inventory` (`inventory_card_id`),
  CONSTRAINT `fk_damage_inspection` FOREIGN KEY (`inspection_id`) REFERENCES `inspection_records` (`id`),
  CONSTRAINT `fk_damage_inventory` FOREIGN KEY (`inventory_card_id`) REFERENCES `vehicle_inventory_cards` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `vehicle_handovers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle_handovers` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_id` bigint NOT NULL,
  `job_id` bigint NOT NULL,
  `vehicle_id` bigint NOT NULL,
  `invoice_id` bigint NOT NULL,
  `final_inspection_id` bigint NOT NULL,
  `released_by_employee_id` bigint NOT NULL,
  `handover_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collector_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collector_phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collector_id_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collector_id_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collector_relationship` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_collected` tinyint(1) NOT NULL DEFAULT '1',
  `keys_handed_over` tinyint(1) NOT NULL DEFAULT '0',
  `documents_handed_over` tinyint(1) NOT NULL DEFAULT '0',
  `vehicle_condition_at_release` text COLLATE utf8mb4_unicode_ci,
  `customer_acknowledged` tinyint(1) NOT NULL DEFAULT '0',
  `acknowledgement_text` text COLLATE utf8mb4_unicode_ci,
  `collector_signature` longblob NOT NULL,
  `signature_content_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'image/png',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `released_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_handover_number` (`workshop_id`,`handover_number`),
  UNIQUE KEY `uq_handover_job` (`job_id`),
  KEY `fk_handover_company` (`company_id`),
  KEY `fk_handover_vehicle` (`vehicle_id`),
  KEY `fk_handover_invoice` (`invoice_id`),
  KEY `fk_handover_inspection` (`final_inspection_id`),
  KEY `fk_handover_employee` (`released_by_employee_id`),
  CONSTRAINT `fk_handover_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_handover_employee` FOREIGN KEY (`released_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_handover_inspection` FOREIGN KEY (`final_inspection_id`) REFERENCES `final_inspections` (`id`),
  CONSTRAINT `fk_handover_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`),
  CONSTRAINT `fk_handover_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_handover_vehicle` FOREIGN KEY (`vehicle_id`) REFERENCES `vehicles` (`id`),
  CONSTRAINT `fk_handover_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `vehicle_inventory_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle_inventory_cards` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `job_number_snapshot` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `registration_number_snapshot` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `make_snapshot` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inventory_date` date NOT NULL,
  `owned_by_snapshot` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `driver_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `driver_phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `odometer_reading_in` decimal(12,2) DEFAULT NULL,
  `odometer_reading_out` decimal(12,2) DEFAULT NULL,
  `fuel_level_in` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fuel_level_out` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number_of_keys_received` int DEFAULT '0',
  `work_requested` text COLLATE utf8mb4_unicode_ci,
  `customer_complaints` text COLLATE utf8mb4_unicode_ci,
  `general_remarks` text COLLATE utf8mb4_unicode_ci,
  `received_by_employee_id` bigint DEFAULT NULL,
  `inspected_by_employee_id` bigint DEFAULT NULL,
  `intake_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `collection_date` datetime DEFAULT NULL,
  `collected_by_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_inventory_job` (`job_id`),
  KEY `fk_inventory_received_by` (`received_by_employee_id`),
  KEY `fk_inventory_inspected_by` (`inspected_by_employee_id`),
  KEY `idx_inventory_registration` (`registration_number_snapshot`),
  KEY `idx_inventory_date` (`inventory_date`),
  CONSTRAINT `fk_inventory_card_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_inventory_inspected_by` FOREIGN KEY (`inspected_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_inventory_received_by` FOREIGN KEY (`received_by_employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `vehicle_releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle_releases` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `job_id` bigint NOT NULL,
  `invoice_id` bigint DEFAULT NULL,
  `release_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authorised_by_employee_id` bigint NOT NULL,
  `released_by_employee_id` bigint NOT NULL,
  `collected_by_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `collector_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collector_id_reference` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `release_status` enum('PENDING_APPROVAL','AUTHORISED','RELEASED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING_APPROVAL',
  `release_date` datetime DEFAULT NULL,
  `vehicle_condition_on_release` text COLLATE utf8mb4_unicode_ci,
  `outstanding_balance` decimal(14,2) DEFAULT '0.00',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_vehicle_release_number` (`release_number`),
  KEY `fk_vehicle_release_invoice` (`invoice_id`),
  KEY `fk_vehicle_release_authoriser` (`authorised_by_employee_id`),
  KEY `fk_vehicle_release_employee` (`released_by_employee_id`),
  KEY `idx_vehicle_release_job` (`job_id`),
  CONSTRAINT `fk_vehicle_release_authoriser` FOREIGN KEY (`authorised_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_vehicle_release_employee` FOREIGN KEY (`released_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_vehicle_release_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`),
  CONSTRAINT `fk_vehicle_release_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_id` bigint NOT NULL,
  `owner_customer_id` bigint NOT NULL,
  `registration_number` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `make` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicle_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_year` year DEFAULT NULL,
  `color` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `engine_number` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fuel_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transmission` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `vehicle_status` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'IN_WORKSHOP',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_vehicle_registration` (`company_id`,`registration_number`),
  KEY `fk_vehicle_workshop` (`workshop_id`),
  KEY `idx_vehicle_owner` (`owner_customer_id`),
  KEY `idx_vehicle_vin` (`vin`),
  KEY `idx_vehicle_make_model` (`make`,`model`),
  CONSTRAINT `fk_vehicle_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_vehicle_owner` FOREIGN KEY (`owner_customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `fk_vehicle_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_order_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_activities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `department_visit_id` bigint DEFAULT NULL,
  `activity_type` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `previous_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity_description` text COLLATE utf8mb4_unicode_ci,
  `performed_by_employee_id` bigint DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_work_order_activity_date` (`work_order_id`,`created_at`),
  KEY `idx_department_visit_activity_date` (`department_visit_id`,`created_at`),
  KEY `fk_work_order_activity_employee` (`performed_by_employee_id`),
  CONSTRAINT `fk_work_order_activity_employee` FOREIGN KEY (`performed_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_work_order_activity_visit` FOREIGN KEY (`department_visit_id`) REFERENCES `work_order_department_visits` (`id`),
  CONSTRAINT `fk_work_order_activity_work_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_order_assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_assignments` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `employee_id` bigint NOT NULL,
  `assigned_by_employee_id` bigint NOT NULL,
  `assignment_role` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assignment_status` enum('ASSIGNED','ACCEPTED','DECLINED','REMOVED','COMPLETED') COLLATE utf8mb4_unicode_ci DEFAULT 'ASSIGNED',
  `assigned_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `accepted_at` datetime DEFAULT NULL,
  `removed_at` datetime DEFAULT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `fk_work_assignment_assigned_by` (`assigned_by_employee_id`),
  KEY `idx_work_assignment_employee` (`employee_id`),
  KEY `idx_work_assignment_order` (`work_order_id`),
  CONSTRAINT `fk_work_assignment_assigned_by` FOREIGN KEY (`assigned_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_work_assignment_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_work_assignment_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_order_confirmations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_confirmations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `confirmed_by_employee_id` bigint NOT NULL,
  `confirmation_status` enum('COMPLETED','REJECTED','RETURNED_FOR_REWORK','NOT_APPLICABLE') COLLATE utf8mb4_unicode_ci NOT NULL,
  `completion_notes` text COLLATE utf8mb4_unicode_ci,
  `confirmed_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_work_confirmation_employee` (`confirmed_by_employee_id`),
  KEY `idx_work_confirmation_order` (`work_order_id`),
  CONSTRAINT `fk_work_confirmation_employee` FOREIGN KEY (`confirmed_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_work_confirmation_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_order_department_visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_department_visits` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `department_id` bigint NOT NULL,
  `visit_number` int NOT NULL,
  `visit_status` enum('OPEN','SENT_OFF') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'OPEN',
  `arrived_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `arrived_by_employee_id` bigint NOT NULL,
  `sent_off_at` datetime DEFAULT NULL,
  `sent_off_by_employee_id` bigint DEFAULT NULL,
  `arrival_notes` text COLLATE utf8mb4_unicode_ci,
  `send_off_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_work_order_visit_number` (`work_order_id`,`visit_number`),
  KEY `idx_department_visit_status` (`department_id`,`visit_status`),
  KEY `idx_work_order_visit_arrival` (`work_order_id`,`arrived_at`),
  KEY `fk_department_visit_arrived_by` (`arrived_by_employee_id`),
  KEY `fk_department_visit_sent_off_by` (`sent_off_by_employee_id`),
  CONSTRAINT `fk_department_visit_arrived_by` FOREIGN KEY (`arrived_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_department_visit_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `fk_department_visit_sent_off_by` FOREIGN KEY (`sent_off_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_department_visit_work_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_order_dependencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_dependencies` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `depends_on_work_order_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_work_order_dependency` (`work_order_id`,`depends_on_work_order_id`),
  KEY `fk_dependency_previous_order` (`depends_on_work_order_id`),
  CONSTRAINT `fk_dependency_previous_order` FOREIGN KEY (`depends_on_work_order_id`) REFERENCES `work_orders` (`id`),
  CONSTRAINT `fk_dependency_work_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`),
  CONSTRAINT `chk_no_self_dependency` CHECK ((`work_order_id` <> `depends_on_work_order_id`))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_order_evidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_evidence` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `media_file_id` bigint NOT NULL,
  `evidence_requirement_id` bigint DEFAULT NULL,
  `evidence_type` enum('BEFORE','DURING','AFTER','REPLACED_PART','TEST_RESULT','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploaded_by_employee_id` bigint NOT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci,
  `captured_at` datetime DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_work_order_media` (`work_order_id`,`media_file_id`),
  KEY `fk_work_evidence_media` (`media_file_id`),
  KEY `fk_work_evidence_requirement` (`evidence_requirement_id`),
  KEY `fk_work_evidence_employee` (`uploaded_by_employee_id`),
  KEY `idx_work_evidence_order` (`work_order_id`),
  CONSTRAINT `fk_work_evidence_employee` FOREIGN KEY (`uploaded_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_work_evidence_media` FOREIGN KEY (`media_file_id`) REFERENCES `media_files` (`id`),
  CONSTRAINT `fk_work_evidence_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`),
  CONSTRAINT `fk_work_evidence_requirement` FOREIGN KEY (`evidence_requirement_id`) REFERENCES `work_order_evidence_requirements` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_order_evidence_requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_evidence_requirements` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `department_id` bigint NOT NULL,
  `work_category` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `evidence_type` enum('BEFORE','DURING','AFTER','REPLACED_PART','TEST_RESULT','OTHER') COLLATE utf8mb4_unicode_ci NOT NULL,
  `requirement_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minimum_photo_count` int DEFAULT '1',
  `is_mandatory` tinyint(1) DEFAULT '1',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_evidence_requirement_department` (`department_id`,`work_category`),
  CONSTRAINT `fk_evidence_requirement_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_order_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_reminders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `employee_id` bigint DEFAULT NULL,
  `reminder_type` enum('WAITING','PAUSED','STAGNANT','ESCALATION') COLLATE utf8mb4_unicode_ci NOT NULL,
  `escalation_level` int NOT NULL DEFAULT '0',
  `priority` enum('LOW','NORMAL','HIGH','URGENT') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'NORMAL',
  `reminder_message` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `acknowledged_at` datetime DEFAULT NULL,
  `acknowledged_by_employee_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reminder_work_order` (`work_order_id`,`sent_at`),
  KEY `idx_reminder_employee` (`employee_id`,`acknowledged_at`),
  KEY `fk_reminder_ack_employee` (`acknowledged_by_employee_id`),
  CONSTRAINT `fk_reminder_ack_employee` FOREIGN KEY (`acknowledged_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_reminder_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_reminder_work_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_order_status_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_order_status_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `previous_status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `changed_by_employee_id` bigint DEFAULT NULL,
  `change_reason` text COLLATE utf8mb4_unicode_ci,
  `changed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_work_status_employee` (`changed_by_employee_id`),
  KEY `idx_work_status_history_order` (`work_order_id`,`changed_at`),
  CONSTRAINT `fk_work_status_employee` FOREIGN KEY (`changed_by_employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_work_status_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repair_plan_id` bigint NOT NULL,
  `job_id` bigint NOT NULL,
  `department_id` bigint NOT NULL,
  `work_order_number` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence_number` int DEFAULT NULL,
  `task_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `work_description` text COLLATE utf8mb4_unicode_ci,
  `work_instructions` text COLLATE utf8mb4_unicode_ci,
  `assigned_foreman_id` bigint DEFAULT NULL,
  `work_order_status` enum('BLOCKED','READY','ASSIGNED','IN_PROGRESS','WAITING','PAUSED','AWAITING_CONFIRMATION','COMPLETED','REJECTED','CANCELLED') COLLATE utf8mb4_unicode_ci DEFAULT 'BLOCKED',
  `priority` enum('LOW','NORMAL','HIGH','URGENT') COLLATE utf8mb4_unicode_ci DEFAULT 'NORMAL',
  `estimated_hours` decimal(8,2) DEFAULT NULL,
  `actual_hours` decimal(8,2) DEFAULT '0.00',
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `completion_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_work_order_number` (`work_order_number`),
  KEY `fk_work_order_plan` (`repair_plan_id`),
  KEY `fk_work_order_foreman` (`assigned_foreman_id`),
  KEY `idx_work_order_job` (`job_id`),
  KEY `idx_work_order_department_status` (`department_id`,`work_order_status`),
  CONSTRAINT `fk_work_order_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `fk_work_order_foreman` FOREIGN KEY (`assigned_foreman_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_work_order_job` FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`),
  CONSTRAINT `fk_work_order_plan` FOREIGN KEY (`repair_plan_id`) REFERENCES `repair_plans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `work_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `work_sessions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `work_order_id` bigint NOT NULL,
  `employee_id` bigint NOT NULL,
  `session_status` enum('RUNNING','PAUSED','COMPLETED') COLLATE utf8mb4_unicode_ci DEFAULT 'RUNNING',
  `started_at` datetime NOT NULL,
  `ended_at` datetime DEFAULT NULL,
  `duration_minutes` int DEFAULT '0',
  `session_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_work_session_order` (`work_order_id`),
  KEY `idx_work_session_employee` (`employee_id`),
  CONSTRAINT `fk_work_session_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`),
  CONSTRAINT `fk_work_session_order` FOREIGN KEY (`work_order_id`) REFERENCES `work_orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `workshop_escalation_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workshop_escalation_rules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `workshop_id` bigint NOT NULL,
  `escalation_level` int NOT NULL,
  `elapsed_minutes` int NOT NULL,
  `priority` enum('LOW','NORMAL','HIGH','URGENT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `notify_manager` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_escalation_level` (`workshop_id`,`escalation_level`),
  CONSTRAINT `fk_escalation_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`),
  CONSTRAINT `chk_escalation_minutes` CHECK ((`elapsed_minutes` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `workshop_monitoring_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workshop_monitoring_settings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `workshop_id` bigint NOT NULL,
  `working_days` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MON,TUE,WED,THU,FRI',
  `opening_time` time NOT NULL DEFAULT '08:00:00',
  `closing_time` time NOT NULL DEFAULT '17:00:00',
  `stagnation_threshold_minutes` int NOT NULL DEFAULT '120',
  `waiting_reminder_minutes` int NOT NULL DEFAULT '60',
  `paused_reminder_minutes` int NOT NULL DEFAULT '60',
  `reminder_repeat_minutes` int NOT NULL DEFAULT '60',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_monitoring_workshop` (`workshop_id`),
  CONSTRAINT `fk_monitoring_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `workshops` (`id`),
  CONSTRAINT `chk_monitoring_reminders` CHECK (((`waiting_reminder_minutes` > 0) and (`paused_reminder_minutes` > 0) and (`reminder_repeat_minutes` > 0))),
  CONSTRAINT `chk_monitoring_threshold` CHECK ((`stagnation_threshold_minutes` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `workshops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workshops` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `company_id` bigint NOT NULL,
  `workshop_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workshop_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_workshop_code` (`company_id`,`workshop_code`),
  KEY `idx_workshop_company` (`company_id`),
  CONSTRAINT `fk_workshop_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `repair_plan_department_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_plan_department_routes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `repair_plan_id` bigint NOT NULL,
  `department_id` bigint NOT NULL,
  `sequence_number` int NOT NULL,
  `applicability` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `not_applicable_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_repair_plan_department` (`repair_plan_id`,`department_id`),
  UNIQUE KEY `uk_repair_plan_sequence` (`repair_plan_id`,`sequence_number`),
  CONSTRAINT `chk_repair_route_applicability` CHECK ((`applicability` in (_utf8mb4'REQUIRED',_utf8mb4'NOT_APPLICABLE'))),
  CONSTRAINT `chk_repair_route_na_reason` CHECK ((`applicability` <> _utf8mb4'NOT_APPLICABLE') or ((`not_applicable_reason` is not null) and (char_length(trim(`not_applicable_reason`)) > 0))),
  CONSTRAINT `fk_repair_route_plan` FOREIGN KEY (`repair_plan_id`) REFERENCES `repair_plans` (`id`),
  CONSTRAINT `fk_repair_route_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

