# Workshop Management System — Workflow Architecture

This folder contains the agreed architecture models, ordered by the workshop process designed so far. The current design covers intake through final inspection and sign-off. Invoicing and vehicle release are the remaining stages to design.

## Workflow order

1. [Vehicle inventory / intake](stage-1-vehicle-intake.svg)
2. Quotation management
3. Customer authorization record and check
4. Job card and department routing
5. Parts availability, purchase, and receiving
6. Dispatch order and manager approval
7. Department work progress and stagnant-job monitoring
8. Final inspection and sign-off

See [workflow-overview.svg](workflow-overview.svg) for the visual sequence. The initial [Stage 1 intake model](stage-1-vehicle-intake.svg) is also available on its own.

Individual stage diagrams:

- [Stage 2 — Quotation management](stage-2-quotation.svg)
- [Stage 3 — Customer authorization check](stage-3-customer-authorization.svg)
- [Stage 4 — Job card and department routing](stage-4-job-card-routing.svg)
- [Stage 5 — Parts availability and procurement](stage-5-parts-availability.svg)
- [Stage 6 — Dispatch order and approval](stage-6-dispatch-approval.svg)
- [Stage 7 — Department progress and monitoring](stage-7-department-progress.svg)
- [Stage 8 — Final inspection and sign-off](stage-8-inspection-signoff.svg)

## Stage 1 — Vehicle inventory / intake

Intake is the vehicle inventory record created when the vehicle arrives. Staff find or create the customer and vehicle, assign a job number, and record arrival date/time, owner, driver, delivering person's name and phone number, mileage and fuel in, accessories and additional items, visible damage, remarks, photos, requested work, and the staff member who received and checked the vehicle.

The customer accepts the paper-form terms once at intake. An intake may be saved as a draft, but cannot be submitted until required details and customer acceptance are complete. Mileage/fuel out, collection, and release details are captured later.

## Stage 2 — Quotation management

Each quotation is linked to the workshop job and has its own quote number and date. A job may have multiple quotations, including later quotations for additional parts or costs. An issued quotation is preserved as a snapshot; changes are traceable and do not silently overwrite the issued copy.

Quotation fields follow the supplied form: bill-to/customer, ship-to/vehicle, salesperson or preparer, quantity, item, description, unit price, line total, subtotal, configured tax, total, prepared-by details, and issued document. Suggested statuses are Draft, Issued, Superseded, and Cancelled. Customer approval is not required for each quotation under the agreed paper-form authorization policy.

## Stage 3 — Customer authorization record and check

Customer authorization is captured once on the intake using the paper-form terms. The record links to the intake and retains the accepting person, acceptance time and method, terms version, recording staff member, and signed-form evidence.

Before the job proceeds, the system verifies that the intake has a complete authorization record. This is a check of the existing authorization, not a new approval request for each quotation. Staff identities and actions remain individually authenticated and auditable.

## Stage 4 — Job card and department routing

The foreman creates the job card from the submitted intake, records repair instructions and quotation references, defines the required work, and plans the department route. Departments are Electrical, Mechanic, Fitting, Panel Beating, Sanding, and Painting. Each department remains visible in the plan. A department that is not required is marked Not Applicable with a reason.

For each required department, assign a specialist/responsible person and record the sequence. Department statuses are Not Started, In Progress, Waiting, Paused, Complete, and Not Applicable. The job card’s part requirements feed the stock availability check in Stage 5.

## Stage 5 — Parts availability, outside purchase, and receiving

The foreman checks the job-card part requirements against available stock. Availability uses on-hand stock less quantities reserved for other jobs. If stock is short, create an outside-purchase request for the missing quantities. When parts arrive, Stores checks the delivery, records received quantities and discrepancies, and adds accepted quantities to stock before they are dispatched.

For partial availability, the recommended behavior is to split the requirement: available quantities can proceed to dispatch while only the shortage is purchased. The user can choose to require the full set before any dispatch if that better matches workshop practice.

## Stage 6 — Dispatch order and approval

The foreman creates a dispatch order linked to the job card, vehicle, parts, quantities, assigned mechanic, foreman, and date. The order is submitted to a manager or boss for approval. A rejected order is returned for correction with a reason. If an approved order’s items or quantities change, the revised order must be approved again.

Stores may issue parts only after approval. On issue, record quantities, issuing staff member, recipient/assigned mechanic, date/time, and any recipient acknowledgement; then reduce available stock. Track when the dispatch order reaches Accounts, including received date/time and the Accounts staff member or signature confirming receipt. The customer signature on the paper dispatch form, if retained, is treated as receipt acknowledgement rather than another customer work authorization.

## Stage 7 — Department workflow and stagnant-job monitoring

On department arrival, record the vehicle’s arrival date/time, assigned person, and current location. Record work start, pause/resume, completion notes, and send-off date/time. The current department is the latest department entered without a send-off. If the vehicle is waiting outside a department, show that waiting state/location explicitly.

When work is not active, staff mark Waiting or Paused with a reason. The system also detects inactivity after a configurable period. It reminds the assigned person and raises priority as stagnation continues, with configurable escalation to supervisors. Use workshop working hours for elapsed-time rules and keep reminder and status history on the job card.

Managers and the boss can monitor all open vehicles, current department and assignee, time in department and total workshop time, waiting/paused/stagnant status, reminder priority, department timeline, Not Applicable reasons, and remaining work. All changes and approvals are timestamped and attributed to individual staff accounts.

## Stage 8 — Final inspection and sign-off

Start the collection checklist when all required job-card work is reported complete. Link it to the vehicle, job number, and date. Preserve the 25 inspection rows from the supplied form; each row has a Done result and comments. Record the inspector and completion time for each entry. The rows cover job-card work completion, road test, tyres and brakes, fluids and battery, inventory/accessories, washer and spray equipment, warning lights and other electrical functions, body parts, reflectors/licence discs, underbody, cleanliness, and paint condition. Confirm the unclear final printed checklist label against the original before loading it into the system.

Capture the mechanic and other discipline sign-offs shown on the form, with the staff member and signature or authenticated confirmation for each required role. A failed or incomplete check needs a comment and returns the vehicle to the responsible department; after rework, repeat the affected checks and obtain the relevant sign-off again. The checklist passes only when every applicable check is done, comments explain any exception, and required discipline sign-offs are complete. Retain a timestamped inspection history.

The paper form also has Collected By and Released By fields. Capture those as part of the later customer handover/release step, together with collection date/time and identity; passing inspection makes the vehicle ready for that step, but does not itself record collection.

## Core authorization and inventory controls

- Customer work authorization is recorded once at intake from the paper-form terms; no customer approval is required for every quotation.
- Staff use individual authenticated accounts; foremen prepare dispatch orders and managers/bosses approve them.
- Stores issues parts only against an approved dispatch order.
- Stock is reduced on issue, not when a dispatch order is drafted or approved.
- Submitted intake records, issued quotations, approvals, and stock movements retain an audit history.
