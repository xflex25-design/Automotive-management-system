# Backend and database setup

## Fresh database

1. Create an empty MySQL database named `auto_db` (or set `DB_URL` to another database).
2. Configure the database and web app environment variables before starting Spring Boot:

   ```powershell
   $env:DB_URL = 'jdbc:mysql://localhost:3307/auto_db?createDatabaseIfNotExist=false&useSSL=false&serverTimezone=Africa/Lusaka'
   $env:DB_USERNAME = 'automotive_app'
   $env:DB_PASSWORD = '<database password>'
   $env:FRONTEND_ORIGINS = 'http://localhost:3000'
   ```

3. Start the backend. Flyway creates the schema in order from `V1__baseline_schema.sql` through `V14__seed_workshop_departments.sql`. Migration V14 provisions Electrical, Mechanic, Fitting, Panel Beating, Sanding, and Painting for each active workshop. Hibernate validates the migrated schema; it does not create tables.

For production, create a separate migration account and set `DB_MIGRATION_USERNAME` and `DB_MIGRATION_PASSWORD`. The application account should have only the data access privileges it needs. Keep credentials in environment configuration or a secret store, not in tracked files.

## Existing database imports

Do not import `database/auto_db_full_schema.sql` before running Flyway on a fresh database. The full schema file is a snapshot of the V13 schema, while Flyway migrations are the canonical fresh-install path.

If you intentionally import the full schema snapshot into an empty database, it contains the V13 tables and role catalog. On its first application startup only, baseline at version `13` so Flyway applies V14 and seeds departments. Set:

```powershell
$env:FLYWAY_BASELINE_ON_MIGRATE = 'true'
$env:FLYWAY_BASELINE_VERSION = '13'
```

Then remove `FLYWAY_BASELINE_ON_MIGRATE` and `FLYWAY_BASELINE_VERSION` from the environment for normal restarts.

If an existing database was imported from the historical V1 schema without a `flyway_schema_history` table, baseline it at version `1` for its first startup; Flyway then applies V2 through V14. For any other existing schema, determine its actual migration level before baselining. Never choose a baseline version merely to bypass a migration error; that can leave the schema incompatible with the application.

## Authentication

API requests use HTTP Basic authentication with the user's email and password. `GET /api/auth/me` returns the authenticated account's user, employee, company, workshop, display name, and authority list. Existing `users.password_hash` values must be BCrypt hashes (`$2a$`, `$2b$`, or `$2y$` formats); plaintext passwords are rejected. Migration V12 seeds the role catalog but does not assign user roles. Assign role rows through `user_roles`; dispatch approval requires `Manager` or `Boss`. An active employee account must be linked to its employee record to perform employee actions.

Set `FRONTEND_ORIGINS` to a comma-separated allowlist of exact browser origins. Basic authentication sends credentials only over HTTPS outside local development.
