# Stage 5 Parts Availability and Procurement API

These endpoints implement the Stage 5 workflow against the MySQL `auto_db` schema. The job-card part lines must be linked to the company's stock catalogue before availability can be checked. Existing rows are linked automatically by the V2 migration when `job_card_parts.part_number` matches `parts.part_code`.

## Database migration

Flyway applies `src/main/resources/db/migration/V2__stage_5_parts_procurement_and_receiving.sql` when the backend starts. The existing baseline schema must already be installed. The migration adds the job-card-to-catalogue link and receipt/discrepancy records. Accepted quantities increase stock; rejected quantities remain out of stock and require a discrepancy note.

## Endpoints

### Check stock for the job card

`GET /api/job-cards/{jobCardId}/parts/availability`

Returns one entry per catalogue part, with its linked job-card line IDs, total required quantity, on-hand quantity, total reserved quantity, available quantity, shortage, and `AVAILABLE`, `PARTIAL`, or `UNAVAILABLE`. Available stock is calculated across active stock locations in that workshop as `on hand - reserved`.

If a job-card line has no catalogue link, the endpoint returns a validation error. Link it first:

`PATCH /api/job-cards/{jobCardId}/parts/{jobCardPartId}/catalog-part`

```json
{
  "partId": 17,
  "linkedByEmployeeId": 4
}
```

### Submit an outside-purchase requisition

`POST /api/jobs/{jobId}/parts/requisitions`

The service rechecks stock in a transaction and creates requisition lines for the shortage quantities only. If no shortage remains, it returns `409 Conflict`.

```json
{
  "requestedByEmployeeId": 4,
  "priority": "NORMAL",
  "requiredDate": "2026-11-20",
  "purpose": "Parts shortage for job card"
}
```

### Record an order placed with a supplier

`POST /api/parts/requisitions/{requisitionId}/purchase-orders`

The order can cover all or part of the remaining requisition quantity. It is saved as `SENT_TO_SUPPLIER` and can be received in multiple deliveries.

```json
{
  "supplierId": 2,
  "createdByEmployeeId": 4,
  "expectedDeliveryDate": "2026-11-20",
  "supplierReference": "SUP-PO-0091",
  "items": [
    {
      "requisitionItemId": 31,
      "quantityOrdered": 2,
      "unitPrice": 250.00,
      "taxAmount": 0.00
    }
  ]
}
```

### Receive a delivery into Stores

`POST /api/parts/purchase-orders/{purchaseOrderId}/receipts`

Accepted quantity is added to the selected stock location and written as a `PURCHASE_RECEIPT` stock movement in the same transaction. Delivered-but-rejected quantity is recorded separately and requires a discrepancy note. Repeated receipts support partial deliveries and supplier replacement of rejected parts.

```json
{
  "receivedByEmployeeId": 8,
  "stockLocationId": 1,
  "supplierDeliveryReference": "DEL-4398",
  "items": [
    {
      "purchaseOrderItemId": 52,
      "quantityDelivered": 2,
      "quantityAccepted": 1,
      "unitCost": 250.00,
      "discrepancyNotes": "One item damaged on arrival"
    }
  ]
}
```

## Workflow notes

- A requisition is created only for shortages; available quantities remain eligible for the later dispatch stage.
- Availability is rechecked when a requisition is submitted. This stage reports and requests shortages but does not reserve available stock; dispatch must recheck stock before issue.
- Employee IDs are validated against the job's company and workshop and the employee must be active. Runtime authentication and role enforcement are not yet configured in the existing backend, so these APIs must not be exposed to untrusted clients until that is addressed.
