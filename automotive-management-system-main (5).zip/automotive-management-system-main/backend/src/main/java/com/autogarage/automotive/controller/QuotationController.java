package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.CreateQuotationRequest;
import com.autogarage.automotive.dto.QuotationResponse;
import com.autogarage.automotive.entity.Quotation;
import com.autogarage.automotive.service.QuotationService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class QuotationController {

    private final QuotationService quotationService;

    public QuotationController(QuotationService quotationService) {
        this.quotationService = quotationService;
    }

    @PostMapping("/jobs/{jobId}/quotations")
    public ResponseEntity<QuotationResponse> createDraftQuotation(
            @PathVariable Long jobId,
            @Valid @RequestBody CreateQuotationRequest request
    ) {
        Quotation quotation =
                quotationService.createDraftQuotation(jobId, request);

        QuotationResponse response =
                quotationService.getQuotationDetails(quotation.getId());

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping("/jobs/{jobId}/quotations")
    public ResponseEntity<List<QuotationResponse>> getJobQuotations(
            @PathVariable Long jobId
    ) {
        return ResponseEntity.ok(
                quotationService.getJobQuotations(jobId)
        );
    }

    @PutMapping("/quotations/{quotationId}/issue")
        public ResponseEntity<QuotationResponse> issueQuotation(
                @PathVariable Long quotationId
        ) {
        Quotation quotation =
                quotationService.issueQuotation(quotationId);

        return ResponseEntity.ok(
                quotationService.getQuotationDetails(quotation.getId())
        );
        }

    @GetMapping("/quotations/{quotationId}")
    public ResponseEntity<QuotationResponse> getQuotation(
            @PathVariable Long quotationId
    ) {
        return ResponseEntity.ok(
                quotationService.getQuotationDetails(quotationId)
        );
    }
}