
package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "jobs")
public class Job {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "workshop_id", nullable = false)
    private Workshop workshop;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;

    @Column(name = "job_number", nullable = false, unique = true, length = 50)
    private String jobNumber;

    @Column(name = "customer_name_snapshot", nullable = false, length = 200)
    private String customerNameSnapshot;

    @Column(name = "vehicle_registration_snapshot", nullable = false, length = 30)
    private String vehicleRegistrationSnapshot;

    @Column(name = "vehicle_make_snapshot", nullable = false, length = 100)
    private String vehicleMakeSnapshot;

    @Column(name = "vehicle_type_snapshot", length = 100)
    private String vehicleTypeSnapshot;

    @Column(name = "brought_in_by_name", length = 200)
    private String broughtInByName;

    @Column(name = "brought_in_by_phone", length = 30)
    private String broughtInByPhone;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "received_by_employee_id")
    private Employee receivedBy;

    @Column(name = "job_type", nullable = false, length = 50)
    private String jobType = "REPAIR";

    @Column(nullable = false, length = 30)
    private String priority = "NORMAL";

    @Column(name = "job_status", nullable = false, length = 40)
    private String jobStatus = "RECEIVED";

    @Column(name = "reported_problem", columnDefinition = "TEXT")
    private String reportedProblem;

    @Column(name = "internal_notes", columnDefinition = "TEXT")
    private String internalNotes;

    @Column(name = "date_received", nullable = false)
    private LocalDateTime dateReceived;

    @Column(name = "estimated_completion_date")
    private LocalDateTime estimatedCompletionDate;

    @Column(name = "actual_completion_date")
    private LocalDateTime actualCompletionDate;

    @Column(name = "vehicle_released_at")
    private LocalDateTime vehicleReleasedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "created_by_user_id", nullable = false)
    private User createdBy;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;

    public Job() {}

    public Long getId() {
        return id;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Workshop getWorkshop() {
        return workshop;
    }

    public void setWorkshop(Workshop workshop) {
        this.workshop = workshop;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public String getJobNumber() {
        return jobNumber;
    }

    public void setJobNumber(String jobNumber) {
        this.jobNumber = jobNumber;
    }

    public String getCustomerNameSnapshot() {
        return customerNameSnapshot;
    }

    public void setCustomerNameSnapshot(String customerNameSnapshot) {
        this.customerNameSnapshot = customerNameSnapshot;
    }

    public String getVehicleRegistrationSnapshot() {
        return vehicleRegistrationSnapshot;
    }

    public void setVehicleRegistrationSnapshot(String vehicleRegistrationSnapshot) {
        this.vehicleRegistrationSnapshot = vehicleRegistrationSnapshot;
    }

    public String getVehicleMakeSnapshot() {
        return vehicleMakeSnapshot;
    }

    public void setVehicleMakeSnapshot(String vehicleMakeSnapshot) {
        this.vehicleMakeSnapshot = vehicleMakeSnapshot;
    }

    public String getVehicleTypeSnapshot() {
        return vehicleTypeSnapshot;
    }

    public void setVehicleTypeSnapshot(String vehicleTypeSnapshot) {
        this.vehicleTypeSnapshot = vehicleTypeSnapshot;
    }

    public String getBroughtInByName() {
        return broughtInByName;
    }

    public void setBroughtInByName(String broughtInByName) {
        this.broughtInByName = broughtInByName;
    }

    public String getBroughtInByPhone() {
        return broughtInByPhone;
    }

    public void setBroughtInByPhone(String broughtInByPhone) {
        this.broughtInByPhone = broughtInByPhone;
    }

    public Employee getReceivedBy() {
        return receivedBy;
    }

    public void setReceivedBy(Employee receivedBy) {
        this.receivedBy = receivedBy;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getJobStatus() {
        return jobStatus;
    }

    public void setJobStatus(String jobStatus) {
        this.jobStatus = jobStatus;
    }

    public String getReportedProblem() {
        return reportedProblem;
    }

    public void setReportedProblem(String reportedProblem) {
        this.reportedProblem = reportedProblem;
    }

    public String getInternalNotes() {
        return internalNotes;
    }

    public void setInternalNotes(String internalNotes) {
        this.internalNotes = internalNotes;
    }

    public LocalDateTime getDateReceived() {
        return dateReceived;
    }

    public void setDateReceived(LocalDateTime dateReceived) {
        this.dateReceived = dateReceived;
    }

    public LocalDateTime getEstimatedCompletionDate() {
        return estimatedCompletionDate;
    }

    public void setEstimatedCompletionDate(LocalDateTime estimatedCompletionDate) {
        this.estimatedCompletionDate = estimatedCompletionDate;
    }

    public LocalDateTime getActualCompletionDate() {
        return actualCompletionDate;
    }

    public void setActualCompletionDate(LocalDateTime actualCompletionDate) {
        this.actualCompletionDate = actualCompletionDate;
    }

    public LocalDateTime getVehicleReleasedAt() {
        return vehicleReleasedAt;
    }

    public void setVehicleReleasedAt(LocalDateTime vehicleReleasedAt) {
        this.vehicleReleasedAt = vehicleReleasedAt;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
