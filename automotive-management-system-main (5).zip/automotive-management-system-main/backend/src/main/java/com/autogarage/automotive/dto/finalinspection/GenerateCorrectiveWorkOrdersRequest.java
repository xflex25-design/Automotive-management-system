package com.autogarage.automotive.dto.finalinspection;

public record GenerateCorrectiveWorkOrdersRequest(
        Long employeeId
) {}