package com.autogarage.automotive.controller;

import com.autogarage.automotive.security.WorkshopPrincipal;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @GetMapping("/me")
    public Map<String, Object> currentUser(
            @AuthenticationPrincipal WorkshopPrincipal principal
    ) {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("userId", principal.userId());
        response.put("employeeId", principal.employeeId());
        response.put("companyId", principal.companyId());
        response.put("workshopId", principal.workshopId());
        response.put("displayName", principal.displayName());
        response.put("authorities", principal.getAuthorities().stream()
                .map(authority -> authority.getAuthority())
                .toList());
        return response;
    }
}
