package com.autogarage.automotive.dto.handover;

import java.time.LocalDateTime;

public record VehicleHandoverResponse(
    Long id,
    String handoverNumber,

    Long jobId,
    String jobNumber,

    Long vehicleId,
    String vehicleRegistration,
    String vehicleMake,
    String vehicleModel,

    Long invoiceId,
    String invoiceNumber,

    Long finalInspectionId,

    String collectorName,
    String collectorPhone,
    String collectorIdType,
    String collectorIdNumber,
    String collectorRelationship,
    Boolean customerCollected,

    Boolean keysHandedOver,
    Boolean documentsHandedOver,
    String vehicleConditionAtRelease,

    Boolean customerAcknowledged,
    String acknowledgementText,
    Boolean hasCollectorSignature,

    Long releasedByEmployeeId,
    LocalDateTime releasedAt,
    String notes
) {}