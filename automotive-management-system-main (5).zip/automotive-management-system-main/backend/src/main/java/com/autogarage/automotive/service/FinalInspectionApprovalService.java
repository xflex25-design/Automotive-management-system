package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.finalinspection.DepartmentSignoffRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class FinalInspectionApprovalService {

    private final FinalInspectionRepository inspectionRepository;
    private final FinalInspectionItemRepository itemRepository;
    private final FinalInspectionSignoffRepository signoffRepository;
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final JobRepository jobRepository;

    public FinalInspectionApprovalService(
            FinalInspectionRepository inspectionRepository,
            FinalInspectionItemRepository itemRepository,
            FinalInspectionSignoffRepository signoffRepository,
            EmployeeRepository employeeRepository,
            DepartmentRepository departmentRepository,
            JobRepository jobRepository
    ) {
        this.inspectionRepository = inspectionRepository;
        this.itemRepository = itemRepository;
        this.signoffRepository = signoffRepository;
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
        this.jobRepository = jobRepository;
    }

    @Transactional
    public Map<String, Object> submitDepartmentSignoff(
            Long inspectionId,
            Long departmentId,
            DepartmentSignoffRequest request
    ) {
        ActorIdentity.requireEmployee(request == null ? null : request.employeeId());
        if (request == null || request.employeeId() == null
                || request.signoffStatus() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Employee ID and sign-off status are required."
            );
        }

        FinalInspection inspection = getInspectionEntity(inspectionId);
        ensureInspectionEditable(inspection);

        Job job = inspection.getJob();

        Employee employee = employeeRepository.findByIdAndCompanyId(
                request.employeeId(),
                job.getCompany().getId()
        ).orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND,
                "Employee not found in this company."
        ));

        if (!"ACTIVE".equalsIgnoreCase(employee.getEmploymentStatus())
                || !Objects.equals(
                        employee.getWorkshop().getId(),
                        job.getWorkshop().getId()
                )) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Employee must be active and belong to this workshop."
            );
        }

        Department department = departmentRepository.findById(departmentId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Department not found."
                ));

        if (!Boolean.TRUE.equals(department.getActive())
                || !Objects.equals(
                        department.getCompany().getId(),
                        job.getCompany().getId()
                )
                || !Objects.equals(
                        department.getWorkshop().getId(),
                        job.getWorkshop().getId()
                )) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Department does not belong to this active workshop."
            );
        }

        FinalInspectionSignoff signoff = signoffRepository
                .findByFinalInspection_IdAndDepartment_Id(
                        inspectionId,
                        departmentId
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "This department is not required to sign off this inspection."
                ));

        String status = request.signoffStatus().trim().toUpperCase();

        if (!List.of("SIGNED", "REJECTED").contains(status)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Sign-off status must be SIGNED or REJECTED."
            );
        }

        signoff.setSignedBy(employee);
        signoff.setSignoffStatus(status);
        signoff.setSignoffNotes(request.signoffNotes());
        signoff.setSignedAt(LocalDateTime.now());

        signoffRepository.save(signoff);

        return getSignoffs(inspectionId);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getSignoffs(Long inspectionId) {
        FinalInspection inspection = getInspectionEntity(inspectionId);

        List<Map<String, Object>> signoffs = signoffRepository
                .findByFinalInspection_IdOrderByDepartment_DepartmentNameAsc(
                        inspectionId
                )
                .stream()
                .map(this::mapSignoff)
                .toList();

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("inspectionId", inspectionId);
        response.put("inspectionNumber", inspection.getInspectionNumber());
        response.put("totalDepartments", signoffs.size());
        response.put("signedDepartments", signoffs.stream()
                .filter(s -> "SIGNED".equals(s.get("signoffStatus")))
                .count());
        response.put("rejectedDepartments", signoffs.stream()
                .filter(s -> "REJECTED".equals(s.get("signoffStatus")))
                .count());
        response.put("pendingDepartments", signoffs.stream()
                .filter(s -> "PENDING".equals(s.get("signoffStatus")))
                .count());
        response.put("signoffs", signoffs);

        return response;
    }

    @Transactional
    public Map<String, Object> completeInspection(Long inspectionId) {
        FinalInspection inspection = getInspectionEntity(inspectionId);
        ensureInspectionEditable(inspection);

        List<FinalInspectionItem> items =
                itemRepository.findByFinalInspection_IdOrderByIdAsc(
                        inspectionId
                );

        List<FinalInspectionSignoff> signoffs =
                signoffRepository
                        .findByFinalInspection_IdOrderByDepartment_DepartmentNameAsc(
                                inspectionId
                        );

        long pendingChecks = items.stream()
                .filter(i -> "PENDING".equalsIgnoreCase(i.getCheckStatus()))
                .count();

        long failedChecks = items.stream()
                .filter(i -> "FAIL".equalsIgnoreCase(i.getCheckStatus()))
                .count();

        long pendingSignoffs = signoffs.stream()
                .filter(s -> "PENDING".equalsIgnoreCase(s.getSignoffStatus()))
                .count();

        long rejectedSignoffs = signoffs.stream()
                .filter(s -> "REJECTED".equalsIgnoreCase(s.getSignoffStatus()))
                .count();

        if (items.size() != 25) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "The final inspection must contain all 25 checklist items."
            );
        }

        if (pendingChecks > 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    pendingChecks + " checklist item(s) are still pending."
            );
        }

        if (pendingSignoffs > 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    pendingSignoffs + " department sign-off(s) are still pending."
            );
        }

        if (signoffs.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "No department sign-offs were generated for this inspection."
            );
        }

        LocalDateTime completedAt = LocalDateTime.now();
        Job job = inspection.getJob();

        if (failedChecks > 0 || rejectedSignoffs > 0) {
            inspection.setInspectionDecision("FAIL");
            inspection.setInspectionStatus("FAILED");
            inspection.setCompletedAt(completedAt);

            job.setJobStatus("FINAL_INSPECTION_FAILED");

            inspectionRepository.save(inspection);
            jobRepository.save(job);

            return buildCompletionResponse(
                    inspection,
                    "FAIL",
                    failedChecks,
                    rejectedSignoffs
            );
        }

        inspection.setInspectionDecision("PASS");
        inspection.setInspectionStatus("COMPLETED");
        inspection.setCompletedAt(completedAt);

        job.setJobStatus("READY_FOR_INVOICING");

        inspectionRepository.save(inspection);
        jobRepository.save(job);

        return buildCompletionResponse(
                inspection,
                "PASS",
                0,
                0
        );
    }

    private FinalInspection getInspectionEntity(Long inspectionId) {
        FinalInspection inspection = inspectionRepository.findById(inspectionId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Final inspection not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                inspection.getJob().getCompany().getId(),
                inspection.getJob().getWorkshop().getId());
        return inspection;
    }

    private void ensureInspectionEditable(FinalInspection inspection) {
        if (!"IN_PROGRESS".equalsIgnoreCase(
                inspection.getInspectionStatus()
        )) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "This final inspection is no longer in progress."
            );
        }
    }

    private Map<String, Object> mapSignoff(
            FinalInspectionSignoff signoff
    ) {
        Map<String, Object> result = new LinkedHashMap<>();

        result.put("id", signoff.getId());
        result.put("departmentId", signoff.getDepartment().getId());
        result.put("departmentName",
                signoff.getDepartment().getDepartmentName());
        result.put("signoffStatus", signoff.getSignoffStatus());
        result.put("signoffNotes", signoff.getSignoffNotes());
        result.put("signedAt", signoff.getSignedAt());

        Employee employee = signoff.getSignedBy();

        result.put("signedByEmployeeId",
                employee != null ? employee.getId() : null);

        result.put("signedByEmployeeName",
                employee != null
                        ? employee.getFirstName() + " " + employee.getLastName()
                        : null);

        return result;
    }

    private Map<String, Object> buildCompletionResponse(
            FinalInspection inspection,
            String decision,
            long failedChecks,
            long rejectedSignoffs
    ) {
        Map<String, Object> response = new LinkedHashMap<>();

        response.put("inspectionId", inspection.getId());
        response.put("inspectionNumber", inspection.getInspectionNumber());
        response.put("jobId", inspection.getJob().getId());
        response.put("jobNumber", inspection.getJob().getJobNumber());
        response.put("inspectionDecision", decision);
        response.put("inspectionStatus", inspection.getInspectionStatus());
        response.put("failedChecks", failedChecks);
        response.put("rejectedSignoffs", rejectedSignoffs);
        response.put("completedAt", inspection.getCompletedAt());
        response.put("jobStatus", inspection.getJob().getJobStatus());

        response.put(
                "message",
                "PASS".equals(decision)
                        ? "Final inspection passed. Vehicle is ready for invoicing."
                        : "Final inspection failed. Corrective work is required."
        );

        return response;
    }
}
