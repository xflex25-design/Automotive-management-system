package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "repair_plans")
@Getter
@Setter
@NoArgsConstructor
public class RepairPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false)
    private Job job;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_card_id", nullable = false)
    private JobCard jobCard;

    @Column(name = "plan_number", nullable = false, unique = true, length = 100)
    private String planNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "prepared_by_employee_id", nullable = false)
    private Employee preparedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "confirmed_by_employee_id")
    private Employee confirmedBy;

    @Column(
        name = "plan_status",
        columnDefinition = "ENUM('DRAFT','PENDING_CUSTOMER_APPROVAL','APPROVED','ACTIVE','COMPLETED','CANCELLED')"
    )
    private String planStatus = "DRAFT";

    @Column(name = "plan_notes", columnDefinition = "TEXT")
    private String planNotes;

    @Column(name = "confirmed_at")
    private LocalDateTime confirmedAt;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}