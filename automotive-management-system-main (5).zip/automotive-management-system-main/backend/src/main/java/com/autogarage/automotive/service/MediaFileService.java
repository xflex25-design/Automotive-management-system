
package com.autogarage.automotive.service;

import com.autogarage.automotive.entity.MediaFile;
import com.autogarage.automotive.entity.Job;
import com.autogarage.automotive.repository.JobRepository;
import com.autogarage.automotive.repository.MediaFileRepository;
import com.autogarage.automotive.security.ActorIdentity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class MediaFileService {

    private final MediaFileRepository mediaFileRepository;
    private final JobRepository jobRepository;

    @Value("${media.storage.location:uploads}")
    private String storageLocation;

    public MediaFileService(
            MediaFileRepository mediaFileRepository,
            JobRepository jobRepository) {
        this.mediaFileRepository = mediaFileRepository;
        this.jobRepository = jobRepository;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getJobMedia(Long jobId) {

        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Job not found."));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        return mediaFileRepository
                .findByJobIdOrderByUploadedAtDesc(jobId)
                .stream()
                .map(this::toMediaResponse)
                .toList();
    }

    private Map<String, Object> toMediaResponse(MediaFile media) {

        Map<String, Object> item = new LinkedHashMap<>();

        String category = "GENERAL";

        if (media.getWorkOrder() != null) {
            category = "DEPARTMENT_WORK";
        } else if (media.getDamageRecord() != null) {
            category = "INTAKE_DAMAGE";
        } else if (media.getInspection() != null) {
            category = "INTAKE_INSPECTION";
        }

        item.put("mediaFileId", media.getId());
        item.put("jobId", media.getJob().getId());
        item.put("category", category);
        item.put("workOrderId",
                media.getWorkOrder() == null ? null : media.getWorkOrder().getId());
        item.put("inspectionId",
                media.getInspection() == null ? null : media.getInspection().getId());
        item.put("damageRecordId",
                media.getDamageRecord() == null ? null : media.getDamageRecord().getId());
        item.put("evidenceType", media.getEvidenceType());
        item.put("fileName", media.getFileName());
        item.put("mimeType", media.getMimeType());
        item.put("fileSize", media.getFileSize());
        item.put("caption", media.getCaption());
        item.put("uploadedByEmployeeId", media.getUploadedBy().getId());
        item.put("uploadedAt", media.getUploadedAt());
        item.put("contentUrl", "/api/media/" + media.getId() + "/content");

        return item;
    }

    @Transactional(readOnly = true)
    public Resource getMediaContent(Long mediaFileId) {

        MediaFile media = mediaFileRepository.findById(mediaFileId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Media file not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                media.getJob().getCompany().getId(),
                media.getJob().getWorkshop().getId());

        try {
            Path root = Paths.get(storageLocation)
                    .toAbsolutePath()
                    .normalize()
                    .toRealPath();

            Path filePath = root.resolve(media.getStorageKey())
                    .normalize();

            if (!filePath.startsWith(root)) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Invalid media storage path."
                );
            }

            Path realFilePath = filePath.toRealPath();

            if (!realFilePath.startsWith(root)
                    || !Files.isRegularFile(realFilePath)
                    || !Files.isReadable(realFilePath)) {
                throw new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Media file is unavailable."
                );
            }

            Resource resource = new UrlResource(realFilePath.toUri());

            if (!resource.exists() || !resource.isReadable()) {
                throw new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Media file is unavailable."
                );
            }

            return resource;

        } catch (IOException exception) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Media file could not be accessed."
            );
        }
    }

    @Transactional(readOnly = true)
    public MediaFile getMediaRecord(Long mediaFileId) {

        MediaFile media = mediaFileRepository.findById(mediaFileId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Media file not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                media.getJob().getCompany().getId(),
                media.getJob().getWorkshop().getId());
        return media;
    }
}
