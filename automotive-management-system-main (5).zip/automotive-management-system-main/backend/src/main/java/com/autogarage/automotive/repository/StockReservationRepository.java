package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.StockReservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Lock;
import java.util.Optional;

import java.math.BigDecimal;
import java.util.List;

public interface StockReservationRepository
        extends JpaRepository<StockReservation, Long> {

    @Query("""
        select coalesce(sum(r.quantityReserved), 0)
        from StockReservation r
        where r.jobCardPart.id = :jobCardPartId
          and r.stockBalance.id = :stockBalanceId
          and r.reservationStatus = 'ACTIVE'
    """)
    BigDecimal sumActiveForJobPartAndBalance(
            @Param("jobCardPartId") Long jobCardPartId,
            @Param("stockBalanceId") Long stockBalanceId
    );

    @Query("""
        select coalesce(sum(r.quantityReserved), 0)
        from StockReservation r
        where r.jobCardPart.jobCard.id = :jobCardId
          and r.stockBalance.id = :stockBalanceId
          and r.reservationStatus = 'ACTIVE'
    """)
    BigDecimal sumActiveForJobCardAndBalance(
            @Param("jobCardId") Long jobCardId,
            @Param("stockBalanceId") Long stockBalanceId
    );

    @Query("""
        select coalesce(sum(r.quantityReserved), 0)
        from StockReservation r
        where r.jobCardPart.id = :jobCardPartId
        and r.reservationStatus = 'ACTIVE'
        """)
        BigDecimal sumActiveForJobPart(
                @Param("jobCardPartId") Long jobCardPartId
        );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
        @Query("""
        select r
        from StockReservation r
        where r.id = :reservationId
        """)
        Optional<StockReservation> findByIdForUpdate(
                @Param("reservationId") Long reservationId
        );

    List<StockReservation> findByJobCardPart_JobCard_IdAndReservationStatusOrderByIdAsc(
            Long jobCardId,
            String reservationStatus
    );

    List<StockReservation> findByJobCardPart_IdAndReservationStatusOrderByIdAsc(
            Long jobCardPartId,
            String reservationStatus
    );
}