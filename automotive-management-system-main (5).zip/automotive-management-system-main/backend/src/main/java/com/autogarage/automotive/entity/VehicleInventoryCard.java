package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "vehicle_inventory_cards")
@Getter
@Setter
@NoArgsConstructor
public class VehicleInventoryCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false, unique = true)
    private Job job;

    @Column(name = "job_number_snapshot", nullable = false, length = 50)
    private String jobNumberSnapshot;

    @Column(name = "registration_number_snapshot", nullable = false, length = 30)
    private String registrationNumberSnapshot;

    @Column(name = "make_snapshot", nullable = false, length = 100)
    private String makeSnapshot;

    @Column(name = "inventory_date", nullable = false)
    private LocalDate inventoryDate;

    @Column(name = "owned_by_snapshot", nullable = false, length = 200)
    private String ownedBySnapshot;

    @Column(name = "driver_name", length = 200)
    private String driverName;

    @Column(name = "driver_phone", length = 30)
    private String driverPhone;

    @Column(name = "odometer_reading_in", precision = 12, scale = 2)
    private BigDecimal odometerReadingIn;

    @Column(name = "odometer_reading_out", precision = 12, scale = 2)
    private BigDecimal odometerReadingOut;

    @Column(name = "fuel_level_in", length = 30)
    private String fuelLevelIn;

    @Column(name = "fuel_level_out", length = 30)
    private String fuelLevelOut;

    @Column(name = "number_of_keys_received")
    private Integer numberOfKeysReceived = 0;

    @Column(name = "work_requested", columnDefinition = "TEXT")
    private String workRequested;

    @Column(name = "customer_complaints", columnDefinition = "TEXT")
    private String customerComplaints;

    @Column(name = "general_remarks", columnDefinition = "TEXT")
    private String generalRemarks;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "received_by_employee_id")
    private Employee receivedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inspected_by_employee_id")
    private Employee inspectedBy;

    @Column(name = "intake_status", nullable = false, length = 30)
    private String intakeStatus = "DRAFT";

    @Column(name = "collection_date")
    private LocalDateTime collectionDate;

    @Column(name = "collected_by_name", length = 200)
    private String collectedByName;

    @Column(name = "collection_remarks", columnDefinition = "TEXT")
    private String collectionRemarks;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "inventoryCard", fetch = FetchType.LAZY)
    private List<MediaFile> mediaFiles = new ArrayList<>();
}