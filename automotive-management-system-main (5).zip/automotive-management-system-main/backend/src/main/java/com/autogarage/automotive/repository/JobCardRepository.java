package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.JobCard;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface JobCardRepository extends JpaRepository<JobCard, Long> {

    Optional<JobCard> findByJobId(Long jobId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select c from JobCard c where c.job.id = :jobId")
    Optional<JobCard> findByJobIdForUpdate(@Param("jobId") Long jobId);

    Optional<JobCard> findByJobCardNumber(String jobCardNumber);

    List<JobCard> findByJobCardStatusOrderByCreatedAtDesc(String status);

    List<JobCard> findByJob_Company_IdAndJob_Workshop_IdOrderByCreatedAtDesc(
            Long companyId, Long workshopId);

    boolean existsByJobId(Long jobId);
}
