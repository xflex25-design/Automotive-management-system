package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "inspection_records")
@Getter
@Setter
@NoArgsConstructor
public class InspectionRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false)
    private Job job;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inventory_card_id", nullable = false)
    private VehicleInventoryCard inventoryCard;

    @Column(name = "inspection_type", nullable = false, length = 50)
    private String inspectionType = "INITIAL";

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inspected_by_employee_id", nullable = false)
    private Employee inspectedBy;

    @Column(name = "inspection_date", insertable = false, updatable = false)
    private LocalDateTime inspectionDate;

    @Column(name = "overall_condition", columnDefinition = "TEXT")
    private String overallCondition;

    @Column(name = "inspection_notes", columnDefinition = "TEXT")
    private String inspectionNotes;

    @Column(name = "inspection_status", nullable = false, length = 30)
    private String inspectionStatus = "DRAFT";

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @OneToMany(mappedBy = "inspection", fetch = FetchType.LAZY)
    private List<MediaFile> mediaFiles = new ArrayList<>();

    @OneToMany(mappedBy = "inspection", fetch = FetchType.LAZY)
    private List<InspectionItem> inspectionItems = new ArrayList<>();

    @OneToMany(mappedBy = "inspection", fetch = FetchType.LAZY)
    private List<VehicleDamageRecord> damageRecords = new ArrayList<>();
}