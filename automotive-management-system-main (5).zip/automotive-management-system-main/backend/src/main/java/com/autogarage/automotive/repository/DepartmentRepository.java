package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

    @Query("""
        SELECT d FROM Department d
        WHERE d.id = :departmentId
        AND d.company.id = :companyId
        AND d.workshop.id = :workshopId
        AND d.active = true
    """)
    Optional<Department> findByIdAndCompany_IdAndWorkshop_IdAndActiveTrue(
            @Param("departmentId") Long departmentId,
            @Param("companyId") Long companyId,
            @Param("workshopId") Long workshopId
    );

    @Query("""
        SELECT d FROM Department d
        WHERE d.company.id = :companyId
        AND d.workshop.id = :workshopId
        AND d.active = true
        ORDER BY d.departmentName ASC
    """)
    List<Department> findActiveByCompanyAndWorkshop(
            @Param("companyId") Long companyId,
            @Param("workshopId") Long workshopId);

    List<Department> findByWorkshop_IdAndActiveTrueOrderByDepartmentNameAsc(Long workshopId);
}
