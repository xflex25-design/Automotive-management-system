package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;

public record CreatePartsRequisitionRequest(
        @NotNull Long requestedByEmployeeId,
        @Size(max = 16) String priority,
        LocalDate requiredDate,
        String purpose
) {}
