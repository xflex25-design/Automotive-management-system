package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(
    name = "repair_task_dependencies",
    uniqueConstraints = @UniqueConstraint(
        name = "uq_repair_task_dependency",
        columnNames = {"task_id", "depends_on_task_id"}
    )
)
@Getter
@Setter
@NoArgsConstructor
public class RepairTaskDependency {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "task_id", nullable = false)
    private RepairTask task;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "depends_on_task_id", nullable = false)
    private RepairTask dependsOnTask;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}