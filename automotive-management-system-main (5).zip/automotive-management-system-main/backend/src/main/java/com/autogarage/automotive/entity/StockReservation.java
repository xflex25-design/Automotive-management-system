package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "stock_reservations")
public class StockReservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_card_part_id", nullable = false)
    private JobCardPart jobCardPart;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "stock_balance_id", nullable = false)
    private StockBalance stockBalance;

    @Column(name = "quantity_reserved", nullable = false, precision = 12, scale = 2)
    private BigDecimal quantityReserved;

    @Column(name = "reservation_status", nullable = false, length = 20)
    private String reservationStatus = "ACTIVE";

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "reserved_by_employee_id", nullable = false)
    private Employee reservedBy;

    @Column(name = "reserved_at", nullable = false)
    private LocalDateTime reservedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "released_by_employee_id")
    private Employee releasedBy;

    @Column(name = "released_at")
    private LocalDateTime releasedAt;

    @Column(name = "consumed_at")
    private LocalDateTime consumedAt;

    @Column(name = "notes", columnDefinition = "TEXT")
    private String notes;

    public Long getId() { return id; }

    public JobCardPart getJobCardPart() { return jobCardPart; }
    public void setJobCardPart(JobCardPart jobCardPart) { this.jobCardPart = jobCardPart; }

    public StockBalance getStockBalance() { return stockBalance; }
    public void setStockBalance(StockBalance stockBalance) { this.stockBalance = stockBalance; }

    public BigDecimal getQuantityReserved() { return quantityReserved; }
    public void setQuantityReserved(BigDecimal quantityReserved) { this.quantityReserved = quantityReserved; }

    public String getReservationStatus() { return reservationStatus; }
    public void setReservationStatus(String reservationStatus) { this.reservationStatus = reservationStatus; }

    public Employee getReservedBy() { return reservedBy; }
    public void setReservedBy(Employee reservedBy) { this.reservedBy = reservedBy; }

    public LocalDateTime getReservedAt() { return reservedAt; }
    public void setReservedAt(LocalDateTime reservedAt) { this.reservedAt = reservedAt; }

    public Employee getReleasedBy() { return releasedBy; }
    public void setReleasedBy(Employee releasedBy) { this.releasedBy = releasedBy; }

    public LocalDateTime getReleasedAt() { return releasedAt; }
    public void setReleasedAt(LocalDateTime releasedAt) { this.releasedAt = releasedAt; }

    public LocalDateTime getConsumedAt() { return consumedAt; }
    public void setConsumedAt(LocalDateTime consumedAt) { this.consumedAt = consumedAt; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}