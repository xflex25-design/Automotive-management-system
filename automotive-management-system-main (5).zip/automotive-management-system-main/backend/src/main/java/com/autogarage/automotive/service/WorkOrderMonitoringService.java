package com.autogarage.automotive.service;

import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class WorkOrderMonitoringService {

    private final WorkshopMonitoringSettingRepository settingsRepository;
    private final WorkshopEscalationRuleRepository escalationRepository;
    private final WorkOrderReminderRepository reminderRepository;
    private final WorkOrderRepository workOrderRepository;
    private final EmployeeRepository employeeRepository;
    private final WorkOrderAssignmentRepository assignmentRepository;

    private final WorkingTimeCalculator workingTimeCalculator;

    public WorkOrderMonitoringService(
            WorkshopMonitoringSettingRepository settingsRepository,
            WorkshopEscalationRuleRepository escalationRepository,
            WorkOrderReminderRepository reminderRepository,
            WorkOrderRepository workOrderRepository,
            EmployeeRepository employeeRepository,
            WorkOrderAssignmentRepository assignmentRepository,
            WorkingTimeCalculator workingTimeCalculator
    ) {
        this.settingsRepository = settingsRepository;
        this.escalationRepository = escalationRepository;
        this.reminderRepository = reminderRepository;
        this.workOrderRepository = workOrderRepository;
        this.employeeRepository = employeeRepository;
        this.assignmentRepository = assignmentRepository;
        this.workingTimeCalculator = workingTimeCalculator;
    }

    @Scheduled(fixedDelay = 60000)
        @Transactional
        public void processMonitoring() {

        LocalDateTime now = LocalDateTime.now();

        List<WorkshopMonitoringSetting> settingsList =
                settingsRepository.findByActiveTrue();

        for (WorkshopMonitoringSetting settings : settingsList) {

            Long workshopId = settings.getWorkshop().getId();

            List<WorkOrder> workOrders =
                    workOrderRepository.findByWorkOrderStatusInOrderByUpdatedAtAsc(
                            List.of(
                                    "READY",
                                    "ASSIGNED",
                                    "IN_PROGRESS",
                                    "WAITING",
                                    "PAUSED"
                            )
                    );

            for (WorkOrder workOrder : workOrders) {

                if (workOrder.getJob() == null
                        || workOrder.getJob().getWorkshop() == null
                        || !workshopId.equals(
                                workOrder.getJob().getWorkshop().getId()
                        )) {
                    continue;
                }

                processWorkOrder(workOrder, settings, now);
            }
        }
    }

    private void processWorkOrder(
            WorkOrder workOrder,
            WorkshopMonitoringSetting settings,
            LocalDateTime now
    ) {

        if (workOrder.getUpdatedAt() == null) {
            return;
        }

        String status = workOrder.getWorkOrderStatus();

        if (!List.of("READY", "ASSIGNED", "IN_PROGRESS", "WAITING", "PAUSED")
                .contains(status)) {
            return;
        }

        long elapsedMinutes =
                workingTimeCalculator.calculateWorkingMinutes(
                        workOrder.getUpdatedAt(),
                        now,
                        settings
                );

        if ("WAITING".equals(status)) {

            processTimedReminder(
                    workOrder,
                    settings,
                    WorkOrderReminder.ReminderType.WAITING,
                    settings.getWaitingReminderMinutes(),
                    elapsedMinutes,
                    now,
                    "Work order has been waiting for additional action."
            );
        }

        if ("PAUSED".equals(status)) {

            processTimedReminder(
                    workOrder,
                    settings,
                    WorkOrderReminder.ReminderType.PAUSED,
                    settings.getPausedReminderMinutes(),
                    elapsedMinutes,
                    now,
                    "Work order remains paused and requires attention."
            );
        }

        if (List.of("READY", "ASSIGNED", "IN_PROGRESS").contains(status)
                && elapsedMinutes >= settings.getStagnationThresholdMinutes()) {

            String message = switch (status) {
                case "READY" -> "Work order is ready but has not been assigned or started.";
                case "ASSIGNED" -> "Work order has been assigned but work has not started.";
                default -> "Work order has had no recorded progress beyond the stagnation threshold.";
            };

            processTimedReminder(
                    workOrder,
                    settings,
                    WorkOrderReminder.ReminderType.STAGNANT,
                    settings.getStagnationThresholdMinutes(),
                    elapsedMinutes,
                    now,
                    message
            );
        }

        processEscalation(workOrder, settings, elapsedMinutes);
    }

    private void processTimedReminder(
                WorkOrder workOrder,
                WorkshopMonitoringSetting settings,
                WorkOrderReminder.ReminderType type,
                int threshold,
                long elapsedMinutes,
                LocalDateTime now,
                String message
        ) {

        if (elapsedMinutes < threshold) {
                return;
        }

        var latest = reminderRepository
                .findTopByWorkOrder_IdAndReminderTypeOrderBySentAtDesc(
                        workOrder.getId(),
                        type
                );

        if (latest.isPresent()) {

                LocalDateTime lastSent = latest.get().getSentAt();

                // Ignore reminders created before the current work period.
                boolean belongsToCurrentPeriod =
                        lastSent != null
                                && !lastSent.isBefore(workOrder.getUpdatedAt());

                if (belongsToCurrentPeriod) {

                if (workingTimeCalculator.calculateWorkingMinutes(
                        lastSent,
                        now,
                        settings
                ) < settings.getReminderRepeatMinutes()) {
                        return;
                }
                }
        }

        boolean sentToTechnician = createTechnicianReminder(
                workOrder,
                type,
                0,
                WorkOrderReminder.Priority.NORMAL,
                message
        );
        if (!sentToTechnician) {
            createManagerReminder(
                    workOrder,
                    type,
                    0,
                    WorkOrderReminder.Priority.NORMAL,
                    "No assigned technician is available for work order "
                            + workOrder.getWorkOrderNumber() + ". " + message
            );
        }
        }

    private void processEscalation(
            WorkOrder workOrder,
            WorkshopMonitoringSetting settings,
            long elapsedMinutes
    ) {

        List<WorkshopEscalationRule> rules =
                escalationRepository
                        .findByWorkshop_IdAndActiveTrueOrderByElapsedMinutesAsc(
                                settings.getWorkshop().getId()
                        );

        for (WorkshopEscalationRule rule : rules) {

            if (elapsedMinutes < rule.getElapsedMinutes()) {
                continue;
            }

            boolean alreadyCreated =
                    reminderRepository
                            .existsByWorkOrder_IdAndReminderTypeAndEscalationLevel(
                                    workOrder.getId(),
                                    WorkOrderReminder.ReminderType.ESCALATION,
                                    rule.getEscalationLevel()
                            );

            if (alreadyCreated) {
                continue;
            }

            WorkOrderReminder.Priority priority =
                    WorkOrderReminder.Priority.valueOf(
                            rule.getPriority().name()
                    );

            String message =
                    "Escalation level " + rule.getEscalationLevel()
                            + ": Work order "
                            + workOrder.getWorkOrderNumber()
                            + " has exceeded "
                            + rule.getElapsedMinutes()
                            + " working minutes.";

            createTechnicianReminder(
                    workOrder,
                    WorkOrderReminder.ReminderType.ESCALATION,
                    rule.getEscalationLevel(),
                    priority,
                    message
            );

            if (Boolean.TRUE.equals(rule.getNotifyManager())) {

                createManagerReminder(
                        workOrder,
                        WorkOrderReminder.ReminderType.ESCALATION,
                        rule.getEscalationLevel(),
                        priority,
                        "MANAGER ALERT: Work order "
                                + workOrder.getWorkOrderNumber()
                                + " requires management attention."
                );
            }
        }
    }

    private boolean createTechnicianReminder(
            WorkOrder workOrder,
            WorkOrderReminder.ReminderType type,
            int escalationLevel,
            WorkOrderReminder.Priority priority,
            String message
    ) {

        Map<Long, Employee> recipients = new LinkedHashMap<>();

        List<WorkOrderAssignment> assignments =
                assignmentRepository
                        .findByWorkOrder_IdAndAssignmentStatusInAndRemovedAtIsNullOrderByAssignedAtDesc(
                                workOrder.getId(),
                                List.of("ASSIGNED", "ACCEPTED")
                        );

        for (WorkOrderAssignment assignment : assignments) {

            Employee employee = assignment.getEmployee();

            if (employee != null
                    && "ACTIVE".equals(employee.getEmploymentStatus())) {

                recipients.put(employee.getId(), employee);
            }
        }

        // If no active assigned technician exists, notify the foreman.
        if (recipients.isEmpty()
                && workOrder.getAssignedForeman() != null
                && "ACTIVE".equals(
                        workOrder.getAssignedForeman().getEmploymentStatus()
                )) {

            Employee foreman = workOrder.getAssignedForeman();
            recipients.put(foreman.getId(), foreman);
        }

        for (Employee employee : recipients.values()) {

            createReminder(
                    workOrder,
                    employee,
                    type,
                    escalationLevel,
                    priority,
                    message
            );
        }

        return !recipients.isEmpty();
    }

    private void createManagerReminder(
            WorkOrder workOrder,
            WorkOrderReminder.ReminderType type,
            int escalationLevel,
            WorkOrderReminder.Priority priority,
            String message
    ) {

        Long workshopId = workOrder.getJob().getWorkshop().getId();

        Map<Long, Employee> managers = new LinkedHashMap<>();
        employeeRepository
                .findByWorkshop_IdAndEmploymentStatusAndJobTitleContainingIgnoreCase(
                        workshopId, "ACTIVE", "Manager")
                .forEach(employee -> managers.put(employee.getId(), employee));
        employeeRepository
                .findByWorkshop_IdAndEmploymentStatusAndJobTitleContainingIgnoreCase(
                        workshopId, "ACTIVE", "Boss")
                .forEach(employee -> managers.put(employee.getId(), employee));

        for (Employee manager : managers.values()) {

            createReminder(
                    workOrder,
                    manager,
                    type,
                    escalationLevel,
                    priority,
                    message
            );
        }
    }

    private void createReminder(
            WorkOrder workOrder,
            Employee employee,
            WorkOrderReminder.ReminderType type,
            int escalationLevel,
            WorkOrderReminder.Priority priority,
            String message
    ) {

        WorkOrderReminder reminder = new WorkOrderReminder();

        reminder.setWorkOrder(workOrder);
        reminder.setEmployee(employee);
        reminder.setReminderType(type);
        reminder.setEscalationLevel(escalationLevel);
        reminder.setPriority(priority);
        reminder.setReminderMessage(message);

        reminderRepository.save(reminder);
    }

    @Transactional(readOnly = true)
    public List<WorkOrderReminder> getWorkOrderReminders(
            Long workOrderId
    ) {

        WorkOrder workOrder = workOrderRepository.findById(workOrderId)
                .orElseThrow(() -> new IllegalArgumentException("Work order not found."));
        ActorIdentity.requireCompanyWorkshop(
                workOrder.getJob().getCompany().getId(),
                workOrder.getJob().getWorkshop().getId());

        return reminderRepository
                .findByWorkOrder_IdOrderBySentAtDesc(workOrderId);
    }

    @Transactional(readOnly = true)
    public List<WorkOrderReminder> getEmployeeReminders(
            Long employeeId
    ) {

        ActorIdentity.requireEmployee(employeeId);

        if (!employeeRepository.existsById(employeeId)) {
            throw new IllegalArgumentException("Employee not found.");
        }

        return reminderRepository
                .findByEmployee_IdAndAcknowledgedAtIsNullOrderBySentAtDesc(
                        employeeId
                );
    }

    @Transactional
    public WorkOrderReminder acknowledgeReminder(
            Long reminderId,
            Long employeeId
    ) {

        ActorIdentity.requireEmployee(employeeId);

        WorkOrderReminder reminder = reminderRepository.findById(reminderId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Reminder not found."
                ));

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Employee not found."
                ));

        ActorIdentity.requireCompanyWorkshop(
                reminder.getWorkOrder().getJob().getCompany().getId(),
                reminder.getWorkOrder().getJob().getWorkshop().getId());

        if (reminder.getAcknowledgedAt() != null) {
            throw new IllegalStateException(
                    "This reminder has already been acknowledged."
            );
        }

        if (reminder.getEmployee() == null
                || !reminder.getEmployee().getId().equals(employeeId)) {

            throw new IllegalStateException(
                    "This reminder is not assigned to this employee."
            );
        }

        reminder.setAcknowledgedAt(LocalDateTime.now());
        reminder.setAcknowledgedBy(employee);

        return reminderRepository.save(reminder);
    }
}
