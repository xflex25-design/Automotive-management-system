package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record AccountsDispatchAcknowledgementRequest(
        @NotNull Long acknowledgedByEmployeeId,
        @NotBlank String signerName,
        Long signatureMediaId,
        String remarks
) {}