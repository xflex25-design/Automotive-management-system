package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "parts_requisitions")
@Getter
@Setter
@NoArgsConstructor
public class PartsRequisition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "workshop_id", nullable = false)
    private Workshop workshop;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false)
    private Job job;

    @Column(name = "requisition_number", nullable = false, length = 100)
    private String requisitionNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requested_by_employee_id", nullable = false)
    private Employee requestedBy;

    @Column(name = "requisition_status", columnDefinition = "ENUM('DRAFT','SUBMITTED','PENDING_APPROVAL','APPROVED','PARTIALLY_FULFILLED','FULFILLED','REJECTED','CANCELLED')")
    private String requisitionStatus = "DRAFT";

    @Column(columnDefinition = "ENUM('LOW','NORMAL','HIGH','URGENT')")
    private String priority = "NORMAL";

    @Column(name = "required_date")
    private LocalDate requiredDate;

    @Column(columnDefinition = "TEXT")
    private String purpose;

    @Column(name = "submitted_at")
    private LocalDateTime submittedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cancelled_by_employee_id")
    private Employee cancelledBy;

    @Column(name = "cancelled_at")
    private LocalDateTime cancelledAt;

    @Column(name = "cancellation_reason", columnDefinition = "TEXT")
    private String cancellationReason;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
