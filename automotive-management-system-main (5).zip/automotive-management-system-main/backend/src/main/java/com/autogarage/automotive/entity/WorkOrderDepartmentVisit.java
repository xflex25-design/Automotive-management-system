
package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "work_order_department_visits")
public class WorkOrderDepartmentVisit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "work_order_id", nullable = false)
    private WorkOrder workOrder;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;

    @Column(name = "visit_number", nullable = false)
    private Integer visitNumber;

    @Column(name = "visit_status", nullable = false)
    private String visitStatus = "OPEN";

    @Column(name = "arrived_at", nullable = false)
    private LocalDateTime arrivedAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "arrived_by_employee_id", nullable = false)
    private Employee arrivedBy;

    @Column(name = "sent_off_at")
    private LocalDateTime sentOffAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sent_off_by_employee_id")
    private Employee sentOffBy;

    @Column(name = "arrival_notes", columnDefinition = "TEXT")
    private String arrivalNotes;

    @Column(name = "send_off_notes", columnDefinition = "TEXT")
    private String sendOffNotes;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;

    public WorkOrderDepartmentVisit() {
    }

    public Long getId() {
        return id;
    }

    public WorkOrder getWorkOrder() {
        return workOrder;
    }

    public void setWorkOrder(WorkOrder workOrder) {
        this.workOrder = workOrder;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public Integer getVisitNumber() {
        return visitNumber;
    }

    public void setVisitNumber(Integer visitNumber) {
        this.visitNumber = visitNumber;
    }

    public String getVisitStatus() {
        return visitStatus;
    }

    public void setVisitStatus(String visitStatus) {
        this.visitStatus = visitStatus;
    }

    public LocalDateTime getArrivedAt() {
        return arrivedAt;
    }

    public void setArrivedAt(LocalDateTime arrivedAt) {
        this.arrivedAt = arrivedAt;
    }

    public Employee getArrivedBy() {
        return arrivedBy;
    }

    public void setArrivedBy(Employee arrivedBy) {
        this.arrivedBy = arrivedBy;
    }

    public LocalDateTime getSentOffAt() {
        return sentOffAt;
    }

    public void setSentOffAt(LocalDateTime sentOffAt) {
        this.sentOffAt = sentOffAt;
    }

    public Employee getSentOffBy() {
        return sentOffBy;
    }

    public void setSentOffBy(Employee sentOffBy) {
        this.sentOffBy = sentOffBy;
    }

    public String getArrivalNotes() {
        return arrivalNotes;
    }

    public void setArrivalNotes(String arrivalNotes) {
        this.arrivalNotes = arrivalNotes;
    }

    public String getSendOffNotes() {
        return sendOffNotes;
    }

    public void setSendOffNotes(String sendOffNotes) {
        this.sendOffNotes = sendOffNotes;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
