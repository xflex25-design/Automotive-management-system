package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.InspectionRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface InspectionRecordRepository
        extends JpaRepository<InspectionRecord, Long> {

    List<InspectionRecord> findByJobIdOrderByInspectionDateDesc(Long jobId);

    List<InspectionRecord> findByInventoryCardIdOrderByInspectionDateDesc(
            Long inventoryCardId
    );

    List<InspectionRecord> findByJobIdAndInspectionTypeIgnoreCase(
            Long jobId, String inspectionType
    );

    Optional<InspectionRecord> findByIdAndJobId(Long id, Long jobId);
}