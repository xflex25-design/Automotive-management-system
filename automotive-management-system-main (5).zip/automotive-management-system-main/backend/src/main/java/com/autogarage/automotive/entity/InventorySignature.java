package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "inventory_signatures")
@Getter
@Setter
@NoArgsConstructor
public class InventorySignature {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inventory_card_id", nullable = false)
    private VehicleInventoryCard inventoryCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "authorisation_id")
    private InventoryAuthorisation authorisation;

    @Column(name = "signer_type", nullable = false, length = 50)
    private String signerType;

    @Column(name = "signer_name", nullable = false, length = 200)
    private String signerName;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @Column(name = "signature_media_id")
    private Long signatureMediaId;

    @Column(name = "signed_at", insertable = false, updatable = false)
    private LocalDateTime signedAt;

    @Column(columnDefinition = "TEXT")
    private String remarks;
}