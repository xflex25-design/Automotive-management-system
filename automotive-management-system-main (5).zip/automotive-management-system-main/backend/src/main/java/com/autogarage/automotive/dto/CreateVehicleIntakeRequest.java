package com.autogarage.automotive.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;

import java.math.BigDecimal;

public record CreateVehicleIntakeRequest(

        @NotNull(message = "Company is required")
        Long companyId,

        @NotNull(message = "Workshop is required")
        Long workshopId,

        @NotNull(message = "The user creating this job is required")
        Long createdByUserId,

        @NotNull(message = "The receiving employee is required")
        Long receivedByEmployeeId,

        @NotNull(message = "Customer details are required")
        @Valid
        CustomerIntakeRequest customer,

        @NotNull(message = "Vehicle details are required")
        @Valid
        VehicleIntakeRequest vehicle,

        @Size(max = 200)
        String ownerName,

        @NotBlank(message = "Name of the person bringing in the vehicle is required")
        @Size(max = 200)
        String broughtInByName,

        @Size(max = 30)
        String broughtInByPhone,

        String jobType,

        String priority,

        String reportedProblem,

        String internalNotes,

        @DecimalMin(value = "0.0", message = "Odometer reading cannot be negative")
        BigDecimal odometerReadingIn,

        String fuelLevelIn,

        @Min(value = 0, message = "Number of keys cannot be negative")
        Integer numberOfKeysReceived,

        String workRequested,

        String customerComplaints,

        String generalRemarks

) {}
