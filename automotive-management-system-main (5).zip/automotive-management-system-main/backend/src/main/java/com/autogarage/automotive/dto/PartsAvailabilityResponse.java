package com.autogarage.automotive.dto;

import java.math.BigDecimal;
import java.util.List;

public record PartsAvailabilityResponse(
        Long jobId,
        String jobNumber,
        Long jobCardId,
        List<Line> parts
) {
    public record Line(
            List<Long> jobCardPartIds,
            Long partId,
            String partCode,
            String partName,
            String category,
            BigDecimal requiredQuantity,
            BigDecimal quantityOnHand,
            BigDecimal quantityReserved,
            BigDecimal quantityAvailable,
            BigDecimal quantityShort,
            String availabilityStatus,
            BigDecimal quantityReservedForThisJob,
            BigDecimal quantityReservedForOtherJobs,
            BigDecimal quantityAvailableToReserve
    ) {}
}