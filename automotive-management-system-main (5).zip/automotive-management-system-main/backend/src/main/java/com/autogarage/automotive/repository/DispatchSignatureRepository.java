package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.DispatchSignature;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DispatchSignatureRepository
        extends JpaRepository<DispatchSignature, Long> {

    List<DispatchSignature> findByDispatchOrder_IdOrderBySignedAtAsc(
            Long dispatchOrderId);
}