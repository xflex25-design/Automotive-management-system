
package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.BatchWorkOrderAssignmentRequest;
import com.autogarage.automotive.entity.Employee;
import com.autogarage.automotive.entity.WorkOrder;
import com.autogarage.automotive.entity.WorkOrderAssignment;
import com.autogarage.automotive.repository.EmployeeDepartmentRepository;
import com.autogarage.automotive.repository.EmployeeRepository;
import com.autogarage.automotive.repository.WorkOrderAssignmentRepository;
import com.autogarage.automotive.repository.WorkOrderRepository;
import com.autogarage.automotive.security.ActorIdentity;
import com.autogarage.automotive.dto.WorkOrderAssignmentResponseRequest;
import java.time.LocalDateTime;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class WorkOrderAssignmentService {

    private final WorkOrderAssignmentRepository assignmentRepository;
    private final WorkOrderRepository workOrderRepository;
    private final EmployeeRepository employeeRepository;
    private final EmployeeDepartmentRepository employeeDepartmentRepository;

    public WorkOrderAssignmentService(
            WorkOrderAssignmentRepository assignmentRepository,
            WorkOrderRepository workOrderRepository,
            EmployeeRepository employeeRepository,
            EmployeeDepartmentRepository employeeDepartmentRepository
    ) {
        this.assignmentRepository = assignmentRepository;
        this.workOrderRepository = workOrderRepository;
        this.employeeRepository = employeeRepository;
        this.employeeDepartmentRepository = employeeDepartmentRepository;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getWorkOrderAssignments(Long workOrderId) {
        WorkOrder workOrder = workOrderRepository.findById(workOrderId)
                .orElseThrow(() -> new IllegalArgumentException("Work order not found"));
        ActorIdentity.requireCompanyWorkshop(
                workOrder.getJob().getCompany().getId(),
                workOrder.getJob().getWorkshop().getId());
        return assignmentRepository
                .findByWorkOrder_IdAndAssignmentStatusInAndRemovedAtIsNullOrderByAssignedAtDesc(
                        workOrderId, List.of("ASSIGNED", "ACCEPTED"))
                .stream()
                .map(assignment -> {
                    Map<String, Object> row = new LinkedHashMap<>();
                    Employee employee = assignment.getEmployee();
                    row.put("assignmentId", assignment.getId());
                    row.put("workOrderId", workOrderId);
                    row.put("employeeId", employee.getId());
                    row.put("employeeName", (employee.getFirstName() + " "
                            + employee.getLastName()).trim());
                    row.put("assignmentRole", assignment.getAssignmentRole());
                    row.put("assignmentStatus", assignment.getAssignmentStatus());
                    row.put("assignedAt", assignment.getAssignedAt());
                    row.put("acceptedAt", assignment.getAcceptedAt());
                    return row;
                })
                .toList();
    }

    @Transactional
    public Map<String, Object> assignWorkOrders(
            BatchWorkOrderAssignmentRequest request
    ) {

        ActorIdentity.requireEmployee(request == null ? null : request.getAssignedByEmployeeId());

        if (request == null
                || request.getAssignedByEmployeeId() == null
                || request.getWorkOrders() == null
                || request.getWorkOrders().isEmpty()) {
            throw new IllegalArgumentException(
                    "Foreman and work order assignments are required"
            );
        }

        Employee foreman = employeeRepository.findById(
                request.getAssignedByEmployeeId()
        ).orElseThrow(() ->
                new IllegalArgumentException("Foreman employee not found")
        );

        if (!"ACTIVE".equalsIgnoreCase(foreman.getEmploymentStatus())) {
            throw new IllegalArgumentException(
                    "The assigning foreman is not active"
            );
        }

        List<WorkOrderAssignment> assignmentsToSave = new ArrayList<>();

        Set<Long> processedWorkOrders = new HashSet<>();

        for (BatchWorkOrderAssignmentRequest.WorkOrderAssignmentGroup group
                : request.getWorkOrders()) {

            if (group.getWorkOrderId() == null
                    || group.getAssignments() == null
                    || group.getAssignments().isEmpty()) {
                throw new IllegalArgumentException(
                        "Each work order must have at least one employee assignment"
                );
            }

            if (!processedWorkOrders.add(group.getWorkOrderId())) {
                throw new IllegalArgumentException(
                        "A work order appears more than once in the request: "
                                + group.getWorkOrderId()
                );
            }

            WorkOrder workOrder = workOrderRepository.findById(
                    group.getWorkOrderId()
            ).orElseThrow(() ->
                    new IllegalArgumentException(
                            "Work order not found: " + group.getWorkOrderId()
                    )
            );

            String status = workOrder.getWorkOrderStatus();

            if (!"READY".equalsIgnoreCase(status)
                    && !"BLOCKED".equalsIgnoreCase(status)) {
                throw new IllegalArgumentException(
                        "Only READY or BLOCKED work orders can be assigned: "
                                + workOrder.getWorkOrderNumber()
                );
            }

            if (!Objects.equals(
                    workOrder.getJob().getCompany().getId(),
                    foreman.getCompany().getId()
            ) || !Objects.equals(
                    workOrder.getJob().getWorkshop().getId(),
                    foreman.getWorkshop().getId()
            )) {
                throw new IllegalArgumentException(
                        "The foreman does not belong to this workshop"
                );
            }

            Set<Long> employeesInThisWorkOrder = new HashSet<>();

            for (BatchWorkOrderAssignmentRequest.EmployeeAssignment employeeRequest
                    : group.getAssignments()) {

                if (employeeRequest.getEmployeeId() == null) {
                    throw new IllegalArgumentException(
                            "Employee ID is required"
                    );
                }

                Long employeeId = employeeRequest.getEmployeeId();

                if (!employeesInThisWorkOrder.add(employeeId)) {
                    throw new IllegalArgumentException(
                            "An employee appears more than once for work order "
                                    + workOrder.getWorkOrderNumber()
                    );
                }

                Employee employee = employeeRepository.findById(employeeId)
                        .orElseThrow(() ->
                                new IllegalArgumentException(
                                        "Employee not found: " + employeeId
                                )
                        );

                if (!"ACTIVE".equalsIgnoreCase(
                        employee.getEmploymentStatus()
                )) {
                    throw new IllegalArgumentException(
                            "Employee is not active: " + employeeId
                    );
                }

                if (!Objects.equals(
                        employee.getCompany().getId(),
                        workOrder.getJob().getCompany().getId()
                ) || !Objects.equals(
                        employee.getWorkshop().getId(),
                        workOrder.getJob().getWorkshop().getId()
                )) {
                    throw new IllegalArgumentException(
                            "Employee does not belong to this workshop: "
                                    + employeeId
                    );
                }

                Long departmentId = workOrder.getDepartment().getId();

                if (employeeDepartmentRepository
                        .countEmployeeDepartmentMembership(
                                employeeId,
                                departmentId
                        ) == 0) {
                    throw new IllegalArgumentException(
                            "Employee " + employeeId
                                    + " is not assigned to department "
                                    + departmentId
                    );
                }

                boolean alreadyAssigned = assignmentRepository
                        .existsByWorkOrder_IdAndEmployee_IdAndAssignmentStatusIn(
                                workOrder.getId(),
                                employeeId,
                                List.of("ASSIGNED", "ACCEPTED")
                        );

                if (alreadyAssigned) {
                    throw new IllegalArgumentException(
                            "Employee " + employeeId
                                    + " already has an active assignment for "
                                    + workOrder.getWorkOrderNumber()
                    );
                }

                WorkOrderAssignment assignment =
                        new WorkOrderAssignment();

                assignment.setWorkOrder(workOrder);
                assignment.setEmployee(employee);
                assignment.setAssignedBy(foreman);
                assignment.setAssignmentStatus("ASSIGNED");

                String role = employeeRequest.getAssignmentRole();

                if (role != null && role.length() > 100) {
                    throw new IllegalArgumentException(
                            "Assignment role cannot exceed 100 characters"
                    );
                }

                assignment.setAssignmentRole(
                        role == null || role.isBlank()
                                ? null
                                : role.trim()
                );

                assignment.setRemarks(employeeRequest.getRemarks());

                assignmentsToSave.add(assignment);
            }
        }

        List<WorkOrderAssignment> savedAssignments =
                assignmentRepository.saveAll(assignmentsToSave);

        List<Map<String, Object>> results = new ArrayList<>();

        for (WorkOrderAssignment assignment : savedAssignments) {
            Map<String, Object> item = new LinkedHashMap<>();

            item.put("assignmentId", assignment.getId());
            item.put("workOrderId", assignment.getWorkOrder().getId());
            item.put("workOrderNumber",
                    assignment.getWorkOrder().getWorkOrderNumber());
            item.put("employeeId", assignment.getEmployee().getId());
            item.put("assignmentRole", assignment.getAssignmentRole());
            item.put("assignmentStatus", assignment.getAssignmentStatus());

            results.add(item);
        }

        Map<String, Object> response = new LinkedHashMap<>();

        response.put("message",
                "Work order assignments created successfully");
        response.put("assignedByEmployeeId", foreman.getId());
        response.put("totalAssignments", savedAssignments.size());
        response.put("assignments", results);

        return response;
    }

    @Transactional
        public Map<String, Object> respondToAssignment(
                Long assignmentId,
                WorkOrderAssignmentResponseRequest request
        ) {
        ActorIdentity.requireEmployee(request == null ? null : request.getEmployeeId());
        if (request == null || request.getEmployeeId() == null
                || request.getDecision() == null) {
                throw new IllegalArgumentException(
                        "Employee ID and decision are required"
                );
        }

        WorkOrderAssignment assignment =
                assignmentRepository.findById(assignmentId)
                        .orElseThrow(() -> new IllegalArgumentException(
                                "Assignment not found"
                        ));

        if (!Objects.equals(
                assignment.getEmployee().getId(),
                request.getEmployeeId()
        )) {
                throw new IllegalArgumentException(
                        "This assignment does not belong to this employee"
                );
        }

        if (!"ASSIGNED".equalsIgnoreCase(
                assignment.getAssignmentStatus()
        )) {
                throw new IllegalArgumentException(
                        "This assignment has already been responded to"
                );
        }

        String decision = request.getDecision().trim().toUpperCase();

        if (!decision.equals("ACCEPTED")
                && !decision.equals("DECLINED")) {
                throw new IllegalArgumentException(
                        "Decision must be ACCEPTED or DECLINED"
                );
        }

        assignment.setAssignmentStatus(decision);

        if ("ACCEPTED".equals(decision)) {
                assignment.setAcceptedAt(LocalDateTime.now());
        }

        if (request.getRemarks() != null
                && !request.getRemarks().isBlank()) {

                String existingRemarks = assignment.getRemarks();

                String responseRemarks =
                        "Technician response: " + request.getRemarks().trim();

                assignment.setRemarks(
                        existingRemarks == null || existingRemarks.isBlank()
                                ? responseRemarks
                                : existingRemarks + "\n" + responseRemarks
                );
        }

        assignmentRepository.save(assignment);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("message", "Assignment response recorded successfully");
        response.put("assignmentId", assignment.getId());
        response.put("employeeId", assignment.getEmployee().getId());
        response.put("workOrderNumber",
                assignment.getWorkOrder().getWorkOrderNumber());
        response.put("assignmentStatus", assignment.getAssignmentStatus());
        response.put("acceptedAt", assignment.getAcceptedAt());

        return response;
        }
}
