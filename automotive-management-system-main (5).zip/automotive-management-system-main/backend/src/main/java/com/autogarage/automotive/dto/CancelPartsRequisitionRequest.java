package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record CancelPartsRequisitionRequest(

        @NotNull
        Long cancelledByEmployeeId,

        @NotBlank
        @Size(max = 2000)
        String cancellationReason

) {}