package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "inventory_authorisations")
@Getter
@Setter
@NoArgsConstructor
public class InventoryAuthorisation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inventory_card_id", nullable = false)
    private VehicleInventoryCard inventoryCard;

    @Column(name = "authorisation_type", nullable = false, length = 60)
    private String authorisationType;

    @Column(name = "authorisation_status", nullable = false, length = 30)
    private String authorisationStatus = "PENDING";

    @Column(name = "authorisation_text", columnDefinition = "TEXT")
    private String authorisationText;

    @Column(name = "authorised_by_name", length = 200)
    private String authorisedByName;

    @Column(name = "authorised_by_phone", length = 30)
    private String authorisedByPhone;

    @Column(name = "authorised_at")
    private LocalDateTime authorisedAt;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}