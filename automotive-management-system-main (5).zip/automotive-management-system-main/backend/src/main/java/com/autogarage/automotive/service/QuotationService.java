
package com.autogarage.automotive.service;

import com.autogarage.automotive.security.ActorIdentity;
import com.autogarage.automotive.dto.CreateQuotationRequest;
import com.autogarage.automotive.dto.QuotationItemRequest;
import com.autogarage.automotive.dto.QuotationItemResponse;
import com.autogarage.automotive.dto.QuotationResponse;
import com.autogarage.automotive.entity.Company;
import com.autogarage.automotive.entity.Customer;
import com.autogarage.automotive.entity.Employee;
import com.autogarage.automotive.entity.Job;
import com.autogarage.automotive.entity.Quotation;
import com.autogarage.automotive.entity.QuotationItem;
import com.autogarage.automotive.entity.Vehicle;
import com.autogarage.automotive.repository.CompanyRepository;
import com.autogarage.automotive.repository.EmployeeRepository;
import com.autogarage.automotive.repository.JobRepository;
import com.autogarage.automotive.repository.QuotationItemRepository;
import com.autogarage.automotive.repository.QuotationRepository;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

@Service
public class QuotationService {

    private final JobRepository jobRepository;
    private final EmployeeRepository employeeRepository;
    private final QuotationRepository quotationRepository;
    private final QuotationItemRepository quotationItemRepository;
    private final CompanyRepository companyRepository;

    public QuotationService(
            JobRepository jobRepository,
            EmployeeRepository employeeRepository,
            QuotationRepository quotationRepository,
            QuotationItemRepository quotationItemRepository,
            CompanyRepository companyRepository
    ) {
        this.jobRepository = jobRepository;
        this.employeeRepository = employeeRepository;
        this.quotationRepository = quotationRepository;
        this.quotationItemRepository = quotationItemRepository;
        this.companyRepository = companyRepository;
    }

    @Transactional
    public Quotation createDraftQuotation(
            Long jobId,
            CreateQuotationRequest request
    ) {
        ActorIdentity.requireEmployee(request.preparedByEmployeeId());
        // Lock the company so its VAT settings remain consistent
        // while this quotation is being calculated.
        Job existingJob = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Workshop job not found"
                ));

        Company company = companyRepository.findByIdForUpdate(
                        existingJob.getCompany().getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Company not found"
                ));

        BigDecimal vatRate = company.getVatRate();

        if (vatRate == null
                || vatRate.compareTo(BigDecimal.ZERO) < 0
                || vatRate.compareTo(new BigDecimal("100")) > 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Company VAT rate must be between 0 and 100"
            );
        }

        Job job = jobRepository.findByIdForUpdate(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Workshop job not found"
                ));

        Employee preparedBy = employeeRepository
                .findByIdAndCompanyId(
                        request.preparedByEmployeeId(),
                        job.getCompany().getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Preparing employee not found for this company"
                ));

        if (!preparedBy.getWorkshop().getId()
                .equals(job.getWorkshop().getId())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Preparing employee does not belong to this workshop"
            );
        }

        if (!"ACTIVE".equalsIgnoreCase(
                preparedBy.getEmploymentStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only active employees can prepare quotations"
            );
        }

        List<Quotation> previousQuotations =
                quotationRepository.findByJobIdOrderByVersionNumberDesc(jobId);

        int versionNumber = 1;

        if (!previousQuotations.isEmpty()) {
            Quotation latest = previousQuotations.get(0);

            if ("DRAFT".equalsIgnoreCase(latest.getQuotationStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "This job already has a draft quotation. Complete or issue it before creating another version."
                );
            }

            versionNumber = latest.getVersionNumber() + 1;
        }

        Quotation quotation = new Quotation();

        quotation.setJob(job);
        quotation.setPreparedBy(preparedBy);
        quotation.setVersionNumber(versionNumber);
        quotation.setQuotationNumber(
                nextQuotationNumber(job.getCompany().getId())
        );
        quotation.setQuotationStatus("DRAFT");
        quotation.setCurrencyCode(
                job.getCompany().getCurrencyCode()
        );
        quotation.setValidUntil(request.validUntil());
        quotation.setEstimatedCompletionDays(
                request.estimatedCompletionDays()
        );
        quotation.setTermsAndConditions(
                trimToNull(request.termsAndConditions())
        );
        quotation.setForemanNotes(
                trimToNull(request.foremanNotes())
        );

        quotation.setSubtotal(BigDecimal.ZERO);
        quotation.setDiscountAmount(BigDecimal.ZERO);
        quotation.setTaxAmount(BigDecimal.ZERO);
        quotation.setTotalAmount(BigDecimal.ZERO);

        quotation = quotationRepository.save(quotation);

        BigDecimal subtotal = BigDecimal.ZERO;
        BigDecimal totalDiscount = BigDecimal.ZERO;
        BigDecimal totalTax = BigDecimal.ZERO;

        for (QuotationItemRequest itemRequest : request.items()) {

            String itemType = itemRequest.itemType()
                    .trim()
                    .toUpperCase(Locale.ROOT);

            if (!List.of("PART", "LABOUR", "SERVICE", "OTHER")
                    .contains(itemType)) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Item type must be PART, LABOUR, SERVICE or OTHER"
                );
            }

            BigDecimal quantity = itemRequest.quantity()
                    .setScale(2, RoundingMode.HALF_UP);

            BigDecimal unitPrice = money(itemRequest.unitPrice());
            BigDecimal discount = money(itemRequest.discountAmount());

            if (quantity.compareTo(BigDecimal.ZERO) <= 0) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Item quantity must be greater than zero"
                );
            }

            if (unitPrice.compareTo(BigDecimal.ZERO) < 0
                    || discount.compareTo(BigDecimal.ZERO) < 0) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Unit price and discount cannot be negative"
                );
            }

            BigDecimal lineSubtotal = quantity
                    .multiply(unitPrice)
                    .setScale(2, RoundingMode.HALF_UP);

            if (discount.compareTo(lineSubtotal) > 0) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "A line discount cannot exceed that item's subtotal"
                );
            }

            // VAT is calculated by the backend using the company's VAT rate.
            // The frontend-provided taxAmount is deliberately ignored.
            BigDecimal taxableAmount = lineSubtotal.subtract(discount);

            BigDecimal tax = taxableAmount
                    .multiply(vatRate)
                    .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);

            BigDecimal lineTotal = taxableAmount
                    .add(tax)
                    .setScale(2, RoundingMode.HALF_UP);

            QuotationItem item = new QuotationItem();

            item.setQuotation(quotation);
            item.setItemType(itemType);
            item.setItemCode(trimToNull(itemRequest.itemCode()));
            item.setDescription(itemRequest.description().trim());
            item.setQuantity(quantity);
            item.setUnitOfMeasure(
                    itemRequest.unitOfMeasure() == null
                            || itemRequest.unitOfMeasure().isBlank()
                            ? "UNIT"
                            : itemRequest.unitOfMeasure()
                                    .trim()
                                    .toUpperCase(Locale.ROOT)
            );
            item.setUnitPrice(unitPrice);
            item.setDiscountAmount(discount);
            item.setTaxAmount(tax);
            item.setLineTotal(lineTotal);
            item.setRemarks(trimToNull(itemRequest.remarks()));

            quotationItemRepository.save(item);

            subtotal = subtotal.add(lineSubtotal);
            totalDiscount = totalDiscount.add(discount);
            totalTax = totalTax.add(tax);
        }

        BigDecimal total = subtotal
                .subtract(totalDiscount)
                .add(totalTax)
                .setScale(2, RoundingMode.HALF_UP);

        quotation.setSubtotal(money(subtotal));
        quotation.setDiscountAmount(money(totalDiscount));
        quotation.setTaxAmount(money(totalTax));
        quotation.setTotalAmount(total);

        return quotationRepository.save(quotation);
    }

    private String nextQuotationNumber(Long companyId) {
        List<String> existingNumbers =
                quotationRepository.findQuotationNumbersByCompanyId(companyId);

        long highestNumber = 0;

        for (String number : existingNumbers) {
            String prefix = "Qtn no-";

            if (number.startsWith(prefix)) {
                try {
                    long currentNumber = Long.parseLong(
                            number.substring(prefix.length())
                    );

                    highestNumber = Math.max(highestNumber, currentNumber);

                } catch (NumberFormatException ignored) {
                    // Ignore quotation numbers that don't follow the expected format.
                }
            }
        }

        return "Qtn no-" + (highestNumber + 1);
    }

    @Transactional(readOnly = true)
    public QuotationResponse getQuotationDetails(Long quotationId) {

        Quotation quotation = quotationRepository.findById(quotationId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Quotation not found"
                ));
        ActorIdentity.requireCompanyWorkshop(
                quotation.getJob().getCompany().getId(),
                quotation.getJob().getWorkshop().getId());

        return mapToResponse(quotation);
    }

    @Transactional(readOnly = true)
    public List<QuotationResponse> getJobQuotations(Long jobId) {

        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Workshop job not found"));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        return quotationRepository
                .findByJobIdOrderByVersionNumberDesc(jobId)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    private QuotationResponse mapToResponse(Quotation quotation) {

        Job job = quotation.getJob();
        Customer customer = job.getCustomer();
        Vehicle vehicle = job.getVehicle();
        Employee employee = quotation.getPreparedBy();

        String customerName;

        if (customer.getCompanyName() != null
                && !customer.getCompanyName().isBlank()) {
            customerName = customer.getCompanyName();
        } else {
            customerName = (
                    (customer.getFirstName() == null ? "" : customer.getFirstName())
                    + " "
                    + (customer.getLastName() == null ? "" : customer.getLastName())
            ).trim();
        }

        String preparedByName = (
                employee.getFirstName() + " " + employee.getLastName()
        ).trim();

        List<QuotationItemResponse> items =
                quotationItemRepository
                        .findByQuotationIdOrderByIdAsc(quotation.getId())
                        .stream()
                        .map(item -> new QuotationItemResponse(
                                item.getId(),
                                item.getItemType(),
                                item.getItemCode(),
                                item.getDescription(),
                                item.getQuantity(),
                                item.getUnitOfMeasure(),
                                item.getUnitPrice(),
                                item.getDiscountAmount(),
                                item.getTaxAmount(),
                                item.getLineTotal(),
                                item.getRemarks()
                        ))
                        .toList();

        return new QuotationResponse(
                quotation.getId(),

                job.getId(),
                job.getJobNumber(),
                job.getJobStatus(),

                quotation.getQuotationNumber(),
                quotation.getVersionNumber(),
                quotation.getQuotationStatus(),

                quotation.getIssueDate(),
                quotation.getValidUntil(),

                quotation.getCurrencyCode(),

                customerName,
                customer.getPhone(),
                customer.getEmail(),

                vehicle.getRegistrationNumber(),
                vehicle.getMake(),
                vehicle.getModel(),
                vehicle.getVehicleType(),

                employee.getId(),
                preparedByName,

                quotation.getSubtotal(),
                quotation.getDiscountAmount(),
                quotation.getTaxAmount(),
                quotation.getTotalAmount(),

                quotation.getEstimatedCompletionDays(),
                quotation.getTermsAndConditions(),
                quotation.getForemanNotes(),

                items,

                quotation.getCreatedAt()
        );
    }

    @Transactional
    public Quotation issueQuotation(Long quotationId) {

        ActorIdentity.employeeId();

        Quotation quotation = quotationRepository
                .findByIdForUpdate(quotationId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Quotation not found"
                ));
        ActorIdentity.requireCompanyWorkshop(
                quotation.getJob().getCompany().getId(),
                quotation.getJob().getWorkshop().getId());

        if (!"DRAFT".equalsIgnoreCase(quotation.getQuotationStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Only draft quotations can be issued"
            );
        }

        if (quotationItemRepository.countByQuotationId(quotationId) == 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "A quotation must contain at least one item before it can be issued"
            );
        }

        if (quotation.getValidUntil() != null
                && quotation.getValidUntil().isBefore(LocalDate.now())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Cannot issue a quotation that has already expired"
            );
        }

        quotation.setIssueDate(LocalDate.now());
        quotation.setQuotationStatus("ISSUED");

        return quotationRepository.save(quotation);
    }

    private BigDecimal money(BigDecimal value) {
        return value == null
                ? BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
                : value.setScale(2, RoundingMode.HALF_UP);
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank()
                ? null
                : value.trim();
    }
}
