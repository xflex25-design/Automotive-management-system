package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.StockLocation;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface StockLocationRepository extends JpaRepository<StockLocation, Long> {
    List<StockLocation> findByWorkshop_IdAndActiveTrue(Long workshopId);
    Optional<StockLocation> findByIdAndWorkshop_IdAndActiveTrue(Long id, Long workshopId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select l from StockLocation l where l.id = :id and l.workshop.id = :workshopId and l.active = true")
    Optional<StockLocation> lockActiveLocation(
            @Param("id") Long id,
            @Param("workshopId") Long workshopId
    );
}
