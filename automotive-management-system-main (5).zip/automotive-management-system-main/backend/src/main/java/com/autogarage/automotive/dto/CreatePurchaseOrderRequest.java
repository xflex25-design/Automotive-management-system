package com.autogarage.automotive.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record CreatePurchaseOrderRequest(
        @NotNull Long supplierId,
        @NotNull Long createdByEmployeeId,
        LocalDate expectedDeliveryDate,
        @Size(max = 150) String supplierReference,
        String notes,
        @NotEmpty List<@Valid PurchaseOrderLineRequest> items
) {
    public record PurchaseOrderLineRequest(
            @NotNull Long requisitionItemId,
            @NotNull @Positive BigDecimal quantityOrdered,
            @NotNull @DecimalMin("0.00") BigDecimal unitPrice,
            @DecimalMin("0.00") BigDecimal taxAmount
    ) {}
}
