package com.autogarage.automotive.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;

import java.time.LocalDate;
import java.util.List;

public record CreateQuotationRequest(

        @NotNull
        Long preparedByEmployeeId,

        LocalDate validUntil,

        @Min(value = 1, message = "Estimated completion days must be at least one")
        Integer estimatedCompletionDays,

        String termsAndConditions,

        String foremanNotes,

        @NotEmpty(message = "A quotation must contain at least one item")
        List<@NotNull @Valid QuotationItemRequest> items
) {}