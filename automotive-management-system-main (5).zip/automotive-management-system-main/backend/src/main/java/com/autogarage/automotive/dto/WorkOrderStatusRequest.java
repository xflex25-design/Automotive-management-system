
package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record WorkOrderStatusRequest(

        @NotNull
        Long employeeId,

        @Size(max = 2000)
        String notes

) {
}
