package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.FinalInspectionItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FinalInspectionItemRepository
        extends JpaRepository<FinalInspectionItem, Long> {

    List<FinalInspectionItem> findByFinalInspection_IdOrderByIdAsc(
            Long finalInspectionId
    );

    List<FinalInspectionItem> findByFinalInspection_IdAndCheckStatus(
            Long finalInspectionId,
            String checkStatus
    );

    long countByFinalInspection_IdAndCheckStatus(
            Long finalInspectionId,
            String checkStatus
    );
}