package com.autogarage.automotive.dto.invoice;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record PaymentResponse(
        Long id,
        String paymentReference,
        String paymentMethod,
        String paymentStatus,
        BigDecimal amount,
        String currencyCode,
        String transactionReference,
        LocalDateTime paymentDate,
        Long receivedByEmployeeId,
        String receivedByEmployeeName,
        String notes
) {}