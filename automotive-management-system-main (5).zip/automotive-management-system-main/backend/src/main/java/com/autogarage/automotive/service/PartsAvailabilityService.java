package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.*;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class PartsAvailabilityService {
    private final JobCardRepository jobCardRepository;
    private final JobCardPartRepository jobCardPartRepository;
    private final PartRepository partRepository;
    private final StockBalanceRepository stockBalanceRepository;
    private final PartsRequisitionRepository requisitionRepository;
    private final PartsRequisitionItemRepository requisitionItemRepository;
    private final PurchaseOrderRepository purchaseOrderRepository;
    private final PurchaseOrderItemRepository purchaseOrderItemRepository;
    private final PurchaseReceiptRepository receiptRepository;
    private final PurchaseReceiptItemRepository receiptItemRepository;
    private final StockLocationRepository stockLocationRepository;
    private final StockMovementRepository stockMovementRepository;
    private final SupplierRepository supplierRepository;
    private final EmployeeRepository employeeRepository;
    private final StockReservationRepository stockReservationRepository;

    public PartsAvailabilityService(
            JobCardRepository jobCardRepository,
            JobCardPartRepository jobCardPartRepository,
            PartRepository partRepository,
            StockBalanceRepository stockBalanceRepository,
            PartsRequisitionRepository requisitionRepository,
            PartsRequisitionItemRepository requisitionItemRepository,
            PurchaseOrderRepository purchaseOrderRepository,
            PurchaseOrderItemRepository purchaseOrderItemRepository,
            PurchaseReceiptRepository receiptRepository,
            PurchaseReceiptItemRepository receiptItemRepository,
            StockLocationRepository stockLocationRepository,
            StockMovementRepository stockMovementRepository,
            SupplierRepository supplierRepository,
            EmployeeRepository employeeRepository,
            StockReservationRepository stockReservationRepository
    ) {
        this.jobCardRepository = jobCardRepository;
        this.jobCardPartRepository = jobCardPartRepository;
        this.partRepository = partRepository;
        this.stockBalanceRepository = stockBalanceRepository;
        this.requisitionRepository = requisitionRepository;
        this.requisitionItemRepository = requisitionItemRepository;
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.purchaseOrderItemRepository = purchaseOrderItemRepository;
        this.receiptRepository = receiptRepository;
        this.receiptItemRepository = receiptItemRepository;
        this.stockLocationRepository = stockLocationRepository;
        this.stockMovementRepository = stockMovementRepository;
        this.supplierRepository = supplierRepository;
        this.employeeRepository = employeeRepository;
        this.stockReservationRepository = stockReservationRepository;
    }

    @Transactional(readOnly = true)
    public PartsAvailabilityResponse checkAvailability(Long jobCardId) {
        JobCard card = getJobCard(jobCardId);
        List<JobCardPart> requirements = jobCardPartRepository
                .findByJobCard_IdOrderByIdAsc(jobCardId);

        Map<Long, BigDecimal> totalsRequired = new HashMap<>();
        Map<Long, Part> partsById = new HashMap<>();
        Map<Long, List<Long>> requirementIdsByPart = new HashMap<>();
        Map<Long, Set<String>> categoriesByPart = new HashMap<>();
        for (JobCardPart requirement : requirements) {
            Part part = resolvePart(requirement, card);
            partsById.put(part.getId(), part);
            requirementIdsByPart.computeIfAbsent(part.getId(), ignored -> new ArrayList<>())
                    .add(requirement.getId());
            if (requirement.getPartCategory() != null) {
                categoriesByPart.computeIfAbsent(part.getId(), ignored -> new TreeSet<>())
                        .add(requirement.getPartCategory());
            }
            totalsRequired.merge(part.getId(), amount(requirement.getQuantity()), BigDecimal::add);
        }

        Map<Long, StockTotals> stock = new HashMap<>();
        for (Long partId : totalsRequired.keySet().stream().sorted().toList()) {
            stock.put(partId, readStock(
                partId,
                card.getJob().getWorkshop().getId(),
                card.getId()
        ));
        }

        List<PartsAvailabilityResponse.Line> lines = new ArrayList<>();
        for (Long partId : totalsRequired.keySet().stream().sorted().toList()) {
            Part part = partsById.get(partId);
            StockTotals totals = stock.getOrDefault(partId, StockTotals.ZERO);
            BigDecimal required = totalsRequired.get(partId);
            BigDecimal available = totals.availableForJob();
                BigDecimal shortage = maxZero(required.subtract(available));

                String status = shortage.signum() == 0
                        ? "AVAILABLE"
                        : available.signum() == 0 ? "UNAVAILABLE" : "PARTIAL";

            lines.add(new PartsAvailabilityResponse.Line(
                        requirementIdsByPart.get(partId),
                        part.getId(),
                        part.getPartCode(),
                        part.getPartName(),
                        String.join(", ", categoriesByPart.getOrDefault(partId, Set.of())),
                        required,
                        totals.onHand(),
                        totals.reserved(),
                        available,
                        shortage,
                        status,
                        totals.reservedForThisJob(),
                        totals.reservedForOtherJobs(),
                        totals.availableToReserve()
                ));
        }

        return new PartsAvailabilityResponse(
                card.getJob().getId(), card.getJob().getJobNumber(), card.getId(), lines
        );
    }

    @Transactional
        public StockReservationResponse reserveStock(
                Long jobCardId,
                Long jobCardPartId,
                ReserveStockRequest request
        ) {
        JobCard card = getJobCard(jobCardId);

        JobCardPart requirement = jobCardPartRepository
        .findByIdAndJobCard_IdForUpdate(jobCardPartId, jobCardId)
        .orElseThrow(() -> new IllegalArgumentException(
                "Job card part not found."
        ));

        Part part = resolvePart(requirement, card);

        Employee employee = requireEmployee(
                request.reservedByEmployeeId(),
                card.getJob().getCompany().getId(),
                card.getJob().getWorkshop().getId()
        );

        StockLocation location = stockLocationRepository
                .lockActiveLocation(
                        request.stockLocationId(),
                        card.getJob().getWorkshop().getId()
                )
                .orElseThrow(() -> notFound("Active stock location not found"));

        List<StockBalance> balances = stockBalanceRepository
                .lockActiveBalances(part.getId(), card.getJob().getWorkshop().getId());

        StockBalance balance = balances.stream()
                .filter(b -> b.getLocation().getId().equals(location.getId()))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "There is no stock balance for this part at the selected location"
                ));

        BigDecimal alreadyReservedForRequirement =
        stockReservationRepository.sumActiveForJobPart(jobCardPartId);

        BigDecimal outstandingRequirement = maxZero(
                amount(requirement.getQuantity()).subtract(alreadyReservedForRequirement)
        );

        BigDecimal requested = amount(request.quantity());

        if (requested.compareTo(outstandingRequirement) > 0) {
                throw badRequest(
                        "Reservation exceeds the outstanding quantity for this job-card part. "
                                + "Outstanding quantity: " + outstandingRequirement
                );
        }

        BigDecimal freeStock = maxZero(
                amount(balance.getQuantityOnHand())
                        .subtract(amount(balance.getQuantityReserved()))
        );

        if (requested.compareTo(freeStock) > 0) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "Insufficient unreserved stock at this location. Available to reserve: "
                                + freeStock
                );
        }

        StockReservation reservation = new StockReservation();
        reservation.setJobCardPart(requirement);
        reservation.setStockBalance(balance);
        reservation.setQuantityReserved(requested);
        reservation.setReservationStatus("ACTIVE");
        reservation.setReservedBy(employee);
        reservation.setReservedAt(LocalDateTime.now());
        reservation.setNotes(trimToNull(request.notes()));

        balance.setQuantityReserved(
                amount(balance.getQuantityReserved()).add(requested)
        );

        stockBalanceRepository.save(balance);
        reservation = stockReservationRepository.saveAndFlush(reservation);

        return reservationResponse(reservation);
        }

        @Transactional
        public StockReservationResponse releaseReservation(
                Long reservationId,
                ReleaseStockReservationRequest request
        ) {
        StockReservation reservation = stockReservationRepository
        .findByIdForUpdate(reservationId)
        .orElseThrow(() -> notFound("Stock reservation not found"));

        if (!"ACTIVE".equals(reservation.getReservationStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "Only active reservations can be released"
                );
        }

        JobCard card = reservation.getJobCardPart().getJobCard();

        Employee employee = requireEmployee(
                request.releasedByEmployeeId(),
                card.getJob().getCompany().getId(),
                card.getJob().getWorkshop().getId()
        );

        StockBalance originalBalance = reservation.getStockBalance();

        List<StockBalance> lockedBalances = stockBalanceRepository.lockPartAtLocation(
                originalBalance.getPart().getId(),
                originalBalance.getLocation().getId()
        );

        if (lockedBalances.isEmpty()) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "The stock balance for this reservation no longer exists"
                );
        }

        StockBalance balance = lockedBalances.get(0);
        BigDecimal reservedQuantity = amount(reservation.getQuantityReserved());
        BigDecimal aggregateReserved = amount(balance.getQuantityReserved());

        if (aggregateReserved.compareTo(reservedQuantity) < 0) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "Stock reservation totals are inconsistent. Reconcile stock before releasing."
                );
        }

        balance.setQuantityReserved(aggregateReserved.subtract(reservedQuantity));
        stockBalanceRepository.save(balance);

        reservation.setReservationStatus("RELEASED");
        reservation.setReleasedBy(employee);
        reservation.setReleasedAt(LocalDateTime.now());

        String releaseNotes = trimToNull(request.notes());
        if (releaseNotes != null) {
                reservation.setNotes(releaseNotes);
        }

        stockReservationRepository.save(reservation);

        return reservationResponse(reservation);
        }

        @Transactional(readOnly = true)
        public List<StockReservationResponse> getJobReservations(Long jobCardId) {
        getJobCard(jobCardId);

        return stockReservationRepository
                .findByJobCardPart_JobCard_IdAndReservationStatusOrderByIdAsc(
                        jobCardId, "ACTIVE"
                )
                .stream()
                .map(this::reservationResponse)
                .toList();
        }

        private StockReservationResponse reservationResponse(StockReservation reservation) {
        StockBalance balance = reservation.getStockBalance();
        Part part = balance.getPart();
        StockLocation location = balance.getLocation();
        Employee employee = reservation.getReservedBy();

        return new StockReservationResponse(
                reservation.getId(),
                reservation.getJobCardPart().getId(),
                part.getId(),
                part.getPartCode(),
                part.getPartName(),
                balance.getId(),
                location.getId(),
                location.getLocationName(),
                reservation.getQuantityReserved(),
                reservation.getReservationStatus(),
                employee.getId(),
                reservation.getReservedAt(),
                reservation.getNotes()
        );
        }

    @Transactional
    public LinkJobCardPartResponse linkCatalogPart(
            Long jobCardId,
            Long jobCardPartId,
            LinkJobCardPartRequest request
    ) {
        JobCard card = getJobCard(jobCardId);
        Employee linker = requireEmployee(
                request.linkedByEmployeeId(), card.getJob().getCompany().getId(),
                card.getJob().getWorkshop().getId()
        );
        JobCardPart requirement = jobCardPartRepository
                .findByIdAndJobCard_Id(jobCardPartId, jobCardId)
                .orElseThrow(() -> notFound("Part requirement not found on this job card"));
        Part part = partRepository
                .findByIdAndCompany_IdAndActiveTrue(
                        request.partId(), card.getJob().getCompany().getId())
                .orElseThrow(() -> notFound("Active stock part not found for this company"));

        requirement.setPart(part);
        requirement.setPartCatalogLinkedBy(linker);
        requirement.setPartCatalogLinkedAt(LocalDateTime.now());
        requirement.setUnitOfMeasure(part.getUnitOfMeasure());
        jobCardPartRepository.save(requirement);

        return new LinkJobCardPartResponse(
                card.getId(), requirement.getId(), part.getId(), part.getPartCode(),
                part.getPartName(), linker.getFirstName() + " " + linker.getLastName(),
                requirement.getPartCatalogLinkedAt()
        );
    }

    @Transactional
    public PartsRequisitionResponse createShortageRequisition(
            Long jobId,
            CreatePartsRequisitionRequest request
    ) {
        JobCard card = jobCardRepository.findByJobIdForUpdate(jobId)
                .orElseThrow(() -> notFound("Job card not found for job"));
        ActorIdentity.requireCompanyWorkshop(
                card.getJob().getCompany().getId(), card.getJob().getWorkshop().getId());

        Long workshopId = card.getJob().getWorkshop().getId();
        
        Employee requester = requireEmployee(
                request.requestedByEmployeeId(), card.getJob().getCompany().getId(),
                card.getJob().getWorkshop().getId()
        );

        List<JobCardPart> requirements = jobCardPartRepository
                .findByJobCard_IdOrderByIdAsc(card.getId());
        if (requirements.isEmpty()) {
            throw badRequest("The job card has no part requirements");
        }

        Map<Long, PartShortage> shortages = new LinkedHashMap<>();
        Map<Long, BigDecimal> totalsRequired = new HashMap<>();
        Map<Long, Part> partsById = new HashMap<>();
        for (JobCardPart requirement : requirements) {
            Part part = resolvePart(requirement, card);
            partsById.put(part.getId(), part);
            totalsRequired.merge(part.getId(), amount(requirement.getQuantity()), BigDecimal::add);
        }

        for (Long partId : totalsRequired.keySet().stream().sorted().toList()) {
                StockTotals totals = lockAndReadStock(partId, workshopId, card.getId());

                BigDecimal outstandingProcurement = amount(
                        requisitionItemRepository.sumOutstandingByJobAndPart(
                                jobId,
                                partId,
                                List.of(
                                        "SUBMITTED",
                                        "PENDING_APPROVAL",
                                        "APPROVED",
                                        "PARTIALLY_FULFILLED"
                                )
                        )
                );

                BigDecimal shortage = maxZero(
                        totalsRequired.get(partId)
                                .subtract(totals.availableForJob())
                                .subtract(outstandingProcurement)
                );

                if (shortage.signum() > 0) {
                        shortages.put(
                                partId,
                                new PartShortage(partsById.get(partId), shortage)
                        );
                }
        }

        if (shortages.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "There is no stock shortage for this job card"
            );
        }

        PartsRequisition requisition = new PartsRequisition();
        requisition.setCompany(card.getJob().getCompany());
        requisition.setWorkshop(card.getJob().getWorkshop());
        requisition.setJob(card.getJob());
        requisition.setRequisitionNumber(newNumber("PR", card.getJob().getWorkshop().getId()));
        requisition.setRequestedBy(requester);
        requisition.setRequisitionStatus("SUBMITTED");
        requisition.setPriority(normalizePriority(request.priority()));
        requisition.setRequiredDate(request.requiredDate());
        requisition.setPurpose(trimToNull(request.purpose()));
        requisition.setSubmittedAt(LocalDateTime.now());
        requisition = requisitionRepository.saveAndFlush(requisition);

        List<PartsRequisitionResponse.Line> responseItems = new ArrayList<>();
        for (PartShortage shortage : shortages.values()) {
            PartsRequisitionItem item = new PartsRequisitionItem();
            item.setRequisition(requisition);
            item.setPart(shortage.part());
            item.setRequestedQuantity(shortage.quantity());
            item.setUnitOfMeasure(shortage.part().getUnitOfMeasure());
            item.setReasonForRequest("Job card " + card.getJobCardNumber() + " stock shortage");
            item.setItemStatus("PENDING");
            item = requisitionItemRepository.save(item);
            responseItems.add(new PartsRequisitionResponse.Line(
                    item.getId(), shortage.part().getId(), shortage.part().getPartCode(),
                    shortage.part().getPartName(), shortage.quantity(), item.getUnitOfMeasure()
            ));
        }

        return new PartsRequisitionResponse(
                requisition.getId(), requisition.getRequisitionNumber(), jobId,
                requisition.getRequisitionStatus(), requisition.getSubmittedAt(), responseItems
        );
    }

    @Transactional
    public PurchaseOrderResponse placeOutsideOrder(
            Long requisitionId,
            CreatePurchaseOrderRequest request
    ) {
        PartsRequisition requisition = requisitionRepository.findByIdForUpdate(requisitionId)
                .orElseThrow(() -> notFound("Parts requisition not found"));
        ActorIdentity.requireCompanyWorkshop(
                requisition.getCompany().getId(), requisition.getWorkshop().getId());
        if (!Set.of("SUBMITTED", "APPROVED", "PARTIALLY_FULFILLED")
                .contains(requisition.getRequisitionStatus())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Only a submitted or partially fulfilled requisition can be ordered");
        }

        Supplier supplier = supplierRepository
                .findByIdAndCompany_IdAndActiveTrue(
                        request.supplierId(), requisition.getCompany().getId())
                .orElseThrow(() -> notFound("Active supplier not found for this company"));
        Employee buyer = requireEmployee(
                request.createdByEmployeeId(), requisition.getCompany().getId(),
                requisition.getWorkshop().getId()
        );

        PurchaseOrder order = new PurchaseOrder();
        order.setCompany(requisition.getCompany());
        order.setWorkshop(requisition.getWorkshop());
        order.setSupplier(supplier);
        order.setRequisition(requisition);
        order.setPurchaseOrderNumber(newNumber("PO", requisition.getWorkshop().getId()));
        order.setCreatedBy(buyer);
        order.setPurchaseOrderStatus("SENT_TO_SUPPLIER");
        order.setOrderDate(LocalDate.now());
        order.setExpectedDeliveryDate(request.expectedDeliveryDate());
        order.setSupplierReference(trimToNull(request.supplierReference()));
        order.setNotes(trimToNull(request.notes()));
        order.setCurrencyCode(requisition.getCompany().getCurrencyCode());
        order = purchaseOrderRepository.saveAndFlush(order);

        Set<Long> seenRequisitionItems = new HashSet<>();
        BigDecimal subtotal = BigDecimal.ZERO;
        BigDecimal totalTax = BigDecimal.ZERO;
        List<PurchaseOrderResponse.Line> responseItems = new ArrayList<>();

        for (CreatePurchaseOrderRequest.PurchaseOrderLineRequest line : request.items()) {
            if (!seenRequisitionItems.add(line.requisitionItemId())) {
                throw badRequest("A requisition item can appear only once in an order");
            }
            PartsRequisitionItem reqItem = requisitionItemRepository
                    .findByIdAndRequisition_Id(line.requisitionItemId(), requisitionId)
                    .orElseThrow(() -> badRequest("A purchase order line is not from this requisition"));
            BigDecimal alreadyOrdered = amount(purchaseOrderItemRepository
                    .sumOrderedByRequisitionItem(reqItem.getId()));
            BigDecimal remaining = maxZero(reqItem.getRequestedQuantity().subtract(alreadyOrdered));
            if (line.quantityOrdered().compareTo(remaining) > 0) {
                throw badRequest("Ordered quantity exceeds the un-ordered requisition quantity for "
                        + reqItem.getPart().getPartName());
            }

            BigDecimal tax = amount(line.taxAmount());
            BigDecimal lineSubtotal = amount(line.quantityOrdered().multiply(line.unitPrice()));
            BigDecimal lineTotal = lineSubtotal.add(tax);

            PurchaseOrderItem orderItem = new PurchaseOrderItem();
            orderItem.setPurchaseOrder(order);
            orderItem.setPart(reqItem.getPart());
            orderItem.setRequisitionItem(reqItem);
            orderItem.setDescriptionSnapshot(reqItem.getPart().getPartName());
            orderItem.setQuantityOrdered(amount(line.quantityOrdered()));
            orderItem.setQuantityReceived(BigDecimal.ZERO);
            orderItem.setUnitPrice(amount(line.unitPrice()));
            orderItem.setTaxAmount(tax);
            orderItem.setLineTotal(lineTotal);
            orderItem = purchaseOrderItemRepository.save(orderItem);

            subtotal = subtotal.add(lineSubtotal);
            totalTax = totalTax.add(tax);
            responseItems.add(orderLine(orderItem));
        }

        order.setSubtotal(subtotal);
        order.setTaxAmount(totalTax);
        order.setTotalAmount(subtotal.add(totalTax));
        order = purchaseOrderRepository.save(order);

        return new PurchaseOrderResponse(
                order.getId(), order.getPurchaseOrderNumber(), order.getPurchaseOrderStatus(),
                supplier.getSupplierName(), order.getExpectedDeliveryDate(), order.getSubtotal(),
                order.getTaxAmount(), order.getTotalAmount(), responseItems
        );
    }

    @Transactional
        public PartsRequisitionResponse cancelRequisition(
                Long requisitionId,
                CancelPartsRequisitionRequest request
        ) {
        PartsRequisition requisition = requisitionRepository
                .findByIdForUpdate(requisitionId)
                .orElseThrow(() -> notFound("Parts requisition not found"));
        ActorIdentity.requireCompanyWorkshop(
                requisition.getCompany().getId(), requisition.getWorkshop().getId());

        if ("CANCELLED".equals(requisition.getRequisitionStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "This requisition has already been cancelled"
                );
        }

        if ("FULFILLED".equals(requisition.getRequisitionStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "A fulfilled requisition cannot be cancelled"
                );
        }

        if ("REJECTED".equals(requisition.getRequisitionStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "A rejected requisition cannot be cancelled"
                );
        }

        if (purchaseOrderRepository.existsByRequisition_Id(requisitionId)) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "This requisition already has a purchase order. "
                                + "Cancel or resolve the purchase order first."
                );
        }

        List<PartsRequisitionItem> items =
                requisitionItemRepository.findByRequisition_IdOrderByIdAsc(requisitionId);

        boolean hasReceivedItems = items.stream()
                .anyMatch(item ->
                        amount(item.getFulfilledQuantity()).compareTo(BigDecimal.ZERO) > 0
                );

        if (hasReceivedItems) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "A requisition with received quantities cannot be cancelled"
                );
        }

        Employee cancelledBy = requireEmployee(
                request.cancelledByEmployeeId(),
                requisition.getCompany().getId(),
                requisition.getWorkshop().getId()
        );

        String reason = trimToNull(request.cancellationReason());

        if (reason == null) {
                throw badRequest("A cancellation reason is required");
        }

        requisition.setRequisitionStatus("CANCELLED");
        requisition.setCancelledBy(cancelledBy);
        requisition.setCancelledAt(LocalDateTime.now());
        requisition.setCancellationReason(reason);

        requisitionRepository.save(requisition);

        List<PartsRequisitionResponse.Line> responseItems = new ArrayList<>();

        for (PartsRequisitionItem item : items) {
                responseItems.add(new PartsRequisitionResponse.Line(
                        item.getId(),
                        item.getPart().getId(),
                        item.getPart().getPartCode(),
                        item.getPart().getPartName(),
                        item.getRequestedQuantity(),
                        item.getUnitOfMeasure()
                ));
        }

        return new PartsRequisitionResponse(
                requisition.getId(),
                requisition.getRequisitionNumber(),
                requisition.getJob().getId(),
                requisition.getRequisitionStatus(),
                requisition.getSubmittedAt(),
                responseItems
        );
        }

    @Transactional
    public PurchaseReceiptResponse receiveDelivery(
            Long purchaseOrderId,
            ReceivePurchaseOrderRequest request
    ) {
        PurchaseOrder order = purchaseOrderRepository.findByIdForUpdate(purchaseOrderId)
                .orElseThrow(() -> notFound("Purchase order not found"));
        ActorIdentity.requireCompanyWorkshop(order.getCompany().getId(), order.getWorkshop().getId());
        if (!Set.of("SENT_TO_SUPPLIER", "PARTIALLY_RECEIVED")
                .contains(order.getPurchaseOrderStatus())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Only an order sent to the supplier can receive a delivery");
        }

        Employee receiver = requireEmployee(
                request.receivedByEmployeeId(), order.getCompany().getId(),
                order.getWorkshop().getId()
        );
        StockLocation location = stockLocationRepository
                .lockActiveLocation(
                        request.stockLocationId(), order.getWorkshop().getId())
                .orElseThrow(() -> notFound("Active stock location not found for this workshop"));

        Set<Long> seenOrderItems = new HashSet<>();
        List<PurchaseOrderItem> orderItems = purchaseOrderItemRepository
                .findByPurchaseOrder_IdOrderByIdAsc(purchaseOrderId);
        if (request.items().isEmpty()) throw badRequest("At least one received item is required");

        PurchaseReceipt receipt = new PurchaseReceipt();
        receipt.setPurchaseOrder(order);
        receipt.setReceiptNumber(newNumber("GRN", order.getWorkshop().getId()));
        receipt.setReceivedBy(receiver);
        receipt.setStockLocation(location);
        receipt.setSupplierDeliveryReference(trimToNull(request.supplierDeliveryReference()));
        receipt.setReceivedAt(LocalDateTime.now());
        receipt.setNotes(trimToNull(request.notes()));
        receipt = receiptRepository.saveAndFlush(receipt);

        List<PurchaseReceiptResponse.Line> responseItems = new ArrayList<>();
        for (ReceivePurchaseOrderRequest.PurchaseReceiptLineRequest line : request.items()) {
            if (!seenOrderItems.add(line.purchaseOrderItemId())) {
                throw badRequest("A purchase order item can appear only once per receipt");
            }
            PurchaseOrderItem item = purchaseOrderItemRepository
                    .lockItem(purchaseOrderId, line.purchaseOrderItemId())
                    .orElseThrow(() -> badRequest("A received item does not belong to this purchase order"));

            BigDecimal delivered = amount(line.quantityDelivered());
            BigDecimal accepted = amount(line.quantityAccepted());
            BigDecimal rejected = delivered.subtract(accepted);
            BigDecimal outstanding = item.getQuantityOrdered().subtract(amount(item.getQuantityReceived()));
            if (accepted.compareTo(delivered) > 0) {
                throw badRequest("Accepted quantity cannot exceed delivered quantity");
            }
            if (delivered.compareTo(outstanding) > 0) {
                throw badRequest("Delivered quantity exceeds the remaining order quantity for "
                        + item.getPart().getPartName());
            }
            String discrepancy = trimToNull(line.discrepancyNotes());
            if (rejected.signum() > 0 && discrepancy == null) {
                throw badRequest("Explain the discrepancy for rejected quantity of "
                        + item.getPart().getPartName());
            }

            PurchaseReceiptItem receiptItem = new PurchaseReceiptItem();
            receiptItem.setReceipt(receipt);
            receiptItem.setPurchaseOrderItem(item);
            receiptItem.setQuantityDelivered(delivered);
            receiptItem.setQuantityAccepted(accepted);
            receiptItem.setQuantityRejected(rejected);
            receiptItem.setDiscrepancyNotes(discrepancy);
            receiptItemRepository.save(receiptItem);

            BigDecimal newOnHand = BigDecimal.ZERO;
            if (accepted.signum() > 0) {
                StockBalance balance = getOrCreateBalance(item.getPart(), location);
                balance.setQuantityOnHand(balance.getQuantityOnHand().add(accepted));
                stockBalanceRepository.save(balance);
                newOnHand = balance.getQuantityOnHand();

                StockMovement movement = new StockMovement();
                movement.setPart(item.getPart());
                movement.setStockLocation(location);
                movement.setMovementType("PURCHASE_RECEIPT");
                movement.setQuantity(accepted);
                movement.setUnitCost(line.unitCost() == null
                        ? item.getUnitPrice() : amount(line.unitCost()));
                movement.setReferenceType("PURCHASE_RECEIPT");
                movement.setReferenceId(receipt.getId());
                movement.setPerformedBy(receiver);
                movement.setRemarks("Accepted from " + order.getPurchaseOrderNumber()
                        + (discrepancy == null ? "" : ": " + discrepancy));
                stockMovementRepository.save(movement);

                item.setQuantityReceived(amount(item.getQuantityReceived()).add(accepted));
                purchaseOrderItemRepository.save(item);

                PartsRequisitionItem reqItem = item.getRequisitionItem();
                if (reqItem != null) {
                    reqItem.setFulfilledQuantity(amount(reqItem.getFulfilledQuantity()).add(accepted));
                    if (reqItem.getFulfilledQuantity().compareTo(reqItem.getRequestedQuantity()) >= 0) {
                        reqItem.setItemStatus("FULFILLED");
                    } else {
                        reqItem.setItemStatus("PARTIALLY_FULFILLED");
                    }
                    requisitionItemRepository.save(reqItem);
                }
            }

            responseItems.add(new PurchaseReceiptResponse.Line(
                    item.getId(), item.getPart().getId(), item.getPart().getPartName(),
                    delivered, accepted, rejected, newOnHand
            ));
        }

        boolean allOrderItemsReceived = orderItems.stream().allMatch(orderItem ->
                amount(orderItem.getQuantityReceived()).compareTo(orderItem.getQuantityOrdered()) >= 0);
        boolean anyOrderItemsReceived = orderItems.stream().anyMatch(orderItem ->
                amount(orderItem.getQuantityReceived()).signum() > 0);
        order.setPurchaseOrderStatus(allOrderItemsReceived ? "RECEIVED" :
                anyOrderItemsReceived ? "PARTIALLY_RECEIVED" : "SENT_TO_SUPPLIER");
        purchaseOrderRepository.save(order);

        if (order.getRequisition() != null) {
            updateRequisitionFulfillment(order.getRequisition());
        }

        return new PurchaseReceiptResponse(
                receipt.getId(), receipt.getReceiptNumber(), order.getId(),
                order.getPurchaseOrderStatus(), receipt.getReceivedAt(), responseItems
        );
    }

    private void updateRequisitionFulfillment(PartsRequisition requisition) {
        List<PartsRequisitionItem> items = requisitionItemRepository
                .findByRequisition_IdOrderByIdAsc(requisition.getId());
        boolean allFulfilled = !items.isEmpty() && items.stream().allMatch(item ->
                amount(item.getFulfilledQuantity()).compareTo(item.getRequestedQuantity()) >= 0);
        boolean anyFulfilled = items.stream().anyMatch(item ->
                amount(item.getFulfilledQuantity()).signum() > 0);
        if (allFulfilled) requisition.setRequisitionStatus("FULFILLED");
        else if (anyFulfilled) requisition.setRequisitionStatus("PARTIALLY_FULFILLED");
        requisitionRepository.save(requisition);
    }

    private PurchaseOrderResponse.Line orderLine(PurchaseOrderItem item) {
        return new PurchaseOrderResponse.Line(
                item.getId(), item.getRequisitionItem().getId(), item.getPart().getId(),
                item.getPart().getPartCode(), item.getPart().getPartName(),
                item.getQuantityOrdered(), amount(item.getQuantityReceived()),
                item.getUnitPrice(), item.getLineTotal()
        );
    }

    private JobCard getJobCard(Long id) {
        JobCard card = jobCardRepository.findById(id)
                .orElseThrow(() -> notFound("Job card not found"));
        ActorIdentity.requireCompanyWorkshop(
                card.getJob().getCompany().getId(), card.getJob().getWorkshop().getId());
        return card;
    }

    private Part resolvePart(JobCardPart requirement, JobCard card) {
        if (requirement.getQuantity() == null || requirement.getQuantity().signum() <= 0) {
            throw badRequest("Job card part quantities must be greater than zero");
        }
        Part part = requirement.getPart();
        if (part == null) {
            throw badRequest("Job card part '" + requirement.getPartName()
                    + "' is not linked to a stock catalogue part. Link its part number to the catalogue first.");
        }
        if (!part.getCompany().getId().equals(card.getJob().getCompany().getId())
                || !Boolean.TRUE.equals(part.getActive())) {
            throw badRequest("Job card references an inactive or foreign stock part");
        }
        return part;
    }

    private StockTotals readStock(Long partId, Long workshopId, Long jobCardId) {
        List<StockBalance> balances =
                stockBalanceRepository.findActiveBalances(partId, workshopId);

        return totals(balances, jobCardId);
        }

        private StockTotals lockAndReadStock(Long partId, Long workshopId, Long jobCardId) {
        List<StockBalance> balances =
                stockBalanceRepository.lockActiveBalances(partId, workshopId);

        return totals(balances, jobCardId);
        }

        private StockTotals totals(List<StockBalance> balances, Long jobCardId) {
        BigDecimal onHand = BigDecimal.ZERO;
        BigDecimal reserved = BigDecimal.ZERO;
        BigDecimal reservedForThisJob = BigDecimal.ZERO;

        for (StockBalance balance : balances) {
                onHand = onHand.add(amount(balance.getQuantityOnHand()));
                reserved = reserved.add(amount(balance.getQuantityReserved()));

                BigDecimal ownReservation =
                        stockReservationRepository.sumActiveForJobCardAndBalance(
                                jobCardId, balance.getId()
                        );

                reservedForThisJob = reservedForThisJob.add(amount(ownReservation));
        }

        BigDecimal reservedForOtherJobs =
                maxZero(reserved.subtract(reservedForThisJob));

        BigDecimal availableToReserve = maxZero(onHand.subtract(reserved));

        BigDecimal availableForJob =
                reservedForThisJob.add(availableToReserve);

        return new StockTotals(
                onHand,
                reserved,
                reservedForThisJob,
                reservedForOtherJobs,
                availableToReserve,
                availableForJob
        );
        }

    private StockBalance getOrCreateBalance(Part part, StockLocation location) {
        List<StockBalance> existing = stockBalanceRepository
                .lockPartAtLocation(part.getId(), location.getId());
        if (!existing.isEmpty()) return existing.get(0);
        StockBalance balance = new StockBalance();
        balance.setPart(part);
        balance.setLocation(location);
        balance.setQuantityOnHand(BigDecimal.ZERO);
        balance.setQuantityReserved(BigDecimal.ZERO);
        return balance;
    }

    private Employee requireEmployee(Long employeeId, Long companyId, Long workshopId) {
        ActorIdentity.requireEmployee(employeeId);
        ActorIdentity.requireCompanyWorkshop(companyId, workshopId);
        Employee employee = employeeRepository.findByIdAndCompanyId(employeeId, companyId)
                .orElseThrow(() -> notFound("Employee not found for this company"));
        if (!employee.getWorkshop().getId().equals(workshopId)) {
            throw badRequest("Employee does not belong to this workshop");
        }
        if (!"ACTIVE".equalsIgnoreCase(employee.getEmploymentStatus())) {
            throw badRequest("Employee is not active");
        }
        return employee;
    }

    private String normalizePriority(String priority) {
        String normalized = priority == null || priority.isBlank()
                ? "NORMAL" : priority.trim().toUpperCase(Locale.ROOT);
        if (!Set.of("LOW", "NORMAL", "HIGH", "URGENT").contains(normalized)) {
            throw badRequest("Priority must be LOW, NORMAL, HIGH, or URGENT");
        }
        return normalized;
    }

    private String newNumber(String prefix, Long workshopId) {
        String date = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
        String suffix = UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT);
        return prefix + "-" + workshopId + "-" + date + "-" + suffix;
    }

    private BigDecimal amount(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value.setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal maxZero(BigDecimal value) {
        return value.signum() < 0 ? BigDecimal.ZERO : value;
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private ResponseStatusException notFound(String message) {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, message);
    }

    private ResponseStatusException badRequest(String message) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, message);
    }

    private record StockTotals(
                BigDecimal onHand,
                BigDecimal reserved,
                BigDecimal reservedForThisJob,
                BigDecimal reservedForOtherJobs,
                BigDecimal availableToReserve,
                BigDecimal availableForJob
        ) {
        static final StockTotals ZERO = new StockTotals(
                BigDecimal.ZERO,
                BigDecimal.ZERO,
                BigDecimal.ZERO,
                BigDecimal.ZERO,
                BigDecimal.ZERO,
                BigDecimal.ZERO
        );
        }

    private record PartShortage(Part part, BigDecimal quantity) {}
}
