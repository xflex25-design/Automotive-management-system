
package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.WorkOrderStatusRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class WorkOrderExecutionService {

    private final WorkOrderRepository workOrderRepository;
    private final WorkOrderDepartmentVisitRepository visitRepository;
    private final WorkOrderActivityRepository activityRepository;
    private final EmployeeRepository employeeRepository;
    private final WorkOrderAssignmentRepository assignmentRepository;

    public WorkOrderExecutionService(
            WorkOrderRepository workOrderRepository,
            WorkOrderDepartmentVisitRepository visitRepository,
            WorkOrderActivityRepository activityRepository,
            EmployeeRepository employeeRepository,
            WorkOrderAssignmentRepository assignmentRepository
    ) {
        this.workOrderRepository = workOrderRepository;
        this.visitRepository = visitRepository;
        this.activityRepository = activityRepository;
        this.employeeRepository = employeeRepository;
        this.assignmentRepository = assignmentRepository;
    }

    @Transactional
    public Map<String, Object> changeStatus(
            Long workOrderId,
            WorkOrderStatusRequest request,
            String targetStatus
    ) {

        ActorIdentity.requireEmployee(request == null ? null : request.employeeId());

        WorkOrder workOrder = workOrderRepository.findById(workOrderId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Work order not found"
                ));

        Employee employee = employeeRepository.findById(request.employeeId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Employee not found"
                ));

        boolean assigned = assignmentRepository
                .existsByWorkOrder_IdAndEmployee_IdAndAssignmentStatusIn(
                        workOrderId,
                        employee.getId(),
                        List.of("ASSIGNED", "ACCEPTED")
                );

        if (!assigned) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Employee is not assigned to this work order"
            );
        }

        WorkOrderDepartmentVisit visit = visitRepository
                .findFirstByWorkOrder_IdAndVisitStatusOrderByVisitNumberDesc(
                        workOrderId, "OPEN"
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "Work order has no active department visit"
                ));

        String currentStatus = workOrder.getWorkOrderStatus();

        validateTransition(currentStatus, targetStatus);

        if ("IN_PROGRESS".equals(targetStatus)
                && workOrder.getStartedAt() == null) {
            workOrder.setStartedAt(LocalDateTime.now());
        }

        if ("IN_PROGRESS".equals(targetStatus)
                && "PAUSED".equals(currentStatus)) {
            // Resume: the original work start timestamp is preserved.
        }

        workOrder.setWorkOrderStatus(targetStatus);

        if ("WAITING".equals(targetStatus)) {
            // Waiting is recorded as a distinct work order status.
        }

        workOrderRepository.save(workOrder);

        WorkOrderActivity activity = new WorkOrderActivity();
        activity.setWorkOrder(workOrder);
        activity.setDepartmentVisit(visit);
        activity.setActivityType("STATUS_CHANGED");
        activity.setPreviousStatus(currentStatus);
        activity.setNewStatus(targetStatus);
        activity.setActivityDescription(request.notes());
        activity.setPerformedBy(employee);

        activityRepository.save(activity);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("workOrderId", workOrderId);
        response.put("workOrderNumber", workOrder.getWorkOrderNumber());
        response.put("previousStatus", currentStatus);
        response.put("newStatus", targetStatus);
        response.put("changedAt", LocalDateTime.now());
        response.put("employeeId", employee.getId());
        response.put("visitId", visit.getId());
        response.put("notes", request.notes());

        return response;
    }

    private void validateTransition(String current, String target) {

        boolean valid = switch (target) {
            case "IN_PROGRESS" ->
                    "ASSIGNED".equals(current)
                    || "READY".equals(current)
                    || "PAUSED".equals(current)
                    || "WAITING".equals(current);

            case "PAUSED" ->
                    "IN_PROGRESS".equals(current);

            case "WAITING" ->
                    "IN_PROGRESS".equals(current)
                    || "PAUSED".equals(current);

            default -> false;
        };

        if (!valid) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Invalid work order status transition: "
                            + current + " -> " + target
            );
        }
    }
}
