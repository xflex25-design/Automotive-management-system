package com.autogarage.automotive.dto.finalinspection;

public record DepartmentSignoffRequest(
        Long employeeId,
        String signoffStatus,
        String signoffNotes
) {
}