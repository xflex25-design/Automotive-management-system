package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record IssueDispatchRequest(
        @NotNull Long issuedByEmployeeId,
        @NotBlank String signerName,
        Long signatureMediaId,
        String remarks
) {}