package com.autogarage.automotive.dto.company;

import java.math.BigDecimal;

public record CompanySettingsRequest(
        String companyName,
        String registrationNumber,
        String vatNumber,
        String email,
        String phone,
        String address,
        String website,
        String currencyCode,
        BigDecimal vatRate,
        String bankName,
        String bankBranch,
        String bankAccountName,
        String bankAccountNumber,
        String bankSwiftCode
) {}