package com.autogarage.automotive.dto.invoice;

import java.time.LocalDate;

public record CreateInvoiceRequest(
        Long jobId,
        Long quotationId,
        Long issuedByEmployeeId,
        LocalDate dueDate,
        String notes
) {}