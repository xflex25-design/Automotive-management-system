package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "inventory_accessories")
@Getter
@Setter
@NoArgsConstructor
public class InventoryAccessory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inventory_card_id", nullable = false)
    private VehicleInventoryCard inventoryCard;

    @Column(name = "accessory_name", nullable = false, length = 120)
    private String accessoryName;

    @Column(name = "is_present", nullable = false)
    private Boolean present = false;

    @Column(name = "condition_description", length = 255)
    private String conditionDescription;

    @Column(columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}