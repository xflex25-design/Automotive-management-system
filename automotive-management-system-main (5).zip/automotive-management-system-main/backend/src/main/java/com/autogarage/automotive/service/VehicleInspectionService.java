package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.*;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class VehicleInspectionService {

    private final JobRepository jobRepository;
    private final EmployeeRepository employeeRepository;
    private final VehicleInventoryCardRepository inventoryCardRepository;
    private final InspectionRecordRepository inspectionRepository;
    private final InspectionItemRepository inspectionItemRepository;
    private final VehicleDamageRecordRepository damageRepository;
    private final InventoryAccessoryRepository accessoryRepository;
    private final InventoryReceivedItemRepository receivedItemRepository;

    public VehicleInspectionService(
            JobRepository jobRepository,
            EmployeeRepository employeeRepository,
            VehicleInventoryCardRepository inventoryCardRepository,
            InspectionRecordRepository inspectionRepository,
            InspectionItemRepository inspectionItemRepository,
            VehicleDamageRecordRepository damageRepository,
            InventoryAccessoryRepository accessoryRepository,
            InventoryReceivedItemRepository receivedItemRepository
    ) {
        this.jobRepository = jobRepository;
        this.employeeRepository = employeeRepository;
        this.inventoryCardRepository = inventoryCardRepository;
        this.inspectionRepository = inspectionRepository;
        this.inspectionItemRepository = inspectionItemRepository;
        this.damageRepository = damageRepository;
        this.accessoryRepository = accessoryRepository;
        this.receivedItemRepository = receivedItemRepository;
    }

    @Transactional
    public VehicleInspectionResponse createInspection(
            Long jobId,
            VehicleInspectionRequest request
    ) {

        ActorIdentity.requireEmployee(request.inspectedByEmployeeId());

        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Job not found"
                ));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        VehicleInventoryCard inventoryCard =
                inventoryCardRepository.findByJobId(jobId)
                        .orElseThrow(() -> new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Vehicle inventory card not found"
                        ));

        Employee inspector = employeeRepository
                .findByIdAndCompanyId(
                        request.inspectedByEmployeeId(),
                        job.getCompany().getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Inspecting employee not found for this company"
                ));

        if (!inspector.getWorkshop().getId()
                .equals(job.getWorkshop().getId())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Inspecting employee does not belong to this workshop"
            );
        }

        if (!"ACTIVE".equalsIgnoreCase(
                inspector.getEmploymentStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Inspecting employee is not active"
            );
        }

        InspectionRecord inspection = new InspectionRecord();

        inspection.setJob(job);
        inspection.setInventoryCard(inventoryCard);
        inspection.setInspectedBy(inspector);

        inspection.setInspectionType(
                defaultValue(request.inspectionType(), "INITIAL")
        );

        inspection.setOverallCondition(request.overallCondition());
        inspection.setInspectionNotes(request.inspectionNotes());
        inspection.setInspectionStatus("DRAFT");

        inspection = inspectionRepository.save(inspection);

        inventoryCard.setInspectedBy(inspector);
        inventoryCardRepository.save(inventoryCard);

        int itemsSaved = 0;
        int damagesSaved = 0;
        int accessoriesSaved = 0;
        int receivedItemsSaved = 0;
        java.util.List<VehicleInspectionResponse.DamageRecordResponse> damageRecords =
                new java.util.ArrayList<>();

        if (request.inspectionItems() != null) {
            for (InspectionItemRequest itemRequest :
                    request.inspectionItems()) {

                InspectionItem item = new InspectionItem();

                item.setInspection(inspection);
                item.setItemName(itemRequest.itemName().trim());
                item.setInspectionCategory(
                        trimToNull(itemRequest.inspectionCategory())
                );
                item.setConditionStatus(
                        trimToNull(itemRequest.conditionStatus())
                );
                item.setObservation(
                        trimToNull(itemRequest.observation())
                );
                item.setRequiresAttention(
                        Boolean.TRUE.equals(itemRequest.requiresAttention())
                );

                inspectionItemRepository.save(item);
                itemsSaved++;
            }
        }

        if (request.damages() != null) {
            for (VehicleDamageRequest damageRequest :
                    request.damages()) {

                VehicleDamageRecord damage =
                        new VehicleDamageRecord();

                damage.setInspection(inspection);
                damage.setInventoryCard(inventoryCard);
                damage.setDamageType(
                        damageRequest.damageType().trim()
                );
                damage.setDamageLocation(
                        damageRequest.damageLocation().trim()
                );
                damage.setDamageDescription(
                        trimToNull(damageRequest.damageDescription())
                );
                damage.setSeverity(
                        trimToNull(damageRequest.severity())
                );
                damage.setDiagramX(damageRequest.diagramX());
                damage.setDiagramY(damageRequest.diagramY());

                VehicleDamageRecord savedDamage = damageRepository.save(damage);
                damageRecords.add(new VehicleInspectionResponse.DamageRecordResponse(
                        savedDamage.getId(),
                        savedDamage.getDamageType(),
                        savedDamage.getDamageLocation()
                ));
                damagesSaved++;
            }
        }

        if (request.accessories() != null) {
            for (InventoryAccessoryRequest accessoryRequest :
                    request.accessories()) {

                InventoryAccessory accessory =
                        new InventoryAccessory();

                accessory.setInventoryCard(inventoryCard);
                accessory.setAccessoryName(
                        accessoryRequest.accessoryName().trim()
                );
                accessory.setPresent(
                        Boolean.TRUE.equals(accessoryRequest.present())
                );
                accessory.setConditionDescription(
                        trimToNull(
                                accessoryRequest.conditionDescription()
                        )
                );
                accessory.setRemarks(
                        trimToNull(accessoryRequest.remarks())
                );

                accessoryRepository.save(accessory);
                accessoriesSaved++;
            }
        }

        if (request.receivedItems() != null) {
            for (InventoryReceivedItemRequest itemRequest :
                    request.receivedItems()) {

                InventoryReceivedItem item =
                        new InventoryReceivedItem();

                item.setInventoryCard(inventoryCard);
                item.setItemName(itemRequest.itemName().trim());
                item.setDescription(
                        trimToNull(itemRequest.description())
                );
                item.setQuantity(
                        itemRequest.quantity() != null
                                ? itemRequest.quantity()
                                : 1
                );
                item.setConditionDescription(
                        trimToNull(itemRequest.conditionDescription())
                );

                receivedItemRepository.save(item);
                receivedItemsSaved++;
            }
        }

        return new VehicleInspectionResponse(
                inspection.getId(),
                job.getId(),
                job.getJobNumber(),
                inventoryCard.getId(),
                inspection.getInspectionType(),
                inspection.getInspectionStatus(),
                itemsSaved,
                damagesSaved,
                accessoriesSaved,
                receivedItemsSaved,
                damageRecords
        );
    }

    private String defaultValue(String value, String defaultValue) {
        return value == null || value.isBlank()
                ? defaultValue
                : value.trim().toUpperCase();
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank()
                ? null
                : value.trim();
    }
}
