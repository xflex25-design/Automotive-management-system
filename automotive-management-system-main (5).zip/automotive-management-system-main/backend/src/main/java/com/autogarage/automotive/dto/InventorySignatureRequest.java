package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record InventorySignatureRequest(

        Long authorisationId,

        @NotBlank
        @Size(max = 50)
        String signerType,

        @NotBlank
        @Size(max = 200)
        String signerName,

        Long employeeId,

        @NotNull
        Long signatureMediaId,

        String remarks
) {}