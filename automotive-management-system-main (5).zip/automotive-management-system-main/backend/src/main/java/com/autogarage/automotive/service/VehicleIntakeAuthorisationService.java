package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.InventoryAuthorisationRequest;
import com.autogarage.automotive.dto.InventorySignatureRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.Locale;

@Service
public class VehicleIntakeAuthorisationService {

    private final JobRepository jobRepository;
    private final VehicleInventoryCardRepository inventoryCardRepository;
    private final InventoryAuthorisationRepository authorisationRepository;
    private final InventorySignatureRepository signatureRepository;
    private final EmployeeRepository employeeRepository;
    private final MediaFileRepository mediaFileRepository;

    public VehicleIntakeAuthorisationService(
            JobRepository jobRepository,
            VehicleInventoryCardRepository inventoryCardRepository,
            InventoryAuthorisationRepository authorisationRepository,
            InventorySignatureRepository signatureRepository,
            EmployeeRepository employeeRepository,
            MediaFileRepository mediaFileRepository
    ) {
        this.jobRepository = jobRepository;
        this.inventoryCardRepository = inventoryCardRepository;
        this.authorisationRepository = authorisationRepository;
        this.signatureRepository = signatureRepository;
        this.employeeRepository = employeeRepository;
        this.mediaFileRepository = mediaFileRepository;
    }

    @Transactional
    public Long createAuthorisation(
            Long jobId,
            InventoryAuthorisationRequest request
    ) {
        ActorIdentity.employeeId();
        findJob(jobId); // Confirm that the job exists.
        VehicleInventoryCard card = findInventoryCard(jobId);

        InventoryAuthorisation authorisation =
                new InventoryAuthorisation();

        authorisation.setInventoryCard(card);
        authorisation.setAuthorisationType(
                request.authorisationType().trim().toUpperCase(Locale.ROOT)
        );
        authorisation.setAuthorisationStatus("PENDING");
        authorisation.setAuthorisationText(
                trimToNull(request.authorisationText())
        );
        authorisation.setAuthorisedByName(
                request.authorisedByName().trim()
        );
        authorisation.setAuthorisedByPhone(
                trimToNull(request.authorisedByPhone())
        );

        return authorisationRepository.save(authorisation).getId();
    }

    @Transactional
    public Long recordSignature(
            Long jobId,
            InventorySignatureRequest request
    ) {
        ActorIdentity.employeeId();
        Job job = findJob(jobId);
        VehicleInventoryCard card = findInventoryCard(jobId);

        String signerType = request.signerType()
                .trim()
                .toUpperCase(Locale.ROOT);

        if (!signerType.equals("CUSTOMER")
                && !signerType.equals("EMPLOYEE")) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Signer type must be CUSTOMER or EMPLOYEE"
            );
        }

        MediaFile signatureMedia = mediaFileRepository
                .findById(request.signatureMediaId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Signature image not found"
                ));

        if (!signatureMedia.getJob().getId().equals(jobId)
                || !signatureMedia.getInventoryCard().getId()
                .equals(card.getId())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Signature image does not belong to this job"
            );
        }

        if (!"SIGNATURE".equalsIgnoreCase(
                signatureMedia.getEvidenceType())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The uploaded media is not marked as a signature"
            );
        }

        InventoryAuthorisation authorisation = null;
        Employee employee = null;

        if (signerType.equals("CUSTOMER")) {
            if (request.authorisationId() == null) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Customer signatures must reference an authorisation"
                );
            }

            authorisation = authorisationRepository
                    .findById(request.authorisationId())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.NOT_FOUND,
                            "Authorisation not found"
                    ));

            if (!authorisation.getInventoryCard().getId()
                    .equals(card.getId())) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Authorisation does not belong to this job"
                );
            }

            if (!"PENDING".equalsIgnoreCase(
                    authorisation.getAuthorisationStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "This authorisation is no longer pending"
                );
            }

        } else {
            if (request.employeeId() == null) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Employee ID is required for employee acknowledgement"
                );
            }

            ActorIdentity.requireEmployee(request.employeeId());

            employee = employeeRepository
                    .findByIdAndCompanyId(
                            request.employeeId(),
                            job.getCompany().getId()
                    )
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.NOT_FOUND,
                            "Employee not found for this company"
                    ));

            if (!employee.getWorkshop().getId()
                    .equals(job.getWorkshop().getId())) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Employee does not belong to this workshop"
                );
            }

            if (!"ACTIVE".equalsIgnoreCase(
                    employee.getEmploymentStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Employee is not active"
                );
            }
        }

        InventorySignature signature = new InventorySignature();

        signature.setInventoryCard(card);
        signature.setAuthorisation(authorisation);
        signature.setSignerType(signerType);
        signature.setSignerName(request.signerName().trim());
        signature.setEmployee(employee);
        signature.setSignatureMediaId(signatureMedia.getId());
        signature.setRemarks(trimToNull(request.remarks()));

        InventorySignature saved = signatureRepository.save(signature);

        if (signerType.equals("CUSTOMER")) {
            authorisation.setAuthorisationStatus("AUTHORISED");
            authorisation.setAuthorisedByName(request.signerName().trim());
            authorisation.setAuthorisedAt(LocalDateTime.now());

            authorisationRepository.save(authorisation);
        }

        return saved.getId();
    }

    private Job findJob(Long jobId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Job not found"
                ));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());
        return job;
    }

    private VehicleInventoryCard findInventoryCard(Long jobId) {
        return inventoryCardRepository.findByJobId(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Vehicle inventory card not found"
                ));
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank()
                ? null
                : value.trim();
    }
}
