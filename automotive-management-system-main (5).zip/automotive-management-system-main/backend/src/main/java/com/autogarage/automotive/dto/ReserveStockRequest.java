package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;

public record ReserveStockRequest(
        @NotNull Long reservedByEmployeeId,
        @NotNull Long stockLocationId,
        @NotNull @Positive BigDecimal quantity,
        String notes
) {}