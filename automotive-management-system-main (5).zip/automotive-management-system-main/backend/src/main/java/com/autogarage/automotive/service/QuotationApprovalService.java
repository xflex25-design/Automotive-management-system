package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.QuotationApprovalResponse;
import com.autogarage.automotive.dto.QuotationItemApprovalResponse;
import com.autogarage.automotive.dto.VerifyQuotationRequest;
import com.autogarage.automotive.dto.CustomerQuotationApprovalView;
import com.autogarage.automotive.dto.QuotationResponse;
import com.autogarage.automotive.dto.CustomerItemDecisionRequest;
import com.autogarage.automotive.dto.SubmitCustomerApprovalRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class QuotationApprovalService {

    private final QuotationRepository quotationRepository;
    private final QuotationItemRepository quotationItemRepository;
    private final QuotationApprovalRepository approvalRepository;
    private final QuotationItemApprovalRepository itemApprovalRepository;
    private final EmployeeRepository employeeRepository;
    private final QuotationService quotationService;

    private final SecureRandom secureRandom = new SecureRandom();

    public QuotationApprovalService(
            QuotationRepository quotationRepository,
            QuotationItemRepository quotationItemRepository,
            QuotationApprovalRepository approvalRepository,
            QuotationItemApprovalRepository itemApprovalRepository,
            EmployeeRepository employeeRepository,
        QuotationService quotationService
    ) {
        this.quotationRepository = quotationRepository;
        this.quotationItemRepository = quotationItemRepository;
        this.approvalRepository = approvalRepository;
        this.itemApprovalRepository = itemApprovalRepository;
        this.employeeRepository = employeeRepository;
        this.quotationService = quotationService;
    }

    @Transactional
    public QuotationApprovalResponse verifyQuotation(
            Long quotationId,
            VerifyQuotationRequest request
    ) {
        ActorIdentity.requireEmployee(request == null ? null : request.verifiedByEmployeeId());
        LocalDateTime now = LocalDateTime.now();

        Quotation quotation = quotationRepository
                .findByIdForUpdate(quotationId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Quotation not found"
                ));

        if (!"ISSUED".equalsIgnoreCase(quotation.getQuotationStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Only issued quotations can be sent for customer approval"
            );
        }

        if (quotation.getValidUntil() != null
                && quotation.getValidUntil().isBefore(now.toLocalDate())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "This quotation has expired"
            );
        }

        Job job = quotation.getJob();
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        Employee foreman = employeeRepository
                .findByIdAndCompanyId(
                        request.verifiedByEmployeeId(),
                        job.getCompany().getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Verifying employee not found for this company"
                ));

        if (!foreman.getWorkshop().getId()
                .equals(job.getWorkshop().getId())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Verifying employee does not belong to this workshop"
            );
        }

        if (!"ACTIVE".equalsIgnoreCase(foreman.getEmploymentStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only active employees can verify quotations"
            );
        }

        String channel = request.notificationChannel() == null
                || request.notificationChannel().isBlank()
                ? "SMS"
                : request.notificationChannel().trim().toUpperCase(Locale.ROOT);

        if (!List.of("SMS", "WHATSAPP").contains(channel)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Notification channel must be SMS or WHATSAPP"
            );
        }

        Customer customer = job.getCustomer();

        if (customer.getPhone() == null || customer.getPhone().isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The customer must have a phone number before requesting approval"
            );
        }

        List<QuotationItem> quotationItems =
                quotationItemRepository.findByQuotationIdOrderByIdAsc(quotationId);

        if (quotationItems.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The quotation has no items to approve"
            );
        }

        // Prevent multiple active approval requests for one quotation.
        Optional<QuotationApproval> existingApprovalOptional =
                approvalRepository.findFirstByQuotationIdAndApprovalStatusOrderByCreatedAtDesc(
                        quotationId,
                        "PENDING"
                );

        if (existingApprovalOptional.isPresent()) {
            QuotationApproval existingApproval = existingApprovalOptional.get();

            if (existingApproval.getApprovalTokenExpiresAt() != null
                    && existingApproval.getApprovalTokenExpiresAt().isAfter(now)) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "This quotation already has a pending customer approval request"
                );
            }

            existingApproval.setApprovalStatus("EXPIRED");
            approvalRepository.save(existingApproval);
        }

        // Generate a secure token. Only its hash will be stored.
        String rawToken = generateSecureToken();
        String tokenHash = hashToken(rawToken);

        QuotationApproval approval = new QuotationApproval();

        approval.setQuotation(quotation);
        approval.setApprovalStatus("PENDING");
        approval.setCustomerNameSnapshot(getCustomerName(customer));
        approval.setCustomerPhoneSnapshot(customer.getPhone());
        approval.setApprovalMethod("ONLINE");
        approval.setApprovalTokenHash(tokenHash);

        approval.setVerifiedBy(foreman);
        approval.setVerifiedAt(now);
        approval.setVerificationNotes(trimToNull(request.verificationNotes()));

        approval.setNotificationStatus("NOT_SENT");
        approval.setNotificationChannel(channel);
        approval.setApprovalTokenExpiresAt(now.plusHours(72));

        // Use a separate variable so it can safely be captured by the lambda.
        final QuotationApproval savedApproval =
                approvalRepository.save(approval);

        // Every quotation item starts with a pending customer decision.
        List<QuotationItemApproval> itemApprovals =
                quotationItems.stream()
                        .map(item -> {
                            QuotationItemApproval itemApproval =
                                    new QuotationItemApproval();

                            itemApproval.setApproval(savedApproval);
                            itemApproval.setQuotationItem(item);
                            itemApproval.setItemApprovalStatus("PENDING");

                            return itemApproval;
                        })
                        .toList();

        itemApprovalRepository.saveAll(itemApprovals);

        String foremanName = (
                foreman.getFirstName() + " " + foreman.getLastName()
        ).trim();

        return mapToResponse(
                savedApproval,
                rawToken,
                foremanName
        );
    }

    @Transactional
        public CustomerQuotationApprovalView getCustomerQuotation(String rawToken) {

        if (rawToken == null || rawToken.isBlank()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Approval token is required"
                );
        }

        String tokenHash = hashToken(rawToken.trim());

        QuotationApproval approval = approvalRepository
                .findByApprovalTokenHash(tokenHash)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Invalid customer approval link"
                ));

        if (!"PENDING".equalsIgnoreCase(approval.getApprovalStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "This quotation approval request is no longer active"
                );
        }

        LocalDateTime now = LocalDateTime.now();

        if (approval.getApprovalTokenExpiresAt() == null
                || !approval.getApprovalTokenExpiresAt().isAfter(now)) {

        throw new ResponseStatusException(
                HttpStatus.GONE,
                "This customer approval link has expired"
        );
        }

        Quotation quotation = approval.getQuotation();

        if (!"ISSUED".equalsIgnoreCase(quotation.getQuotationStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "This quotation is no longer available for approval"
                );
        }

        QuotationResponse quotationDetails =
                quotationService.getQuotationDetails(quotation.getId());

        List<QuotationItemApprovalResponse> items =
                itemApprovalRepository
                        .findByApprovalIdOrderByIdAsc(approval.getId())
                        .stream()
                        .map(itemApproval -> {
                                QuotationItem item = itemApproval.getQuotationItem();

                                return new QuotationItemApprovalResponse(
                                        itemApproval.getId(),
                                        item.getId(),
                                        item.getItemType(),
                                        item.getDescription(),
                                        item.getQuantity(),
                                        item.getUnitOfMeasure(),
                                        item.getUnitPrice(),
                                        item.getLineTotal(),
                                        itemApproval.getItemApprovalStatus(),
                                        itemApproval.getCustomerComments()
                                );
                        })
                        .toList();

        return new CustomerQuotationApprovalView(
                approval.getId(),
                approval.getApprovalStatus(),
                approval.getApprovalTokenExpiresAt(),
                quotationDetails,
                items
        );
        }

    @Transactional
        public QuotationApprovalResponse submitCustomerApproval(
                SubmitCustomerApprovalRequest request
        ) {
        String tokenHash = hashToken(request.token().trim());

        QuotationApproval approval = approvalRepository
                .findByApprovalTokenHashForUpdate(tokenHash)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Invalid customer approval link"
                ));

        if (!"PENDING".equalsIgnoreCase(approval.getApprovalStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "This approval request has already been submitted or is no longer active"
                );
        }

        LocalDateTime now = LocalDateTime.now();

        if (approval.getApprovalTokenExpiresAt() == null
                || !approval.getApprovalTokenExpiresAt().isAfter(now)) {
                throw new ResponseStatusException(
                        HttpStatus.GONE,
                        "This customer approval link has expired"
                );
        }

        if (!"ISSUED".equalsIgnoreCase(
                approval.getQuotation().getQuotationStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "This quotation is no longer available for approval"
                );
        }

        List<QuotationItemApproval> existingItems =
                itemApprovalRepository.findByApprovalIdOrderByIdAsc(
                        approval.getId()
                );

        if (existingItems.isEmpty()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "There are no quotation items to approve"
                );
        }

        // Every quotation item must receive exactly one decision.
        Set<Long> expectedItemIds = existingItems.stream()
                .map(item -> item.getQuotationItem().getId())
                .collect(Collectors.toSet());

        Set<Long> submittedItemIds = request.decisions().stream()
                .map(CustomerItemDecisionRequest::quotationItemId)
                .collect(Collectors.toSet());

        if (submittedItemIds.size() != request.decisions().size()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Duplicate quotation item decisions are not allowed"
                );
        }

        if (!expectedItemIds.equals(submittedItemIds)) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "You must submit a decision for every quotation item"
                );
        }

        int approvedCount = 0;
        int rejectedCount = 0;

        for (CustomerItemDecisionRequest decision : request.decisions()) {

                String status = decision.decision().trim().toUpperCase(Locale.ROOT);

                QuotationItemApproval itemApproval = existingItems.stream()
                        .filter(item -> item.getQuotationItem().getId()
                                .equals(decision.quotationItemId()))
                        .findFirst()
                        .orElseThrow();

                if (!"PENDING".equalsIgnoreCase(
                        itemApproval.getItemApprovalStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "A quotation item has already been decided"
                );
                }

                itemApproval.setItemApprovalStatus(status);

                if ("APPROVED".equals(status)) {
                approvedCount++;
                } else {
                rejectedCount++;
                }
        }

        itemApprovalRepository.saveAll(existingItems);

        // Determine the final quotation approval outcome.
        String finalStatus;

        if (approvedCount == existingItems.size()) {
                finalStatus = "APPROVED";
                approval.setApprovedAt(now);
        } else if (rejectedCount == existingItems.size()) {
                finalStatus = "REJECTED";
                approval.setRejectedAt(now);
        } else {
                finalStatus = "PARTIALLY_APPROVED";
        }

        approval.setApprovalStatus(finalStatus);
        approval.setCustomerComments(trimToNull(request.customerComments()));
        approval.setDecisionSubmittedAt(now);

        QuotationApproval savedApproval =
                approvalRepository.save(approval);

        return mapToResponse(
                savedApproval,
                null,
                getEmployeeName(savedApproval.getVerifiedBy())
        );
        }

    @Transactional(readOnly = true)
    public List<QuotationApprovalResponse> getQuotationApprovals(
            Long quotationId
    ) {
        Quotation quotation = quotationRepository.findById(quotationId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Quotation not found"));
        ActorIdentity.requireCompanyWorkshop(
                quotation.getJob().getCompany().getId(),
                quotation.getJob().getWorkshop().getId());

        return approvalRepository
                .findByQuotationIdOrderByCreatedAtDesc(quotationId)
                .stream()
                .map(approval -> mapToResponse(
                        approval,
                        null,
                        getEmployeeName(approval.getVerifiedBy())
                ))
                .toList();
    }

    @Transactional(readOnly = true)
    public QuotationApprovalResponse getApprovalDetails(Long approvalId) {

        QuotationApproval approval = approvalRepository.findById(approvalId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Quotation approval not found"
                ));
        ActorIdentity.requireCompanyWorkshop(
                approval.getQuotation().getJob().getCompany().getId(),
                approval.getQuotation().getJob().getWorkshop().getId());

        return mapToResponse(
                approval,
                null,
                getEmployeeName(approval.getVerifiedBy())
        );
    }

    private String getEmployeeName(Employee employee) {
        if (employee == null) {
            return null;
        }

        return (
                employee.getFirstName() + " "
                + employee.getLastName()
        ).trim();
    }

    private QuotationApprovalResponse mapToResponse(
            QuotationApproval approval,
            String rawToken,
            String foremanName
    ) {

        List<QuotationItemApprovalResponse> items =
                itemApprovalRepository
                        .findByApprovalIdOrderByIdAsc(approval.getId())
                        .stream()
                        .map(itemApproval -> {
                            QuotationItem item =
                                    itemApproval.getQuotationItem();

                            return new QuotationItemApprovalResponse(
                                    itemApproval.getId(),
                                    item.getId(),
                                    item.getItemType(),
                                    item.getDescription(),
                                    item.getQuantity(),
                                    item.getUnitOfMeasure(),
                                    item.getUnitPrice(),
                                    item.getLineTotal(),
                                    itemApproval.getItemApprovalStatus(),
                                    itemApproval.getCustomerComments()
                            );
                        })
                        .toList();

        Quotation quotation = approval.getQuotation();

        Employee verifiedBy = approval.getVerifiedBy();

        Long verifiedById = verifiedBy == null
                ? null
                : verifiedBy.getId();

        return new QuotationApprovalResponse(
                approval.getId(),
                quotation.getId(),
                quotation.getQuotationNumber(),
                approval.getCustomerNameSnapshot(),
                approval.getCustomerPhoneSnapshot(),
                approval.getApprovalStatus(),
                approval.getApprovalMethod(),
                verifiedById,
                foremanName,
                approval.getVerifiedAt(),
                approval.getVerificationNotes(),
                approval.getNotificationStatus(),
                approval.getNotificationChannel(),
                approval.getNotificationSentAt(),
                approval.getApprovalTokenExpiresAt(),
                rawToken,
                items
        );
    }

    private String generateSecureToken() {
        byte[] bytes = new byte[32];
        secureRandom.nextBytes(bytes);

        return Base64.getUrlEncoder()
                .withoutPadding()
                .encodeToString(bytes);
    }

    private String hashToken(String token) {
        try {
            MessageDigest digest =
                    MessageDigest.getInstance("SHA-256");

            byte[] hash = digest.digest(
                    token.getBytes(StandardCharsets.UTF_8)
            );

            return java.util.HexFormat.of().formatHex(hash);

        } catch (Exception exception) {
            throw new IllegalStateException(
                    "Could not generate approval token hash",
                    exception
            );
        }
    }

    private String getCustomerName(Customer customer) {

        if (customer.getCompanyName() != null
                && !customer.getCompanyName().isBlank()) {
            return customer.getCompanyName();
        }

        return (
                (customer.getFirstName() == null
                        ? "" : customer.getFirstName())
                + " "
                + (customer.getLastName() == null
                        ? "" : customer.getLastName())
        ).trim();
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank()
                ? null
                : value.trim();
    }
}
