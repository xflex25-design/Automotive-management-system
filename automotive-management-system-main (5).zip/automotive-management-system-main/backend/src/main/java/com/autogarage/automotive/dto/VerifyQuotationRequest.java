package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record VerifyQuotationRequest(

        @NotNull
        Long verifiedByEmployeeId,

        @Size(max = 4000)
        String verificationNotes,

        @Size(max = 30)
        String notificationChannel

) {}