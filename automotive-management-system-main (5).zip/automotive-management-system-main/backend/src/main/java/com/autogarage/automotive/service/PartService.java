package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.CreatePartRequest;
import com.autogarage.automotive.dto.PartResponse;
import com.autogarage.automotive.entity.Company;
import com.autogarage.automotive.entity.Part;
import com.autogarage.automotive.repository.CompanyRepository;
import com.autogarage.automotive.repository.PartRepository;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.List;

@Service
public class PartService {

    private final PartRepository partRepository;
    private final CompanyRepository companyRepository;

    public PartService(
            PartRepository partRepository,
            CompanyRepository companyRepository
    ) {
        this.partRepository = partRepository;
        this.companyRepository = companyRepository;
    }

    @Transactional
    public PartResponse createPart(Long companyId, CreatePartRequest request) {
        ActorIdentity.requireCompany(companyId);

        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Company not found"
                ));

        if (!Boolean.TRUE.equals(company.getActive())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Cannot add parts to an inactive company"
            );
        }

        String partCode = request.partCode().trim();

        if (partRepository.existsByCompany_IdAndPartCodeIgnoreCase(
                companyId, partCode
        )) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "A part with code " + partCode + " already exists for this company"
            );
        }

        Part part = new Part();
        part.setCompany(company);
        part.setPartCode(partCode);
        part.setPartName(request.partName().trim());
        part.setDescription(trimToNull(request.description()));
        part.setCategory(trimToNull(request.category()));
        part.setBrand(trimToNull(request.brand()));
        part.setUnitOfMeasure(
                request.unitOfMeasure() == null || request.unitOfMeasure().isBlank()
                        ? "Piece" : request.unitOfMeasure().trim()
        );
        part.setBarcode(trimToNull(request.barcode()));
        part.setMinimumStockLevel(
                request.minimumStockLevel() == null
                        ? BigDecimal.ZERO
                        : request.minimumStockLevel()
        );
        part.setActive(true);

        return toResponse(partRepository.save(part));
    }

    @Transactional(readOnly = true)
    public List<PartResponse> getParts(Long companyId, boolean activeOnly) {
        ActorIdentity.requireCompany(companyId);

        if (!companyRepository.existsById(companyId)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Company not found"
            );
        }

        List<Part> parts = activeOnly
                ? partRepository.findByCompany_IdAndActiveTrueOrderByPartNameAsc(companyId)
                : partRepository.findByCompany_IdOrderByPartNameAsc(companyId);

        return parts.stream()
                .map(this::toResponse)
                .toList();
    }

    private PartResponse toResponse(Part part) {
        return new PartResponse(
                part.getId(),
                part.getCompany().getId(),
                part.getPartCode(),
                part.getPartName(),
                part.getDescription(),
                part.getCategory(),
                part.getBrand(),
                part.getUnitOfMeasure(),
                part.getBarcode(),
                part.getMinimumStockLevel(),
                part.getActive()
        );
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
