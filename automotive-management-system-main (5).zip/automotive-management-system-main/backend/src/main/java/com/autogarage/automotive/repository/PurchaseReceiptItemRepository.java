package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.PurchaseReceiptItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PurchaseReceiptItemRepository extends JpaRepository<PurchaseReceiptItem, Long> {
}
