package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkOrderDependency;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkOrderDependencyRepository
        extends JpaRepository<WorkOrderDependency, Long> {

    List<WorkOrderDependency> findByWorkOrder_Id(Long workOrderId);

    List<WorkOrderDependency> findByDependsOnWorkOrder_Id(Long workOrderId);

    boolean existsByWorkOrder_IdAndDependsOnWorkOrder_Id(
            Long workOrderId,
            Long dependsOnWorkOrderId
    );
}