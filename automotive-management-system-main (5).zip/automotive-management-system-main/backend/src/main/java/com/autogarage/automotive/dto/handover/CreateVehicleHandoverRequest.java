package com.autogarage.automotive.dto.handover;

public record CreateVehicleHandoverRequest(
    Long jobId,
    Long invoiceId,
    Long releasedByEmployeeId,

    String collectorName,
    String collectorPhone,
    String collectorIdType,
    String collectorIdNumber,
    String collectorRelationship,
    Boolean customerCollected,

    Boolean keysHandedOver,
    Boolean documentsHandedOver,
    String vehicleConditionAtRelease,

    Boolean customerAcknowledged,
    String acknowledgementText,
    String collectorSignatureBase64,

    String notes
) {}