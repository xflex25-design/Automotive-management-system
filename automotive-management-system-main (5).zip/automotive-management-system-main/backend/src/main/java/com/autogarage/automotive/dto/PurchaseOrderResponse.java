package com.autogarage.automotive.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record PurchaseOrderResponse(
        Long purchaseOrderId,
        String purchaseOrderNumber,
        String status,
        String supplierName,
        LocalDate expectedDeliveryDate,
        BigDecimal subtotal,
        BigDecimal taxAmount,
        BigDecimal totalAmount,
        List<Line> items
) {
    public record Line(Long purchaseOrderItemId, Long requisitionItemId,
                       Long partId, String partCode, String partName,
                       BigDecimal quantityOrdered, BigDecimal quantityReceived,
                       BigDecimal unitPrice, BigDecimal lineTotal) {}
}
