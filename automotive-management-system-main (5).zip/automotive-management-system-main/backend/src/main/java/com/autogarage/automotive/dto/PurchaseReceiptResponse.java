package com.autogarage.automotive.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record PurchaseReceiptResponse(
        Long receiptId,
        String receiptNumber,
        Long purchaseOrderId,
        String purchaseOrderStatus,
        LocalDateTime receivedAt,
        List<Line> items
) {
    public record Line(Long purchaseOrderItemId, Long partId, String partName,
                       BigDecimal quantityDelivered, BigDecimal quantityAccepted,
                       BigDecimal quantityRejected, BigDecimal newQuantityOnHand) {}
}
