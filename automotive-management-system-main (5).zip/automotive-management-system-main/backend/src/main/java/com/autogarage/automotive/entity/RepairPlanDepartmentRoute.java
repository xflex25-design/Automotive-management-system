package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "repair_plan_department_routes")
@Getter
@Setter
@NoArgsConstructor
public class RepairPlanDepartmentRoute {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "repair_plan_id", nullable = false)
    private RepairPlan repairPlan;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;

    @Column(name = "sequence_number", nullable = false)
    private Integer sequenceNumber;

    @Column(name = "applicability", nullable = false, length = 20)
    private String applicability;

    @Column(name = "not_applicable_reason", columnDefinition = "TEXT")
    private String notApplicableReason;
}
