package com.autogarage.automotive.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record CreatePartRequest(

        @NotBlank
        @Size(max = 100)
        String partCode,

        @NotBlank
        @Size(max = 255)
        String partName,

        String description,

        @Size(max = 150)
        String category,

        @Size(max = 150)
        String brand,

        @Size(max = 50)
        String unitOfMeasure,

        @Size(max = 150)
        String barcode,

        @DecimalMin("0.00")
        @Digits(integer = 10, fraction = 2)
        BigDecimal minimumStockLevel
) {}