package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public record CustomerItemDecisionRequest(

        @NotNull(message = "Quotation item ID is required")
        Long quotationItemId,
        
        @NotBlank(message = "An item decision is required")
        @Pattern(
                regexp = "(?i)APPROVED|REJECTED",
                message = "Decision must be APPROVED or REJECTED"
        )
        String decision

) {}