
package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.BatchWorkOrderAssignmentRequest;
import com.autogarage.automotive.service.WorkOrderAssignmentService;
import com.autogarage.automotive.dto.WorkOrderAssignmentResponseRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/work-order-assignments")
public class WorkOrderAssignmentController {

    private final WorkOrderAssignmentService assignmentService;

    public WorkOrderAssignmentController(
            WorkOrderAssignmentService assignmentService
    ) {
        this.assignmentService = assignmentService;
    }

    @PostMapping("/batch")
    public ResponseEntity<Map<String, Object>> assignWorkOrders(
            @RequestBody BatchWorkOrderAssignmentRequest request
    ) {
        Map<String, Object> response =
                assignmentService.assignWorkOrders(request);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/work-orders/{workOrderId}")
    public ResponseEntity<java.util.List<Map<String, Object>>> getWorkOrderAssignments(
            @PathVariable Long workOrderId) {
        return ResponseEntity.ok(assignmentService.getWorkOrderAssignments(workOrderId));
    }

    @PostMapping("/{assignmentId}/respond")
    public ResponseEntity<Map<String, Object>> respondToAssignment(
            @PathVariable Long assignmentId,
            @RequestBody WorkOrderAssignmentResponseRequest request
    ) {
        return ResponseEntity.ok(
                assignmentService.respondToAssignment(
                        assignmentId,
                        request
                )
        );
    }
}
