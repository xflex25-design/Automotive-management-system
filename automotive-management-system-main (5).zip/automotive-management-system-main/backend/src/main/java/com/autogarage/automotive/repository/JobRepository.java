package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Lock;

import java.util.List;
import java.util.Optional;

@Repository
public interface JobRepository extends JpaRepository<Job, Long> {

    Optional<Job> findByJobNumber(String jobNumber);

    List<Job> findByCompanyIdAndWorkshopIdOrderByDateReceivedDesc(
            Long companyId,
            Long workshopId
    );

    boolean existsByJobNumber(String jobNumber);

    @Query(
        value = "SELECT COALESCE(MAX(CAST(job_number AS UNSIGNED)), 0) " +
                "FROM jobs WHERE company_id = :companyId",
        nativeQuery = true
    )
    Long findHighestNumericJobNumberByCompanyId(
            @Param("companyId") Long companyId
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT j FROM Job j WHERE j.id = :jobId")
    Optional<Job> findByIdForUpdate(@Param("jobId") Long jobId);
}