package com.autogarage.automotive.dto;

import java.math.BigDecimal;

public record QuotationItemResponse(
        Long itemId,
        String itemType,
        String itemCode,
        String description,
        BigDecimal quantity,
        String unitOfMeasure,
        BigDecimal unitPrice,
        BigDecimal discountAmount,
        BigDecimal taxAmount,
        BigDecimal lineTotal,
        String remarks
) {}