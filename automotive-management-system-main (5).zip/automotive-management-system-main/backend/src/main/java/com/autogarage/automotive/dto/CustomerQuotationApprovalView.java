package com.autogarage.automotive.dto;

import java.time.LocalDateTime;
import java.util.List;

public record CustomerQuotationApprovalView(
        Long approvalId,
        String approvalStatus,
        LocalDateTime expiresAt,
        QuotationResponse quotation,
        List<QuotationItemApprovalResponse> items
) {}