package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(
    name = "vehicle_handovers",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uq_handover_number",
            columnNames = {"workshop_id", "handover_number"}
        ),
        @UniqueConstraint(
            name = "uq_handover_job",
            columnNames = {"job_id"}
        )
    }
)
@Getter
@Setter
@NoArgsConstructor
public class VehicleHandover {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "workshop_id", nullable = false)
    private Workshop workshop;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false)
    private Job job;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "invoice_id", nullable = false)
    private Invoice invoice;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "final_inspection_id", nullable = false)
    private FinalInspection finalInspection;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "released_by_employee_id", nullable = false)
    private Employee releasedBy;

    @Column(name = "handover_number", nullable = false, length = 100)
    private String handoverNumber;

    @Column(name = "collector_name", nullable = false, length = 200)
    private String collectorName;

    @Column(name = "collector_phone", nullable = false, length = 50)
    private String collectorPhone;

    @Column(name = "collector_id_type", nullable = false, length = 50)
    private String collectorIdType;

    @Column(name = "collector_id_number", nullable = false, length = 100)
    private String collectorIdNumber;

    @Column(name = "collector_relationship", length = 100)
    private String collectorRelationship;

    @Column(name = "customer_collected", nullable = false)
    private Boolean customerCollected = true;

    @Column(name = "keys_handed_over", nullable = false)
    private Boolean keysHandedOver = false;

    @Column(name = "documents_handed_over", nullable = false)
    private Boolean documentsHandedOver = false;

    @Column(name = "vehicle_condition_at_release", columnDefinition = "TEXT")
    private String vehicleConditionAtRelease;

    @Column(name = "customer_acknowledged", nullable = false)
    private Boolean customerAcknowledged = false;

    @Column(name = "acknowledgement_text", columnDefinition = "TEXT")
    private String acknowledgementText;

    @Lob
    @Column(name = "collector_signature", nullable = false, columnDefinition = "LONGBLOB")
    private byte[] collectorSignature;

    @Column(name = "signature_content_type", nullable = false, length = 50)
    private String signatureContentType = "image/png";

    @Column(columnDefinition = "TEXT")
    private String notes;

    @Column(name = "released_at", nullable = false)
    private LocalDateTime releasedAt;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}