
package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "final_inspection_items")
@Getter
@Setter
@NoArgsConstructor
public class FinalInspectionItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "final_inspection_id", nullable = false)
    private FinalInspection finalInspection;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "responsible_department_id")
    private Department responsibleDepartment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "checked_by_employee_id")
    private Employee checkedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "corrective_work_order_id")
    private WorkOrder correctiveWorkOrder;

    @Column(name = "item_code", nullable = false, length = 50)
    private String itemCode;

    @Column(name = "item_name", nullable = false, length = 255)
    private String itemName;

    @Column(name = "inspection_category", nullable = false, length = 150)
    private String inspectionCategory;

    @Column(name = "check_status", nullable = false, length = 30)
    private String checkStatus = "PENDING";

    @Column(columnDefinition = "TEXT")
    private String comments;

    @Column(name = "reinspection_required", nullable = false)
    private Boolean reinspectionRequired = false;

    @Column(name = "checked_at")
    private LocalDateTime checkedAt;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
