
package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.WorkOrderStatusRequest;
import com.autogarage.automotive.service.WorkOrderExecutionService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/work-orders")
public class WorkOrderExecutionController {

    private final WorkOrderExecutionService executionService;

    public WorkOrderExecutionController(
            WorkOrderExecutionService executionService
    ) {
        this.executionService = executionService;
    }

    @PostMapping("/{workOrderId}/start")
    public ResponseEntity<Map<String, Object>> start(
            @PathVariable Long workOrderId,
            @Valid @RequestBody WorkOrderStatusRequest request
    ) {
        return ResponseEntity.ok(
                executionService.changeStatus(
                        workOrderId, request, "IN_PROGRESS"
                )
        );
    }

    @PostMapping("/{workOrderId}/pause")
    public ResponseEntity<Map<String, Object>> pause(
            @PathVariable Long workOrderId,
            @Valid @RequestBody WorkOrderStatusRequest request
    ) {
        return ResponseEntity.ok(
                executionService.changeStatus(
                        workOrderId, request, "PAUSED"
                )
        );
    }

    @PostMapping("/{workOrderId}/resume")
    public ResponseEntity<Map<String, Object>> resume(
            @PathVariable Long workOrderId,
            @Valid @RequestBody WorkOrderStatusRequest request
    ) {
        return ResponseEntity.ok(
                executionService.changeStatus(
                        workOrderId, request, "IN_PROGRESS"
                )
        );
    }

    @PostMapping("/{workOrderId}/waiting")
    public ResponseEntity<Map<String, Object>> waiting(
            @PathVariable Long workOrderId,
            @Valid @RequestBody WorkOrderStatusRequest request
    ) {
        return ResponseEntity.ok(
                executionService.changeStatus(
                        workOrderId, request, "WAITING"
                )
        );
    }
}
