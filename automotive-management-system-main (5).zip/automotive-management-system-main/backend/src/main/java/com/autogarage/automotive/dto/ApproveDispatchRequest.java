package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record ApproveDispatchRequest(
        @NotNull Long approvedByEmployeeId,
        @NotBlank String signerName,
        Long signatureMediaId,
        String remarks
) {}