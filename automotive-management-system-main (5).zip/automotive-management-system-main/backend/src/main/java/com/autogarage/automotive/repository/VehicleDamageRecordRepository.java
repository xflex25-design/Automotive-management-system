package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.VehicleDamageRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VehicleDamageRecordRepository
        extends JpaRepository<VehicleDamageRecord, Long> {

    List<VehicleDamageRecord> findByInspectionIdOrderByCreatedAtDesc(
            Long inspectionId
    );

    List<VehicleDamageRecord> findByInventoryCard_Id(Long inventoryCardId);
}