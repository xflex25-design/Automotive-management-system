package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.PartsRequisitionItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface PartsRequisitionItemRepository
        extends JpaRepository<PartsRequisitionItem, Long> {

    List<PartsRequisitionItem> findByRequisition_IdOrderByIdAsc(Long requisitionId);

    Optional<PartsRequisitionItem> findByIdAndRequisition_Id(
            Long id,
            Long requisitionId
    );

    @Query("""
        select coalesce(
            sum(i.requestedQuantity - i.fulfilledQuantity),
            0
        )
        from PartsRequisitionItem i
        where i.requisition.job.id = :jobId
          and i.part.id = :partId
          and i.requisition.requisitionStatus in :statuses
    """)
    BigDecimal sumOutstandingByJobAndPart(
            @Param("jobId") Long jobId,
            @Param("partId") Long partId,
            @Param("statuses") List<String> statuses
    );
}