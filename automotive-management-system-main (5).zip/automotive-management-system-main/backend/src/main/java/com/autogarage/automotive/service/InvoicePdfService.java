
package com.autogarage.automotive.service;

import com.autogarage.automotive.entity.Invoice;
import com.autogarage.automotive.entity.InvoiceItem;
import com.autogarage.automotive.entity.Payment;
import com.autogarage.automotive.repository.InvoiceItemRepository;
import com.autogarage.automotive.repository.InvoiceRepository;
import com.autogarage.automotive.repository.PaymentRepository;
import com.autogarage.automotive.security.ActorIdentity;

import lombok.RequiredArgsConstructor;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

@Service
@RequiredArgsConstructor
public class InvoicePdfService {

    private final InvoiceRepository invoiceRepository;
    private final InvoiceItemRepository invoiceItemRepository;
    private final PaymentRepository paymentRepository;

    private static final float PAGE_WIDTH = PDRectangle.A4.getWidth();
    private static final float PAGE_HEIGHT = PDRectangle.A4.getHeight();

    private static final float LEFT = 45;
    private static final float RIGHT = PAGE_WIDTH - 45;
    private static final float CONTENT_WIDTH = RIGHT - LEFT;
    private static final float BOTTOM_MARGIN = 55;

    private static final PDType1Font REGULAR =
            new PDType1Font(Standard14Fonts.FontName.HELVETICA);

    private static final PDType1Font BOLD =
            new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);

    @Transactional(readOnly = true)
    public byte[] generateInvoicePdf(Long invoiceId) {

        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Invoice not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                invoice.getCompany().getId(), invoice.getWorkshop().getId());

        List<InvoiceItem> items =
                invoiceItemRepository.findByInvoice_IdOrderByIdAsc(invoiceId);

        List<Payment> payments =
                paymentRepository.findByInvoice_IdOrderByPaymentDateDesc(invoiceId);

        try (PDDocument document = new PDDocument()) {

            /*
             * IMPORTANT:
             * Load the company logo BEFORE opening any page content stream.
             */
            PDImageXObject logo = null;

            byte[] logoData = invoice.getCompany().getLogoData();

            if (logoData != null && logoData.length > 0) {
                logo = PDImageXObject.createFromByteArray(
                        document,
                        logoData,
                        "company-logo"
                );
            }

            ByteArrayOutputStream output = new ByteArrayOutputStream();

            try (PdfWriter writer = new PdfWriter(document)) {

                writer.newPage();

                drawHeader(writer, invoice, logo);
                drawCustomerDetails(writer, invoice);
                drawInvoiceDetails(writer, invoice);
                drawItemsTable(writer, items);
                drawTotals(writer, invoice);
                drawPaymentHistory(writer, payments);
                drawBankDetails(writer, invoice);
                drawFooter(writer, invoice);

                /*
                 * IMPORTANT:
                 * Close the content stream BEFORE saving the document.
                 */
                writer.closeCurrentStream();

                document.save(output);
            }

            return output.toByteArray();

        } catch (IOException exception) {

            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to generate invoice PDF.",
                    exception
            );
        }
    }

    private void drawHeader(
            PdfWriter writer,
            Invoice invoice,
            PDImageXObject logo
    ) throws IOException {

        var company = invoice.getCompany();

        if (logo != null) {
            writer.stream.drawImage(
                    logo,
                    RIGHT - 100,
                    writer.y - 45,
                    100,
                    45
            );
        }

        writer.text(
                company.getCompanyName(),
                LEFT,
                writer.y,
                20,
                BOLD
        );

        writer.y -= 20;

        if (company.getAddress() != null) {
            writer.text(company.getAddress(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 13;
        }

        if (company.getPhone() != null) {
            writer.text("Phone: " + company.getPhone(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 13;
        }

        if (company.getEmail() != null) {
            writer.text("Email: " + company.getEmail(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 13;
        }

        if (company.getWebsite() != null) {
            writer.text("Website: " + company.getWebsite(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 13;
        }

        if (company.getVatNumber() != null) {
            writer.text("VAT Number: " + company.getVatNumber(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 13;
        }

        if (company.getRegistrationNumber() != null) {
            writer.text(
                    "Registration Number: " + company.getRegistrationNumber(),
                    LEFT,
                    writer.y,
                    9,
                    REGULAR
            );
            writer.y -= 13;
        }

        writer.y -= 15;

        writer.text("INVOICE", LEFT, writer.y, 22, BOLD);

        writer.y -= 18;
        writer.line(writer.y);
        writer.y -= 25;
    }

    private void drawCustomerDetails(
            PdfWriter writer,
            Invoice invoice
    ) throws IOException {

        writer.text("BILL TO", LEFT, writer.y, 10, BOLD);
        writer.y -= 17;

        writer.text(
                invoice.getCustomerNameSnapshot(),
                LEFT,
                writer.y,
                10,
                REGULAR
        );

        writer.y -= 15;

        if (invoice.getCustomerPhoneSnapshot() != null) {
            writer.text(
                    "Phone: " + invoice.getCustomerPhoneSnapshot(),
                    LEFT,
                    writer.y,
                    9,
                    REGULAR
            );
            writer.y -= 14;
        }

        if (invoice.getCustomerAddressSnapshot() != null) {
            writer.text(
                    "Address: " + invoice.getCustomerAddressSnapshot(),
                    LEFT,
                    writer.y,
                    9,
                    REGULAR
            );
            writer.y -= 14;
        }

        writer.y -= 15;
    }

    private void drawInvoiceDetails(
            PdfWriter writer,
            Invoice invoice
    ) throws IOException {

        float rightColumn = LEFT + CONTENT_WIDTH * 0.58f;

        writer.text(
                "Invoice Number: " + invoice.getInvoiceNumber(),
                rightColumn,
                writer.y + 55,
                9,
                BOLD
        );

        writer.text(
                "Invoice Date: " + invoice.getInvoiceDate(),
                rightColumn,
                writer.y + 40,
                9,
                REGULAR
        );

        writer.text(
                "Due Date: " + (
                        invoice.getDueDate() == null
                                ? "Not specified"
                                : invoice.getDueDate()
                ),
                rightColumn,
                writer.y + 25,
                9,
                REGULAR
        );

        writer.text(
                "Job Number: " + invoice.getJob().getJobNumber(),
                rightColumn,
                writer.y + 10,
                9,
                REGULAR
        );

        writer.y -= 15;
    }

    private void drawItemsTable(
            PdfWriter writer,
            List<InvoiceItem> items
    ) throws IOException {

        float descriptionX = LEFT;
        float quantityX = LEFT + 275;
        float priceX = LEFT + 345;
        float discountX = LEFT + 415;
        float totalX = LEFT + 475;

        drawTableHeader(writer);

        for (InvoiceItem item : items) {

            if (writer.y < BOTTOM_MARGIN + 35) {
                writer.newPage();
                drawTableHeader(writer);
            }

            writer.text(
                    truncate(safe(item.getDescription()), 42),
                    descriptionX,
                    writer.y,
                    8,
                    REGULAR
            );

            writer.text(number(item.getQuantity()), quantityX, writer.y, 8, REGULAR);
            writer.text(money(item.getUnitPrice()), priceX, writer.y, 8, REGULAR);
            writer.text(money(item.getDiscountAmount()), discountX, writer.y, 8, REGULAR);
            writer.text(money(item.getLineTotal()), totalX, writer.y, 8, REGULAR);

            writer.y -= 17;
        }

        writer.y -= 10;
        writer.line(writer.y);
        writer.y -= 20;
    }

    private void drawTableHeader(PdfWriter writer) throws IOException {

        writer.text("Description", LEFT, writer.y, 8, BOLD);
        writer.text("Qty", LEFT + 275, writer.y, 8, BOLD);
        writer.text("Unit Price", LEFT + 345, writer.y, 8, BOLD);
        writer.text("Discount", LEFT + 415, writer.y, 8, BOLD);
        writer.text("Total", LEFT + 475, writer.y, 8, BOLD);

        writer.y -= 10;
        writer.line(writer.y);
        writer.y -= 17;
    }

    private void drawTotals(
            PdfWriter writer,
            Invoice invoice
    ) throws IOException {

        if (writer.y < BOTTOM_MARGIN + 130) {
            writer.newPage();
        }

        float labelX = LEFT + 310;
        float valueX = LEFT + 450;

        drawTotalRow(writer, "Subtotal", invoice.getSubtotal(), labelX, valueX);
        drawTotalRow(writer, "Discount", invoice.getDiscountAmount(), labelX, valueX);
        drawTotalRow(writer, "VAT / Tax", invoice.getTaxAmount(), labelX, valueX);

        writer.y -= 3;
        writer.line(writer.y);
        writer.y -= 18;

        drawTotalRow(writer, "GRAND TOTAL", invoice.getTotalAmount(), labelX, valueX, true);
        drawTotalRow(writer, "Amount Paid", invoice.getAmountPaid(), labelX, valueX);
        drawTotalRow(writer, "BALANCE DUE", invoice.getBalanceDue(), labelX, valueX, true);

        writer.y -= 20;
    }

    private void drawTotalRow(
            PdfWriter writer,
            String label,
            BigDecimal amount,
            float labelX,
            float valueX
    ) throws IOException {

        drawTotalRow(writer, label, amount, labelX, valueX, false);
    }

    private void drawTotalRow(
            PdfWriter writer,
            String label,
            BigDecimal amount,
            float labelX,
            float valueX,
            boolean bold
    ) throws IOException {

        PDType1Font font = bold ? BOLD : REGULAR;
        int size = bold ? 10 : 9;

        writer.text(label, labelX, writer.y, size, font);
        writer.text(money(amount), valueX, writer.y, size, font);

        writer.y -= 17;
    }

    private void drawPaymentHistory(
            PdfWriter writer,
            List<Payment> payments
    ) throws IOException {

        if (payments == null || payments.isEmpty()) {
            return;
        }

        if (writer.y < BOTTOM_MARGIN + 100) {
            writer.newPage();
        }

        writer.text("PAYMENT HISTORY", LEFT, writer.y, 11, BOLD);
        writer.y -= 20;

        writer.text("Date", LEFT, writer.y, 8, BOLD);
        writer.text("Method", LEFT + 120, writer.y, 8, BOLD);
        writer.text("Reference", LEFT + 250, writer.y, 8, BOLD);
        writer.text("Amount", LEFT + 430, writer.y, 8, BOLD);

        writer.y -= 12;
        writer.line(writer.y);
        writer.y -= 17;

        for (Payment payment : payments) {

            if (writer.y < BOTTOM_MARGIN + 20) {
                writer.newPage();
            }

            String date = payment.getPaymentDate() == null
                    ? "-"
                    : payment.getPaymentDate().format(
                            DateTimeFormatter.ofPattern("dd MMM yyyy")
                    );

            writer.text(date, LEFT, writer.y, 8, REGULAR);

            writer.text(
                    safe(payment.getPaymentMethod()),
                    LEFT + 120,
                    writer.y,
                    8,
                    REGULAR
            );

            writer.text(
                    truncate(safe(payment.getTransactionReference()), 25),
                    LEFT + 250,
                    writer.y,
                    8,
                    REGULAR
            );

            writer.text(money(payment.getAmount()), LEFT + 430, writer.y, 8, REGULAR);

            writer.y -= 16;
        }

        writer.y -= 15;
    }

    private void drawBankDetails(
            PdfWriter writer,
            Invoice invoice
    ) throws IOException {

        var company = invoice.getCompany();

        if (writer.y < BOTTOM_MARGIN + 120) {
            writer.newPage();
        }

        writer.text("BANKING DETAILS", LEFT, writer.y, 11, BOLD);
        writer.y -= 18;

        if (company.getBankName() != null) {
            writer.text("Bank: " + company.getBankName(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 14;
        }

        if (company.getBankBranch() != null) {
            writer.text("Branch: " + company.getBankBranch(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 14;
        }

        if (company.getBankAccountName() != null) {
            writer.text("Account Name: " + company.getBankAccountName(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 14;
        }

        if (company.getBankAccountNumber() != null) {
            writer.text("Account Number: " + company.getBankAccountNumber(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 14;
        }

        if (company.getBankSwiftCode() != null) {
            writer.text("SWIFT Code: " + company.getBankSwiftCode(), LEFT, writer.y, 9, REGULAR);
            writer.y -= 14;
        }

        writer.y -= 15;
    }

    private void drawFooter(
            PdfWriter writer,
            Invoice invoice
    ) throws IOException {

        if (writer.y < BOTTOM_MARGIN + 35) {
            writer.newPage();
        }

        writer.line(writer.y);
        writer.y -= 20;

        writer.text(
                "Thank you for choosing " + invoice.getCompany().getCompanyName() + ".",
                LEFT,
                writer.y,
                10,
                BOLD
        );

        writer.y -= 16;

        writer.text(
                "We appreciate your business.",
                LEFT,
                writer.y,
                9,
                REGULAR
        );

        writer.y -= 25;

        if (invoice.getNotes() != null && !invoice.getNotes().isBlank()) {
            writer.text(
                    "Notes: " + truncate(invoice.getNotes(), 100),
                    LEFT,
                    writer.y,
                    8,
                    REGULAR
            );
        }
    }

    private String money(BigDecimal amount) {

        BigDecimal value = amount == null ? BigDecimal.ZERO : amount;

        return String.format(
                Locale.US,
                "%,.2f",
                value.setScale(2, RoundingMode.HALF_UP)
        );
    }

    private String number(BigDecimal amount) {

        if (amount == null) {
            return "0";
        }

        return amount.stripTrailingZeros().toPlainString();
    }

    private String safe(String value) {

        if (value == null || value.isBlank()) {
            return "-";
        }

        return value.replaceAll("[^\\x20-\\x7E]", "?");
    }

    private String truncate(String value, int maxLength) {

        if (value == null) {
            return "-";
        }

        if (value.length() <= maxLength) {
            return value;
        }

        return value.substring(0, maxLength - 3) + "...";
    }

    private class PdfWriter implements AutoCloseable {

        private final PDDocument document;

        private PDPage page;
        private PDPageContentStream stream;

        private float y = PAGE_HEIGHT - 50;

        private PdfWriter(PDDocument document) {
            this.document = document;
        }

        private void newPage() throws IOException {

            closeCurrentStream();

            page = new PDPage(PDRectangle.A4);
            document.addPage(page);

            stream = new PDPageContentStream(document, page);

            y = PAGE_HEIGHT - 50;
        }

        private void closeCurrentStream() throws IOException {

            if (stream != null) {
                stream.close();
                stream = null;
            }
        }

        @Override
        public void close() throws IOException {
            closeCurrentStream();
        }

        private void text(
                String value,
                float x,
                float y,
                int fontSize,
                PDType1Font font
        ) throws IOException {

            if (value == null) {
                return;
            }

            stream.beginText();
            stream.setFont(font, fontSize);
            stream.newLineAtOffset(x, y);
            stream.showText(safe(value));
            stream.endText();
        }

        private void line(float y) throws IOException {

            stream.moveTo(LEFT, y);
            stream.lineTo(RIGHT, y);
            stream.stroke();
        }
    }
}
