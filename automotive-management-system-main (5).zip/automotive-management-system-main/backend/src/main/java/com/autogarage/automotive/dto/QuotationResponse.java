package com.autogarage.automotive.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public record QuotationResponse(
        Long quotationId,

        Long jobId,
        String jobNumber,
        String jobStatus,

        String quotationNumber,
        Integer versionNumber,
        String quotationStatus,

        LocalDate issueDate,
        LocalDate validUntil,

        String currencyCode,

        String customerName,
        String customerPhone,
        String customerEmail,

        String vehicleRegistration,
        String vehicleMake,
        String vehicleModel,
        String vehicleType,

        Long preparedByEmployeeId,
        String preparedByName,

        BigDecimal subtotal,
        BigDecimal discountAmount,
        BigDecimal taxAmount,
        BigDecimal totalAmount,

        Integer estimatedCompletionDays,
        String termsAndConditions,
        String foremanNotes,

        List<QuotationItemResponse> items,

        LocalDateTime createdAt
) {}