package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.MediaFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MediaFileRepository extends JpaRepository<MediaFile, Long> {

    List<MediaFile> findByJobIdOrderByUploadedAtDesc(Long jobId);

    List<MediaFile> findByInventoryCardIdOrderByUploadedAtDesc(
            Long inventoryCardId
    );

    List<MediaFile> findByInspectionIdOrderByUploadedAtDesc(
            Long inspectionId
    );

    List<MediaFile> findByDamageRecordIdOrderByUploadedAtDesc(
            Long damageRecordId
    );

    List<MediaFile> findByEvidenceTypeOrderByUploadedAtDesc(
            String evidenceType
    );

    List<MediaFile> findByInventoryCard_IdAndEvidenceTypeIgnoreCase(
                Long inventoryCardId, String evidenceType
        );

        List<MediaFile> findByDamageRecord_Id(Long damageRecordId);
}