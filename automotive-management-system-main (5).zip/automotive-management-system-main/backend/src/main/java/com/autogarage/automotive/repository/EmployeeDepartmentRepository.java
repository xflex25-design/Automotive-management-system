
package com.autogarage.automotive.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.autogarage.automotive.entity.Employee;

public interface EmployeeDepartmentRepository
        extends Repository<Employee, Long> {

    @Query(value = """
            SELECT COUNT(*)
            FROM employee_departments
            WHERE employee_id = :employeeId
              AND department_id = :departmentId
            """, nativeQuery = true)
    Long countEmployeeDepartmentMembership(
            @Param("employeeId") Long employeeId,
            @Param("departmentId") Long departmentId
    );
}
