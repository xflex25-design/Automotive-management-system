package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.WorkOrderCompletionRequest;
import com.autogarage.automotive.dto.WorkOrderConfirmationRequest;
import com.autogarage.automotive.service.WorkOrderConfirmationService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/work-orders")
public class WorkOrderConfirmationController {

    private final WorkOrderConfirmationService confirmationService;

    public WorkOrderConfirmationController(
            WorkOrderConfirmationService confirmationService
    ) {
        this.confirmationService = confirmationService;
    }

    @PostMapping("/{workOrderId}/submit-completion")
    public ResponseEntity<Map<String, Object>> submitCompletion(
            @PathVariable Long workOrderId,
            @Valid @RequestBody WorkOrderCompletionRequest request
    ) {
        return ResponseEntity.ok(
                confirmationService.submitForConfirmation(
                        workOrderId,
                        request
                )
        );
    }

    @PostMapping("/{workOrderId}/confirm")
    public ResponseEntity<Map<String, Object>> confirmWorkOrder(
            @PathVariable Long workOrderId,
            @Valid @RequestBody WorkOrderConfirmationRequest request
    ) {
        return ResponseEntity.ok(
                confirmationService.confirmWorkOrder(
                        workOrderId,
                        request
                )
        );
    }
}