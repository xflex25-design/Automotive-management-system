package com.autogarage.automotive.dto.invoice;

import java.math.BigDecimal;

public record InvoiceItemResponse(
        Long id,
        String itemType,
        Long partId,
        String description,
        BigDecimal quantity,
        String unitOfMeasure,
        BigDecimal unitPrice,
        BigDecimal discountAmount,
        BigDecimal taxAmount,
        BigDecimal lineTotal
) {}