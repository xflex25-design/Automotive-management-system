package com.autogarage.automotive.controller;

import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Provides a single authenticated, workshop-scoped read for the web workspace. */
@RestController
@RequestMapping("/api/companies/{companyId}/workflow-records")
public class WorkspaceRecordsController {
    private final JobRepository jobRepository;
    private final JobCardRepository jobCardRepository;
    private final JobCardPartRepository jobCardPartRepository;
    private final RepairPlanRepository repairPlanRepository;
    private final PartsRequisitionRepository requisitionRepository;
    private final PartsRequisitionItemRepository requisitionItemRepository;
    private final FinalInspectionRepository finalInspectionRepository;
    private final VehicleInventoryCardRepository inventoryRepository;
    private final InventoryAccessoryRepository accessoryRepository;
    private final InventoryReceivedItemRepository receivedItemRepository;
    private final PartRepository partRepository;
    private final PurchaseOrderRepository purchaseOrderRepository;
    private final DepartmentRepository departmentRepository;
    private final EmployeeRepository employeeRepository;
    private final SupplierRepository supplierRepository;
    private final StockLocationRepository stockLocationRepository;

    public WorkspaceRecordsController(
            JobRepository jobRepository,
            JobCardRepository jobCardRepository,
            JobCardPartRepository jobCardPartRepository,
            RepairPlanRepository repairPlanRepository,
            PartsRequisitionRepository requisitionRepository,
            PartsRequisitionItemRepository requisitionItemRepository,
            FinalInspectionRepository finalInspectionRepository,
            VehicleInventoryCardRepository inventoryRepository,
            InventoryAccessoryRepository accessoryRepository,
            InventoryReceivedItemRepository receivedItemRepository,
            PartRepository partRepository,
            PurchaseOrderRepository purchaseOrderRepository,
            DepartmentRepository departmentRepository,
            EmployeeRepository employeeRepository,
            SupplierRepository supplierRepository,
            StockLocationRepository stockLocationRepository
    ) {
        this.jobRepository = jobRepository;
        this.jobCardRepository = jobCardRepository;
        this.jobCardPartRepository = jobCardPartRepository;
        this.repairPlanRepository = repairPlanRepository;
        this.requisitionRepository = requisitionRepository;
        this.requisitionItemRepository = requisitionItemRepository;
        this.finalInspectionRepository = finalInspectionRepository;
        this.inventoryRepository = inventoryRepository;
        this.accessoryRepository = accessoryRepository;
        this.receivedItemRepository = receivedItemRepository;
        this.partRepository = partRepository;
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.departmentRepository = departmentRepository;
        this.employeeRepository = employeeRepository;
        this.supplierRepository = supplierRepository;
        this.stockLocationRepository = stockLocationRepository;
    }

    @GetMapping
    @Transactional(readOnly = true)
    public Map<String, Object> getWorkspaceRecords(
            @PathVariable Long companyId,
            @RequestParam Long workshopId
    ) {
        ActorIdentity.requireCompanyWorkshop(companyId, workshopId);
        List<Job> jobs = jobRepository
                .findByCompanyIdAndWorkshopIdOrderByDateReceivedDesc(companyId, workshopId);

        List<Map<String, Object>> vehicles = jobs.stream().map(this::vehicleRecord).toList();
        List<Map<String, Object>> jobCards = jobCardRepository
                .findByJob_Company_IdAndJob_Workshop_IdOrderByCreatedAtDesc(companyId, workshopId)
                .stream().map(this::jobCardRecord).toList();
        List<Map<String, Object>> requisitions = requisitionRepository
                .findByCompany_IdAndWorkshop_IdOrderByCreatedAtDesc(companyId, workshopId)
                .stream().map(this::requisitionRecord).toList();
        List<Map<String, Object>> inspections = finalInspectionRepository
                .findByJob_Company_IdAndJob_Workshop_IdOrderByStartedAtDesc(companyId, workshopId)
                .stream().map(this::inspectionRecord).toList();
        List<Map<String, Object>> inventory = inventoryRepository
                .findByJob_Company_IdAndJob_Workshop_IdOrderByInventoryDateDesc(companyId, workshopId)
                .stream().map(this::inventoryRecord).toList();
        List<Map<String, Object>> parts = partRepository
                .findByCompany_IdAndActiveTrueOrderByPartNameAsc(companyId)
                .stream().map(this::partRecord).toList();
        List<Map<String, Object>> purchaseOrders = purchaseOrderRepository
                .findByCompany_IdAndWorkshop_IdOrderByCreatedAtDesc(companyId, workshopId)
                .stream().map(this::purchaseOrderRecord).toList();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("vehicles", vehicles);
        result.put("jobCards", jobCards);
        result.put("requisitions", requisitions);
        result.put("inspections", inspections);
        result.put("inventory", inventory);
        result.put("parts", parts);
        result.put("purchaseOrders", purchaseOrders);
        result.put("options", workflowOptions(companyId, workshopId));
        return result;
    }

    private Map<String, Object> vehicleRecord(Job job) {
        Vehicle vehicle = job.getVehicle();
        Customer customer = job.getCustomer();
        VehicleInventoryCard inventory = inventoryRepository.findByJobId(job.getId()).orElse(null);
        return row(
                "jobId", job.getId(), "jobNumber", job.getJobNumber(),
                "vehicleId", vehicle.getId(), "customerId", customer.getId(),
                "inventoryCardId", inventory == null ? null : inventory.getId(),
                "registrationNumber", job.getVehicleRegistrationSnapshot(),
                "make", job.getVehicleMakeSnapshot(), "model", vehicle.getModel(),
                "customerName", job.getCustomerNameSnapshot(),
                "customerPhone", customer.getPhone(), "customerEmail", customer.getEmail(),
                "broughtInByName", job.getBroughtInByName(),
                "broughtInByPhone", job.getBroughtInByPhone(),
                "receivedByName", job.getReceivedBy() == null ? null
                        : (job.getReceivedBy().getFirstName() + " "
                        + job.getReceivedBy().getLastName()).trim(),
                "dateReceived", job.getDateReceived(),
                "vehicleReleasedAt", job.getVehicleReleasedAt(),
                "reportedProblem", job.getReportedProblem(), "internalNotes", job.getInternalNotes(),
                "estimatedCompletionDate", job.getEstimatedCompletionDate(),
                "vin", vehicle.getVin(), "jobStatus", job.getJobStatus()
        );
    }

    private Map<String, Object> jobCardRecord(JobCard card) {
        Job job = card.getJob();
        RepairPlan plan = repairPlanRepository.findByJob_IdOrderByCreatedAtDesc(job.getId())
                .stream().findFirst().orElse(null);
        List<Map<String, Object>> parts = jobCardPartRepository
                .findByJobCard_IdOrderByIdAsc(card.getId()).stream().map(part -> row(
                        "jobCardPartId", part.getId(),
                        "partId", part.getPart() == null ? null : part.getPart().getId(),
                        "partCode", part.getPart() == null ? part.getPartNumber() : part.getPart().getPartCode(),
                        "partName", part.getPartName(), "quantity", part.getQuantity(),
                        "unitOfMeasure", part.getUnitOfMeasure()
                )).toList();
        return row(
                "jobCardId", card.getId(), "jobCardNumber", card.getJobCardNumber(),
                "jobId", job.getId(), "quotationId", card.getApprovedQuotationId(),
                "repairPlanId", plan == null ? null : plan.getId(),
                "jobCardStatus", card.getJobCardStatus(),
                "workDescription", card.getWorkDescription(), "parts", parts
        );
    }

    private Map<String, Object> requisitionRecord(PartsRequisition requisition) {
        List<Map<String, Object>> items = requisitionItemRepository
                .findByRequisition_IdOrderByIdAsc(requisition.getId()).stream().map(part -> row(
                        "requisitionItemId", part.getId(), "partId", part.getPart().getId(),
                        "partCode", part.getPart().getPartCode(), "partName", part.getPart().getPartName(),
                        "requestedQuantity", part.getRequestedQuantity(),
                        "unitOfMeasure", part.getUnitOfMeasure(), "itemStatus", part.getItemStatus()
                )).toList();
        return row(
                "requisitionId", requisition.getId(),
                "requisitionNumber", requisition.getRequisitionNumber(),
                "jobId", requisition.getJob().getId(),
                "requisitionStatus", requisition.getRequisitionStatus(),
                "purpose", requisition.getPurpose(), "submittedAt", requisition.getSubmittedAt(),
                "items", items
        );
    }

    private Map<String, Object> inspectionRecord(FinalInspection inspection) {
        Employee inspector = inspection.getInspector();
        return row(
                "inspectionId", inspection.getId(),
                "inspectionNumber", inspection.getInspectionNumber(),
                "jobId", inspection.getJob().getId(),
                "inspectorName", inspector.getFirstName() + " " + inspector.getLastName(),
                "startedAt", inspection.getStartedAt(),
                "inspectionDecision", inspection.getInspectionDecision(),
                "inspectionNotes", inspection.getInspectionNotes(),
                "inspectionStatus", inspection.getInspectionStatus()
        );
    }

    private Map<String, Object> inventoryRecord(VehicleInventoryCard card) {
        List<Map<String, Object>> accessories = accessoryRepository
                .findByInventoryCardIdOrderByIdAsc(card.getId()).stream().map(accessory -> row(
                        "name", accessory.getAccessoryName(), "accessoryName", accessory.getAccessoryName(),
                        "present", accessory.getPresent(), "condition", accessory.getConditionDescription()
                )).toList();
        List<Map<String, Object>> receivedItems = receivedItemRepository
                .findByInventoryCardIdOrderByIdAsc(card.getId()).stream().map(received -> row(
                        "itemName", received.getItemName(), "quantity", received.getQuantity(),
                        "condition", received.getConditionDescription()
                )).toList();
        return row(
                "inventoryCardId", card.getId(), "jobId", card.getJob().getId(),
                "inventoryDate", card.getInventoryDate(), "intakeStatus", card.getIntakeStatus(),
                "generalRemarks", card.getGeneralRemarks(),
                "odometerReadingIn", card.getOdometerReadingIn(), "fuelLevelIn", card.getFuelLevelIn(),
                "accessories", accessories, "receivedItems", receivedItems
        );
    }

    private Map<String, Object> partRecord(Part part) {
        return row(
                "partId", part.getId(), "partCode", part.getPartCode(),
                "partName", part.getPartName(), "unitOfMeasure", part.getUnitOfMeasure(),
                "description", part.getDescription()
        );
    }

    private Map<String, Object> purchaseOrderRecord(PurchaseOrder order) {
        return row(
                "purchaseOrderId", order.getId(),
                "purchaseOrderNumber", order.getPurchaseOrderNumber(),
                "purchaseOrderStatus", order.getPurchaseOrderStatus(),
                "requisitionId", order.getRequisition() == null ? null : order.getRequisition().getId(),
                "supplierId", order.getSupplier().getId(),
                "supplierName", order.getSupplier().getSupplierName(),
                "orderDate", order.getOrderDate(),
                "expectedDeliveryDate", order.getExpectedDeliveryDate(),
                "totalAmount", order.getTotalAmount(), "currencyCode", order.getCurrencyCode()
        );
    }

    private Map<String, Object> workflowOptions(Long companyId, Long workshopId) {
        List<Map<String, Object>> departments = departmentRepository
                .findActiveByCompanyAndWorkshop(companyId, workshopId).stream()
                .map(department -> row("id", department.getId(), "name", department.getDepartmentName()))
                .toList();
        List<Map<String, Object>> employees = employeeRepository
                .findByCompanyIdAndWorkshopIdAndEmploymentStatus(companyId, workshopId, "ACTIVE")
                .stream().map(employee -> row(
                        "id", employee.getId(),
                        "name", (employee.getFirstName() + " " + employee.getLastName()).trim(),
                        "employeeNumber", employee.getEmployeeNumber(),
                        "jobTitle", employee.getJobTitle()
                )).toList();
        List<Map<String, Object>> suppliers = supplierRepository
                .findByCompany_IdAndActiveTrueOrderBySupplierNameAsc(companyId).stream()
                .map(supplier -> row("supplierId", supplier.getId(), "supplierName", supplier.getSupplierName()))
                .toList();
        List<Map<String, Object>> stockLocations = stockLocationRepository
                .findByWorkshop_IdAndActiveTrue(workshopId).stream()
                .map(location -> row("stockLocationId", location.getId(), "locationName", location.getLocationName()))
                .toList();
        return row(
                "departments", departments, "employees", employees,
                "suppliers", suppliers, "stockLocations", stockLocations
        );
    }

    private Map<String, Object> row(Object... fields) {
        Map<String, Object> row = new LinkedHashMap<>();
        for (int index = 0; index < fields.length; index += 2) {
            row.put((String) fields[index], fields[index + 1]);
        }
        return row;
    }
}
