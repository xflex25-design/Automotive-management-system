package com.autogarage.automotive.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record QuotationItemRequest(

        @NotBlank
        @Size(max = 30)
        String itemType,

        @Size(max = 80)
        String itemCode,

        @NotBlank
        @Size(max = 255)
        String description,

        @NotNull
        @DecimalMin(value = "0.01", message = "Quantity must be greater than zero")
        BigDecimal quantity,

        @Size(max = 30)
        String unitOfMeasure,

        @NotNull
        @DecimalMin(value = "0.00", message = "Unit price cannot be negative")
        BigDecimal unitPrice,

        @DecimalMin(value = "0.00", message = "Discount cannot be negative")
        BigDecimal discountAmount,

        @DecimalMin(value = "0.00", message = "Tax cannot be negative")
        BigDecimal taxAmount,

        String remarks
) {}