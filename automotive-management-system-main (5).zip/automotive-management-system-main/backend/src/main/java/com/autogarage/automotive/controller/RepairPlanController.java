package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.RepairPlanAcceptanceRequest;
import com.autogarage.automotive.service.RepairPlanReviewService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/repair-plans")
public class RepairPlanController {

    private final RepairPlanReviewService repairPlanReviewService;

    public RepairPlanController(
            RepairPlanReviewService repairPlanReviewService
    ) {
        this.repairPlanReviewService = repairPlanReviewService;
    }

    @GetMapping("/{repairPlanId}")
    public ResponseEntity<Map<String, Object>> getRepairPlan(
            @PathVariable Long repairPlanId
    ) {
        return ResponseEntity.ok(
                repairPlanReviewService.getRepairPlan(repairPlanId)
        );
    }

    @PostMapping("/{repairPlanId}/accept")
    public ResponseEntity<Map<String, Object>> acceptRepairPlan(
            @PathVariable Long repairPlanId,
            @Valid @RequestBody RepairPlanAcceptanceRequest request
    ) {
        return ResponseEntity.ok(
                repairPlanReviewService.acceptRepairPlan(
                        repairPlanId,
                        request.getForemanEmployeeId()
                )
        );
    }
}