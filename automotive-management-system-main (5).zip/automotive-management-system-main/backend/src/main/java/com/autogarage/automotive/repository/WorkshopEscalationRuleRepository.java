package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkshopEscalationRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkshopEscalationRuleRepository
        extends JpaRepository<WorkshopEscalationRule, Long> {

    List<WorkshopEscalationRule> findByWorkshop_IdAndActiveTrueOrderByElapsedMinutesAsc(
            Long workshopId
    );
}