package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.DispatchOrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DispatchOrderItemRepository
        extends JpaRepository<DispatchOrderItem, Long> {

    List<DispatchOrderItem> findByDispatchOrder_IdOrderByIdAsc(
            Long dispatchOrderId);

    boolean existsByStockReservation_IdAndDispatchOrder_IdNot(
            Long reservationId,
            Long dispatchOrderId
    );
}