package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.RepairTask;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RepairTaskRepository extends JpaRepository<RepairTask, Long> {

    Optional<RepairTask> findByTaskCode(String taskCode);

    List<RepairTask> findByActiveTrueOrderByTaskNameAsc();

    List<RepairTask> findByDepartment_IdAndActiveTrueOrderByTaskNameAsc(
            Long departmentId
    );

    boolean existsByTaskCode(String taskCode);
}