package com.autogarage.automotive.dto;

import java.time.LocalDateTime;

public record VehicleIntakeResponse(

        Long jobId,

        String jobNumber,

        Long customerId,

        String customerName,

        String ownerName,

        String broughtInByName,

        String broughtInByPhone,

        Long vehicleId,

        String registrationNumber,

        Long inventoryCardId,

        String jobStatus,

        String intakeStatus,

        LocalDateTime dateReceived

) {}
