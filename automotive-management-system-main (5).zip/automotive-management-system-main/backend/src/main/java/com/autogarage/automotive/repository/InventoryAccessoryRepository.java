package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.InventoryAccessory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InventoryAccessoryRepository
        extends JpaRepository<InventoryAccessory, Long> {

    List<InventoryAccessory> findByInventoryCardIdOrderByIdAsc(
            Long inventoryCardId
    );

    List<InventoryAccessory> findByInventoryCardIdAndPresent(
            Long inventoryCardId,
            Boolean present
    );
}