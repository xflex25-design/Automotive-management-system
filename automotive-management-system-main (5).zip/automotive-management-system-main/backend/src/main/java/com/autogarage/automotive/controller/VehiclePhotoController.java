package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.VehiclePhotoResponse;
import com.autogarage.automotive.service.VehiclePhotoService;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/intake/jobs")
public class VehiclePhotoController {

    private final VehiclePhotoService photoService;

    public VehiclePhotoController(VehiclePhotoService photoService) {
        this.photoService = photoService;
    }

    @PostMapping(
            value = "/{jobId}/photos",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ResponseEntity<VehiclePhotoResponse> uploadIntakePhoto(
            @PathVariable Long jobId,

            @RequestParam Long inspectionId,

            @RequestParam(required = false) Long damageRecordId,

            @RequestParam Long uploadedByEmployeeId,

            @RequestParam String evidenceType,

            @RequestParam(required = false) String caption,

            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime capturedAt,

            @RequestParam("file") MultipartFile file
    ) {
        VehiclePhotoResponse response = photoService.uploadIntakePhoto(
                jobId,
                inspectionId,
                damageRecordId,
                uploadedByEmployeeId,
                evidenceType,
                caption,
                capturedAt,
                file
        );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }
}