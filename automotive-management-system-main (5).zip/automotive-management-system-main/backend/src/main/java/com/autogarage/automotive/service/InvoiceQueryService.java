package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.invoice.InvoiceItemResponse;
import com.autogarage.automotive.dto.invoice.InvoiceResponse;
import com.autogarage.automotive.dto.invoice.PaymentResponse;
import com.autogarage.automotive.entity.Invoice;
import com.autogarage.automotive.entity.InvoiceItem;
import com.autogarage.automotive.entity.Payment;
import com.autogarage.automotive.entity.Vehicle;
import com.autogarage.automotive.repository.InvoiceItemRepository;
import com.autogarage.automotive.repository.InvoiceRepository;
import com.autogarage.automotive.repository.PaymentRepository;
import com.autogarage.automotive.repository.JobRepository;
import com.autogarage.automotive.security.ActorIdentity;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class InvoiceQueryService {

    private final InvoiceRepository invoiceRepository;
    private final InvoiceItemRepository invoiceItemRepository;
    private final PaymentRepository paymentRepository;
    private final JobRepository jobRepository;

    public InvoiceResponse getInvoice(Long invoiceId) {

        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Invoice not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                invoice.getCompany().getId(), invoice.getWorkshop().getId());

        return buildInvoiceResponse(invoice);
    }

    public List<InvoiceResponse> getInvoicesByJob(Long jobId) {

        var job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Job not found."));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        List<Invoice> invoices =
                invoiceRepository.findByJob_IdOrderByInvoiceDateDesc(jobId);

        return invoices.stream()
                .map(this::buildInvoiceResponse)
                .toList();
    }

    private InvoiceResponse buildInvoiceResponse(Invoice invoice) {

        List<InvoiceItemResponse> items =
                invoiceItemRepository.findByInvoice_IdOrderByIdAsc(invoice.getId())
                        .stream()
                        .map(this::buildItemResponse)
                        .toList();

        List<PaymentResponse> payments =
                paymentRepository.findByInvoice_IdOrderByPaymentDateDesc(invoice.getId())
                        .stream()
                        .map(this::buildPaymentResponse)
                        .toList();

        Vehicle vehicle = invoice.getJob().getVehicle();

        return new InvoiceResponse(
                invoice.getId(),
                invoice.getInvoiceNumber(),
                invoice.getJob().getId(),
                invoice.getJob().getJobNumber(),
                invoice.getQuotation() != null
                        ? invoice.getQuotation().getId()
                        : null,
                invoice.getFinalInspection() != null
                        ? invoice.getFinalInspection().getId()
                        : null,
                invoice.getCustomerNameSnapshot(),
                invoice.getCustomerPhoneSnapshot(),
                invoice.getCustomerAddressSnapshot(),
                vehicle != null ? vehicle.getRegistrationNumber() : null,
                vehicle != null ? vehicle.getMake() : null,
                invoice.getCurrencyCode(),
                invoice.getInvoiceStatus(),
                invoice.getInvoiceDate(),
                invoice.getDueDate(),
                invoice.getSubtotal(),
                invoice.getDiscountAmount(),
                invoice.getTaxAmount(),
                invoice.getTotalAmount(),
                invoice.getAmountPaid(),
                invoice.getBalanceDue(),
                invoice.getNotes(),
                invoice.getIssuedBy().getId(),
                items,
                payments,
                invoice.getCreatedAt()
        );
    }

    private InvoiceItemResponse buildItemResponse(InvoiceItem item) {

        return new InvoiceItemResponse(
                item.getId(),
                item.getItemType(),
                item.getPart() != null ? item.getPart().getId() : null,
                item.getDescription(),
                item.getQuantity(),
                item.getUnitOfMeasure(),
                item.getUnitPrice(),
                item.getDiscountAmount(),
                item.getTaxAmount(),
                item.getLineTotal()
        );
    }

    private PaymentResponse buildPaymentResponse(Payment payment) {

        String employeeName = payment.getReceivedBy().getFirstName()
                + " " + payment.getReceivedBy().getLastName();

        return new PaymentResponse(
                payment.getId(),
                payment.getPaymentReference(),
                payment.getPaymentMethod(),
                payment.getPaymentStatus(),
                payment.getAmount(),
                payment.getCurrencyCode(),
                payment.getTransactionReference(),
                payment.getPaymentDate(),
                payment.getReceivedBy().getId(),
                employeeName,
                payment.getNotes()
        );
    }
}
