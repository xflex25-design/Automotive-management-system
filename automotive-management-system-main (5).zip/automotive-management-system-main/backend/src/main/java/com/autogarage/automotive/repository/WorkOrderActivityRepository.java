
package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkOrderActivity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkOrderActivityRepository
        extends JpaRepository<WorkOrderActivity, Long> {

    List<WorkOrderActivity>
    findByWorkOrder_IdOrderByCreatedAtAsc(Long workOrderId);

    List<WorkOrderActivity>
    findByDepartmentVisit_IdOrderByCreatedAtAsc(Long departmentVisitId);

    List<WorkOrderActivity>
    findTop20ByWorkOrder_IdOrderByCreatedAtDesc(Long workOrderId);
}
