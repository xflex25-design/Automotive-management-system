package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "inspection_items")
@Getter
@Setter
@NoArgsConstructor
public class InspectionItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inspection_id", nullable = false)
    private InspectionRecord inspection;

    @Column(name = "item_name", nullable = false, length = 150)
    private String itemName;

    @Column(name = "inspection_category", length = 100)
    private String inspectionCategory;

    @Column(name = "condition_status", length = 40)
    private String conditionStatus;

    @Column(columnDefinition = "TEXT")
    private String observation;

    @Column(name = "requires_attention", nullable = false)
    private Boolean requiresAttention = false;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}