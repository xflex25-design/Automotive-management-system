
package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.invoice.CreateInvoiceRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

@Service
public class InvoiceService {

    private final InvoiceRepository invoiceRepository;
    private final InvoiceItemRepository invoiceItemRepository;
    private final JobRepository jobRepository;
    private final FinalInspectionRepository finalInspectionRepository;
    private final QuotationRepository quotationRepository;
    private final QuotationItemRepository quotationItemRepository;
    private final EmployeeRepository employeeRepository;

    public InvoiceService(
            InvoiceRepository invoiceRepository,
            InvoiceItemRepository invoiceItemRepository,
            JobRepository jobRepository,
            FinalInspectionRepository finalInspectionRepository,
            QuotationRepository quotationRepository,
            QuotationItemRepository quotationItemRepository,
            EmployeeRepository employeeRepository
    ) {
        this.invoiceRepository = invoiceRepository;
        this.invoiceItemRepository = invoiceItemRepository;
        this.jobRepository = jobRepository;
        this.finalInspectionRepository = finalInspectionRepository;
        this.quotationRepository = quotationRepository;
        this.quotationItemRepository = quotationItemRepository;
        this.employeeRepository = employeeRepository;
    }

    @Transactional
    public Invoice createInvoice(CreateInvoiceRequest request) {

        if (request == null
                || request.jobId() == null
                || request.quotationId() == null
                || request.issuedByEmployeeId() == null) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Job, quotation and issuing employee are required."
            );
        }
        ActorIdentity.requireEmployee(request.issuedByEmployeeId());

        Job job = jobRepository.findByIdForUpdate(request.jobId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Job not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        if (!"READY_FOR_INVOICING".equals(job.getJobStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Job is not ready for invoicing."
            );
        }

        FinalInspection finalInspection =
                finalInspectionRepository
                        .findFirstByJob_IdOrderByStartedAtDesc(job.getId())
                        .orElseThrow(() -> new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Final inspection not found."
                        ));

        if (!"COMPLETED".equals(finalInspection.getInspectionStatus())
                || !"PASS".equals(finalInspection.getInspectionDecision())) {

            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "The latest final inspection must be completed and passed."
            );
        }

        Quotation quotation = quotationRepository
                .findByIdForUpdate(request.quotationId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Quotation not found."
                ));

        if (quotation.getJob() == null
                || !quotation.getJob().getId().equals(job.getId())) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The quotation does not belong to this job."
            );
        }

        if (!"ISSUED".equalsIgnoreCase(quotation.getQuotationStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Only an issued quotation can be invoiced."
            );
        }

        if (invoiceRepository.findByQuotation_Id(quotation.getId()).isPresent()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "An invoice has already been generated for this quotation."
            );
        }

        Employee employee = employeeRepository
                .findByIdAndCompanyId(
                        request.issuedByEmployeeId(),
                        job.getCompany().getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Issuing employee not found."
                ));

        if (!"ACTIVE".equalsIgnoreCase(employee.getEmploymentStatus())
                || employee.getWorkshop() == null
                || !employee.getWorkshop().getId()
                        .equals(job.getWorkshop().getId())) {

            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The issuing employee is not active in this workshop."
            );
        }

        List<QuotationItem> quotationItems = quotationItemRepository
                .findByQuotationIdOrderByIdAsc(quotation.getId());

        if (quotationItems.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "There are no quotation items to invoice."
            );
        }

        Invoice invoice = new Invoice();

        invoice.setCompany(job.getCompany());
        invoice.setWorkshop(job.getWorkshop());
        invoice.setJob(job);
        invoice.setQuotation(quotation);
        invoice.setFinalInspection(finalInspection);
        invoice.setIssuedBy(employee);

        invoice.setInvoiceNumber(
                "INV-" + job.getJobNumber()
                        + "-" + System.currentTimeMillis()
        );

        Customer customer = job.getCustomer();

        String customerName;

        if ("COMPANY".equalsIgnoreCase(customer.getCustomerType())
                && customer.getCompanyName() != null
                && !customer.getCompanyName().isBlank()) {

            customerName = customer.getCompanyName();

        } else {

            customerName = (
                    (customer.getFirstName() == null ? "" : customer.getFirstName())
                    + " "
                    + (customer.getLastName() == null ? "" : customer.getLastName())
            ).trim();

            if (customerName.isBlank()) {
                customerName = job.getCustomerNameSnapshot();
            }
        }

        invoice.setCustomerNameSnapshot(customerName);
        invoice.setCustomerPhoneSnapshot(customer.getPhone());
        invoice.setCustomerEmailSnapshot(customer.getEmail());
        invoice.setCustomerAddressSnapshot(customer.getAddress());

        invoice.setCurrencyCode(quotation.getCurrencyCode());
        invoice.setInvoiceDate(LocalDate.now());
        invoice.setDueDate(request.dueDate());

        invoice.setNotes(request.notes());
        invoice.setInvoiceStatus("ISSUED");

        invoice.setAmountPaid(
                BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
        );

        BigDecimal subtotal = BigDecimal.ZERO;
        BigDecimal discountTotal = BigDecimal.ZERO;
        BigDecimal taxTotal = BigDecimal.ZERO;
        BigDecimal total = BigDecimal.ZERO;

        invoice = invoiceRepository.save(invoice);

        for (QuotationItem quotationItem : quotationItems) {

            if (quotationItem == null
                    || quotationItem.getQuotation() == null
                    || !quotationItem.getQuotation().getId()
                            .equals(quotation.getId())) {

                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                    "A quotation item does not belong to the selected quotation."
                );
            }

            BigDecimal quantity = quotationItem.getQuantity();
            BigDecimal unitPrice = quotationItem.getUnitPrice();
            BigDecimal discount = quotationItem.getDiscountAmount();
            BigDecimal tax = quotationItem.getTaxAmount();

            if (quantity == null
                    || quantity.compareTo(BigDecimal.ZERO) <= 0) {

                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                    "A quotation item has an invalid quantity."
                );
            }

            if (unitPrice == null
                    || unitPrice.compareTo(BigDecimal.ZERO) < 0) {

                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                    "A quotation item has an invalid unit price."
                );
            }

            if (discount == null
                    || discount.compareTo(BigDecimal.ZERO) < 0) {

                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                    "A quotation item has an invalid discount."
                );
            }

            if (tax == null || tax.compareTo(BigDecimal.ZERO) < 0) {

                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                    "A quotation item has an invalid VAT amount."
                );
            }

            quantity = quantity.setScale(2, RoundingMode.HALF_UP);
            unitPrice = unitPrice.setScale(2, RoundingMode.HALF_UP);
            discount = discount.setScale(2, RoundingMode.HALF_UP);
            tax = tax.setScale(2, RoundingMode.HALF_UP);

            BigDecimal grossAmount = quantity
                    .multiply(unitPrice)
                    .setScale(2, RoundingMode.HALF_UP);

            if (discount.compareTo(grossAmount) > 0) {

                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                    "A quotation item has a discount exceeding its gross amount."
                );
            }

            BigDecimal taxableAmount = grossAmount.subtract(discount);

            BigDecimal lineTotal = taxableAmount
                    .add(tax)
                    .setScale(2, RoundingMode.HALF_UP);

            InvoiceItem invoiceItem = new InvoiceItem();

            invoiceItem.setInvoice(invoice);
            invoiceItem.setItemType(
                    mapItemType(quotationItem.getItemType())
            );
            invoiceItem.setDescription(quotationItem.getDescription());
            invoiceItem.setQuantity(quantity);
            invoiceItem.setUnitOfMeasure(quotationItem.getUnitOfMeasure());
            invoiceItem.setUnitPrice(unitPrice);
            invoiceItem.setDiscountAmount(discount);
            invoiceItem.setTaxAmount(tax);
            invoiceItem.setLineTotal(lineTotal);

            invoiceItemRepository.save(invoiceItem);

            subtotal = subtotal.add(grossAmount);
            discountTotal = discountTotal.add(discount);
            taxTotal = taxTotal.add(tax);
            total = total.add(lineTotal);
        }

        subtotal = subtotal.setScale(2, RoundingMode.HALF_UP);
        discountTotal = discountTotal.setScale(2, RoundingMode.HALF_UP);
        taxTotal = taxTotal.setScale(2, RoundingMode.HALF_UP);
        total = total.setScale(2, RoundingMode.HALF_UP);

        invoice.setSubtotal(subtotal);
        invoice.setDiscountAmount(discountTotal);
        invoice.setTaxAmount(taxTotal);
        invoice.setTotalAmount(total);
        invoice.setBalanceDue(total);

        return invoiceRepository.save(invoice);
    }

    private String mapItemType(String itemType) {

        if (itemType == null) {
            return "OTHER";
        }

        return switch (itemType.toUpperCase(Locale.ROOT)) {
            case "PART", "SPARE_PART" -> "PART";
            case "LABOUR", "LABOR" -> "LABOUR";
            case "SERVICE" -> "SERVICE";
            default -> "OTHER";
        };
    }
}
