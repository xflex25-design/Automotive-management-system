package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.WorkOrderCompletionRequest;
import com.autogarage.automotive.dto.WorkOrderConfirmationRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class WorkOrderConfirmationService {

    private final WorkOrderRepository workOrderRepository;
    private final EmployeeRepository employeeRepository;
    private final WorkOrderAssignmentRepository assignmentRepository;
    private final WorkOrderDepartmentVisitRepository visitRepository;
    private final WorkOrderActivityRepository activityRepository;
    private final WorkOrderEvidenceRepository evidenceRepository;
    private final WorkOrderEvidenceRequirementRepository requirementRepository;
    private final WorkOrderConfirmationRepository confirmationRepository;
    private final WorkOrderDependencyRepository dependencyRepository;

    public WorkOrderConfirmationService(
            WorkOrderRepository workOrderRepository,
            EmployeeRepository employeeRepository,
            WorkOrderAssignmentRepository assignmentRepository,
            WorkOrderDepartmentVisitRepository visitRepository,
            WorkOrderActivityRepository activityRepository,
            WorkOrderEvidenceRepository evidenceRepository,
            WorkOrderEvidenceRequirementRepository requirementRepository,
            WorkOrderConfirmationRepository confirmationRepository,
            WorkOrderDependencyRepository dependencyRepository
    ) {
        this.workOrderRepository = workOrderRepository;
        this.employeeRepository = employeeRepository;
        this.assignmentRepository = assignmentRepository;
        this.visitRepository = visitRepository;
        this.activityRepository = activityRepository;
        this.evidenceRepository = evidenceRepository;
        this.requirementRepository = requirementRepository;
        this.confirmationRepository = confirmationRepository;
        this.dependencyRepository = dependencyRepository;
    }

    @Transactional
    public Map<String, Object> submitForConfirmation(
            Long workOrderId,
            WorkOrderCompletionRequest request
    ) {
        ActorIdentity.requireEmployee(request == null ? null : request.employeeId());
        WorkOrder workOrder = getWorkOrder(workOrderId);
        Employee employee = getEmployee(request.employeeId());

        requireAssignedEmployee(workOrderId, employee.getId());

        WorkOrderDepartmentVisit visit = getOpenVisit(workOrderId);

        if (!"IN_PROGRESS".equals(workOrder.getWorkOrderStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Only work currently in progress can be submitted for confirmation."
            );
        }

        validateMandatoryEvidence(workOrder);

        String previousStatus = workOrder.getWorkOrderStatus();

        workOrder.setWorkOrderStatus("AWAITING_CONFIRMATION");
        workOrder.setCompletionNotes(request.completionNotes());

        workOrderRepository.save(workOrder);

        recordActivity(
                workOrder,
                visit,
                employee,
                "COMPLETION_SUBMITTED",
                previousStatus,
                "AWAITING_CONFIRMATION",
                request.completionNotes()
        );

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("workOrderId", workOrderId);
        response.put("workOrderNumber", workOrder.getWorkOrderNumber());
        response.put("status", workOrder.getWorkOrderStatus());
        response.put("submittedByEmployeeId", employee.getId());
        response.put("submittedAt", LocalDateTime.now());
        response.put("message", "Work submitted for confirmation.");

        return response;
    }

    @Transactional
    public Map<String, Object> confirmWorkOrder(
            Long workOrderId,
            WorkOrderConfirmationRequest request
    ) {
        ActorIdentity.requireEmployee(request == null ? null : request.employeeId());
        WorkOrder workOrder = getWorkOrder(workOrderId);
        Employee confirmer = getEmployee(request.employeeId());

        getOpenVisit(workOrderId);

        if (!"AWAITING_CONFIRMATION".equals(workOrder.getWorkOrderStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "This work order is not awaiting confirmation."
            );
        }

        String decision = request.decision().trim().toUpperCase();

        if (!Set.of(
                "COMPLETED",
                "REJECTED",
                "RETURNED_FOR_REWORK",
                "NOT_APPLICABLE"
        ).contains(decision)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Invalid confirmation decision."
            );
        }

        if ("NOT_APPLICABLE".equals(decision)
                && request.reason().isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "A reason is required when marking work as not applicable."
            );
        }

        String previousStatus = workOrder.getWorkOrderStatus();

        WorkOrderConfirmation confirmation = new WorkOrderConfirmation();
        confirmation.setWorkOrder(workOrder);
        confirmation.setConfirmedBy(confirmer);
        confirmation.setConfirmationStatus(decision);
        confirmation.setCompletionNotes(request.reason());

        confirmationRepository.save(confirmation);

        String newStatus;

        switch (decision) {
            case "COMPLETED", "NOT_APPLICABLE" -> {
                newStatus = "COMPLETED";
                workOrder.setWorkOrderStatus(newStatus);
                workOrder.setCompletedAt(LocalDateTime.now());

                if ("NOT_APPLICABLE".equals(decision)) {
                    recordActivity(
                            workOrder,
                            getOpenVisit(workOrderId),
                            confirmer,
                            "WORK_NOT_APPLICABLE",
                            previousStatus,
                            newStatus,
                            request.reason()
                    );
                } else {
                    recordActivity(
                            workOrder,
                            getOpenVisit(workOrderId),
                            confirmer,
                            "WORK_CONFIRMED",
                            previousStatus,
                            newStatus,
                            request.reason()
                    );
                }

                unlockDependentWorkOrders(workOrder);
            }

            case "REJECTED" -> {
                newStatus = "REJECTED";
                workOrder.setWorkOrderStatus(newStatus);

                recordActivity(
                        workOrder,
                        getOpenVisit(workOrderId),
                        confirmer,
                        "WORK_REJECTED",
                        previousStatus,
                        newStatus,
                        request.reason()
                );
            }

            case "RETURNED_FOR_REWORK" -> {
                newStatus = "IN_PROGRESS";
                workOrder.setWorkOrderStatus(newStatus);

                recordActivity(
                        workOrder,
                        getOpenVisit(workOrderId),
                        confirmer,
                        "WORK_RETURNED_FOR_REWORK",
                        previousStatus,
                        newStatus,
                        request.reason()
                );
            }

            default -> throw new IllegalStateException(
                    "Unsupported confirmation decision."
            );
        }

        workOrderRepository.save(workOrder);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("confirmationId", confirmation.getId());
        response.put("workOrderId", workOrderId);
        response.put("confirmationDecision", decision);
        response.put("previousStatus", previousStatus);
        response.put("newStatus", newStatus);
        response.put("confirmedByEmployeeId", confirmer.getId());
        response.put("reason", request.reason());
        response.put("message", "Work order confirmation recorded.");

        return response;
    }

    private void validateMandatoryEvidence(WorkOrder workOrder) {

        List<WorkOrderEvidenceRequirement> requirements =
                requirementRepository.findByDepartment_IdAndActiveTrue(
                        workOrder.getDepartment().getId()
                );

        for (WorkOrderEvidenceRequirement requirement : requirements) {

            if (!Boolean.TRUE.equals(requirement.getMandatory())) {
                continue;
            }

            long uploadedCount =
                    evidenceRepository.countByWorkOrder_IdAndEvidenceRequirement_Id(
                            workOrder.getId(),
                            requirement.getId()
                    );

            int minimum = requirement.getMinimumPhotoCount() == null
                    ? 1
                    : requirement.getMinimumPhotoCount();

            if (uploadedCount < minimum) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "Missing mandatory evidence: "
                                + requirement.getEvidenceType()
                                + ". Required: " + minimum
                                + ", uploaded: " + uploadedCount
                );
            }
        }
    }

    private void unlockDependentWorkOrders(WorkOrder completedWorkOrder) {
        List<WorkOrderDependency> dependentOrders =
                dependencyRepository.findByDependsOnWorkOrder_Id(
                        completedWorkOrder.getId()
                );

        for (WorkOrderDependency dependency : dependentOrders) {
            WorkOrder dependent = dependency.getWorkOrder();

            if (!"BLOCKED".equals(dependent.getWorkOrderStatus())) {
                continue;
            }

            List<WorkOrderDependency> dependencies =
                    dependencyRepository.findByWorkOrder_Id(dependent.getId());

            boolean allPrerequisitesCompleted = dependencies.stream()
                    .allMatch(item ->
                            "COMPLETED".equals(
                                    item.getDependsOnWorkOrder().getWorkOrderStatus()
                            )
                    );

            if (allPrerequisitesCompleted) {
                dependent.setWorkOrderStatus("READY");
                workOrderRepository.save(dependent);
            }
        }
    }

    private void recordActivity(
            WorkOrder workOrder,
            WorkOrderDepartmentVisit visit,
            Employee employee,
            String activityType,
            String previousStatus,
            String newStatus,
            String description
    ) {
        WorkOrderActivity activity = new WorkOrderActivity();
        activity.setWorkOrder(workOrder);
        activity.setDepartmentVisit(visit);
        activity.setPerformedBy(employee);
        activity.setActivityType(activityType);
        activity.setPreviousStatus(previousStatus);
        activity.setNewStatus(newStatus);
        activity.setActivityDescription(description);

        activityRepository.save(activity);
    }

    private WorkOrder getWorkOrder(Long id) {
        return workOrderRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Work order not found."
                ));
    }

    private Employee getEmployee(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Employee not found."
                ));
    }

    private WorkOrderDepartmentVisit getOpenVisit(Long workOrderId) {
        return visitRepository
                .findFirstByWorkOrder_IdAndVisitStatusOrderByVisitNumberDesc(
                        workOrderId,
                        "OPEN"
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "Work order has no active department visit."
                ));
    }

    private void requireAssignedEmployee(Long workOrderId, Long employeeId) {
        boolean assigned = assignmentRepository
                .existsByWorkOrder_IdAndEmployee_IdAndAssignmentStatusIn(
                        workOrderId,
                        employeeId,
                        List.of("ASSIGNED", "ACCEPTED")
                );

        if (!assigned) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Employee is not assigned to this work order."
            );
        }
    }
}
