package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.JobCardCreationRequest;
import com.autogarage.automotive.service.JobCardService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/job-cards")
public class JobCardController {

    private final JobCardService jobCardService;

    public JobCardController(JobCardService jobCardService) {
        this.jobCardService = jobCardService;
    }

    @PostMapping
    public ResponseEntity<Map<String, Object>> createJobCard(
            @Valid @RequestBody JobCardCreationRequest request
    ) {

        Map<String, Object> response =
                jobCardService.createJobCard(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }

    @GetMapping("/{jobCardId}")
    public ResponseEntity<Map<String, Object>> getJobCard(
            @PathVariable Long jobCardId) {
        return ResponseEntity.ok(jobCardService.getJobCard(jobCardId));
    }
}
