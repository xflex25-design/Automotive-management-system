package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Quotation;
import org.springframework.data.jpa.repository.JpaRepository;

import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface QuotationRepository extends JpaRepository<Quotation, Long> {

    List<Quotation> findByJobIdOrderByVersionNumberDesc(Long jobId);

    Optional<Quotation> findByJobIdAndVersionNumber(
            Long jobId,
            Integer versionNumber
    );

    Optional<Quotation> findByJobIdAndQuotationNumber(
            Long jobId,
            String quotationNumber
    );

    List<Quotation> findByQuotationStatusOrderByCreatedAtDesc(
            String quotationStatus
    );

    @Query("""
        SELECT q.quotationNumber
        FROM Quotation q
        WHERE q.job.company.id = :companyId
        AND q.quotationNumber LIKE 'Qtn no-%'
        """)
        List<String> findQuotationNumbersByCompanyId(
                @Param("companyId") Long companyId
        );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
        @Query("SELECT q FROM Quotation q WHERE q.id = :quotationId")
        Optional<Quotation> findByIdForUpdate(
                @Param("quotationId") Long quotationId
        );
}