package com.autogarage.automotive.controller;

import com.autogarage.automotive.entity.Employee;
import com.autogarage.automotive.repository.DepartmentRepository;
import com.autogarage.automotive.repository.EmployeeRepository;
import com.autogarage.automotive.repository.StockLocationRepository;
import com.autogarage.automotive.repository.SupplierRepository;
import com.autogarage.automotive.security.WorkshopPrincipal;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/companies/{companyId}/workflow-options")
public class WorkflowOptionsController {

    private final DepartmentRepository departmentRepository;
    private final EmployeeRepository employeeRepository;
    private final SupplierRepository supplierRepository;
    private final StockLocationRepository stockLocationRepository;

    public WorkflowOptionsController(
            DepartmentRepository departmentRepository,
            EmployeeRepository employeeRepository,
            SupplierRepository supplierRepository,
            StockLocationRepository stockLocationRepository
    ) {
        this.departmentRepository = departmentRepository;
        this.employeeRepository = employeeRepository;
        this.supplierRepository = supplierRepository;
        this.stockLocationRepository = stockLocationRepository;
    }

    @GetMapping
    public Map<String, Object> getWorkflowOptions(
            @PathVariable Long companyId,
            @RequestParam Long workshopId,
            @AuthenticationPrincipal WorkshopPrincipal principal
    ) {
        if (principal == null || !companyId.equals(principal.companyId())
                || principal.workshopId() == null
                || !workshopId.equals(principal.workshopId())) {
            throw new AccessDeniedException("Workflow options are only available for your assigned company and workshop.");
        }

        var departments = departmentRepository
                .findActiveByCompanyAndWorkshop(companyId, workshopId)
                .stream()
                .map(department -> Map.of(
                        "id", department.getId(),
                        "name", department.getDepartmentName()))
                .toList();

        var employees = employeeRepository
                .findByCompanyIdAndWorkshopIdAndEmploymentStatus(
                        companyId, workshopId, "ACTIVE")
                .stream()
                .map(this::employeeOption)
                .toList();

        var suppliers = supplierRepository
                .findByCompany_IdAndActiveTrueOrderBySupplierNameAsc(companyId)
                .stream()
                .map(supplier -> Map.of(
                        "supplierId", supplier.getId(),
                        "supplierName", supplier.getSupplierName()))
                .toList();

        var stockLocations = stockLocationRepository
                .findByWorkshop_IdAndActiveTrue(workshopId)
                .stream()
                .map(location -> Map.of(
                        "stockLocationId", location.getId(),
                        "locationName", location.getLocationName()))
                .toList();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("departments", departments);
        result.put("employees", employees);
        result.put("suppliers", suppliers);
        result.put("stockLocations", stockLocations);
        return result;
    }

    private Map<String, Object> employeeOption(Employee employee) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("id", employee.getId());
        result.put("name", (employee.getFirstName() + " " + employee.getLastName()).trim());
        result.put("employeeNumber", employee.getEmployeeNumber());
        result.put("jobTitle", employee.getJobTitle());
        return result;
    }
}
