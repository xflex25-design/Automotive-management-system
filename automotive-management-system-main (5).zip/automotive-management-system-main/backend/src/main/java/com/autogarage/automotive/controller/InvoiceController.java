
package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.invoice.CancelInvoiceRequest;
import com.autogarage.automotive.dto.invoice.CreateInvoiceRequest;
import com.autogarage.automotive.dto.invoice.InvoiceEmailResponse;
import com.autogarage.automotive.dto.invoice.InvoiceResponse;
import com.autogarage.automotive.dto.invoice.PaymentResponse;
import com.autogarage.automotive.dto.invoice.RecordPaymentRequest;

import com.autogarage.automotive.service.InvoiceCancellationService;
import com.autogarage.automotive.service.InvoiceEmailService;
import com.autogarage.automotive.service.InvoicePdfService;
import com.autogarage.automotive.service.InvoiceQueryService;
import com.autogarage.automotive.service.InvoiceService;
import com.autogarage.automotive.service.PaymentService;

import lombok.RequiredArgsConstructor;

import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoices")
@RequiredArgsConstructor
public class InvoiceController {

    private final InvoiceService invoiceService;
    private final PaymentService paymentService;
    private final InvoiceQueryService invoiceQueryService;
    private final InvoiceCancellationService invoiceCancellationService;
    private final InvoicePdfService invoicePdfService;
    private final InvoiceEmailService invoiceEmailService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public InvoiceResponse createInvoice(
            @RequestBody CreateInvoiceRequest request
    ) {

        var invoice = invoiceService.createInvoice(request);

        return invoiceQueryService.getInvoice(invoice.getId());
    }

    @PostMapping("/{invoiceId}/payments")
    @ResponseStatus(HttpStatus.CREATED)
    public PaymentResponse recordPayment(
            @PathVariable Long invoiceId,
            @RequestBody RecordPaymentRequest request
    ) {
        return paymentService.recordPayment(invoiceId, request);
    }

    @GetMapping("/{invoiceId}")
    public InvoiceResponse getInvoice(
            @PathVariable Long invoiceId
    ) {
        return invoiceQueryService.getInvoice(invoiceId);
    }

    @GetMapping("/job/{jobId}")
    public List<InvoiceResponse> getInvoicesByJob(
            @PathVariable Long jobId
    ) {
        return invoiceQueryService.getInvoicesByJob(jobId);
    }

    @PatchMapping("/{invoiceId}/cancel")
    public InvoiceResponse cancelInvoice(
            @PathVariable Long invoiceId,
            @RequestBody CancelInvoiceRequest request
    ) {

        var invoice = invoiceCancellationService.cancelInvoice(
                invoiceId,
                request
        );

        return invoiceQueryService.getInvoice(invoice.getId());
    }

    @GetMapping(
            value = "/{invoiceId}/pdf",
            produces = MediaType.APPLICATION_PDF_VALUE
    )
    public ResponseEntity<byte[]> downloadInvoicePdf(
            @PathVariable Long invoiceId
    ) {

        byte[] pdf = invoicePdfService.generateInvoicePdf(invoiceId);

        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_PDF);

        headers.setContentDisposition(
                ContentDisposition.inline()
                        .filename("Invoice-" + invoiceId + ".pdf")
                        .build()
        );

        headers.setContentLength(pdf.length);

        return new ResponseEntity<>(
                pdf,
                headers,
                HttpStatus.OK
        );
    }

    @PostMapping("/{invoiceId}/email")
    public InvoiceEmailResponse emailInvoice(
            @PathVariable Long invoiceId
    ) {
        return invoiceEmailService.sendInvoice(invoiceId);
    }
}
