package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.VehicleHandover;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VehicleHandoverRepository
        extends JpaRepository<VehicleHandover, Long> {

    Optional<VehicleHandover> findByJob_Id(Long jobId);

    Optional<VehicleHandover> findByIdAndWorkshop_Id(
        Long id,
        Long workshopId
    );

    boolean existsByJob_Id(Long jobId);
}