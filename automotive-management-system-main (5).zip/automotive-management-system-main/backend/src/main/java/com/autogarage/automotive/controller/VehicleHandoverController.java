package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.handover.CreateVehicleHandoverRequest;
import com.autogarage.automotive.dto.handover.VehicleHandoverResponse;
import com.autogarage.automotive.service.VehicleHandoverService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/handovers")
public class VehicleHandoverController {

    private final VehicleHandoverService handoverService;

    public VehicleHandoverController(
            VehicleHandoverService handoverService
    ) {
        this.handoverService = handoverService;
    }

    @PostMapping
    public ResponseEntity<VehicleHandoverResponse> releaseVehicle(
            @RequestBody CreateVehicleHandoverRequest request
    ) {
        VehicleHandoverResponse response =
            handoverService.releaseVehicle(request);

        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(response);
    }

    @GetMapping("/{handoverId}")
    public ResponseEntity<VehicleHandoverResponse> getHandover(
            @PathVariable Long handoverId
    ) {
        return ResponseEntity.ok(
            handoverService.getHandoverById(handoverId)
        );
    }

    @GetMapping("/job/{jobId}")
    public ResponseEntity<VehicleHandoverResponse> getHandoverByJob(
            @PathVariable Long jobId
    ) {
        return ResponseEntity.ok(
            handoverService.getHandoverByJobId(jobId)
        );
    }
}