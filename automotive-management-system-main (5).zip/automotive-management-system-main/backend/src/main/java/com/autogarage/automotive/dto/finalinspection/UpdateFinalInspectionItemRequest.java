package com.autogarage.automotive.dto.finalinspection;

public record UpdateFinalInspectionItemRequest(
        Long employeeId,
        String checkStatus,
        String comments,
        Long responsibleDepartmentId
) {
}