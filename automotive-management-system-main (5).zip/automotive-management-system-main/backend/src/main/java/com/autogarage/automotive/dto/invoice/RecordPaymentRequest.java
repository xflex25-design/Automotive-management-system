package com.autogarage.automotive.dto.invoice;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record RecordPaymentRequest(
        Long receivedByEmployeeId,
        String paymentMethod,
        BigDecimal amount,
        String transactionReference,
        LocalDateTime paymentDate,
        String notes
) {}