package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Max;

public record VehicleIntakeRequest(

        @NotBlank(message = "Vehicle registration number is required")
        @Size(max = 30)
        String registrationNumber,

        @NotBlank(message = "Vehicle make is required")
        @Size(max = 100)
        String make,

        @Size(max = 100)
        String model,

        @Size(max = 100)
        String vehicleType,

        @Min(value = 1886, message = "Enter a valid vehicle model year")
        @Max(value = 2100, message = "Enter a valid vehicle model year")
        Integer modelYear,

        @Size(max = 50)
        String color,

        @Size(max = 100)
        String vin,

        @Size(max = 100)
        String engineNumber,

        @Size(max = 50)
        String fuelType,

        @Size(max = 50)
        String transmission

) {}