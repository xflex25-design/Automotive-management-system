package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "vehicle_damage_records")
@Getter
@Setter
@NoArgsConstructor
public class VehicleDamageRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inspection_id", nullable = false)
    private InspectionRecord inspection;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inventory_card_id", nullable = false)
    private VehicleInventoryCard inventoryCard;

    @Column(name = "damage_type", nullable = false, length = 30)
    private String damageType;

    @Column(name = "damage_location", nullable = false, length = 150)
    private String damageLocation;

    @Column(name = "damage_description", columnDefinition = "TEXT")
    private String damageDescription;

    @Column(length = 30)
    private String severity;

    @Column(name = "diagram_x", precision = 6, scale = 3)
    private BigDecimal diagramX;

    @Column(name = "diagram_y", precision = 6, scale = 3)
    private BigDecimal diagramY;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}