package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.PartsRequisition;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;
import java.util.Collection;
import java.util.List;

public interface PartsRequisitionRepository extends JpaRepository<PartsRequisition, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select r from PartsRequisition r where r.id = :id")
    Optional<PartsRequisition> findByIdForUpdate(@Param("id") Long id);

    Optional<PartsRequisition> findFirstByJob_IdAndRequisitionStatusIn(
            Long jobId, Collection<String> statuses);

    List<PartsRequisition> findByCompany_IdAndWorkshop_IdOrderByCreatedAtDesc(
            Long companyId, Long workshopId);
}
