package com.autogarage.automotive.dto;

import java.time.LocalDateTime;

public record VehiclePhotoResponse(
        Long mediaId,
        Long jobId,
        Long inventoryCardId,
        Long inspectionId,
        Long damageRecordId,
        String evidenceType,
        String fileName,
        String storageKey,
        String mimeType,
        Long fileSize,
        String caption,
        LocalDateTime capturedAt
) {}