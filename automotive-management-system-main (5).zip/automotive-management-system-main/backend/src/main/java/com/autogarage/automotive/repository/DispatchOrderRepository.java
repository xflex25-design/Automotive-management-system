package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.DispatchOrder;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface DispatchOrderRepository
        extends JpaRepository<DispatchOrder, Long> {

    Optional<DispatchOrder> findByWorkshop_IdAndDispatchNumber(
            Long workshopId, String dispatchNumber);

    List<DispatchOrder> findByJob_IdOrderByCreatedAtDesc(Long jobId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT d FROM DispatchOrder d WHERE d.id = :id")
    Optional<DispatchOrder> findByIdForUpdate(@Param("id") Long id);
}