package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "inventory_received_items")
@Getter
@Setter
@NoArgsConstructor
public class InventoryReceivedItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inventory_card_id", nullable = false)
    private VehicleInventoryCard inventoryCard;

    @Column(name = "item_name", nullable = false, length = 150)
    private String itemName;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false)
    private Integer quantity = 1;

    @Column(name = "condition_description", length = 255)
    private String conditionDescription;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}