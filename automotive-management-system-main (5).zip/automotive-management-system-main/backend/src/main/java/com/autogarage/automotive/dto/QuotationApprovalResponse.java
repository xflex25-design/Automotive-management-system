package com.autogarage.automotive.dto;

import java.time.LocalDateTime;
import java.util.List;

public record QuotationApprovalResponse(

        Long approvalId,
        Long quotationId,
        String quotationNumber,

        String customerName,
        String customerPhone,

        String approvalStatus,
        String approvalMethod,

        Long verifiedByEmployeeId,
        String verifiedByName,
        LocalDateTime verifiedAt,
        String verificationNotes,

        String notificationStatus,
        String notificationChannel,
        LocalDateTime notificationSentAt,

        LocalDateTime approvalTokenExpiresAt,

        String customerApprovalToken,

        List<QuotationItemApprovalResponse> items

) {}