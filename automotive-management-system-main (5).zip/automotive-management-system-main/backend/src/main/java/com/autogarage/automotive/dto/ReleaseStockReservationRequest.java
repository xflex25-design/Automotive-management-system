package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotNull;

public record ReleaseStockReservationRequest(
        @NotNull Long releasedByEmployeeId,
        String notes
) {}