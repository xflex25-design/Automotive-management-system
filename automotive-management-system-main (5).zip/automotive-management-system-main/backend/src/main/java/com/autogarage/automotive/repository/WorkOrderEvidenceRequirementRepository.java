
package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkOrderEvidenceRequirement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkOrderEvidenceRequirementRepository
        extends JpaRepository<WorkOrderEvidenceRequirement, Long> {

    List<WorkOrderEvidenceRequirement>
    findByDepartment_IdAndActiveTrue(Long departmentId);

    List<WorkOrderEvidenceRequirement>
    findByDepartment_IdAndWorkCategoryAndActiveTrue(
            Long departmentId,
            String workCategory
    );
}
