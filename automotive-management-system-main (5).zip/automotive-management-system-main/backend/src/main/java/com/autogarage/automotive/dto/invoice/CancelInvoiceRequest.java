package com.autogarage.automotive.dto.invoice;

public record CancelInvoiceRequest(
        Long cancelledByEmployeeId,
        String reason
) {}