package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "stock_locations")
@Getter
@Setter
@NoArgsConstructor
public class StockLocation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "workshop_id", nullable = false)
    private Workshop workshop;

    @Column(name = "location_name", nullable = false, length = 150)
    private String locationName;

    @Column(name = "location_code", nullable = false, length = 50)
    private String locationCode;

    @Column(name = "is_active")
    private Boolean active = true;
}
