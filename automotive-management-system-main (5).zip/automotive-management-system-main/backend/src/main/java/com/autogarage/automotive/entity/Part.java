package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(
    name = "parts",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uq_parts_company_code",
            columnNames = {"company_id", "part_code"}
        )
    }
)
@Getter
@Setter
@NoArgsConstructor
public class Part {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @Column(name = "part_code", nullable = false, length = 100)
    private String partCode;

    @Column(name = "part_name", nullable = false, length = 255)
    private String partName;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(length = 150)
    private String category;

    @Column(length = 150)
    private String brand;

    @Column(name = "unit_of_measure", length = 50)
    private String unitOfMeasure = "Piece";

    @Column(length = 150)
    private String barcode;

    @Column(name = "minimum_stock_level", precision = 12, scale = 2)
    private BigDecimal minimumStockLevel = BigDecimal.ZERO;

    @Column(name = "is_active")
    private Boolean active = true;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}