package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record RejectDispatchRequest(
        @NotNull Long rejectedByEmployeeId,
        @NotBlank String reason,
        @NotBlank String signerName,
        Long signatureMediaId,
        String remarks
) {}