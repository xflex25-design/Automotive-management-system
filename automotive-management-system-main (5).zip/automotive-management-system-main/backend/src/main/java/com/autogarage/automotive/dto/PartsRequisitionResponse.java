package com.autogarage.automotive.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record PartsRequisitionResponse(
        Long requisitionId,
        String requisitionNumber,
        Long jobId,
        String status,
        LocalDateTime submittedAt,
        List<Line> items
) {
    public record Line(Long requisitionItemId, Long partId, String partCode,
                       String partName, BigDecimal shortageQuantity,
                       String unitOfMeasure) {}
}
