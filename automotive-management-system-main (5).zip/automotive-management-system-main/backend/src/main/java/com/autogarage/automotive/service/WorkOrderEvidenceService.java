package com.autogarage.automotive.service;

import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class WorkOrderEvidenceService {

    private final WorkOrderRepository workOrderRepository;
    private final EmployeeRepository employeeRepository;
    private final MediaFileRepository mediaFileRepository;
    private final WorkOrderEvidenceRepository evidenceRepository;
    private final WorkOrderEvidenceRequirementRepository requirementRepository;
    private final WorkOrderDepartmentVisitRepository visitRepository;
    private final WorkOrderAssignmentRepository assignmentRepository;

    @Value("${media.storage.location:uploads}")
    private String storageLocation;

    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024;

    private static final Set<String> ALLOWED_TYPES = Set.of(
            "image/jpeg",
            "image/png",
            "image/webp"
    );

    private static final Set<String> ALLOWED_EVIDENCE_TYPES = Set.of(
            "BEFORE",
            "DURING",
            "AFTER",
            "REPLACED_PART",
            "TEST_RESULT",
            "OTHER"
    );

    public WorkOrderEvidenceService(
            WorkOrderRepository workOrderRepository,
            EmployeeRepository employeeRepository,
            MediaFileRepository mediaFileRepository,
            WorkOrderEvidenceRepository evidenceRepository,
            WorkOrderEvidenceRequirementRepository requirementRepository,
            WorkOrderDepartmentVisitRepository visitRepository,
            WorkOrderAssignmentRepository assignmentRepository
    ) {
        this.workOrderRepository = workOrderRepository;
        this.employeeRepository = employeeRepository;
        this.mediaFileRepository = mediaFileRepository;
        this.evidenceRepository = evidenceRepository;
        this.requirementRepository = requirementRepository;
        this.visitRepository = visitRepository;
        this.assignmentRepository = assignmentRepository;
    }

    @Transactional
    public Map<String, Object> uploadEvidence(
            Long workOrderId,
            Long employeeId,
            Long requirementId,
            String evidenceType,
            String caption,
            MultipartFile file
    ) throws IOException {

        ActorIdentity.requireEmployee(employeeId);

        WorkOrder workOrder = workOrderRepository.findById(workOrderId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Work order not found."
                ));

        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Employee not found."
                ));

        boolean assigned = assignmentRepository
                .existsByWorkOrder_IdAndEmployee_IdAndAssignmentStatusIn(
                        workOrderId,
                        employeeId,
                        List.of("ASSIGNED", "ACCEPTED")
                );

        if (!assigned) {
        throw new ResponseStatusException(
                HttpStatus.FORBIDDEN,
                "Only employees assigned to this work order can upload evidence."
        );
        }

        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("An image file is required.");
        }

        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException(
                    "Image size must not exceed 10 MB."
            );
        }

        String contentType = file.getContentType();

        if (contentType == null || !ALLOWED_TYPES.contains(contentType.toLowerCase())) {
            throw new IllegalArgumentException(
                    "Only JPEG, PNG and WebP images are allowed."
            );
        }

        byte[] fileBytes = file.getBytes();
        if (!matchesImageSignature(contentType.toLowerCase(Locale.ROOT), fileBytes)) {
            throw new IllegalArgumentException(
                    "The uploaded file content does not match its declared image type."
            );
        }

        String type = evidenceType == null
                ? ""
                : evidenceType.trim().toUpperCase();

        if (!ALLOWED_EVIDENCE_TYPES.contains(type)) {
            throw new IllegalArgumentException(
                    "Invalid evidence type."
            );
        }

        boolean openVisit = visitRepository
                .findFirstByWorkOrder_IdAndVisitStatusOrderByVisitNumberDesc(
                        workOrderId,
                        "OPEN"
                )
                .isPresent();

        if (!openVisit) {
            throw new IllegalStateException(
                    "Evidence can only be uploaded during an open department visit."
            );
        }

        WorkOrderEvidenceRequirement requirement = null;

        if (requirementId != null) {
            requirement = requirementRepository.findById(requirementId)
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Evidence requirement not found."
                    ));

            if (!Boolean.TRUE.equals(requirement.getActive())) {
                throw new IllegalArgumentException(
                        "This evidence requirement is inactive."
                );
            }

            if (!Objects.equals(
                    requirement.getDepartment().getId(),
                    workOrder.getDepartment().getId()
            )) {
                throw new IllegalArgumentException(
                        "The evidence requirement does not belong to this work order's department."
                );
            }

            if (!requirement.getEvidenceType().equalsIgnoreCase(type)) {
                throw new IllegalArgumentException(
                        "Evidence type does not match the selected requirement."
                );
            }
        }

        String extension = switch (contentType.toLowerCase()) {
            case "image/jpeg" -> ".jpg";
            case "image/png" -> ".png";
            case "image/webp" -> ".webp";
            default -> throw new IllegalArgumentException("Unsupported image type.");
        };

        String storageKey = "work-order-evidence/"
                + workOrderId + "/"
                + UUID.randomUUID() + extension;

        Path root = Paths.get(storageLocation).toAbsolutePath().normalize();
        Path destination = root.resolve(storageKey).normalize();

        if (!destination.startsWith(root)) {
            throw new IllegalArgumentException("Invalid storage path.");
        }

        Files.createDirectories(destination.getParent());
        Files.write(destination, fileBytes, StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);

        try {
            MediaFile mediaFile = new MediaFile();
            mediaFile.setJob(workOrder.getJob());
            mediaFile.setWorkOrder(workOrder);
            mediaFile.setUploadedBy(employee);
            mediaFile.setEvidenceType(type);
            mediaFile.setFileName(
                    file.getOriginalFilename() == null
                            ? "evidence" + extension
                            : Paths.get(file.getOriginalFilename())
                                    .getFileName().toString()
            );
            mediaFile.setStorageKey(storageKey);
            mediaFile.setMimeType(contentType);
            mediaFile.setFileSize((long) fileBytes.length);
            mediaFile.setCaption(caption);

            MediaFile savedMedia = mediaFileRepository.save(mediaFile);

            WorkOrderEvidence evidence = new WorkOrderEvidence();
            evidence.setWorkOrder(workOrder);
            evidence.setMediaFile(savedMedia);
            evidence.setEvidenceRequirement(requirement);
            evidence.setEvidenceType(type);
            evidence.setUploadedBy(employee);
            evidence.setCaption(caption);
            evidence.setCapturedAt(LocalDateTime.now());

            WorkOrderEvidence savedEvidence =
                    evidenceRepository.save(evidence);

            Map<String, Object> response = new LinkedHashMap<>();
            response.put("evidenceId", savedEvidence.getId());
            response.put("mediaFileId", savedMedia.getId());
            response.put("workOrderId", workOrderId);
            response.put("evidenceType", type);
            response.put("fileName", savedMedia.getFileName());
            response.put("storageKey", storageKey);
            response.put("uploadedByEmployeeId", employeeId);
            response.put("message", "Work order evidence uploaded successfully.");

            return response;

        } catch (RuntimeException exception) {
            Files.deleteIfExists(destination);
            throw exception;
        }
    }

    private boolean matchesImageSignature(String contentType, byte[] bytes) {
        return switch (contentType) {
            case "image/jpeg" -> bytes.length >= 3
                    && (bytes[0] & 0xFF) == 0xFF
                    && (bytes[1] & 0xFF) == 0xD8
                    && (bytes[2] & 0xFF) == 0xFF;
            case "image/png" -> bytes.length >= 8
                    && (bytes[0] & 0xFF) == 0x89
                    && bytes[1] == 0x50
                    && bytes[2] == 0x4E
                    && bytes[3] == 0x47
                    && bytes[4] == 0x0D
                    && bytes[5] == 0x0A
                    && bytes[6] == 0x1A
                    && bytes[7] == 0x0A;
            case "image/webp" -> bytes.length >= 12
                    && bytes[0] == 'R'
                    && bytes[1] == 'I'
                    && bytes[2] == 'F'
                    && bytes[3] == 'F'
                    && bytes[8] == 'W'
                    && bytes[9] == 'E'
                    && bytes[10] == 'B'
                    && bytes[11] == 'P';
            default -> false;
        };
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getEvidence(Long workOrderId) {

        WorkOrder workOrder = workOrderRepository.findById(workOrderId)
                .orElseThrow(() -> new IllegalArgumentException("Work order not found."));
        ActorIdentity.requireCompanyWorkshop(
                workOrder.getJob().getCompany().getId(),
                workOrder.getJob().getWorkshop().getId());

        return evidenceRepository
                .findByWorkOrder_IdOrderByUploadedAtDesc(workOrderId)
                .stream()
                .map(evidence -> {
                    Map<String, Object> item = new LinkedHashMap<>();

                    item.put("evidenceId", evidence.getId());
                    item.put("mediaFileId", evidence.getMediaFile().getId());
                    item.put("evidenceType", evidence.getEvidenceType());
                    item.put("fileName", evidence.getMediaFile().getFileName());
                    item.put("storageKey", evidence.getMediaFile().getStorageKey());
                    item.put("caption", evidence.getCaption());
                    item.put("uploadedByEmployeeId",
                            evidence.getUploadedBy().getId());
                    item.put("uploadedAt", evidence.getUploadedAt());

                    return item;
                })
                .toList();
    }
}
