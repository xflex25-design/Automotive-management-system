package com.autogarage.automotive.service;

import com.autogarage.automotive.security.ActorIdentity;
import com.autogarage.automotive.dto.*;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import jakarta.transaction.Transactional;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class DispatchOrderService {

    private final DispatchOrderRepository dispatchRepository;
    private final DispatchOrderItemRepository itemRepository;
    private final DispatchSignatureRepository signatureRepository;
    private final JobRepository jobRepository;
    private final EmployeeRepository employeeRepository;
    private final StockReservationRepository reservationRepository;
    private final StockBalanceRepository stockBalanceRepository;
    private final StockMovementRepository stockMovementRepository;
    private final MediaFileRepository mediaFileRepository;
    private final DepartmentRepository departmentRepository;

    public DispatchOrderService(
            DispatchOrderRepository dispatchRepository,
            DispatchOrderItemRepository itemRepository,
            DispatchSignatureRepository signatureRepository,
            JobRepository jobRepository,
            EmployeeRepository employeeRepository,
            StockReservationRepository reservationRepository,
            StockBalanceRepository stockBalanceRepository,
            StockMovementRepository stockMovementRepository,
            MediaFileRepository mediaFileRepository,
            DepartmentRepository departmentRepository
    ) {
        this.dispatchRepository = dispatchRepository;
        this.itemRepository = itemRepository;
        this.signatureRepository = signatureRepository;
        this.jobRepository = jobRepository;
        this.employeeRepository = employeeRepository;
        this.reservationRepository = reservationRepository;
        this.stockBalanceRepository = stockBalanceRepository;
        this.stockMovementRepository = stockMovementRepository;
        this.mediaFileRepository = mediaFileRepository;
        this.departmentRepository = departmentRepository;
    }

    @Transactional
    public Map<String, Object> createDispatchOrder(CreateDispatchOrderRequest request) {
        ActorIdentity.requireAnyAuthority("ROLE_FOREMAN");
        ActorIdentity.requireEmployee(request.createdByEmployeeId());

        Job job = jobRepository.findByIdForUpdate(request.jobId())
                .orElseThrow(() -> notFound("Job not found"));

        Employee foreman = findEmployee(
                request.createdByEmployeeId(), job.getCompany().getId());

        Employee mechanic = findEmployee(
                request.assignedMechanicEmployeeId(), job.getCompany().getId());

        validateWorkshopEmployee(foreman, job);
        validateWorkshopEmployee(mechanic, job);

        DispatchOrder order = new DispatchOrder();
        order.setCompany(job.getCompany());
        order.setWorkshop(job.getWorkshop());
        order.setJob(job);
        order.setDispatchNumber("TEMP-" + UUID.randomUUID());
        order.setCreatedBy(foreman);

        // Existing database column is NOT NULL.
        // It is replaced with the actual Stores issuer when stock is issued.
        order.setDispatchedBy(foreman);

        order.setAssignedMechanic(mechanic);
        order.setDepartment(
                findDispatchDepartment(request.departmentId(), job)
        );
        order.setDispatchStatus("PENDING_APPROVAL");
        order.setCustomerOrCompanyNameSnapshot(job.getBroughtInByName());
        order.setContactNumberSnapshot(job.getBroughtInByPhone());
        order.setRemarks(request.remarks());

        DispatchOrder savedOrder = dispatchRepository.save(order);

        savedOrder.setDispatchNumber(
                String.valueOf(savedOrder.getId())
        );

        savedOrder = dispatchRepository.save(savedOrder);

        Set<Long> usedReservationIds = new HashSet<>();

        for (CreateDispatchOrderRequest.DispatchItemRequest line : request.items()) {

            if (!usedReservationIds.add(line.stockReservationId())) {
                throw badRequest("A stock reservation cannot appear twice in one dispatch order.");
            }

            StockReservation reservation = reservationRepository
                    .findByIdForUpdate(line.stockReservationId())
                    .orElseThrow(() -> notFound(
                            "Stock reservation " + line.stockReservationId() + " not found"));

            if (!"ACTIVE".equals(reservation.getReservationStatus())) {
                throw conflict("Only active stock reservations can be dispatched.");
            }

            Job reservedJob = reservation.getJobCardPart()
                    .getJobCard()
                    .getJob();

            if (!Objects.equals(reservedJob.getId(), job.getId())) {
                throw badRequest("A reservation belongs to a different job.");
            }

            if (reservation.getQuantityReserved() == null
                    || reservation.getQuantityReserved().compareTo(BigDecimal.ZERO) <= 0) {
                throw badRequest("The reservation quantity must be greater than zero.");
            }

            Part part = reservation.getJobCardPart().getPart();

            if (part == null) {
                throw badRequest("The reserved job item has no catalogue part linked.");
            }

            StockBalance balance = reservation.getStockBalance();

            DispatchOrderItem item = new DispatchOrderItem();
            item.setDispatchOrder(savedOrder);
            item.setStockReservation(reservation);
            item.setPart(part);
            item.setStockLocation(balance.getLocation());
            item.setDescriptionSnapshot(
                    reservation.getJobCardPart().getPartName());
            item.setQuantityRequested(reservation.getQuantityReserved());
            item.setQuantityDispatched(null);
            item.setUnitOfMeasure(
                    reservation.getJobCardPart().getUnitOfMeasure());
            item.setUnitSellingPrice(line.unitSellingPrice());

            BigDecimal amountSold = line.amountSold();

            if (amountSold == null && line.unitSellingPrice() != null) {
                amountSold = reservation.getQuantityReserved()
                        .multiply(line.unitSellingPrice());
            }

            item.setAmountSold(amountSold);
            item.setRemarks(line.remarks());

            itemRepository.save(item);
        }

        return orderResponse(savedOrder);
    }

    @Transactional
    public Map<String, Object> approveDispatch(
            Long dispatchId, ApproveDispatchRequest request) {
        ActorIdentity.requireEmployee(request.approvedByEmployeeId());

        DispatchOrder order = lockOrder(dispatchId);
        requireStatus(order, "PENDING_APPROVAL");

        Employee approver = findEmployee(
                request.approvedByEmployeeId(), order.getCompany().getId());

        validateWorkshopEmployee(approver, order.getJob());

        order.setApprovedBy(approver);
        order.setApprovedAt(LocalDateTime.now());
        order.setDispatchStatus("APPROVED");

        saveSignature(
                order, "AUTHORISED_BY", request.signerName(),
                approver, request.signatureMediaId(), request.remarks());

        dispatchRepository.save(order);
        return orderResponse(order);
    }

    @Transactional
    public Map<String, Object> rejectDispatch(
            Long dispatchId, RejectDispatchRequest request) {
        ActorIdentity.requireEmployee(request.rejectedByEmployeeId());

        DispatchOrder order = lockOrder(dispatchId);
        requireStatus(order, "PENDING_APPROVAL");

        Employee rejector = findEmployee(
                request.rejectedByEmployeeId(), order.getCompany().getId());

        validateWorkshopEmployee(rejector, order.getJob());

        order.setDispatchStatus("REJECTED");
        order.setRejectionReason(request.reason());

        saveSignature(
                order, "AUTHORISED_BY", request.signerName(),
                rejector, request.signatureMediaId(), request.remarks());

        dispatchRepository.save(order);
        return orderResponse(order);
    }

    @Transactional
    public Map<String, Object> resubmitDispatch(Long dispatchId) {

        ActorIdentity.requireAnyAuthority("ROLE_FOREMAN");
        ActorIdentity.employeeId();

        DispatchOrder order = lockOrder(dispatchId);
        requireStatus(order, "REJECTED");

        List<DispatchOrderItem> items =
                itemRepository.findByDispatchOrder_IdOrderByIdAsc(dispatchId);

        if (items.isEmpty()) {
            throw badRequest("A dispatch order must contain at least one item.");
        }

        for (DispatchOrderItem item : items) {
            StockReservation reservation = reservationRepository
                    .findByIdForUpdate(item.getStockReservation().getId())
                    .orElseThrow(() -> notFound("Stock reservation not found"));

            if (!"ACTIVE".equals(reservation.getReservationStatus())) {
                throw conflict("A reservation on this dispatch is no longer active.");
            }
        }

        order.setDispatchStatus("PENDING_APPROVAL");
        order.setApprovedBy(null);
        order.setApprovedAt(null);
        order.setRejectionReason(null);

        dispatchRepository.save(order);
        return orderResponse(order);
    }

    @Transactional
    public Map<String, Object> correctDispatch(
            Long dispatchId,
            CorrectDispatchOrderRequest request) {

        ActorIdentity.requireAnyAuthority("ROLE_FOREMAN");
        ActorIdentity.employeeId();

        DispatchOrder order = lockOrder(dispatchId);
        requireStatus(order, "REJECTED");

        Job job = order.getJob();

        Employee mechanic = findEmployee(
                request.assignedMechanicEmployeeId(),
                job.getCompany().getId()
        );

        validateWorkshopEmployee(mechanic, job);

        Department department = findDispatchDepartment(
                request.departmentId(), job
        );

        // Validate all replacement reservations before changing any items.
        Map<Long, StockReservation> requestedReservations =
                new LinkedHashMap<>();

        for (CreateDispatchOrderRequest.DispatchItemRequest line
                : request.items()) {

            Long reservationId = line.stockReservationId();

            if (requestedReservations.containsKey(reservationId)) {
                throw badRequest(
                        "A stock reservation cannot appear twice in one dispatch order."
                );
            }

            StockReservation reservation = reservationRepository
                    .findByIdForUpdate(reservationId)
                    .orElseThrow(() ->
                            notFound("Stock reservation " + reservationId + " not found")
                    );

            if (!"ACTIVE".equals(reservation.getReservationStatus())) {
                throw conflict(
                        "Only active stock reservations can be used."
                );
            }

            Job reservedJob = reservation.getJobCardPart()
                    .getJobCard()
                    .getJob();

            if (!Objects.equals(reservedJob.getId(), job.getId())) {
                throw badRequest(
                        "A reservation belongs to a different job."
                );
            }

            if (reservation.getQuantityReserved() == null
                    || reservation.getQuantityReserved()
                    .compareTo(BigDecimal.ZERO) <= 0) {
                throw badRequest(
                        "The reservation quantity must be greater than zero."
                );
            }

            Part part = reservation.getJobCardPart().getPart();

            if (part == null) {
                throw badRequest(
                        "The reserved job item has no catalogue part linked."
                );
            }

            if (itemRepository
                    .existsByStockReservation_IdAndDispatchOrder_IdNot(
                            reservationId, dispatchId)) {
                throw conflict(
                        "This stock reservation is already attached to another dispatch order."
                );
            }

            requestedReservations.put(reservationId, reservation);
        }

        List<DispatchOrderItem> existingItems =
                itemRepository.findByDispatchOrder_IdOrderByIdAsc(dispatchId);

        Map<Long, DispatchOrderItem> existingByReservation =
                new HashMap<>();

        for (DispatchOrderItem existing : existingItems) {

            if (existing.getStockReservation() != null) {
                existingByReservation.put(
                        existing.getStockReservation().getId(),
                        existing
                );
            }
        }

        // Update dispatch header.
        order.setAssignedMechanic(mechanic);
        order.setDepartment(department);
        order.setRemarks(request.remarks());

        // Remove obsolete dispatch lines.
        List<DispatchOrderItem> obsoleteItems = existingItems.stream()
                .filter(item ->
                        item.getStockReservation() == null
                        || !requestedReservations.containsKey(
                                item.getStockReservation().getId()
                        ))
                .toList();

        if (!obsoleteItems.isEmpty()) {
            itemRepository.deleteAll(obsoleteItems);
            itemRepository.flush();
        }

        // Update existing lines or create new ones.
        for (CreateDispatchOrderRequest.DispatchItemRequest line
                : request.items()) {

            StockReservation reservation =
                    requestedReservations.get(line.stockReservationId());

            DispatchOrderItem item =
                    existingByReservation.get(line.stockReservationId());

            if (item == null) {
                item = new DispatchOrderItem();
                item.setDispatchOrder(order);
                item.setStockReservation(reservation);
            }

            StockBalance balance = reservation.getStockBalance();

            item.setPart(reservation.getJobCardPart().getPart());
            item.setStockLocation(balance.getLocation());

            item.setDescriptionSnapshot(
                    reservation.getJobCardPart().getPartName()
            );

            item.setQuantityRequested(
                    reservation.getQuantityReserved()
            );

            item.setQuantityDispatched(null);

            item.setUnitOfMeasure(
                    reservation.getJobCardPart().getUnitOfMeasure()
            );

            item.setUnitSellingPrice(line.unitSellingPrice());

            BigDecimal amountSold = line.amountSold();

            if (amountSold == null && line.unitSellingPrice() != null) {
                amountSold = reservation.getQuantityReserved()
                        .multiply(line.unitSellingPrice());
            }

            item.setAmountSold(amountSold);
            item.setRemarks(line.remarks());

            itemRepository.save(item);
        }

        dispatchRepository.save(order);

        return orderResponse(order);
    }

    @Transactional
    public Map<String, Object> issueDispatch(
            Long dispatchId, IssueDispatchRequest request) {
        ActorIdentity.requireAnyAuthority("ROLE_STORES");
        ActorIdentity.requireEmployee(request.issuedByEmployeeId());

        DispatchOrder order = lockOrder(dispatchId);

        // Critical control: stock cannot be issued before approval.
        requireStatus(order, "APPROVED");

        Employee issuer = findEmployee(
                request.issuedByEmployeeId(), order.getCompany().getId());

        validateWorkshopEmployee(issuer, order.getJob());

        List<DispatchOrderItem> items =
                itemRepository.findByDispatchOrder_IdOrderByIdAsc(dispatchId);

        if (items.isEmpty()) {
            throw badRequest("This dispatch order has no items.");
        }

        for (DispatchOrderItem item : items) {

            StockReservation reservation = reservationRepository
                    .findByIdForUpdate(item.getStockReservation().getId())
                    .orElseThrow(() -> notFound("Stock reservation not found"));

            if (!"ACTIVE".equals(reservation.getReservationStatus())) {
                throw conflict("A dispatch item no longer has an active reservation.");
            }

            BigDecimal quantity = reservation.getQuantityReserved();

            List<StockBalance> balances = stockBalanceRepository
                    .lockPartAtLocation(
                            reservation.getJobCardPart().getPart().getId(),
                            reservation.getStockBalance().getLocation().getId());

            if (balances.isEmpty()) {
                throw notFound("Stock balance not found");
            }

            StockBalance balance = balances.get(0);

            if (balance.getQuantityOnHand().compareTo(quantity) < 0
                    || balance.getQuantityReserved().compareTo(quantity) < 0) {
                throw conflict("Stock balance or reserved quantity is insufficient.");
            }

            balance.setQuantityOnHand(
                    balance.getQuantityOnHand().subtract(quantity));

            balance.setQuantityReserved(
                    balance.getQuantityReserved().subtract(quantity));

            stockBalanceRepository.save(balance);

            reservation.setReservationStatus("CONSUMED");
            reservation.setConsumedAt(LocalDateTime.now());
            reservationRepository.save(reservation);

            item.setQuantityDispatched(quantity);
            itemRepository.save(item);

            StockMovement movement = new StockMovement();
            movement.setPart(reservation.getJobCardPart().getPart());
            movement.setStockLocation(balance.getLocation());
            movement.setMovementType("ISSUE");
            movement.setQuantity(quantity);
            movement.setReferenceType("DISPATCH_ORDER");
            movement.setReferenceId(order.getId());
            movement.setPerformedBy(issuer);
            movement.setRemarks(
                    "Issued against dispatch order " + order.getDispatchNumber());

            stockMovementRepository.save(movement);
        }

        order.setDispatchedBy(issuer);
        order.setIssuedAt(LocalDateTime.now());
        order.setDispatchDate(LocalDateTime.now());
        order.setDispatchStatus("ISSUED");

        saveSignature(
                order, "DISPATCHED_BY", request.signerName(),
                issuer, request.signatureMediaId(), request.remarks());

        dispatchRepository.save(order);
        return orderResponse(order);
    }

    @Transactional
    public Map<String, Object> receiveDispatch(
            Long dispatchId, ReceiveDispatchRequest request) {
        ActorIdentity.requireEmployee(request.receivedByEmployeeId());

        DispatchOrder order = lockOrder(dispatchId);
        requireStatus(order, "ISSUED");

        Employee receiver = findEmployee(
                request.receivedByEmployeeId(), order.getCompany().getId());

        validateWorkshopEmployee(receiver, order.getJob());

        if (!Objects.equals(
                receiver.getId(), order.getAssignedMechanic().getId())) {
            throw badRequest(
                    "Only the mechanic assigned to this dispatch can acknowledge receipt.");
        }

        order.setReceivedBy(receiver);
        order.setReceivedAt(LocalDateTime.now());
        order.setDispatchStatus("RECEIVED");

        saveSignature(
                order, "RECEIVED_BY", request.signerName(),
                receiver, request.signatureMediaId(), request.remarks());

        dispatchRepository.save(order);
        return orderResponse(order);
    }

    @Transactional
    public Map<String, Object> acknowledgeAccounts(
            Long dispatchId, AccountsDispatchAcknowledgementRequest request) {
        ActorIdentity.requireAnyAuthority("ROLE_ACCOUNTS");
        ActorIdentity.requireEmployee(request.acknowledgedByEmployeeId());

        DispatchOrder order = lockOrder(dispatchId);
        if (!Set.of("APPROVED", "ISSUED", "RECEIVED")
                .contains(order.getDispatchStatus())) {
            throw conflict(
                    "Accounts can acknowledge the dispatch document after manager or boss approval.");
        }

        if (signatureRepository.findByDispatchOrder_IdOrderBySignedAtAsc(dispatchId)
                .stream().anyMatch(signature ->
                        "ACCOUNTS_ACKNOWLEDGEMENT".equalsIgnoreCase(signature.getSignerType()))) {
            throw conflict("Accounts has already acknowledged this dispatch order.");
        }

        Employee accountsEmployee = findEmployee(
                request.acknowledgedByEmployeeId(), order.getCompany().getId());

        validateWorkshopEmployee(accountsEmployee, order.getJob());

        saveSignature(
                order, "ACCOUNTS_ACKNOWLEDGEMENT",
                request.signerName(), accountsEmployee,
                request.signatureMediaId(), request.remarks());

        return orderResponse(order);
    }

  
    @Transactional
    public Map<String, Object> acknowledgeCustomer(
            Long dispatchId, CustomerDispatchAcknowledgementRequest request) {

        DispatchOrder order = lockOrder(dispatchId);

        if (!"ISSUED".equals(order.getDispatchStatus())
                && !"RECEIVED".equals(order.getDispatchStatus())) {
            throw conflict(
                    "Customer acknowledgement is available after the parts have been issued.");
        }

        saveSignature(
                order,
                "CUSTOMER_ACKNOWLEDGEMENT",
                request.signerName(),
                null,
                request.signatureMediaId(),
                request.remarks()
        );

        return orderResponse(order);
    }


    @Transactional
    public Map<String, Object> getDispatch(Long dispatchId) {
        return orderResponse(lockOrder(dispatchId));
    }

    @Transactional
    public List<Map<String, Object>> getJobDispatches(Long jobId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> notFound("Job not found"));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());
        return dispatchRepository.findByJob_IdOrderByCreatedAtDesc(jobId)
                .stream()
                .map(this::orderResponse)
                .toList();
    }

    private DispatchOrder lockOrder(Long id) {
        DispatchOrder order = dispatchRepository.findByIdForUpdate(id)
                .orElseThrow(() -> notFound("Dispatch order not found"));
        ActorIdentity.requireCompanyWorkshop(
                order.getCompany().getId(), order.getWorkshop().getId());
        return order;
    }

    private Employee findEmployee(Long employeeId, Long companyId) {
        return employeeRepository.findByIdAndCompanyId(employeeId, companyId)
                .orElseThrow(() -> notFound("Employee not found in this company"));
    }

    private void validateWorkshopEmployee(Employee employee, Job job) {
        if (employee.getWorkshop() == null
                || !Objects.equals(
                employee.getWorkshop().getId(), job.getWorkshop().getId())) {
            throw badRequest("Employee does not belong to this workshop.");
        }

        if (!"ACTIVE".equalsIgnoreCase(employee.getEmploymentStatus())) {
            throw badRequest("Employee is not active.");
        }
    }

    private Department findDispatchDepartment(Long departmentId, Job job) {
        if (departmentId == null) {
            return null;
        }

        return departmentRepository
                .findByIdAndCompany_IdAndWorkshop_IdAndActiveTrue(
                        departmentId,
                        job.getCompany().getId(),
                        job.getWorkshop().getId()
                )
                .orElseThrow(() ->
                        badRequest(
                                "The selected department is inactive or does not belong to this workshop."
                        )
                );
    }

    private void saveSignature(
            DispatchOrder order,
            String type,
            String signerName,
            Employee employee,
            Long mediaId,
            String remarks) {

        DispatchSignature signature = new DispatchSignature();
        signature.setDispatchOrder(order);
        signature.setSignerType(type);
        signature.setSignerName(signerName.trim());
        signature.setEmployee(employee);
        signature.setRemarks(remarks);

        if (mediaId != null) {
            MediaFile media = mediaFileRepository.findById(mediaId)
                    .orElseThrow(() -> notFound("Signature media file not found"));
            signature.setSignatureMedia(media);
        }

        signatureRepository.save(signature);
    }

    private void requireStatus(DispatchOrder order, String expected) {
        if (!expected.equals(order.getDispatchStatus())) {
            throw conflict(
                    "Dispatch order must be " + expected
                            + ". Current status: " + order.getDispatchStatus());
        }
    }

    private Map<String, Object> orderResponse(DispatchOrder order) {

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("dispatchOrderId", order.getId());
        response.put("dispatchNumber", order.getDispatchNumber());
        response.put("jobId", order.getJob().getId());
        response.put("status", order.getDispatchStatus());
        response.put("assignedMechanicId",
                order.getAssignedMechanic() == null
                        ? null : order.getAssignedMechanic().getId());
        response.put("createdAt", order.getCreatedAt());
        response.put("approvedAt", order.getApprovedAt());
        response.put("issuedAt", order.getIssuedAt());
        response.put("receivedAt", order.getReceivedAt());
        response.put("rejectionReason", order.getRejectionReason());

        List<Map<String, Object>> itemResponses = new ArrayList<>();

        for (DispatchOrderItem item :
                itemRepository.findByDispatchOrder_IdOrderByIdAsc(order.getId())) {

            Map<String, Object> line = new LinkedHashMap<>();
            line.put("itemId", item.getId());
            line.put("stockReservationId", item.getStockReservation() == null
                    ? null : item.getStockReservation().getId());
            line.put("partId", item.getPart().getId());
            line.put("description", item.getDescriptionSnapshot());
            line.put("quantityRequested", item.getQuantityRequested());
            line.put("quantityDispatched", item.getQuantityDispatched());
            line.put("unitOfMeasure", item.getUnitOfMeasure());
            line.put("unitSellingPrice", item.getUnitSellingPrice());
            line.put("amountSold", item.getAmountSold());
            itemResponses.add(line);
        }

        response.put("items", itemResponses);

        List<Map<String, Object>> signatures = new ArrayList<>();

        for (DispatchSignature signature :
                signatureRepository.findByDispatchOrder_IdOrderBySignedAtAsc(order.getId())) {

            Map<String, Object> signed = new LinkedHashMap<>();
            signed.put("type", signature.getSignerType());
            signed.put("signerName", signature.getSignerName());
            signed.put("employeeId",
                    signature.getEmployee() == null
                            ? null : signature.getEmployee().getId());
            signed.put("signedAt", signature.getSignedAt());
            signed.put("remarks", signature.getRemarks());
            signatures.add(signed);
        }

        response.put("signatures", signatures);
        signatures.stream()
                .filter(signature -> "ACCOUNTS_ACKNOWLEDGEMENT".equals(signature.get("type")))
                .findFirst()
                .ifPresent(signature -> {
                    response.put("accountsArrivedAt", signature.get("signedAt"));
                    response.put("accountsAcknowledgedByEmployeeId", signature.get("employeeId"));
                });
        return response;
    }

    private ResponseStatusException notFound(String message) {
        return new ResponseStatusException(HttpStatus.NOT_FOUND, message);
    }

    private ResponseStatusException badRequest(String message) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, message);
    }

    private ResponseStatusException conflict(String message) {
        return new ResponseStatusException(HttpStatus.CONFLICT, message);
    }
}
