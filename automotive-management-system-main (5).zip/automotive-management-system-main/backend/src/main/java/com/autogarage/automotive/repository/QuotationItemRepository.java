package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.QuotationItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuotationItemRepository extends JpaRepository<QuotationItem, Long> {

    List<QuotationItem> findByQuotationIdOrderByIdAsc(Long quotationId);

    List<QuotationItem> findByQuotationIdAndItemType(
            Long quotationId,
            String itemType
    );

    long countByQuotationId(Long quotationId);
}