package com.autogarage.automotive.service;

import com.autogarage.automotive.config.FileStorageProperties;
import com.autogarage.automotive.dto.VehiclePhotoResponse;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

@Service
public class VehiclePhotoService {

    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024;

    private static final Set<String> ALLOWED_EVIDENCE_TYPES = Set.of(
            "INTAKE_OVERVIEW",
            "DAMAGE",
            "ODOMETER",
            "FUEL_LEVEL",
            "ACCESSORY",
            "INSPECTION",
            "SIGNATURE"
    );

    private final JobRepository jobRepository;
    private final VehicleInventoryCardRepository inventoryCardRepository;
    private final InspectionRecordRepository inspectionRepository;
    private final VehicleDamageRecordRepository damageRepository;
    private final EmployeeRepository employeeRepository;
    private final MediaFileRepository mediaFileRepository;
    private final FileStorageProperties storageProperties;

    public VehiclePhotoService(
            JobRepository jobRepository,
            VehicleInventoryCardRepository inventoryCardRepository,
            InspectionRecordRepository inspectionRepository,
            VehicleDamageRecordRepository damageRepository,
            EmployeeRepository employeeRepository,
            MediaFileRepository mediaFileRepository,
            FileStorageProperties storageProperties
    ) {
        this.jobRepository = jobRepository;
        this.inventoryCardRepository = inventoryCardRepository;
        this.inspectionRepository = inspectionRepository;
        this.damageRepository = damageRepository;
        this.employeeRepository = employeeRepository;
        this.mediaFileRepository = mediaFileRepository;
        this.storageProperties = storageProperties;
    }

    @Transactional
    public VehiclePhotoResponse uploadIntakePhoto(
            Long jobId,
            Long inspectionId,
            Long damageRecordId,
            Long uploadedByEmployeeId,
            String evidenceType,
            String caption,
            LocalDateTime capturedAt,
            MultipartFile file
    ) {
        ActorIdentity.requireEmployee(uploadedByEmployeeId);
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Job not found"
                ));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        VehicleInventoryCard inventoryCard =
                inventoryCardRepository.findByJobId(jobId)
                        .orElseThrow(() -> new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Vehicle inventory card not found"
                        ));

        InspectionRecord inspection = inspectionRepository
                .findById(inspectionId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Inspection not found"
                ));

        if (!inspection.getJob().getId().equals(jobId)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Inspection does not belong to this job"
            );
        }

        Employee uploader = employeeRepository
                .findByIdAndCompanyId(
                        uploadedByEmployeeId,
                        job.getCompany().getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Uploading employee not found for this company"
                ));

        if (!uploader.getWorkshop().getId()
                .equals(job.getWorkshop().getId())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Uploading employee does not belong to this workshop"
            );
        }

        if (!"ACTIVE".equalsIgnoreCase(
                uploader.getEmploymentStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Uploading employee is not active"
            );
        }

        String normalizedEvidenceType = evidenceType == null
                ? ""
                : evidenceType.trim().toUpperCase(Locale.ROOT);

        if (!ALLOWED_EVIDENCE_TYPES.contains(normalizedEvidenceType)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Unsupported evidence type"
            );
        }

        VehicleDamageRecord damageRecord = null;

        if (damageRecordId != null) {
            damageRecord = damageRepository.findById(damageRecordId)
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.NOT_FOUND,
                            "Damage record not found"
                    ));

            if (!damageRecord.getInspection().getId().equals(inspectionId)
                    || !damageRecord.getInventoryCard().getId()
                    .equals(inventoryCard.getId())) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Damage record does not belong to this inspection"
                );
            }
        }

        if ("DAMAGE".equals(normalizedEvidenceType)
                && damageRecord == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "A damage record ID is required for DAMAGE photos"
            );
        }

        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "Please select a photo"
            );
        }

        if (file.getSize() > MAX_FILE_SIZE) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Photo must not exceed 10 MB"
            );
        }

        byte[] fileBytes;

        try {
            fileBytes = file.getBytes();
        } catch (IOException exception) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Could not read the uploaded photo"
            );
        }

        String extension;
        String mimeType;

        if (isJpeg(fileBytes)) {
            extension = ".jpg";
            mimeType = "image/jpeg";
        } else if (isPng(fileBytes)) {
            extension = ".png";
            mimeType = "image/png";
        } else if (isWebp(fileBytes)) {
            extension = ".webp";
            mimeType = "image/webp";
        } else {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only JPEG, PNG and WEBP images are supported"
            );
        }

        String originalFileName = file.getOriginalFilename();

        if (originalFileName == null || originalFileName.isBlank()) {
            originalFileName = "vehicle-photo" + extension;
        } else {
            originalFileName = originalFileName
                    .replace("\\", "/");

            originalFileName = Paths.get(originalFileName)
                    .getFileName()
                    .toString();

            if (originalFileName.length() > 255) {
                originalFileName = originalFileName.substring(0, 255);
            }
        }

        String storageKey = "intake/job-" + jobId + "/"
                + UUID.randomUUID() + extension;

        Path storageRoot = Paths.get(storageProperties.getUploadDir())
                .toAbsolutePath()
                .normalize();

        Path destination = storageRoot.resolve(storageKey).normalize();

        if (!destination.startsWith(storageRoot)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Invalid photo storage path"
            );
        }

        try {
            Files.createDirectories(destination.getParent());
            Files.write(destination, fileBytes);
        } catch (IOException exception) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Could not store the uploaded photo"
            );
        }

        final Path savedFile = destination;

        if (TransactionSynchronizationManager.isSynchronizationActive()) {
            TransactionSynchronizationManager.registerSynchronization(
                    new TransactionSynchronization() {
                        @Override
                        public void afterCompletion(int status) {
                            if (status == STATUS_ROLLED_BACK) {
                                deleteFile(savedFile);
                            }
                        }
                    }
            );
        }

        try {
            MediaFile mediaFile = new MediaFile();

            mediaFile.setJob(job);
            mediaFile.setInventoryCard(inventoryCard);
            mediaFile.setInspection(inspection);
            mediaFile.setDamageRecord(damageRecord);
            mediaFile.setUploadedBy(uploader);
            mediaFile.setEvidenceType(normalizedEvidenceType);
            mediaFile.setFileName(originalFileName);
            mediaFile.setStorageKey(storageKey);
            mediaFile.setMimeType(mimeType);
            mediaFile.setFileSize((long) fileBytes.length);
            mediaFile.setFileHash(sha256(fileBytes));
            mediaFile.setCaption(
                    caption == null || caption.isBlank()
                            ? null
                            : caption.trim()
            );
            mediaFile.setCapturedAt(capturedAt);

            MediaFile saved = mediaFileRepository.saveAndFlush(mediaFile);

            return new VehiclePhotoResponse(
                    saved.getId(),
                    job.getId(),
                    inventoryCard.getId(),
                    inspection.getId(),
                    damageRecord != null ? damageRecord.getId() : null,
                    saved.getEvidenceType(),
                    saved.getFileName(),
                    saved.getStorageKey(),
                    saved.getMimeType(),
                    saved.getFileSize(),
                    saved.getCaption(),
                    saved.getCapturedAt()
            );

        } catch (RuntimeException exception) {
            deleteFile(destination);
            throw exception;
        }
    }

    private boolean isJpeg(byte[] bytes) {
        return bytes.length >= 3
                && (bytes[0] & 0xFF) == 0xFF
                && (bytes[1] & 0xFF) == 0xD8
                && (bytes[2] & 0xFF) == 0xFF;
    }

    private boolean isPng(byte[] bytes) {
        byte[] signature = {
                (byte) 0x89, 0x50, 0x4E, 0x47,
                0x0D, 0x0A, 0x1A, 0x0A
        };

        if (bytes.length < signature.length) {
            return false;
        }

        for (int i = 0; i < signature.length; i++) {
            if (bytes[i] != signature[i]) {
                return false;
            }
        }

        return true;
    }

    private boolean isWebp(byte[] bytes) {
        return bytes.length >= 12
                && bytes[0] == 'R'
                && bytes[1] == 'I'
                && bytes[2] == 'F'
                && bytes[3] == 'F'
                && bytes[8] == 'W'
                && bytes[9] == 'E'
                && bytes[10] == 'B'
                && bytes[11] == 'P';
    }

    private String sha256(byte[] bytes) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(bytes));
        } catch (Exception exception) {
            throw new IllegalStateException(
                    "Could not calculate photo checksum", exception
            );
        }
    }

    private void deleteFile(Path path) {
        try {
            Files.deleteIfExists(path);
        } catch (IOException ignored) {
            // A failed cleanup should not hide the original database error.
        }
    }
}
