package com.autogarage.automotive.dto;

public record VehicleInspectionResponse(

        Long inspectionId,
        Long jobId,
        String jobNumber,
        Long inventoryCardId,
        String inspectionType,
        String inspectionStatus,
        int inspectionItemsSaved,
        int damagesSaved,
        int accessoriesSaved,
        int receivedItemsSaved,
        java.util.List<DamageRecordResponse> damageRecords

) {
    public record DamageRecordResponse(
            Long damageRecordId,
            String damageType,
            String damageLocation
    ) {}
}
