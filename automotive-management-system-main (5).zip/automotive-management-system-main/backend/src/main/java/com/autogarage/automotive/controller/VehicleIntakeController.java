
package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.CreateVehicleIntakeRequest;
import com.autogarage.automotive.dto.VehicleIntakeResponse;
import com.autogarage.automotive.service.VehicleIntakeService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/intake")
public class VehicleIntakeController {

    private final VehicleIntakeService vehicleIntakeService;

    public VehicleIntakeController(
            VehicleIntakeService vehicleIntakeService
    ) {
        this.vehicleIntakeService = vehicleIntakeService;
    }

    @PostMapping("/vehicles")
    public ResponseEntity<VehicleIntakeResponse> createVehicleIntake(
            @Valid @RequestBody CreateVehicleIntakeRequest request
    ) {
        VehicleIntakeResponse response =
                vehicleIntakeService.createIntake(request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }
}
