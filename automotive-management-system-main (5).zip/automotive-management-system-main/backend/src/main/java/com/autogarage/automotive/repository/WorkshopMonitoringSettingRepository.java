package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkshopMonitoringSetting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.List;

@Repository
public interface WorkshopMonitoringSettingRepository
        extends JpaRepository<WorkshopMonitoringSetting, Long> {

    Optional<WorkshopMonitoringSetting> findByWorkshop_Id(Long workshopId);

    List<WorkshopMonitoringSetting> findByActiveTrue();
}