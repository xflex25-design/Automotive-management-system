package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.InventorySignature;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InventorySignatureRepository
        extends JpaRepository<InventorySignature, Long> {

    List<InventorySignature> findByInventoryCardIdOrderBySignedAtDesc(
            Long inventoryCardId
    );

    List<InventorySignature> findByInventoryCard_Id(
                Long inventoryCardId
        );

    List<InventorySignature> findByAuthorisationId(Long authorisationId);

    List<InventorySignature> findByEmployeeId(Long employeeId);
}