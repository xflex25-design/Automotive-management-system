package com.autogarage.automotive.dto;

import java.math.BigDecimal;

public record PartResponse(
        Long id,
        Long companyId,
        String partCode,
        String partName,
        String description,
        String category,
        String brand,
        String unitOfMeasure,
        String barcode,
        BigDecimal minimumStockLevel,
        Boolean active
) {}