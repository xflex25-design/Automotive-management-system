package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.InvoiceItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InvoiceItemRepository
        extends JpaRepository<InvoiceItem, Long> {

    List<InvoiceItem> findByInvoice_IdOrderByIdAsc(Long invoiceId);

    List<InvoiceItem> findByInvoice_Id(Long invoiceId);
}