package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByCompanyIdAndWorkshopIdAndEmploymentStatus(
            Long companyId,
            Long workshopId,
            String employmentStatus
    );

    Optional<Employee> findByIdAndCompanyId(
            Long id,
            Long companyId
    );

    Optional<Employee> findByUser_Id(Long userId);

    boolean existsByCompanyIdAndEmployeeNumber(
            Long companyId,
            String employeeNumber
    );

    List<Employee>
    findByWorkshop_IdAndEmploymentStatusAndJobTitleContainingIgnoreCase(
            Long workshopId,
            String employmentStatus,
            String jobTitle
    );
}
