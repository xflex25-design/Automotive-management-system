
package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkOrderEvidence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkOrderEvidenceRepository
        extends JpaRepository<WorkOrderEvidence, Long> {

    List<WorkOrderEvidence> findByWorkOrder_IdOrderByUploadedAtAsc(
            Long workOrderId
    );

    List<WorkOrderEvidence> findByWorkOrder_IdAndEvidenceType(
            Long workOrderId,
            String evidenceType
    );

    long countByWorkOrder_IdAndEvidenceType(
            Long workOrderId,
            String evidenceType
    );

    boolean existsByWorkOrder_IdAndMediaFile_Id(
            Long workOrderId,
            Long mediaFileId
    );

    List<WorkOrderEvidence> findByWorkOrder_IdOrderByUploadedAtDesc(Long workOrderId);

        long countByWorkOrder_IdAndEvidenceRequirement_Id(
                Long workOrderId,
                Long requirementId
        );
}
