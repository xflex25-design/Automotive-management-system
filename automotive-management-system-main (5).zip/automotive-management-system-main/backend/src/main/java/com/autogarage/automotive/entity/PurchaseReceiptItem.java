package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "purchase_receipt_items")
@Getter
@Setter
@NoArgsConstructor
public class PurchaseReceiptItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "receipt_id", nullable = false)
    private PurchaseReceipt receipt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "purchase_order_item_id", nullable = false)
    private PurchaseOrderItem purchaseOrderItem;

    @Column(name = "quantity_delivered", nullable = false, precision = 12, scale = 2)
    private BigDecimal quantityDelivered;

    @Column(name = "quantity_accepted", nullable = false, precision = 12, scale = 2)
    private BigDecimal quantityAccepted;

    @Column(name = "quantity_rejected", nullable = false, precision = 12, scale = 2)
    private BigDecimal quantityRejected;

    @Column(name = "discrepancy_notes", columnDefinition = "TEXT")
    private String discrepancyNotes;
}
