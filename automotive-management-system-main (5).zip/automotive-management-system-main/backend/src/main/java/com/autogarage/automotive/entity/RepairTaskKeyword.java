package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "repair_task_keywords")
@Getter
@Setter
@NoArgsConstructor
public class RepairTaskKeyword {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "repair_task_id", nullable = false)
    private RepairTask repairTask;

    @Column(name = "keyword", nullable = false, length = 150)
    private String keyword;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}