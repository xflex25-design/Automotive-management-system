package com.autogarage.automotive.controller;

import com.autogarage.automotive.service.VehicleIntakeCompletionService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/intake/jobs")
public class VehicleIntakeCompletionController {

    private final VehicleIntakeCompletionService completionService;

    public VehicleIntakeCompletionController(
            VehicleIntakeCompletionService completionService
    ) {
        this.completionService = completionService;
    }

    @PostMapping("/{jobId}/complete")
    public ResponseEntity<Map<String, Object>> completeIntake(
            @PathVariable Long jobId
    ) {
        completionService.completeIntake(jobId);

        return ResponseEntity.ok(
                Map.of(
                        "jobId", jobId,
                        "intakeStatus", "COMPLETED",
                        "jobStatus", "INTAKE_COMPLETED",
                        "message", "Vehicle intake completed successfully"
                )
        );
    }
}