package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.finalinspection.StartFinalInspectionRequest;
import com.autogarage.automotive.dto.finalinspection.UpdateFinalInspectionItemRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class FinalInspectionService {

    private final FinalInspectionRepository inspectionRepository;
    private final FinalInspectionItemRepository itemRepository;
    private final FinalInspectionSignoffRepository signoffRepository;
    private final JobRepository jobRepository;
    private final WorkOrderRepository workOrderRepository;
    private final WorkOrderDepartmentVisitRepository visitRepository;
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final MediaFileRepository mediaFileRepository;
    private final RepairPlanRepository repairPlanRepository;

    public FinalInspectionService(
            FinalInspectionRepository inspectionRepository,
            FinalInspectionItemRepository itemRepository,
            FinalInspectionSignoffRepository signoffRepository,
            JobRepository jobRepository,
            WorkOrderRepository workOrderRepository,
            WorkOrderDepartmentVisitRepository visitRepository,
            EmployeeRepository employeeRepository,
            DepartmentRepository departmentRepository,
            MediaFileRepository mediaFileRepository,
            RepairPlanRepository repairPlanRepository
    ) {
        this.inspectionRepository = inspectionRepository;
        this.itemRepository = itemRepository;
        this.signoffRepository = signoffRepository;
        this.jobRepository = jobRepository;
        this.workOrderRepository = workOrderRepository;
        this.visitRepository = visitRepository;
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
        this.mediaFileRepository = mediaFileRepository;
        this.repairPlanRepository = repairPlanRepository;
    }

    private record ChecklistDefinition(
            String code,
            String name,
            String category
    ) {}

    private List<ChecklistDefinition> checklist() {
        return List.of(
            new ChecklistDefinition("FI001", "All works done on job card", "JOB_CARD_COMPLETION"),
            new ChecklistDefinition("FI002", "Road test", "ROAD_TEST"),
            new ChecklistDefinition("FI003", "Tyres tightened", "TYRES"),
            new ChecklistDefinition("FI004", "Tyre pressure", "TYRES"),
            new ChecklistDefinition("FI005", "Brakes and shoes", "BRAKES"),
            new ChecklistDefinition("FI006", "Hand brake adjusted", "BRAKES"),
            new ChecklistDefinition("FI007", "Check water and engine oil", "FLUIDS"),
            new ChecklistDefinition("FI008", "Battery clamp", "ELECTRICAL"),
            new ChecklistDefinition("FI009", "Battery charged and able to start", "ELECTRICAL"),
            new ChecklistDefinition("FI010", "Inventory checklist", "INVENTORY"),
            new ChecklistDefinition("FI011", "Workshop accessories / tools", "INVENTORY"),
            new ChecklistDefinition("FI012", "Washer fluid", "EXTERIOR"),
            new ChecklistDefinition("FI013", "Spray nozzle working", "EXTERIOR"),
            new ChecklistDefinition("FI014", "Dashboard warning lights", "ELECTRICAL"),
            new ChecklistDefinition("FI015", "Headlights and brake lights working", "ELECTRICAL"),
            new ChecklistDefinition("FI016", "Wipers working", "EXTERIOR"),
            new ChecklistDefinition("FI017", "Horn working", "ELECTRICAL"),
            new ChecklistDefinition("FI018", "Aircon system working", "ELECTRICAL"),
            new ChecklistDefinition("FI019", "Window central locking system", "ELECTRICAL"),
            new ChecklistDefinition("FI020", "Neat and secured body parts", "BODY"),
            new ChecklistDefinition("FI021", "Reflectors and licence discs", "EXTERIOR"),
            new ChecklistDefinition("FI022", "Under body check", "UNDERBODY"),
            new ChecklistDefinition("FI023", "Clean and neat (interior and exterior)", "CLEANLINESS"),
            new ChecklistDefinition("FI024", "Paint inspection and defects", "PAINT"),
            new ChecklistDefinition("FI025", "Inverspray and paint reaction", "PAINT")
        );
    }

    @Transactional
    public Map<String, Object> startInspection(
            Long jobId,
            StartFinalInspectionRequest request
    ) {
        ActorIdentity.requireEmployee(request == null ? null : request.inspectorEmployeeId());
        if (request == null || request.inspectorEmployeeId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Inspector employee ID is required."
            );
        }

        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Job not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        Employee inspector = employeeRepository
                .findByIdAndCompanyId(
                        request.inspectorEmployeeId(),
                        job.getCompany().getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Inspector not found in this company."
                ));

        if (!Objects.equals(
                inspector.getWorkshop().getId(),
                job.getWorkshop().getId()
        )) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Inspector does not belong to this workshop."
            );
        }

        if (!"ACTIVE".equalsIgnoreCase(inspector.getEmploymentStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Inspector is not an active employee."
            );
        }

        validateJobEligibility(jobId);

        if (inspectionRepository
                .findFirstByJob_IdAndInspectionStatusOrderByStartedAtDesc(
                        jobId, "IN_PROGRESS"
                ).isPresent()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "This job already has an inspection in progress."
            );
        }

        FinalInspection inspection = new FinalInspection();
        inspection.setJob(job);
        inspection.setInspector(inspector);
        inspectionRepository.findByJob_IdOrderByStartedAtDesc(jobId)
                .stream()
                .filter(previous ->
                        "FAILED".equalsIgnoreCase(previous.getInspectionStatus()))
                .findFirst()
                .ifPresent(inspection::setPreviousInspection);
        inspection.setInspectionNumber(
                "FI-" + job.getJobNumber() + "-" + System.currentTimeMillis()
        );
        inspection.setInspectionStatus("IN_PROGRESS");
        inspection.setStartedAt(LocalDateTime.now());

        inspection = inspectionRepository.save(inspection);

        List<FinalInspectionItem> items = new ArrayList<>();

        for (ChecklistDefinition definition : checklist()) {
            FinalInspectionItem item = new FinalInspectionItem();

            item.setFinalInspection(inspection);
            item.setItemCode(definition.code());
            item.setItemName(definition.name());
            item.setInspectionCategory(definition.category());
            item.setCheckStatus("PENDING");
            item.setReinspectionRequired(false);

            items.add(item);
        }

        itemRepository.saveAll(items);

        // Create one pending sign-off for each department involved in this job.
        Map<Long, Department> departments = new LinkedHashMap<>();

        for (WorkOrder workOrder : workOrderRepository
                .findByJob_IdOrderBySequenceNumberAsc(jobId)) {

            Department department = workOrder.getDepartment();

            if (department != null) {
                departments.put(department.getId(), department);
            }
        }

        List<FinalInspectionSignoff> signoffs = new ArrayList<>();

        for (Department department : departments.values()) {
            FinalInspectionSignoff signoff = new FinalInspectionSignoff();

            signoff.setFinalInspection(inspection);
            signoff.setDepartment(department);
            signoff.setSignoffStatus("PENDING");

            signoffs.add(signoff);
        }

        signoffRepository.saveAll(signoffs);

        return getInspection(inspection.getId());
    }

    private void validateJobEligibility(Long jobId) {
        List<WorkOrder> workOrders =
                workOrderRepository.findByJob_IdOrderBySequenceNumberAsc(jobId);

        if (workOrders.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Final inspection cannot start because this job has no work orders."
            );
        }

        for (WorkOrder workOrder : workOrders) {

            if (!"COMPLETED".equalsIgnoreCase(
                    workOrder.getWorkOrderStatus()
            )) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Work order " + workOrder.getWorkOrderNumber()
                                + " must be COMPLETED before final inspection."
                );
            }

            List<WorkOrderDepartmentVisit> visits =
                    visitRepository.findByWorkOrder_IdOrderByVisitNumberAsc(
                            workOrder.getId()
                    );

            if (visits.isEmpty()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Work order " + workOrder.getWorkOrderNumber()
                                + " has no recorded department visits."
                );
            }

            for (WorkOrderDepartmentVisit visit : visits) {
                if (!"SENT_OFF".equalsIgnoreCase(visit.getVisitStatus())) {
                    throw new ResponseStatusException(
                            HttpStatus.BAD_REQUEST,
                            "All department visits must be SENT_OFF. "
                                    + "Work order: "
                                    + workOrder.getWorkOrderNumber()
                    );
                }
            }
        }
    }

    @Transactional
    public Map<String, Object> updateChecklistItem(
            Long inspectionId,
            Long itemId,
            UpdateFinalInspectionItemRequest request
    ) {
        ActorIdentity.requireEmployee(request == null ? null : request.employeeId());
        if (request == null || request.employeeId() == null
                || request.checkStatus() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Employee ID and check status are required."
            );
        }

        FinalInspection inspection = getInspectionEntity(inspectionId);

        if (!"IN_PROGRESS".equalsIgnoreCase(
                inspection.getInspectionStatus()
        )) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "This final inspection is no longer editable."
            );
        }

        FinalInspectionItem item = itemRepository.findById(itemId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Checklist item not found."
                ));

        if (!Objects.equals(
                item.getFinalInspection().getId(),
                inspectionId
        )) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Checklist item does not belong to this inspection."
            );
        }

        Employee employee = employeeRepository.findByIdAndCompanyId(
                request.employeeId(),
                inspection.getJob().getCompany().getId()
        ).orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Employee not found."
        ));

        if (!Objects.equals(
                employee.getWorkshop().getId(),
                inspection.getJob().getWorkshop().getId()
        ) || !"ACTIVE".equalsIgnoreCase(employee.getEmploymentStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Employee must be active and belong to this workshop."
            );
        }

        String status = request.checkStatus().trim().toUpperCase();

        if (!List.of("PENDING", "PASS", "FAIL").contains(status)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Check status must be PENDING, PASS or FAIL."
            );
        }

        Department responsibleDepartment = null;

        if (request.responsibleDepartmentId() != null) {
            responsibleDepartment = departmentRepository
                    .findById(request.responsibleDepartmentId())
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.NOT_FOUND,
                            "Responsible department not found."
                    ));

            if (!Objects.equals(
                    responsibleDepartment.getCompany().getId(),
                    inspection.getJob().getCompany().getId()
            ) || !Objects.equals(
                    responsibleDepartment.getWorkshop().getId(),
                    inspection.getJob().getWorkshop().getId()
            )) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Responsible department does not belong to this workshop."
                );
            }
        }

        if ("FAIL".equals(status) && responsibleDepartment == null
                && item.getResponsibleDepartment() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "A responsible department must be assigned to a failed check."
            );
        }

        item.setCheckStatus(status);
        item.setComments(request.comments());

        if (responsibleDepartment != null) {
            item.setResponsibleDepartment(responsibleDepartment);
        }

        item.setReinspectionRequired("FAIL".equals(status));

        if ("PENDING".equals(status)) {
            item.setCheckedBy(null);
            item.setCheckedAt(null);
        } else {
            item.setCheckedBy(employee);
            item.setCheckedAt(LocalDateTime.now());
        }

        itemRepository.save(item);

        return getInspection(inspectionId);
    }

    @Transactional
        public Map<String, Object> generateCorrectiveWorkOrders(
                Long inspectionId,
                com.autogarage.automotive.dto.finalinspection.GenerateCorrectiveWorkOrdersRequest request
        ) {
        ActorIdentity.requireEmployee(request == null ? null : request.employeeId());
        if (request == null || request.employeeId() == null) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Employee ID is required."
                );
        }

        FinalInspection inspection = getInspectionEntity(inspectionId);

        if (!"FAILED".equalsIgnoreCase(inspection.getInspectionStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "Corrective work orders can only be generated for a failed inspection."
                );
        }

        Employee employee = employeeRepository.findByIdAndCompanyId(
                request.employeeId(),
                inspection.getJob().getCompany().getId()
        ).orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND,
                "Employee not found in this company."
        ));

        if (!Objects.equals(
                employee.getWorkshop().getId(),
                inspection.getJob().getWorkshop().getId()
        ) || !"ACTIVE".equalsIgnoreCase(employee.getEmploymentStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Employee must be active and belong to this workshop."
                );
        }

        List<FinalInspectionItem> failedItems =
                itemRepository.findByFinalInspection_IdAndCheckStatus(
                        inspectionId, "FAIL"
                );

        if (failedItems.isEmpty()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "This inspection has no failed checklist items."
                );
        }

        for (FinalInspectionItem item : failedItems) {
                if (item.getResponsibleDepartment() == null) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Failed item " + item.getItemCode()
                                + " has no responsible department."
                );
                }
        }

        Job job = inspection.getJob();

        List<RepairPlan> repairPlans =
                repairPlanRepository.findByJob_IdOrderByCreatedAtDesc(job.getId());

        if (repairPlans.isEmpty()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "No repair plan exists for this job."
                );
        }

        RepairPlan repairPlan = repairPlans.get(0);

        List<WorkOrder> existingWorkOrders =
                workOrderRepository.findByJob_IdOrderBySequenceNumberAsc(job.getId());

        int nextSequence = existingWorkOrders.stream()
                .map(WorkOrder::getSequenceNumber)
                .filter(Objects::nonNull)
                .mapToInt(Integer::intValue)
                .max()
                .orElse(0) + 1;

        Map<Long, List<FinalInspectionItem>> itemsByDepartment =
                new LinkedHashMap<>();

        for (FinalInspectionItem item : failedItems) {
                Long departmentId = item.getResponsibleDepartment().getId();

                itemsByDepartment
                        .computeIfAbsent(departmentId, key -> new ArrayList<>())
                        .add(item);
        }

        List<WorkOrder> generatedWorkOrders = new ArrayList<>();

        for (Map.Entry<Long, List<FinalInspectionItem>> entry
                : itemsByDepartment.entrySet()) {

                Long departmentId = entry.getKey();
                List<FinalInspectionItem> departmentItems = entry.getValue();

                Department department =
                        departmentItems.get(0).getResponsibleDepartment();

                // Reuse an already-linked corrective work order if this
                // endpoint has previously been called for these failed items.
                WorkOrder correctiveWorkOrder = departmentItems.stream()
                        .map(FinalInspectionItem::getCorrectiveWorkOrder)
                        .filter(Objects::nonNull)
                        .findFirst()
                        .orElse(null);

                if (correctiveWorkOrder == null) {
                correctiveWorkOrder = new WorkOrder();

                correctiveWorkOrder.setRepairPlan(repairPlan);
                correctiveWorkOrder.setJob(job);
                correctiveWorkOrder.setDepartment(department);

                correctiveWorkOrder.setWorkOrderNumber(
                        "WO-" + job.getJobNumber() + "-" + nextSequence
                );

                correctiveWorkOrder.setSequenceNumber(nextSequence);
                nextSequence++;

                correctiveWorkOrder.setTaskTitle(
                        "Final Inspection Corrective Work - "
                                + department.getDepartmentName()
                );

                StringBuilder description = new StringBuilder();
                StringBuilder instructions = new StringBuilder();

                description.append(
                        "Corrective work required following failed final inspection "
                ).append(inspection.getInspectionNumber()).append(". ");

                instructions.append("FINAL INSPECTION: ")
                        .append(inspection.getInspectionNumber())
                        .append("\n")
                        .append("Corrective work must be completed and submitted "
                                + "through the normal work-order confirmation process.")
                        .append("\n")
                        .append("Required completion evidence must be uploaded.")
                        .append("\n\nFAILED CHECKLIST ITEMS:\n");

                for (FinalInspectionItem item : departmentItems) {
                        description.append(item.getItemCode())
                                .append(" - ")
                                .append(item.getItemName())
                                .append("; ");

                        instructions.append("\n")
                                .append(item.getItemCode())
                                .append(" - ")
                                .append(item.getItemName())
                                .append("\nInspector comments: ")
                                .append(item.getComments() == null
                                        || item.getComments().isBlank()
                                        ? "No additional comments."
                                        : item.getComments())
                                .append("\n");
                }

                correctiveWorkOrder.setWorkDescription(description.toString());
                correctiveWorkOrder.setWorkInstructions(instructions.toString());

                correctiveWorkOrder.setWorkOrderStatus("READY");

                String priority = existingWorkOrders.stream()
                        .filter(workOrder ->
                                workOrder.getDepartment() != null
                                        && Objects.equals(
                                                workOrder.getDepartment().getId(),
                                                departmentId
                                        ))
                        .map(WorkOrder::getPriority)
                        .filter(Objects::nonNull)
                        .findFirst()
                        .orElse("NORMAL");

                correctiveWorkOrder.setPriority(priority);

                correctiveWorkOrder =
                        workOrderRepository.save(correctiveWorkOrder);

                generatedWorkOrders.add(correctiveWorkOrder);
                }

                for (FinalInspectionItem item : departmentItems) {
                item.setCorrectiveWorkOrder(correctiveWorkOrder);
                item.setReinspectionRequired(true);
                }

                itemRepository.saveAll(departmentItems);
        }

        Map<String, Object> response = new LinkedHashMap<>();

        response.put("inspectionId", inspectionId);
        response.put("inspectionNumber", inspection.getInspectionNumber());
        response.put("generatedWorkOrderCount", generatedWorkOrders.size());

        response.put(
                "correctiveWorkOrders",
                itemsByDepartment.entrySet().stream()
                        .map(entry -> {
                                List<FinalInspectionItem> departmentItems =
                                        entry.getValue();

                                WorkOrder workOrder = departmentItems.stream()
                                        .map(FinalInspectionItem::getCorrectiveWorkOrder)
                                        .filter(Objects::nonNull)
                                        .findFirst()
                                        .orElse(null);

                                Map<String, Object> result = new LinkedHashMap<>();

                                result.put("workOrderId",
                                        workOrder != null ? workOrder.getId() : null);
                                result.put("workOrderNumber",
                                        workOrder != null
                                                ? workOrder.getWorkOrderNumber() : null);
                                result.put("departmentId", entry.getKey());
                                result.put("departmentName",
                                        departmentItems.get(0)
                                                .getResponsibleDepartment()
                                                .getDepartmentName());
                                result.put("failedItemCount", departmentItems.size());

                                result.put(
                                        "failedItems",
                                        departmentItems.stream()
                                                .map(FinalInspectionItem::getItemCode)
                                                .toList()
                                );

                                return result;
                        })
                        .toList()
        );

        return response;
        }
    
        @Transactional(readOnly = true)
        public Map<String, Object> getInspection(Long inspectionId) {

        FinalInspection inspection = getInspectionEntity(inspectionId);

        Long jobId = inspection.getJob().getId();

        List<Map<String, Object>> items = itemRepository
                .findByFinalInspection_IdOrderByIdAsc(inspectionId)
                .stream()
                .map(this::mapItem)
                .toList();

        List<Map<String, Object>> evidence = mediaFileRepository
                .findByJobIdOrderByUploadedAtDesc(jobId)
                .stream()
                .map(this::mapEvidence)
                .toList();

        List<Map<String, Object>> signoffs = signoffRepository
                .findByFinalInspection_IdOrderByDepartment_DepartmentNameAsc(
                        inspectionId
                )
                .stream()
                .map(this::mapSignoff)
                .toList();

        long intakePhotos = evidence.stream()
                .filter(item -> !"DEPARTMENT_WORK".equals(item.get("category")))
                .count();

        long departmentPhotos = evidence.stream()
                .filter(item -> "DEPARTMENT_WORK".equals(item.get("category")))
                .count();

        Map<String, Object> response = new LinkedHashMap<>();

        response.put("id", inspection.getId());
        response.put("inspectionNumber", inspection.getInspectionNumber());

        response.put("jobId", jobId);
        response.put("jobNumber", inspection.getJob().getJobNumber());

        response.put("inspectorId", inspection.getInspector().getId());
        response.put("inspectorName",
                inspection.getInspector().getFirstName() + " "
                        + inspection.getInspector().getLastName());

        response.put("inspectionStatus", inspection.getInspectionStatus());
        response.put("inspectionDecision", inspection.getInspectionDecision());
        response.put("inspectionNotes", inspection.getInspectionNotes());
        response.put("startedAt", inspection.getStartedAt());
        response.put("completedAt", inspection.getCompletedAt());

        response.put("previousInspectionId",
                inspection.getPreviousInspection() != null
                        ? inspection.getPreviousInspection().getId() : null);

        response.put("previousInspectionNumber",
                inspection.getPreviousInspection() != null
                        ? inspection.getPreviousInspection().getInspectionNumber() : null);

        response.put("checklist", items);
        response.put("totalChecks", items.size());
        response.put("passedChecks",
                itemRepository.countByFinalInspection_IdAndCheckStatus(
                        inspectionId, "PASS"));
        response.put("failedChecks",
                itemRepository.countByFinalInspection_IdAndCheckStatus(
                        inspectionId, "FAIL"));
        response.put("pendingChecks",
                itemRepository.countByFinalInspection_IdAndCheckStatus(
                        inspectionId, "PENDING"));

        response.put("departmentSignoffs", signoffs);

        response.put("jobEvidence", evidence);

        Map<String, Object> evidenceSummary = new LinkedHashMap<>();
        evidenceSummary.put("totalPhotos", evidence.size());
        evidenceSummary.put("intakePhotos", intakePhotos);
        evidenceSummary.put("departmentWorkPhotos", departmentPhotos);

        response.put("evidenceSummary", evidenceSummary);

        return response;
        }
 
        private Map<String, Object> mapEvidence(MediaFile media) {

        Map<String, Object> result = new LinkedHashMap<>();

        String category = "GENERAL";

        if (media.getWorkOrder() != null) {
                category = "DEPARTMENT_WORK";
        } else if (media.getDamageRecord() != null) {
                category = "INTAKE_DAMAGE";
        } else if (media.getInspection() != null) {
                category = "INTAKE_INSPECTION";
        }

        result.put("mediaFileId", media.getId());
        result.put("category", category);
        result.put("evidenceType", media.getEvidenceType());

        result.put("fileName", media.getFileName());
        result.put("mimeType", media.getMimeType());
        result.put("fileSize", media.getFileSize());
        result.put("caption", media.getCaption());

        result.put("contentUrl",
                "/api/media/" + media.getId() + "/content");

        result.put("uploadedByEmployeeId",
                media.getUploadedBy() != null
                        ? media.getUploadedBy().getId() : null);

        result.put("uploadedByName",
                media.getUploadedBy() != null
                        ? media.getUploadedBy().getFirstName() + " "
                        + media.getUploadedBy().getLastName() : null);

        result.put("uploadedAt", media.getUploadedAt());
        result.put("capturedAt", media.getCapturedAt());

        if (media.getWorkOrder() != null) {
                result.put("workOrderId", media.getWorkOrder().getId());
                result.put("workOrderNumber",
                        media.getWorkOrder().getWorkOrderNumber());

                result.put("departmentName",
                        media.getWorkOrder().getDepartment() != null
                                ? media.getWorkOrder().getDepartment().getDepartmentName()
                                : null);
        }

        if (media.getInspection() != null) {
                result.put("intakeInspectionId", media.getInspection().getId());
        }

        if (media.getDamageRecord() != null) {
                result.put("damageRecordId", media.getDamageRecord().getId());
        }

        return result;
        }
    
        private Map<String, Object> mapSignoff(FinalInspectionSignoff signoff) {

        Map<String, Object> result = new LinkedHashMap<>();

        result.put("signoffId", signoff.getId());

        result.put("departmentId", signoff.getDepartment().getId());
        result.put("departmentName",
                signoff.getDepartment().getDepartmentName());

        result.put("signoffStatus", signoff.getSignoffStatus());
        result.put("signoffNotes", signoff.getSignoffNotes());
        result.put("signedAt", signoff.getSignedAt());

        result.put("signedByEmployeeId",
                signoff.getSignedBy() != null
                        ? signoff.getSignedBy().getId() : null);

        result.put("signedByName",
                signoff.getSignedBy() != null
                        ? signoff.getSignedBy().getFirstName() + " "
                        + signoff.getSignedBy().getLastName() : null);

        return result;
        }

    private Map<String, Object> mapItem(FinalInspectionItem item) {
        Map<String, Object> result = new LinkedHashMap<>();

        result.put("id", item.getId());
        result.put("itemCode", item.getItemCode());
        result.put("itemName", item.getItemName());
        result.put("inspectionCategory", item.getInspectionCategory());
        result.put("checkStatus", item.getCheckStatus());
        result.put("comments", item.getComments());
        result.put("reinspectionRequired", item.getReinspectionRequired());
        result.put("checkedAt", item.getCheckedAt());

        result.put("checkedByEmployeeId",
                item.getCheckedBy() != null
                        ? item.getCheckedBy().getId() : null);

        result.put("responsibleDepartmentId",
                item.getResponsibleDepartment() != null
                        ? item.getResponsibleDepartment().getId() : null);

        result.put("responsibleDepartmentName",
                item.getResponsibleDepartment() != null
                        ? item.getResponsibleDepartment().getDepartmentName() : null);

        result.put("correctiveWorkOrderId",
                item.getCorrectiveWorkOrder() != null
                        ? item.getCorrectiveWorkOrder().getId() : null);

        result.put("correctiveWorkOrderNumber",
                item.getCorrectiveWorkOrder() != null
                        ? item.getCorrectiveWorkOrder().getWorkOrderNumber() : null);

        return result;
    }

    private FinalInspection getInspectionEntity(Long inspectionId) {
        FinalInspection inspection = inspectionRepository.findById(inspectionId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Final inspection not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                inspection.getJob().getCompany().getId(),
                inspection.getJob().getWorkshop().getId());
        return inspection;
    }
}
