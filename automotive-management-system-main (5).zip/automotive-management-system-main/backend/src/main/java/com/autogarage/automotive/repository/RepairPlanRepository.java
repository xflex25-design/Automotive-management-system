package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.RepairPlan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RepairPlanRepository extends JpaRepository<RepairPlan, Long> {

    List<RepairPlan> findByJob_IdOrderByCreatedAtDesc(Long jobId);

    Optional<RepairPlan> findByPlanNumber(String planNumber);

    Optional<RepairPlan> findByIdAndJob_Id(Long id, Long jobId);
}