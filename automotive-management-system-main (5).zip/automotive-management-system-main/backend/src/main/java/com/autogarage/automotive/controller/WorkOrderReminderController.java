package com.autogarage.automotive.controller;

import com.autogarage.automotive.entity.WorkOrderReminder;
import com.autogarage.automotive.service.WorkOrderMonitoringService;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/work-order-reminders")
public class WorkOrderReminderController {

    private final WorkOrderMonitoringService monitoringService;

    public WorkOrderReminderController(
            WorkOrderMonitoringService monitoringService
    ) {
        this.monitoringService = monitoringService;
    }

    @GetMapping("/work-orders/{workOrderId}")
    @Transactional(readOnly = true)
    public List<Map<String, Object>> getWorkOrderReminders(
            @PathVariable Long workOrderId
    ) {
        try {
            return monitoringService.getWorkOrderReminders(workOrderId)
                    .stream()
                    .map(this::toMap)
                    .toList();
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, exception.getMessage()
            );
        }
    }

    @GetMapping("/employees/{employeeId}/pending")
    @Transactional(readOnly = true)
    public List<Map<String, Object>> getEmployeeReminders(
            @PathVariable Long employeeId
    ) {
        try {
            return monitoringService.getEmployeeReminders(employeeId)
                    .stream()
                    .map(this::toMap)
                    .toList();
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, exception.getMessage()
            );
        }
    }

    @PutMapping("/{reminderId}/acknowledge")
    @Transactional
    public Map<String, Object> acknowledgeReminder(
            @PathVariable Long reminderId,
            @RequestParam Long employeeId
    ) {
        try {
            return toMap(
                    monitoringService.acknowledgeReminder(
                            reminderId, employeeId
                    )
            );
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, exception.getMessage()
            );
        } catch (IllegalStateException exception) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT, exception.getMessage()
            );
        }
    }

    private Map<String, Object> toMap(WorkOrderReminder reminder) {

        Map<String, Object> response = new LinkedHashMap<>();

        response.put("id", reminder.getId());
        response.put("workOrderId", reminder.getWorkOrder().getId());
        response.put("workOrderNumber",
                reminder.getWorkOrder().getWorkOrderNumber());
        response.put("employeeId",
                reminder.getEmployee() != null
                        ? reminder.getEmployee().getId() : null);
        response.put("reminderType", reminder.getReminderType());
        response.put("escalationLevel", reminder.getEscalationLevel());
        response.put("priority", reminder.getPriority());
        response.put("message", reminder.getReminderMessage());
        response.put("sentAt", reminder.getSentAt());
        response.put("acknowledgedAt", reminder.getAcknowledgedAt());
        response.put("acknowledgedByEmployeeId",
                reminder.getAcknowledgedBy() != null
                        ? reminder.getAcknowledgedBy().getId() : null);

        return response;
    }
}