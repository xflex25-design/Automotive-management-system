package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "work_orders")
@Getter
@Setter
@NoArgsConstructor
public class WorkOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "repair_plan_id", nullable = false)
    private RepairPlan repairPlan;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false)
    private Job job;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;

    @Column(name = "work_order_number", nullable = false, unique = true, length = 100)
    private String workOrderNumber;

    @Column(name = "sequence_number")
    private Integer sequenceNumber;

    @Column(name = "task_title", nullable = false, length = 255)
    private String taskTitle;

    @Column(name = "work_description", columnDefinition = "TEXT")
    private String workDescription;

    @Column(name = "work_instructions", columnDefinition = "TEXT")
    private String workInstructions;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_foreman_id")
    private Employee assignedForeman;

    @Column(
        name = "work_order_status",
        columnDefinition = "ENUM('BLOCKED','READY','ASSIGNED','IN_PROGRESS','WAITING','PAUSED','AWAITING_CONFIRMATION','COMPLETED','REJECTED','CANCELLED')"
    )
    private String workOrderStatus = "BLOCKED";

    @Column(
        name = "priority",
        columnDefinition = "ENUM('LOW','NORMAL','HIGH','URGENT')"
    )
    private String priority = "NORMAL";

    @Column(name = "estimated_hours", precision = 8, scale = 2)
    private BigDecimal estimatedHours;

    @Column(name = "actual_hours", precision = 8, scale = 2)
    private BigDecimal actualHours = BigDecimal.ZERO;

    @Column(name = "started_at")
    private LocalDateTime startedAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @Column(name = "completion_notes", columnDefinition = "TEXT")
    private String completionNotes;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}