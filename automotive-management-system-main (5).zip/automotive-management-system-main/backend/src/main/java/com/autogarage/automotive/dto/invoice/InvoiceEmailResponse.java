package com.autogarage.automotive.dto.invoice;

public record InvoiceEmailResponse(
        Long invoiceId,
        String invoiceNumber,
        String recipient,
        String status,
        String message
) {}