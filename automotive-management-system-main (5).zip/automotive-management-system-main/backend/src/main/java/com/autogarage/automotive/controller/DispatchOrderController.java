package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.*;
import com.autogarage.automotive.service.DispatchOrderService;

import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dispatch-orders")
public class DispatchOrderController {

    private final DispatchOrderService dispatchService;

    public DispatchOrderController(DispatchOrderService dispatchService) {
        this.dispatchService = dispatchService;
    }

    // Foreman creates a dispatch order from active stock reservations.
    @PostMapping
    public ResponseEntity<Map<String, Object>> create(
            @Valid @RequestBody CreateDispatchOrderRequest request) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(dispatchService.createDispatchOrder(request));
    }

    // View one dispatch order.
    @GetMapping("/{dispatchId}")
    public ResponseEntity<Map<String, Object>> get(
            @PathVariable Long dispatchId) {

        return ResponseEntity.ok(dispatchService.getDispatch(dispatchId));
    }

    // View dispatch orders for a job.
    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<List<Map<String, Object>>> getByJob(
            @PathVariable Long jobId) {

        return ResponseEntity.ok(dispatchService.getJobDispatches(jobId));
    }

    // Manager/boss approves.
    @PostMapping("/{dispatchId}/approve")
    @PreAuthorize("hasAnyAuthority('ROLE_MANAGER', 'ROLE_BOSS')")
    public ResponseEntity<Map<String, Object>> approve(
            @PathVariable Long dispatchId,
            @Valid @RequestBody ApproveDispatchRequest request) {

        return ResponseEntity.ok(
                dispatchService.approveDispatch(dispatchId, request));
    }

    // Manager/boss rejects.
    @PostMapping("/{dispatchId}/reject")
    @PreAuthorize("hasAnyAuthority('ROLE_MANAGER', 'ROLE_BOSS')")
    public ResponseEntity<Map<String, Object>> reject(
            @PathVariable Long dispatchId,
            @Valid @RequestBody RejectDispatchRequest request) {

        return ResponseEntity.ok(
                dispatchService.rejectDispatch(dispatchId, request));
    }

    // Foreman resubmits a rejected order.
    @PostMapping("/{dispatchId}/resubmit")
    public ResponseEntity<Map<String, Object>> resubmit(
            @PathVariable Long dispatchId) {

        return ResponseEntity.ok(
                dispatchService.resubmitDispatch(dispatchId));
    }

    // Stores issues the approved parts.
    @PostMapping("/{dispatchId}/issue")
    public ResponseEntity<Map<String, Object>> issue(
            @PathVariable Long dispatchId,
            @Valid @RequestBody IssueDispatchRequest request) {

        return ResponseEntity.ok(
                dispatchService.issueDispatch(dispatchId, request));
    }

    // Assigned mechanic acknowledges receipt.
    @PostMapping("/{dispatchId}/receive")
    public ResponseEntity<Map<String, Object>> receive(
            @PathVariable Long dispatchId,
            @Valid @RequestBody ReceiveDispatchRequest request) {

        return ResponseEntity.ok(
                dispatchService.receiveDispatch(dispatchId, request));
    }

    // Accounts acknowledges arrival of the dispatch order.
    @PostMapping("/{dispatchId}/accounts-acknowledgement")
    public ResponseEntity<Map<String, Object>> accountsAcknowledgement(
            @PathVariable Long dispatchId,
            @Valid @RequestBody AccountsDispatchAcknowledgementRequest request) {

        return ResponseEntity.ok(
                dispatchService.acknowledgeAccounts(dispatchId, request));
    }

    // Optional customer acknowledgement.
    @PostMapping("/{dispatchId}/customer-acknowledgement")
    public ResponseEntity<Map<String, Object>> customerAcknowledgement(
            @PathVariable Long dispatchId,
            @Valid @RequestBody CustomerDispatchAcknowledgementRequest request) {

        return ResponseEntity.ok(
                dispatchService.acknowledgeCustomer(dispatchId, request));
    }

    @PutMapping("/{dispatchId}/corrections")
        public ResponseEntity<Map<String, Object>> correctDispatch(
                @PathVariable Long dispatchId,
                @Valid @RequestBody CorrectDispatchOrderRequest request) {

        return ResponseEntity.ok(
                dispatchService.correctDispatch(dispatchId, request)
        );
    }
}
