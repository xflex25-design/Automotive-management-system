package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.CreatePartRequest;
import com.autogarage.automotive.dto.PartResponse;
import com.autogarage.automotive.service.PartService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/companies/{companyId}/parts")
public class PartController {

    private final PartService partService;

    public PartController(PartService partService) {
        this.partService = partService;
    }

    @PostMapping
    public ResponseEntity<PartResponse> createPart(
            @PathVariable Long companyId,
            @Valid @RequestBody CreatePartRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(partService.createPart(companyId, request));
    }

    @GetMapping
    public List<PartResponse> getParts(
            @PathVariable Long companyId,
            @RequestParam(defaultValue = "true") boolean activeOnly
    ) {
        return partService.getParts(companyId, activeOnly);
    }
}