
package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

    Optional<Customer> findByIdAndCompanyId(Long id, Long companyId);

    Optional<Customer> findByCompanyIdAndPhone(Long companyId, String phone);

    Optional<Customer> findByCompanyIdAndCustomerCode(
            Long companyId,
            String customerCode
    );
}
