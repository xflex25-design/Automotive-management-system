package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.StockBalance;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface StockBalanceRepository extends JpaRepository<StockBalance, Long> {
    @Query("select b from StockBalance b join fetch b.location l where b.part.id = :partId and l.workshop.id = :workshopId and l.active = true")
    List<StockBalance> findActiveBalances(
            @Param("partId") Long partId,
            @Param("workshopId") Long workshopId
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select b from StockBalance b join fetch b.location l where b.part.id = :partId and l.workshop.id = :workshopId and l.active = true")
    List<StockBalance> lockActiveBalances(
            @Param("partId") Long partId,
            @Param("workshopId") Long workshopId
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select b from StockBalance b where b.part.id = :partId and b.location.id = :locationId")
    List<StockBalance> lockPartAtLocation(
            @Param("partId") Long partId,
            @Param("locationId") Long locationId
    );
}
