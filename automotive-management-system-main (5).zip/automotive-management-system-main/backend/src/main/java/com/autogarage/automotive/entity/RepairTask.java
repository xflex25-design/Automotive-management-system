package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "repair_task_catalogue")
@Getter
@Setter
@NoArgsConstructor
public class RepairTask {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;

    @Column(name = "task_code", nullable = false, unique = true, length = 80)
    private String taskCode;

    @Column(name = "task_name", nullable = false, length = 200)
    private String taskName;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "default_instructions", columnDefinition = "TEXT")
    private String defaultInstructions;

    @Column(name = "estimated_hours", precision = 8, scale = 2)
    private BigDecimal estimatedHours;

    @Column(name = "requires_parts", nullable = false)
    private Boolean requiresParts = false;

    @Column(name = "requires_evidence", nullable = false)
    private Boolean requiresEvidence = true;

    @Column(name = "requires_final_inspection", nullable = false)
    private Boolean requiresFinalInspection = false;

    @Column(name = "is_active", nullable = false)
    private Boolean active = true;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}