package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.DecimalMax;

import java.math.BigDecimal;

public record VehicleDamageRequest(

        @NotBlank
        @Size(max = 30)
        String damageType,

        @NotBlank
        @Size(max = 150)
        String damageLocation,

        String damageDescription,

        @Size(max = 30)
        String severity,

        @DecimalMin("0.0")
        @DecimalMax("1.0")
        BigDecimal diagramX,

        @DecimalMin("0.0")
        @DecimalMax("1.0")
        BigDecimal diagramY

) {}