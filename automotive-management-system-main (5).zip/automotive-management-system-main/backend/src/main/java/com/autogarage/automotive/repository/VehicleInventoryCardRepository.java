package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.VehicleInventoryCard;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface VehicleInventoryCardRepository
        extends JpaRepository<VehicleInventoryCard, Long> {

    Optional<VehicleInventoryCard> findByJobId(Long jobId);

    List<VehicleInventoryCard> findByJob_Company_IdAndJob_Workshop_IdOrderByInventoryDateDesc(
            Long companyId, Long workshopId);

    boolean existsByJobId(Long jobId);

    List<VehicleInventoryCard> findByRegistrationNumberSnapshotIgnoreCaseOrderByInventoryDateDesc(
            String registrationNumber
    );
}
