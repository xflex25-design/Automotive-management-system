package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "dispatch_order_items")
@Getter
@Setter
@NoArgsConstructor
public class DispatchOrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dispatch_order_id", nullable = false)
    private DispatchOrder dispatchOrder;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requisition_item_id")
    private PartsRequisitionItem requisitionItem;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "part_id", nullable = false)
    private Part part;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "stock_location_id", nullable = false)
    private StockLocation stockLocation;

    @Column(name = "description_snapshot")
    private String descriptionSnapshot;

    @Column(name = "quantity_requested", precision = 12, scale = 2)
    private BigDecimal quantityRequested;

    @Column(name = "quantity_dispatched", precision = 12, scale = 2)
    private BigDecimal quantityDispatched;

    @Column(name = "unit_of_measure", length = 50)
    private String unitOfMeasure;

    @Column(name = "unit_cost", precision = 14, scale = 2)
    private BigDecimal unitCost;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "stock_reservation_id")
    private StockReservation stockReservation;

    @Column(name = "unit_selling_price", precision = 14, scale = 2)
    private BigDecimal unitSellingPrice;

    @Column(name = "amount_sold", precision = 14, scale = 2)
    private BigDecimal amountSold;

    @Column(columnDefinition = "TEXT")
    private String remarks;
}