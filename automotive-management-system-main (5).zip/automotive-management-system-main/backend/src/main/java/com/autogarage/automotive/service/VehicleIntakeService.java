
package com.autogarage.automotive.service;

import com.autogarage.automotive.security.ActorIdentity;
import com.autogarage.automotive.dto.CreateVehicleIntakeRequest;
import com.autogarage.automotive.dto.VehicleIntakeResponse;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
public class VehicleIntakeService {

    private final CompanyRepository companyRepository;
    private final WorkshopRepository workshopRepository;
    private final CustomerRepository customerRepository;
    private final VehicleRepository vehicleRepository;
    private final EmployeeRepository employeeRepository;
    private final UserRepository userRepository;
    private final JobRepository jobRepository;
    private final VehicleInventoryCardRepository inventoryCardRepository;

    public VehicleIntakeService(
            CompanyRepository companyRepository,
            WorkshopRepository workshopRepository,
            CustomerRepository customerRepository,
            VehicleRepository vehicleRepository,
            EmployeeRepository employeeRepository,
            UserRepository userRepository,
            JobRepository jobRepository,
            VehicleInventoryCardRepository inventoryCardRepository
    ) {
        this.companyRepository = companyRepository;
        this.workshopRepository = workshopRepository;
        this.customerRepository = customerRepository;
        this.vehicleRepository = vehicleRepository;
        this.employeeRepository = employeeRepository;
        this.userRepository = userRepository;
        this.jobRepository = jobRepository;
        this.inventoryCardRepository = inventoryCardRepository;
    }

    @Transactional
    public VehicleIntakeResponse createIntake(
            CreateVehicleIntakeRequest request
    ) {
        ActorIdentity.requireUser(request.createdByUserId());
        ActorIdentity.requireEmployee(request.receivedByEmployeeId());

        // Lock the company row to protect sequential job numbering.
        Company company = companyRepository
                .findByIdForUpdate(request.companyId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Company not found"
                ));

        Workshop workshop = workshopRepository
                .findByCompanyIdAndActiveTrue(company.getId())
                .stream()
                .filter(w -> w.getId().equals(request.workshopId()))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Active workshop not found for this company"
                ));

        User createdBy = userRepository
                .findByIdAndCompanyId(
                        request.createdByUserId(),
                        company.getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Creating user not found for this company"
                ));

        Employee receivedBy = employeeRepository
                .findByIdAndCompanyId(
                        request.receivedByEmployeeId(),
                        company.getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Receiving employee not found for this company"
                ));

        if (!receivedBy.getWorkshop().getId().equals(workshop.getId())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Receiving employee does not belong to this workshop"
            );
        }

        if (!"ACTIVE".equalsIgnoreCase(receivedBy.getEmploymentStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Receiving employee is not active"
            );
        }

        Customer customer = findOrCreateCustomer(request, company);

        Vehicle vehicle = findOrCreateVehicle(
                request, company, workshop, customer
        );

        String jobNumber = generateNextJobNumber(company.getId());

        LocalDateTime now = LocalDateTime.now();

        Job job = new Job();
        job.setCompany(company);
        job.setWorkshop(workshop);
        job.setCustomer(customer);
        job.setVehicle(vehicle);
        job.setJobNumber(jobNumber);

        job.setCustomerNameSnapshot(getCustomerName(customer));
        job.setVehicleRegistrationSnapshot(vehicle.getRegistrationNumber());
        job.setVehicleMakeSnapshot(vehicle.getMake());
        job.setVehicleTypeSnapshot(vehicle.getVehicleType());

        job.setBroughtInByName(request.broughtInByName().trim());
        job.setBroughtInByPhone(trimToNull(request.broughtInByPhone()));

        job.setReceivedBy(receivedBy);
        job.setCreatedBy(createdBy);

        job.setJobType(defaultValue(request.jobType(), "REPAIR"));
        job.setPriority(defaultValue(request.priority(), "NORMAL"));
        job.setJobStatus("RECEIVED");

        job.setReportedProblem(request.reportedProblem());
        job.setInternalNotes(request.internalNotes());
        job.setDateReceived(now);

        job = jobRepository.save(job);

        VehicleInventoryCard inventoryCard = new VehicleInventoryCard();

        inventoryCard.setJob(job);
        inventoryCard.setJobNumberSnapshot(jobNumber);
        inventoryCard.setRegistrationNumberSnapshot(
                vehicle.getRegistrationNumber()
        );
        inventoryCard.setMakeSnapshot(vehicle.getMake());
        inventoryCard.setInventoryDate(LocalDate.now());

        inventoryCard.setOwnedBySnapshot(
                request.ownerName() == null || request.ownerName().isBlank()
                        ? getCustomerName(customer)
                        : request.ownerName().trim()
        );
        inventoryCard.setDriverName(request.broughtInByName().trim());
        inventoryCard.setDriverPhone(trimToNull(request.broughtInByPhone()));

        inventoryCard.setOdometerReadingIn(request.odometerReadingIn());
        inventoryCard.setFuelLevelIn(trimToNull(request.fuelLevelIn()));

        inventoryCard.setNumberOfKeysReceived(
                request.numberOfKeysReceived() != null
                        ? request.numberOfKeysReceived()
                        : 0
        );

        inventoryCard.setWorkRequested(request.workRequested());
        inventoryCard.setCustomerComplaints(request.customerComplaints());
        inventoryCard.setGeneralRemarks(request.generalRemarks());

        inventoryCard.setReceivedBy(receivedBy);
        inventoryCard.setIntakeStatus("DRAFT");

        inventoryCard = inventoryCardRepository.save(inventoryCard);

        return new VehicleIntakeResponse(
                job.getId(),
                job.getJobNumber(),
                customer.getId(),
                getCustomerName(customer),
                inventoryCard.getOwnedBySnapshot(),
                job.getBroughtInByName(),
                job.getBroughtInByPhone(),
                vehicle.getId(),
                vehicle.getRegistrationNumber(),
                inventoryCard.getId(),
                job.getJobStatus(),
                inventoryCard.getIntakeStatus(),
                job.getDateReceived()
        );
    }

    private Customer findOrCreateCustomer(
            CreateVehicleIntakeRequest request,
            Company company
    ) {
        var details = request.customer();

        if (details.customerId() != null) {
            return customerRepository
                    .findByIdAndCompanyId(
                            details.customerId(),
                            company.getId()
                    )
                    .orElseThrow(() -> new ResponseStatusException(
                            HttpStatus.NOT_FOUND,
                            "Selected customer was not found for this company"
                    ));
        }

        String phone = details.phone().trim();

        return customerRepository
                .findByCompanyIdAndPhone(company.getId(), phone)
                .orElseGet(() -> {
                    Customer customer = new Customer();

                    customer.setCompany(company);
                    customer.setCustomerType(
                            defaultValue(details.customerType(), "INDIVIDUAL")
                    );
                    customer.setCustomerCode(
                            trimToNull(details.customerCode())
                    );
                    customer.setFirstName(trimToNull(details.firstName()));
                    customer.setLastName(trimToNull(details.lastName()));
                    customer.setCompanyName(trimToNull(details.companyName()));
                    customer.setPhone(phone);
                    customer.setAlternativePhone(
                            trimToNull(details.alternativePhone())
                    );
                    customer.setEmail(trimToNull(details.email()));
                    customer.setAddress(trimToNull(details.address()));
                    customer.setTaxNumber(trimToNull(details.taxNumber()));
                    customer.setActive(true);

                    return customerRepository.save(customer);
                });
    }

    private Vehicle findOrCreateVehicle(
            CreateVehicleIntakeRequest request,
            Company company,
            Workshop workshop,
            Customer customer
    ) {
        var details = request.vehicle();

        String registration = details.registrationNumber()
                .trim()
                .toUpperCase();

        return vehicleRepository
                .findByCompanyIdAndRegistrationNumberIgnoreCase(
                        company.getId(),
                        registration
                )
                .map(existingVehicle -> {
                    if (!existingVehicle.getOwner().getId()
                            .equals(customer.getId())) {
                        throw new ResponseStatusException(
                                HttpStatus.CONFLICT,
                                "This vehicle is registered to another customer. "
                                        + "Please verify the vehicle owner before continuing."
                        );
                    }

                    return existingVehicle;
                })
                .orElseGet(() -> {
                    Vehicle vehicle = new Vehicle();

                    vehicle.setCompany(company);
                    vehicle.setWorkshop(workshop);
                    vehicle.setOwner(customer);

                    vehicle.setRegistrationNumber(registration);
                    vehicle.setMake(details.make().trim());
                    vehicle.setModel(trimToNull(details.model()));
                    vehicle.setVehicleType(trimToNull(details.vehicleType()));
                    vehicle.setModelYear(details.modelYear());
                    vehicle.setColor(trimToNull(details.color()));
                    vehicle.setVin(trimToNull(details.vin()));
                    vehicle.setEngineNumber(trimToNull(details.engineNumber()));
                    vehicle.setFuelType(trimToNull(details.fuelType()));
                    vehicle.setTransmission(trimToNull(details.transmission()));

                    return vehicleRepository.save(vehicle);
                });
    }

    private String generateNextJobNumber(Long companyId) {
        Long highestNumber =
                jobRepository.findHighestNumericJobNumberByCompanyId(companyId);

        return String.valueOf(highestNumber + 1);
    }

    private String getCustomerName(Customer customer) {
        if (customer.getCompanyName() != null
                && !customer.getCompanyName().isBlank()) {
            return customer.getCompanyName();
        }

        String firstName = customer.getFirstName() != null
                ? customer.getFirstName().trim() : "";

        String lastName = customer.getLastName() != null
                ? customer.getLastName().trim() : "";

        String fullName = (firstName + " " + lastName).trim();

        return fullName.isEmpty() ? customer.getPhone() : fullName;
    }

    private String defaultValue(String value, String defaultValue) {
        return value == null || value.isBlank()
                ? defaultValue
                : value.trim().toUpperCase();
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank()
                ? null
                : value.trim();
    }
}
