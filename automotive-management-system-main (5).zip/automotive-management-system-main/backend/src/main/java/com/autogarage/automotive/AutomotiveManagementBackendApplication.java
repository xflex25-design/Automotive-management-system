package com.autogarage.automotive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.tomcat.servlet.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class AutomotiveManagementBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomotiveManagementBackendApplication.class, args);
	}

	@Bean
	WebServerFactoryCustomizer<TomcatServletWebServerFactory> useTomcatNio2Connector() {
		return factory -> factory.setProtocol("org.apache.coyote.http11.Http11Nio2Protocol");
	}

}
