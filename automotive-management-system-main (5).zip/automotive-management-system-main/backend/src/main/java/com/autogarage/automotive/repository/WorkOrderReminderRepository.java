package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkOrderReminder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WorkOrderReminderRepository
        extends JpaRepository<WorkOrderReminder, Long> {

    List<WorkOrderReminder> findByWorkOrder_IdOrderBySentAtDesc(Long workOrderId);

    List<WorkOrderReminder> findByEmployee_IdAndAcknowledgedAtIsNullOrderBySentAtDesc(
            Long employeeId
    );

    List<WorkOrderReminder> findByAcknowledgedAtIsNullOrderBySentAtDesc();

    Optional<WorkOrderReminder>
    findTopByWorkOrder_IdAndReminderTypeOrderBySentAtDesc(
            Long workOrderId,
            WorkOrderReminder.ReminderType reminderType
    );

    boolean existsByWorkOrder_IdAndReminderTypeAndEscalationLevel(
            Long workOrderId,
            WorkOrderReminder.ReminderType reminderType,
            Integer escalationLevel
    );
}