package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(
    name = "workshop_escalation_rules",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_escalation_level",
            columnNames = {"workshop_id", "escalation_level"}
        )
    }
)
public class WorkshopEscalationRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "workshop_id", nullable = false)
    private Workshop workshop;

    @Column(name = "escalation_level", nullable = false)
    private Integer escalationLevel;

    @Column(name = "elapsed_minutes", nullable = false)
    private Integer elapsedMinutes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Priority priority;

    @Column(name = "notify_manager", nullable = false)
    private Boolean notifyManager = false;

    @Column(name = "is_active", nullable = false)
    private Boolean active = true;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    public enum Priority {
        LOW, NORMAL, HIGH, URGENT
    }

    public WorkshopEscalationRule() {
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Workshop getWorkshop() { return workshop; }
    public void setWorkshop(Workshop workshop) { this.workshop = workshop; }

    public Integer getEscalationLevel() { return escalationLevel; }
    public void setEscalationLevel(Integer escalationLevel) { this.escalationLevel = escalationLevel; }

    public Integer getElapsedMinutes() { return elapsedMinutes; }
    public void setElapsedMinutes(Integer elapsedMinutes) { this.elapsedMinutes = elapsedMinutes; }

    public Priority getPriority() { return priority; }
    public void setPriority(Priority priority) { this.priority = priority; }

    public Boolean getNotifyManager() { return notifyManager; }
    public void setNotifyManager(Boolean notifyManager) { this.notifyManager = notifyManager; }

    public Boolean getActive() { return active; }
    public void setActive(Boolean active) { this.active = active; }

    public LocalDateTime getCreatedAt() { return createdAt; }
}