package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.RepairTaskKeyword;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RepairTaskKeywordRepository
        extends JpaRepository<RepairTaskKeyword, Long> {

    List<RepairTaskKeyword> findByRepairTask_IdOrderByKeywordAsc(
            Long repairTaskId
    );

    List<RepairTaskKeyword> findByKeywordIgnoreCaseAndRepairTask_ActiveTrue(
            String keyword
    );

    boolean existsByRepairTask_IdAndKeywordIgnoreCase(
            Long repairTaskId,
            String keyword
    );
}