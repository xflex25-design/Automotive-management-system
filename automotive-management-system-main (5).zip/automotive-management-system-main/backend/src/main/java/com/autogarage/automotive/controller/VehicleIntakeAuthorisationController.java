package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.InventoryAuthorisationRequest;
import com.autogarage.automotive.dto.InventorySignatureRequest;
import com.autogarage.automotive.service.VehicleIntakeAuthorisationService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/intake/jobs")
public class VehicleIntakeAuthorisationController {

    private final VehicleIntakeAuthorisationService authorisationService;

    public VehicleIntakeAuthorisationController(
            VehicleIntakeAuthorisationService authorisationService
    ) {
        this.authorisationService = authorisationService;
    }

    @PostMapping("/{jobId}/authorisations")
    public ResponseEntity<Map<String, Object>> createAuthorisation(
            @PathVariable Long jobId,
            @Valid @RequestBody InventoryAuthorisationRequest request
    ) {
        Long authorisationId =
                authorisationService.createAuthorisation(jobId, request);

        return ResponseEntity.status(HttpStatus.CREATED).body(
                Map.of(
                        "authorisationId", authorisationId,
                        "jobId", jobId,
                        "authorisationStatus", "PENDING"
                )
        );
    }

    @PostMapping("/{jobId}/signatures")
    public ResponseEntity<Map<String, Object>> recordSignature(
            @PathVariable Long jobId,
            @Valid @RequestBody InventorySignatureRequest request
    ) {
        Long signatureId =
                authorisationService.recordSignature(jobId, request);

        return ResponseEntity.status(HttpStatus.CREATED).body(
                Map.of(
                        "signatureId", signatureId,
                        "jobId", jobId,
                        "signerType", request.signerType().toUpperCase(),
                        "signatureMediaId", request.signatureMediaId()
                )
        );
    }
}