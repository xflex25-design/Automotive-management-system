package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotNull;

public record LinkJobCardPartRequest(
        @NotNull Long partId,
        @NotNull Long linkedByEmployeeId
) {}
