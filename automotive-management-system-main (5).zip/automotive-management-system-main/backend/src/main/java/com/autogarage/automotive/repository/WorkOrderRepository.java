package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WorkOrderRepository extends JpaRepository<WorkOrder, Long> {

    List<WorkOrder> findByJob_IdOrderBySequenceNumberAsc(Long jobId);

    List<WorkOrder> findByDepartment_IdAndWorkOrderStatus(
            Long departmentId,
            String workOrderStatus
    );

    List<WorkOrder> findByAssignedForeman_Id(Long foremanId);

    List<WorkOrder> findByRepairPlan_IdOrderBySequenceNumberAsc(Long repairPlanId);

    Optional<WorkOrder> findByWorkOrderNumber(String workOrderNumber);

    Optional<WorkOrder> findByIdAndJob_Id(Long id, Long jobId);

    List<WorkOrder> findByWorkOrderStatusInOrderByUpdatedAtAsc(
            List<String> statuses
    );

    List<WorkOrder> findByDepartment_IdAndWorkOrderStatusInOrderBySequenceNumberAsc(
            Long departmentId,
            List<String> statuses
    );

    Optional<WorkOrder> findTopByJob_IdOrderBySequenceNumberDesc(Long jobId);
}