package com.autogarage.automotive.security;

import com.autogarage.automotive.entity.Employee;
import com.autogarage.automotive.entity.User;
import com.autogarage.automotive.repository.EmployeeRepository;
import com.autogarage.automotive.repository.UserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

@Service
public class WorkshopUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;
    private final EmployeeRepository employeeRepository;

    public WorkshopUserDetailsService(
            UserRepository userRepository,
            EmployeeRepository employeeRepository
    ) {
        this.userRepository = userRepository;
        this.employeeRepository = employeeRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String email) {
        User user = userRepository.findByEmailIgnoreCase(email.trim())
                .orElseThrow(() -> new UsernameNotFoundException("Invalid email or password."));

        Employee employee = employeeRepository.findByUser_Id(user.getId()).orElse(null);
        Set<String> authorityNames = new LinkedHashSet<>();

        for (String roleName : userRepository.findRoleNamesByUserId(user.getId())) {
            addRole(authorityNames, roleName);
        }

        // Existing staff data predates the role join table in some installations.
        // Preserve the employee's explicitly assigned manager/boss title during migration.
        if (employee != null) {
            String title = employee.getJobTitle();
            if (title != null) {
                if (title.toUpperCase(Locale.ROOT).contains("MANAGER")) {
                    authorityNames.add("ROLE_MANAGER");
                }
                if (title.toUpperCase(Locale.ROOT).contains("BOSS")) {
                    authorityNames.add("ROLE_BOSS");
                }
                if (title.toUpperCase(Locale.ROOT).contains("FOREMAN")) {
                    authorityNames.add("ROLE_FOREMAN");
                }
                if (title.toUpperCase(Locale.ROOT).contains("MECHANIC")
                        || title.toUpperCase(Locale.ROOT).contains("TECHNICIAN")) {
                    authorityNames.add("ROLE_MECHANIC");
                }
                if (title.toUpperCase(Locale.ROOT).contains("STORE")) {
                    authorityNames.add("ROLE_STORES");
                }
                if (title.toUpperCase(Locale.ROOT).contains("ACCOUNT")) {
                    authorityNames.add("ROLE_ACCOUNTS");
                }
            }
        }

        if (authorityNames.isEmpty()) {
            authorityNames.add("ROLE_STAFF");
        }

        Set<SimpleGrantedAuthority> authorities = authorityNames.stream()
                .map(SimpleGrantedAuthority::new)
                .collect(java.util.stream.Collectors.toCollection(LinkedHashSet::new));

        boolean employeeActive = employee == null
                || "ACTIVE".equalsIgnoreCase(employee.getEmploymentStatus());
        String displayName = employee == null
                ? user.getEmail()
                : (employee.getFirstName() + " " + employee.getLastName()).trim();

        return new WorkshopPrincipal(
                user.getId(),
                employee == null ? null : employee.getId(),
                user.getCompany().getId(),
                employee == null || employee.getWorkshop() == null
                        ? null : employee.getWorkshop().getId(),
                displayName,
                user.getEmail(),
                user.getPasswordHash(),
                Boolean.TRUE.equals(user.getActive()) && employeeActive,
                Boolean.TRUE.equals(user.getLocked()),
                authorities
        );
    }

    private void addRole(Set<String> authorities, String roleName) {
        if (roleName == null || roleName.isBlank()) {
            return;
        }
        String normalized = roleName.trim().toUpperCase(Locale.ROOT)
                .replaceAll("[^A-Z0-9]+", "_")
                .replaceAll("^_+|_+$", "");
        if (normalized.startsWith("ROLE_")) {
            normalized = normalized.substring("ROLE_".length());
        }
        if (normalized.contains("MANAGER")) {
            authorities.add("ROLE_MANAGER");
        } else if (normalized.contains("BOSS")) {
            authorities.add("ROLE_BOSS");
        } else if (!normalized.isBlank()) {
            authorities.add("ROLE_" + normalized);
        }
    }
}
