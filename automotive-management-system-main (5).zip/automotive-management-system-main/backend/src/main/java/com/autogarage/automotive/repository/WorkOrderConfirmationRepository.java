
package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkOrderConfirmation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WorkOrderConfirmationRepository
        extends JpaRepository<WorkOrderConfirmation, Long> {

    List<WorkOrderConfirmation>
    findByWorkOrder_IdOrderByConfirmedAtDesc(Long workOrderId);

    boolean existsByWorkOrder_IdAndConfirmationStatus(
            Long workOrderId,
            String confirmationStatus
    );
}
