package com.autogarage.automotive.security;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import java.util.Objects;

/** Identity assertions for legacy DTOs that still carry actor IDs for compatibility. */
public final class ActorIdentity {

    private ActorIdentity() {}

    public static Long userId() {
        return principal().userId();
    }

    public static Long employeeId() {
        Long employeeId = principal().employeeId();
        if (employeeId == null) {
            throw new AccessDeniedException("This account is not linked to an active workshop employee.");
        }
        return employeeId;
    }

    public static void requireUser(Long submittedUserId) {
        if (!userId().equals(submittedUserId)) {
            throw new AccessDeniedException("The user ID must match the authenticated account.");
        }
    }

    public static void requireEmployee(Long submittedEmployeeId) {
        if (!employeeId().equals(submittedEmployeeId)) {
            throw new AccessDeniedException("The employee ID must match the authenticated account.");
        }
    }

    public static void requireAnyAuthority(String... expectedAuthorities) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        boolean permitted = authentication != null && authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(actual -> java.util.Arrays.stream(expectedAuthorities)
                        .anyMatch(actual::equals));
        if (!permitted) {
            throw new AccessDeniedException("This action is not allowed for the authenticated workshop role.");
        }
    }

    public static void requireCompany(Long companyId) {
        if (companyId == null || !Objects.equals(principal().companyId(), companyId)) {
            throw new AccessDeniedException("The requested record is outside the authenticated company.");
        }
    }

    public static void requireWorkshop(Long workshopId) {
        if (workshopId == null || principal().workshopId() == null
                || !principal().workshopId().equals(workshopId)) {
            throw new AccessDeniedException("The requested record is outside the authenticated workshop.");
        }
    }

    public static void requireCompanyWorkshop(Long companyId, Long workshopId) {
        requireCompany(companyId);
        requireWorkshop(workshopId);
    }

    private static WorkshopPrincipal principal() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()
                || !(authentication.getPrincipal() instanceof WorkshopPrincipal principal)) {
            throw new AccessDeniedException("An authenticated workshop account is required.");
        }
        return principal;
    }
}
