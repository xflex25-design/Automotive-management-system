package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.invoice.CancelInvoiceRequest;
import com.autogarage.automotive.entity.Employee;
import com.autogarage.automotive.entity.Invoice;
import com.autogarage.automotive.repository.EmployeeRepository;
import com.autogarage.automotive.repository.InvoiceRepository;
import com.autogarage.automotive.repository.PaymentRepository;
import com.autogarage.automotive.security.ActorIdentity;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@RequiredArgsConstructor
public class InvoiceCancellationService {

    private final InvoiceRepository invoiceRepository;
    private final PaymentRepository paymentRepository;
    private final EmployeeRepository employeeRepository;

    @Transactional
    public Invoice cancelInvoice(
            Long invoiceId,
            CancelInvoiceRequest request
    ) {
        if (request == null || request.cancelledByEmployeeId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Employee ID is required."
            );
        }
        ActorIdentity.requireEmployee(request.cancelledByEmployeeId());

        Invoice invoice = invoiceRepository.findByIdForUpdate(invoiceId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Invoice not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                invoice.getCompany().getId(), invoice.getWorkshop().getId());

        Employee employee = employeeRepository.findByIdAndCompanyId(
                request.cancelledByEmployeeId(),
                invoice.getCompany().getId()
        ).orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND,
                "Employee not found in this company."
        ));

        if (!"ACTIVE".equalsIgnoreCase(employee.getEmploymentStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only active employees can cancel invoices."
            );
        }

        if (!employee.getWorkshop().getId()
                .equals(invoice.getWorkshop().getId())) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Employee does not belong to this workshop."
            );
        }

        String status = invoice.getInvoiceStatus();

        if (!"DRAFT".equalsIgnoreCase(status)
                && !"ISSUED".equalsIgnoreCase(status)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only draft or issued invoices can be cancelled."
            );
        }

        boolean hasPayments = !paymentRepository
                .findByInvoice_IdOrderByPaymentDateDesc(invoiceId)
                .isEmpty();

        if (hasPayments) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "An invoice with recorded payments cannot be cancelled."
            );
        }

        invoice.setInvoiceStatus("CANCELLED");

        if (request.reason() != null && !request.reason().isBlank()) {
            String existingNotes = invoice.getNotes() == null
                    ? ""
                    : invoice.getNotes() + "\n";

            invoice.setNotes(
                    existingNotes + "Cancellation reason: "
                            + request.reason().trim()
            );
        }

        return invoiceRepository.save(invoice);
    }
}
