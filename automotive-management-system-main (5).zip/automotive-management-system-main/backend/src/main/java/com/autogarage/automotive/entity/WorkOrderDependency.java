package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(
    name = "work_order_dependencies",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uq_work_order_dependency",
            columnNames = {"work_order_id", "depends_on_work_order_id"}
        )
    }
)
@Getter
@Setter
@NoArgsConstructor
public class WorkOrderDependency {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "work_order_id", nullable = false)
    private WorkOrder workOrder;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "depends_on_work_order_id", nullable = false)
    private WorkOrder dependsOnWorkOrder;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}