package com.autogarage.automotive.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CustomerIntakeRequest(

        Long customerId,

        String customerType,

        String customerCode,

        @Size(max = 100)
        String firstName,

        @Size(max = 100)
        String lastName,

        @Size(max = 150)
        String companyName,

        @NotBlank(message = "Customer phone number is required")
        @Size(max = 30)
        String phone,

        @Size(max = 30)
        String alternativePhone,

        @Email(message = "Enter a valid customer email")
        @Size(max = 150)
        String email,

        String address,

        @Size(max = 100)
        String taxNumber

) {}