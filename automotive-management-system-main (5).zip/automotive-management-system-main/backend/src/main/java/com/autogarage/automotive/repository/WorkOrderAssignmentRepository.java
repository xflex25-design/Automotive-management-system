package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkOrderAssignment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkOrderAssignmentRepository
        extends JpaRepository<WorkOrderAssignment, Long> {

    List<WorkOrderAssignment> findByWorkOrder_IdOrderByAssignedAtDesc(
            Long workOrderId
    );

    List<WorkOrderAssignment> findByEmployee_IdOrderByAssignedAtDesc(
            Long employeeId
    );

    boolean existsByWorkOrder_IdAndEmployee_IdAndAssignmentStatus(
            Long workOrderId,
            Long employeeId,
            String assignmentStatus
    );

    boolean existsByWorkOrder_IdAndEmployee_IdAndAssignmentStatusIn(
            Long workOrderId,
            Long employeeId,
            List<String> assignmentStatuses
    );

    List<WorkOrderAssignment>
    findByWorkOrder_IdAndAssignmentStatusInAndRemovedAtIsNullOrderByAssignedAtDesc(
            Long workOrderId,
            List<String> assignmentStatuses
    );
}