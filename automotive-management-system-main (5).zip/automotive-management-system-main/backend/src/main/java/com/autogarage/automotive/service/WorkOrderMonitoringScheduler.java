package com.autogarage.automotive.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class WorkOrderMonitoringScheduler {

    private final WorkOrderMonitoringService monitoringService;

    public WorkOrderMonitoringScheduler(
            WorkOrderMonitoringService monitoringService
    ) {
        this.monitoringService = monitoringService;
    }

    @Scheduled(fixedDelay = 60000)
    public void monitorWorkOrders() {
        monitoringService.processMonitoring();
    }
}