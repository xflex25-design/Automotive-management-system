package com.autogarage.automotive.dto.finalinspection;

public record StartFinalInspectionRequest(
        Long inspectorEmployeeId
) {
}