package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.InventoryAuthorisation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InventoryAuthorisationRepository
        extends JpaRepository<InventoryAuthorisation, Long> {

    List<InventoryAuthorisation> findByInventoryCardIdOrderByCreatedAtDesc(
            Long inventoryCardId
    );

    List<InventoryAuthorisation> findByInventoryCardIdAndAuthorisationStatus(
            Long inventoryCardId,
            String authorisationStatus
    );

    List<InventoryAuthorisation> findByInventoryCard_Id(
                Long inventoryCardId
        );
}