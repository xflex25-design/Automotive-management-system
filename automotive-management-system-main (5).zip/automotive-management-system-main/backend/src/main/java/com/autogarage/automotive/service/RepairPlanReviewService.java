package com.autogarage.automotive.service;

import com.autogarage.automotive.security.ActorIdentity;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class RepairPlanReviewService {

    private final RepairPlanRepository repairPlanRepository;
    private final JobCardRepository jobCardRepository;
    private final WorkOrderRepository workOrderRepository;
    private final WorkOrderDependencyRepository dependencyRepository;
    private final EmployeeRepository employeeRepository;
    private final RepairPlanDepartmentRouteRepository departmentRouteRepository;

    public RepairPlanReviewService(
            RepairPlanRepository repairPlanRepository,
            JobCardRepository jobCardRepository,
            WorkOrderRepository workOrderRepository,
            WorkOrderDependencyRepository dependencyRepository,
            EmployeeRepository employeeRepository,
            RepairPlanDepartmentRouteRepository departmentRouteRepository
    ) {
        this.repairPlanRepository = repairPlanRepository;
        this.jobCardRepository = jobCardRepository;
        this.workOrderRepository = workOrderRepository;
        this.dependencyRepository = dependencyRepository;
        this.employeeRepository = employeeRepository;
        this.departmentRouteRepository = departmentRouteRepository;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getRepairPlan(Long repairPlanId) {

        RepairPlan plan = repairPlanRepository.findById(repairPlanId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Repair plan not found"
                ));

        List<WorkOrder> workOrders =
                workOrderRepository.findByRepairPlan_IdOrderBySequenceNumberAsc(
                        repairPlanId
                );

        List<RepairPlanDepartmentRoute> routes = departmentRouteRepository
                .findByRepairPlan_IdOrderBySequenceNumberAsc(repairPlanId);

        List<Map<String, Object>> workOrderDetails = new ArrayList<>();

        for (WorkOrder workOrder : workOrders) {

            List<WorkOrderDependency> dependencies =
                    dependencyRepository.findByWorkOrder_Id(workOrder.getId());

            List<Map<String, Object>> dependencyDetails = new ArrayList<>();

            for (WorkOrderDependency dependency : dependencies) {
                WorkOrder prerequisite = dependency.getDependsOnWorkOrder();

                Map<String, Object> dependencyInfo = new LinkedHashMap<>();
                dependencyInfo.put("workOrderId", prerequisite.getId());
                dependencyInfo.put("workOrderNumber",
                        prerequisite.getWorkOrderNumber());
                dependencyInfo.put("taskTitle", prerequisite.getTaskTitle());
                dependencyInfo.put("status", prerequisite.getWorkOrderStatus());

                dependencyDetails.add(dependencyInfo);
            }

            Map<String, Object> details = new LinkedHashMap<>();
            details.put("workOrderId", workOrder.getId());
            details.put("workOrderNumber", workOrder.getWorkOrderNumber());
            details.put("sequenceNumber", workOrder.getSequenceNumber());
            details.put("departmentId", workOrder.getDepartment().getId());
            details.put("departmentName",
                    workOrder.getDepartment().getDepartmentName());
            details.put("taskTitle", workOrder.getTaskTitle());
            details.put("workDescription", workOrder.getWorkDescription());
            details.put("workInstructions", workOrder.getWorkInstructions());
            details.put("estimatedHours", workOrder.getEstimatedHours());
            details.put("status", workOrder.getWorkOrderStatus());
            details.put("dependencies", dependencyDetails);

            workOrderDetails.add(details);
        }

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("repairPlanId", plan.getId());
        response.put("repairPlanNumber", plan.getPlanNumber());
        response.put("repairPlanStatus", plan.getPlanStatus());
        response.put("jobId", plan.getJob().getId());
        response.put("jobCardId", plan.getJobCard().getId());
        response.put("preparedByEmployeeId", plan.getPreparedBy().getId());
        response.put("planNotes", plan.getPlanNotes());
        response.put("workOrderCount", workOrders.size());
        response.put("workOrders", workOrderDetails);
        response.put("departmentRoutes", routes.stream().map(route -> {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("departmentId", route.getDepartment().getId());
            item.put("departmentName", route.getDepartment().getDepartmentName());
            item.put("sequenceNumber", route.getSequenceNumber());
            item.put("applicability", route.getApplicability());
            item.put("notApplicableReason", route.getNotApplicableReason());
            return item;
        }).toList());

        return response;
    }

    @Transactional
    public Map<String, Object> acceptRepairPlan(
            Long repairPlanId,
            Long foremanEmployeeId
    ) {
        ActorIdentity.requireEmployee(foremanEmployeeId);

        RepairPlan plan = repairPlanRepository.findById(repairPlanId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Repair plan not found"
                ));

        if (!"DRAFT".equals(plan.getPlanStatus())) {
            throw new IllegalStateException(
                    "Only a draft repair plan can be accepted"
            );
        }

        JobCard jobCard = jobCardRepository.findById(
                plan.getJobCard().getId()
        ).orElseThrow(() -> new IllegalArgumentException(
                "Job card not found"
        ));

        if (!"DRAFT".equals(jobCard.getJobCardStatus())) {
            throw new IllegalStateException(
                    "The job card is no longer in draft status"
            );
        }

        Employee foreman = employeeRepository.findById(foremanEmployeeId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Foreman employee not found"
                ));

        List<WorkOrder> workOrders =
                workOrderRepository.findByRepairPlan_IdOrderBySequenceNumberAsc(
                        repairPlanId
                );

        List<RepairPlanDepartmentRoute> routes = departmentRouteRepository
                .findByRepairPlan_IdOrderBySequenceNumberAsc(repairPlanId);
        validateCompleteDepartmentRoutes(routes, workOrders);

        if (workOrders.isEmpty()) {
            throw new IllegalStateException(
                    "Cannot accept a repair plan with no proposed work orders"
            );
        }

        LocalDateTime acceptedAt = LocalDateTime.now();

        for (WorkOrder workOrder : workOrders) {

            if (!"BLOCKED".equals(workOrder.getWorkOrderStatus())
                    && !"READY".equals(workOrder.getWorkOrderStatus())) {
                throw new IllegalStateException(
                        "Work order " + workOrder.getWorkOrderNumber()
                                + " has an unexpected status and cannot be released"
                );
            }

            List<WorkOrderDependency> dependencies =
                    dependencyRepository.findByWorkOrder_Id(workOrder.getId());

            boolean prerequisitesCompleted = dependencies.stream()
                    .allMatch(dependency ->
                            "COMPLETED".equals(
                                    dependency.getDependsOnWorkOrder()
                                            .getWorkOrderStatus()
                            )
                    );

            workOrder.setWorkOrderStatus(
                    prerequisitesCompleted ? "READY" : "BLOCKED"
            );
        }

        plan.setPlanStatus("APPROVED");
        plan.setConfirmedBy(foreman);
        plan.setConfirmedAt(acceptedAt);
        repairPlanRepository.save(plan);

        jobCard.setJobCardStatus("CONFIRMED");
        jobCard.setConfirmedBy(foreman);
        jobCard.setConfirmedAt(acceptedAt);
        jobCardRepository.save(jobCard);

        workOrderRepository.saveAll(workOrders);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("message",
                "Repair plan accepted successfully. Eligible work orders are ready for assignment.");
        response.put("repairPlanId", plan.getId());
        response.put("repairPlanNumber", plan.getPlanNumber());
        response.put("repairPlanStatus", plan.getPlanStatus());
        response.put("jobCardId", jobCard.getId());
        response.put("jobCardStatus", jobCard.getJobCardStatus());
        response.put("confirmedByEmployeeId", foreman.getId());
        response.put("confirmedAt", acceptedAt);
        response.put("workOrders", workOrders.stream().map(workOrder -> {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("workOrderId", workOrder.getId());
            item.put("workOrderNumber", workOrder.getWorkOrderNumber());
            item.put("taskTitle", workOrder.getTaskTitle());
            item.put("status", workOrder.getWorkOrderStatus());
            return item;
        }).toList());

        return response;
    }

    private void validateCompleteDepartmentRoutes(
            List<RepairPlanDepartmentRoute> routes,
            List<WorkOrder> workOrders
    ) {
        Set<String> expected = Set.of(
                "ELECTRICAL", "MECHANIC", "FITTING", "PANELBEATING", "SANDING", "PAINTING");
        Map<String, RepairPlanDepartmentRoute> byDepartment = routes.stream()
                .collect(java.util.stream.Collectors.toMap(
                        route -> canonicalDepartment(route.getDepartment().getDepartmentName()),
                        route -> route,
                        (left, right) -> left,
                        LinkedHashMap::new));
        if (!byDepartment.keySet().equals(expected)) {
            throw new IllegalStateException(
                    "A repair plan needs explicit decisions for all six departments before acceptance");
        }
        for (RepairPlanDepartmentRoute route : routes) {
            boolean hasWork = workOrders.stream().anyMatch(order ->
                    order.getDepartment() != null
                            && Objects.equals(order.getDepartment().getId(), route.getDepartment().getId()));
            if ("NOT_APPLICABLE".equalsIgnoreCase(route.getApplicability())) {
                if (route.getNotApplicableReason() == null || route.getNotApplicableReason().isBlank()) {
                    throw new IllegalStateException("Not Applicable department needs a reason");
                }
                if (hasWork) {
                    throw new IllegalStateException(
                            route.getDepartment().getDepartmentName()
                                    + " is marked Not Applicable but has work orders");
                }
            } else if (!"REQUIRED".equalsIgnoreCase(route.getApplicability()) || !hasWork) {
                throw new IllegalStateException(
                        "Each required department must have at least one work order");
            }
        }
    }

    private String canonicalDepartment(String name) {
        String normalized = name == null ? "" : name.toUpperCase(java.util.Locale.ROOT)
                .replaceAll("[^A-Z0-9]", "");
        return "MECHANICAL".equals(normalized) ? "MECHANIC" : normalized;
    }
}
