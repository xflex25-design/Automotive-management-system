package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.company.CompanySettingsRequest;
import com.autogarage.automotive.dto.company.CompanySettingsResponse;
import com.autogarage.automotive.entity.Company;
import com.autogarage.automotive.repository.CompanyRepository;
import com.autogarage.automotive.security.ActorIdentity;

import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.math.BigDecimal;

@Service
@RequiredArgsConstructor
public class CompanySettingsService {

    private final CompanyRepository companyRepository;

    @Transactional(readOnly = true)
    public CompanySettingsResponse getSettings(Long companyId) {
        Company company = getCompany(companyId);
        return toResponse(company);
    }

    @Transactional
    public CompanySettingsResponse updateSettings(
            Long companyId,
            CompanySettingsRequest request
    ) {
        if (request == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Company settings are required."
            );
        }

        Company company = getCompany(companyId);

        if (request.companyName() == null
                || request.companyName().isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Company name is required."
            );
        }

        if (request.vatRate() != null
                && (request.vatRate().compareTo(BigDecimal.ZERO) < 0
                || request.vatRate().compareTo(new BigDecimal("100")) > 0)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "VAT rate must be between 0 and 100."
            );
        }

        company.setCompanyName(request.companyName().trim());
        company.setRegistrationNumber(request.registrationNumber());
        company.setVatNumber(request.vatNumber());
        company.setEmail(request.email());
        company.setPhone(request.phone());
        company.setAddress(request.address());
        company.setWebsite(request.website());
        company.setCurrencyCode(
                request.currencyCode() == null
                        || request.currencyCode().isBlank()
                        ? "ZMW"
                        : request.currencyCode().trim().toUpperCase()
        );

        if (request.vatRate() != null) {
            company.setVatRate(request.vatRate());
        }

        company.setBankName(request.bankName());
        company.setBankBranch(request.bankBranch());
        company.setBankAccountName(request.bankAccountName());
        company.setBankAccountNumber(request.bankAccountNumber());
        company.setBankSwiftCode(request.bankSwiftCode());

        return toResponse(companyRepository.save(company));
    }

    @Transactional
    public CompanySettingsResponse uploadLogo(
            Long companyId,
            MultipartFile file
    ) {
        Company company = getCompany(companyId);

        if (file == null || file.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Please select a logo file."
            );
        }

        if (file.getSize() > 2 * 1024 * 1024) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Company logo must not exceed 2 MB."
            );
        }

        String contentType = file.getContentType();

        if (!"image/png".equalsIgnoreCase(contentType)
                && !"image/jpeg".equalsIgnoreCase(contentType)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only PNG and JPEG logos are supported."
            );
        }

        try {
            company.setLogoData(file.getBytes());
            company.setLogoContentType(contentType);

            return toResponse(companyRepository.save(company));

        } catch (IOException exception) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Unable to upload company logo."
            );
        }
    }

    private Company getCompany(Long companyId) {
        Company company = companyRepository.findById(companyId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Company not found."
                ));
        ActorIdentity.requireCompany(company.getId());
        return company;
    }

    private CompanySettingsResponse toResponse(Company company) {
        return new CompanySettingsResponse(
                company.getId(),
                company.getCompanyName(),
                company.getRegistrationNumber(),
                company.getVatNumber(),
                company.getEmail(),
                company.getPhone(),
                company.getAddress(),
                company.getWebsite(),
                company.getCurrencyCode(),
                company.getVatRate(),
                company.getBankName(),
                company.getBankBranch(),
                company.getBankAccountName(),
                company.getBankAccountNumber(),
                company.getBankSwiftCode(),
                company.getLogoData() != null
                        && company.getLogoData().length > 0
        );
    }
}
