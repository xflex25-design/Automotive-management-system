package com.autogarage.automotive.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/** Verifies bcrypt hashes already stored by the workshop account provisioning process. */
public class StoredPasswordEncoder implements PasswordEncoder {

    private final BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();

    @Override
    public String encode(CharSequence rawPassword) {
        return bcrypt.encode(rawPassword);
    }

    @Override
    public boolean matches(CharSequence rawPassword, String storedHash) {
        if (rawPassword == null || storedHash == null) {
            return false;
        }
        String hash = storedHash.startsWith("{bcrypt}")
                ? storedHash.substring("{bcrypt}".length())
                : storedHash;
        if (!(hash.startsWith("$2a$") || hash.startsWith("$2b$") || hash.startsWith("$2y$"))) {
            return false;
        }
        try {
            return bcrypt.matches(rawPassword, hash);
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }
}
