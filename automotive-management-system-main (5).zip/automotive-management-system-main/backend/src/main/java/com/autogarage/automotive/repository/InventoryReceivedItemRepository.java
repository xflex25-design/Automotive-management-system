package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.InventoryReceivedItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InventoryReceivedItemRepository
        extends JpaRepository<InventoryReceivedItem, Long> {

    List<InventoryReceivedItem> findByInventoryCardIdOrderByIdAsc(
            Long inventoryCardId
    );
}