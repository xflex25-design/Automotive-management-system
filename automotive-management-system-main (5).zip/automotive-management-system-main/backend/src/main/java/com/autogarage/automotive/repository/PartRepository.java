package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Part;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PartRepository extends JpaRepository<Part, Long> {

    Optional<Part> findByIdAndCompany_IdAndActiveTrue(
            Long id,
            Long companyId
    );

    List<Part> findByCompany_IdOrderByPartNameAsc(Long companyId);

    List<Part> findByCompany_IdAndActiveTrueOrderByPartNameAsc(
            Long companyId
    );

    boolean existsByCompany_IdAndPartCodeIgnoreCase(
            Long companyId,
            String partCode
    );
}