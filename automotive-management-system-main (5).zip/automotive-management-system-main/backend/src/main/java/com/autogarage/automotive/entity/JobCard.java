package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "job_cards")
@Getter
@Setter
@NoArgsConstructor
public class JobCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false, unique = true)
    private Job job;

    @Column(name = "approved_quotation_id", nullable = false)
    private Long approvedQuotationId;

    @Column(name = "job_card_number", nullable = false, unique = true, length = 60)
    private String jobCardNumber;

    @Column(name = "vehicle_type_snapshot", nullable = false, length = 100)
    private String vehicleTypeSnapshot;

    @Column(name = "registration_number_snapshot", nullable = false, length = 30)
    private String registrationNumberSnapshot;

    @Column(name = "client_name_snapshot", nullable = false, length = 200)
    private String clientNameSnapshot;

    @Column(name = "work_description", nullable = false, columnDefinition = "TEXT")
    private String workDescription;

    @Column(name = "inspection_findings", columnDefinition = "TEXT")
    private String inspectionFindings;

    @Column(name = "repair_instructions", columnDefinition = "TEXT")
    private String repairInstructions;

    @Column(name = "foreman_remarks", columnDefinition = "TEXT")
    private String foremanRemarks;

    @Column(name = "job_card_status", nullable = false, length = 30)
    private String jobCardStatus = "DRAFT";

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "prepared_by_employee_id", nullable = false)
    private Employee preparedBy;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "confirmed_by_employee_id")
    private Employee confirmedBy;

    @Column(name = "confirmed_at")
    private LocalDateTime confirmedAt;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}