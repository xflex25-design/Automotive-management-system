package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record InspectionItemRequest(

        @NotBlank
        @Size(max = 150)
        String itemName,

        @Size(max = 100)
        String inspectionCategory,

        @Size(max = 40)
        String conditionStatus,

        String observation,

        Boolean requiresAttention

) {}