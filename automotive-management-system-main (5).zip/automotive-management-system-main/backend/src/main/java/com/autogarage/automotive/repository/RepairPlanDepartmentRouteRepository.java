package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.RepairPlanDepartmentRoute;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RepairPlanDepartmentRouteRepository
        extends JpaRepository<RepairPlanDepartmentRoute, Long> {

    List<RepairPlanDepartmentRoute> findByRepairPlan_IdOrderBySequenceNumberAsc(Long repairPlanId);
}
