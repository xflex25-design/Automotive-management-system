package com.autogarage.automotive.service;

import com.autogarage.automotive.security.ActorIdentity;
import com.autogarage.automotive.dto.JobCardCreationRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.repository.RepairTaskDependencyRepository;
import com.autogarage.automotive.repository.WorkOrderDependencyRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class JobCardService {

    private final JobRepository jobRepository;
    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final QuotationRepository quotationRepository;
    private final QuotationItemRepository quotationItemRepository;
    private final VehicleInventoryCardRepository inventoryCardRepository;
    private final JobCardRepository jobCardRepository;
    private final JobCardPartRepository jobCardPartRepository;
    private final RepairPlanRepository repairPlanRepository;
    private final RepairPlanDepartmentRouteRepository departmentRouteRepository;
    private final WorkOrderRepository workOrderRepository;
    private final RepairTaskRepository repairTaskRepository;
    private final RepairTaskKeywordRepository repairTaskKeywordRepository;
    private final RepairTaskDependencyRepository repairTaskDependencyRepository;
    private final WorkOrderDependencyRepository workOrderDependencyRepository;

    public JobCardService(
            JobRepository jobRepository,
            EmployeeRepository employeeRepository,
            DepartmentRepository departmentRepository,
            QuotationRepository quotationRepository,
            QuotationItemRepository quotationItemRepository,
            VehicleInventoryCardRepository inventoryCardRepository,
            JobCardRepository jobCardRepository,
            JobCardPartRepository jobCardPartRepository,
            RepairPlanRepository repairPlanRepository,
            RepairPlanDepartmentRouteRepository departmentRouteRepository,
            WorkOrderRepository workOrderRepository,
            RepairTaskRepository repairTaskRepository,
            RepairTaskKeywordRepository repairTaskKeywordRepository,
            RepairTaskDependencyRepository repairTaskDependencyRepository,
            WorkOrderDependencyRepository workOrderDependencyRepository
    ) {
        this.jobRepository = jobRepository;
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
        this.quotationRepository = quotationRepository;
        this.quotationItemRepository = quotationItemRepository;
        this.inventoryCardRepository = inventoryCardRepository;
        this.jobCardRepository = jobCardRepository;
        this.jobCardPartRepository = jobCardPartRepository;
        this.repairPlanRepository = repairPlanRepository;
        this.departmentRouteRepository = departmentRouteRepository;
        this.workOrderRepository = workOrderRepository;
        this.repairTaskRepository = repairTaskRepository;
        this.repairTaskKeywordRepository = repairTaskKeywordRepository;
        this.repairTaskDependencyRepository = repairTaskDependencyRepository;
        this.workOrderDependencyRepository = workOrderDependencyRepository;
    }

    @Transactional
    public Map<String, Object> createJobCard(
            JobCardCreationRequest request
    ) {
        ActorIdentity.requireEmployee(request.getPreparedByEmployeeId());

        Job job = jobRepository.findById(request.getJobId())
                .orElseThrow(() ->
                        new IllegalArgumentException("Job not found")
                );
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());
        List<PlannedDepartmentRoute> plannedRoutes = validateDepartmentRoutes(
                job, request.getDepartmentRoutes());

        Quotation quotation = quotationRepository.findById(
                request.getQuotationId()
        ).orElseThrow(() ->
                new IllegalArgumentException("Quotation not found")
        );

        Employee foreman = employeeRepository.findById(
                request.getPreparedByEmployeeId()
        ).orElseThrow(() ->
                new IllegalArgumentException("Foreman employee not found")
        );

        if (!quotation.getJob().getId().equals(job.getId())) {
            throw new IllegalArgumentException(
                    "The quotation does not belong to the supplied job"
            );
        }

        if (jobCardRepository.existsByJobId(job.getId())) {
            throw new IllegalStateException(
                    "A job card already exists for this job"
            );
        }

        if (!"ISSUED".equalsIgnoreCase(quotation.getQuotationStatus())) {
            throw new IllegalStateException(
                    "Only an issued quotation can be used to create a job card"
            );
        }

        List<RepairPlan> existingPlans =
                repairPlanRepository.findByJob_IdOrderByCreatedAtDesc(
                        job.getId()
                );

        if (!existingPlans.isEmpty()) {
            throw new IllegalStateException(
                    "A repair plan already exists for this job"
            );
        }

        VehicleInventoryCard inventoryCard = inventoryCardRepository
                .findByJobId(job.getId())
                .orElseThrow(() -> new IllegalStateException(
                        "A completed vehicle intake is required before job-card creation"));
        if (!"COMPLETED".equalsIgnoreCase(inventoryCard.getIntakeStatus())) {
            throw new IllegalStateException(
                    "Complete the signed vehicle intake before creating a job card");
        }

        List<QuotationItem> quotationItems =
                quotationItemRepository.findByQuotationIdOrderByIdAsc(
                        quotation.getId()
                );

        if (quotationItems.isEmpty()) {
            throw new IllegalStateException(
                    "The quotation contains no items"
            );
        }

        // The customer authorizes work once on the intake. All items in this
        // issued quote are therefore eligible for the job card.
        List<QuotationItem> workItems = quotationItems;

        // Build the job card.
        JobCard jobCard = new JobCard();

        jobCard.setJob(job);
        jobCard.setApprovedQuotationId(quotation.getId());
        jobCard.setJobCardNumber("JC-" + job.getJobNumber());

        jobCard.setVehicleTypeSnapshot(
                job.getVehicleTypeSnapshot() != null
                        ? job.getVehicleTypeSnapshot()
                        : "NOT SPECIFIED"
        );

        jobCard.setRegistrationNumberSnapshot(
                job.getVehicleRegistrationSnapshot()
        );

        jobCard.setClientNameSnapshot(
                job.getCustomerNameSnapshot()
        );

        String approvedDescriptions = workItems.stream()
                .map(item ->
                        item.getItemType() + ": " + item.getDescription()
                )
                .collect(Collectors.joining("\n"));

        String workDescription = request.getWorkDescription();

        if (workDescription == null || workDescription.isBlank()) {
            workDescription = approvedDescriptions;
        } else {
            workDescription += "\n\nCustomer-approved quotation items:\n"
                    + approvedDescriptions;
        }

        jobCard.setWorkDescription(workDescription);
        jobCard.setInspectionFindings(request.getInspectionFindings());
        jobCard.setRepairInstructions(request.getRepairInstructions());
        jobCard.setForemanRemarks(request.getForemanRemarks());
        jobCard.setPreparedBy(foreman);
        jobCard.setJobCardStatus("DRAFT");

        jobCard = jobCardRepository.save(jobCard);

        // All PART items on the issued quote become job-card requirements.
        for (QuotationItem item : workItems) {

            if (!"PART".equalsIgnoreCase(item.getItemType())) {
                continue;
            }

            JobCardPart part = new JobCardPart();

            part.setJobCard(jobCard);
            part.setSourceQuotationItem(item);
            part.setPartCategory("PART");
            part.setPartName(item.getDescription());
            part.setPartNumber(item.getItemCode());
            part.setQuantity(item.getQuantity());
            part.setUnitOfMeasure(item.getUnitOfMeasure());
            part.setRequiredFor("Job " + job.getJobNumber());
            part.setRemarks(item.getRemarks());

            jobCardPartRepository.save(part);
        }

        // Create the draft repair plan.
        RepairPlan repairPlan = new RepairPlan();

        repairPlan.setJob(job);
        repairPlan.setJobCard(jobCard);
        repairPlan.setPlanNumber("RP-" + job.getJobNumber());
        repairPlan.setPreparedBy(foreman);
        repairPlan.setPlanStatus("DRAFT");

        repairPlan.setPlanNotes(
                request.getPlanNotes() != null
                        ? request.getPlanNotes()
                        : "Automatically proposed from customer-approved quotation items. "
                        + "Foreman review and acceptance required before work begins."
        );

        repairPlan = repairPlanRepository.save(repairPlan);
        final RepairPlan persistedRepairPlan = repairPlan;

        // Match the issued quote items against the active task catalogue.
        List<RepairTask> activeTasks =
                repairTaskRepository.findByActiveTrueOrderByTaskNameAsc();

        Map<Long, RepairTask> matchedTasks = new LinkedHashMap<>();
        Map<Long, List<String>> taskDescriptions = new HashMap<>();

        List<String> unmatchedItems = new ArrayList<>();
        List<String> ambiguousMatches = new ArrayList<>();

        for (QuotationItem item : workItems) {

            String searchableText = normalize(
                    item.getDescription() + " "
                            + Objects.toString(item.getItemCode(), "") + " "
                            + Objects.toString(item.getRemarks(), "")
            );

            List<RepairTask> itemMatches = new ArrayList<>();

            for (RepairTask task : activeTasks) {

                List<RepairTaskKeyword> keywords =
                        repairTaskKeywordRepository
                                .findByRepairTask_IdOrderByKeywordAsc(
                                        task.getId()
                                );

                boolean matched = keywords.stream()
                        .map(RepairTaskKeyword::getKeyword)
                        .map(this::normalize)
                        .filter(keyword -> !keyword.isBlank())
                        .anyMatch(searchableText::contains);

                if (matched) {
                    itemMatches.add(task);
                }
            }

            if (itemMatches.isEmpty()) {
                unmatchedItems.add(item.getDescription());
                continue;
            }

            if (itemMatches.size() > 1) {
                ambiguousMatches.add(item.getDescription());
                unmatchedItems.add(item.getDescription());
                continue;
            }

            for (RepairTask task : itemMatches) {

                matchedTasks.putIfAbsent(task.getId(), task);

                taskDescriptions.computeIfAbsent(
                        task.getId(),
                        ignored -> new ArrayList<>()
                ).add(item.getDescription());
            }
        }

        // Create proposed work orders. None are released for execution.
        // Load all configured task prerequisites.
        List<RepairTaskDependency> configuredDependencies =
                repairTaskDependencyRepository.findAll();

        Map<Long, List<RepairTaskDependency>> dependenciesByTask =
                configuredDependencies.stream()
                        .collect(Collectors.groupingBy(
                                dependency -> dependency.getTask().getId()
                        ));

        // Automatically include prerequisite tasks, including chained prerequisites.
        Queue<Long> pendingTasks = new ArrayDeque<>(matchedTasks.keySet());
        Set<Long> processedTasks = new HashSet<>();

        while (!pendingTasks.isEmpty()) {

        Long taskId = pendingTasks.poll();

        if (!processedTasks.add(taskId)) {
                continue;
        }

        Set<Long> notApplicableDepartmentIds = plannedRoutes.stream()
                .filter(route -> "NOT_APPLICABLE".equals(route.applicability()))
                .map(route -> route.department().getId())
                .collect(Collectors.toSet());
        boolean matchedNotApplicable = matchedTasks.values().stream()
                .anyMatch(task -> notApplicableDepartmentIds.contains(
                        task.getDepartment().getId()));
        if (matchedNotApplicable) {
            throw new IllegalArgumentException(
                    "A department marked Not Applicable has a routed task; correct the department decisions");
        }

        List<RepairTaskDependency> prerequisites =
                dependenciesByTask.getOrDefault(taskId, Collections.emptyList());

        for (RepairTaskDependency dependency : prerequisites) {

                RepairTask prerequisiteTask = dependency.getDependsOnTask();

                if (!Boolean.TRUE.equals(prerequisiteTask.getActive())) {
                throw new IllegalStateException(
                        "Task " + matchedTasks.get(taskId).getTaskName()
                                + " requires inactive prerequisite task: "
                                + prerequisiteTask.getTaskName()
                );
                }

                if (!matchedTasks.containsKey(prerequisiteTask.getId())) {

                matchedTasks.put(prerequisiteTask.getId(), prerequisiteTask);

                taskDescriptions.put(
                        prerequisiteTask.getId(),
                        new ArrayList<>()
                );

                taskDescriptions.get(prerequisiteTask.getId()).add(
                        "Required prerequisite for "
                                + matchedTasks.get(taskId).getTaskName()
                );
                }

                pendingTasks.add(prerequisiteTask.getId());
        }
        }

        // Sort tasks so every prerequisite comes before its dependent task.
        List<RepairTask> orderedTasks = orderTasksByDependencies(
                matchedTasks,
                configuredDependencies
        );

        // Create proposed work orders in the correct sequence.
        Map<Long, WorkOrder> workOrdersByTask = new LinkedHashMap<>();

        int sequence = 1;

        for (RepairTask task : orderedTasks) {

        WorkOrder workOrder = new WorkOrder();

        workOrder.setRepairPlan(repairPlan);
        workOrder.setJob(job);
        workOrder.setDepartment(task.getDepartment());

        workOrder.setWorkOrderNumber(
                "WO-" + job.getJobNumber() + "-" + sequence
        );

        workOrder.setSequenceNumber(sequence);
        workOrder.setTaskTitle(task.getTaskName());
        workOrder.setWorkDescription(task.getDescription());

        workOrder.setWorkInstructions(
                "Catalogue task: " + task.getTaskCode()
                        + "\nDefault instructions: "
                        + Objects.toString(
                                task.getDefaultInstructions(),
                                "No additional instructions"
                        )
                        + "\nApproved quotation items: "
                        + String.join(
                                "; ",
                                taskDescriptions.getOrDefault(
                                        task.getId(),
                                        Collections.emptyList()
                                )
                        )
        );

        workOrder.setWorkOrderStatus("BLOCKED");
        workOrder.setPriority(job.getPriority());
        workOrder.setEstimatedHours(task.getEstimatedHours());

        workOrder = workOrderRepository.save(workOrder);

        workOrdersByTask.put(task.getId(), workOrder);

        sequence++;
        }

        // The foreman may add manual work for departments that have no active
        // catalogue match, and may explicitly route unmatched quote items.
        String manualRoutingText = plannedRoutes.stream()
                .filter(route -> "REQUIRED".equals(route.applicability()))
                .map(PlannedDepartmentRoute::manualWorkDescription)
                .filter(Objects::nonNull)
                .collect(Collectors.joining("\n"))
                .toLowerCase(Locale.ROOT);
        for (String unmatched : unmatchedItems) {
            if (!manualRoutingText.contains(unmatched.toLowerCase(Locale.ROOT))) {
                throw new IllegalArgumentException(
                        "Manually route each unmatched quotation item in a required department's manualWorkDescription: "
                                + unmatched);
            }
        }

        for (PlannedDepartmentRoute route : plannedRoutes) {
            if (!"REQUIRED".equals(route.applicability())) {
                continue;
            }
            boolean hasCatalogueWork = workOrdersByTask.values().stream()
                    .anyMatch(workOrder -> Objects.equals(
                            workOrder.getDepartment().getId(), route.department().getId()));
            String manualDescription = route.manualWorkDescription();
            if (!hasCatalogueWork && (manualDescription == null || manualDescription.isBlank())) {
                throw new IllegalArgumentException(
                        "Provide manual work description for required department "
                                + route.department().getDepartmentName());
            }
            if (manualDescription != null && !manualDescription.isBlank()) {
                WorkOrder manualOrder = new WorkOrder();
                manualOrder.setRepairPlan(repairPlan);
                manualOrder.setJob(job);
                manualOrder.setDepartment(route.department());
                manualOrder.setWorkOrderNumber(
                        "WO-" + job.getJobNumber() + "-" + sequence);
                manualOrder.setSequenceNumber(sequence++);
                manualOrder.setTaskTitle("Foreman-routed work - "
                        + route.department().getDepartmentName());
                manualOrder.setWorkDescription(manualDescription.trim());
                manualOrder.setWorkInstructions(
                        route.manualWorkInstructions() == null
                                || route.manualWorkInstructions().isBlank()
                                ? "Manually routed by the foreman from the job card and issued quotation."
                                : route.manualWorkInstructions().trim());
                manualOrder.setWorkOrderStatus("BLOCKED");
                manualOrder.setPriority(job.getPriority());
                workOrderRepository.save(manualOrder);
            }
        }

        List<RepairPlanDepartmentRoute> persistedRoutes = plannedRoutes.stream()
                .map(route -> {
                    RepairPlanDepartmentRoute entity = new RepairPlanDepartmentRoute();
                    entity.setRepairPlan(persistedRepairPlan);
                    entity.setDepartment(route.department());
                    entity.setSequenceNumber(route.sequenceNumber());
                    entity.setApplicability(route.applicability());
                    entity.setNotApplicableReason(route.notApplicableReason());
                    return entity;
                })
                .toList();
        departmentRouteRepository.saveAll(persistedRoutes);

        // Persist configured dependencies between the generated work orders.
        List<WorkOrderDependency> generatedDependencies = new ArrayList<>();

        for (RepairTaskDependency dependency : configuredDependencies) {

        Long taskId = dependency.getTask().getId();
        Long prerequisiteTaskId = dependency.getDependsOnTask().getId();

        WorkOrder dependentWorkOrder = workOrdersByTask.get(taskId);
        WorkOrder prerequisiteWorkOrder =
                workOrdersByTask.get(prerequisiteTaskId);

        if (dependentWorkOrder == null || prerequisiteWorkOrder == null) {
                continue;
        }

        WorkOrderDependency workOrderDependency =
                new WorkOrderDependency();

        workOrderDependency.setWorkOrder(dependentWorkOrder);
        workOrderDependency.setDependsOnWorkOrder(prerequisiteWorkOrder);

        generatedDependencies.add(workOrderDependency);
        }

        if (!generatedDependencies.isEmpty()) {
        workOrderDependencyRepository.saveAll(generatedDependencies);
        }

        if (!unmatchedItems.isEmpty()) {
            repairPlan.setPlanNotes(
                    Objects.toString(repairPlan.getPlanNotes(), "")
                            + "\n\nMANUAL ROUTING:\n"
                            + String.join("; ", unmatchedItems));
            repairPlanRepository.save(repairPlan);
        }

        Map<String, Object> response = new LinkedHashMap<>();

        response.put("message",
                "Job card and draft repair plan created successfully");

        response.put("jobId", job.getId());
        response.put("jobNumber", job.getJobNumber());

        response.put("jobCardId", jobCard.getId());
        response.put("jobCardNumber", jobCard.getJobCardNumber());
        response.put("jobCardStatus", jobCard.getJobCardStatus());

        response.put("quotationId", quotation.getId());
        response.put("intakeAuthorizationVerified", true);
        response.put("quotationItemsUsed", workItems.size());

        response.put("approvedQuotationItems",
                workItems.size());

        response.put("approvedParts",
                workItems.stream()
                        .filter(item ->
                                "PART".equalsIgnoreCase(item.getItemType())
                        )
                        .count());

        response.put("repairPlanId", repairPlan.getId());
        response.put("repairPlanNumber", repairPlan.getPlanNumber());
        response.put("repairPlanStatus", repairPlan.getPlanStatus());

        response.put("proposedWorkOrders", orderedTasks.size()
                + plannedRoutes.stream()
                .filter(route -> "REQUIRED".equals(route.applicability()))
                .filter(route -> route.manualWorkDescription() != null
                        && !route.manualWorkDescription().isBlank())
                .count());
        response.put("proposedDependencies", generatedDependencies.size());
        response.put("unmatchedItems", List.of());
        response.put("manuallyRoutedItems", unmatchedItems);
        response.put("departmentRoutes", persistedRoutes.stream().map(route -> Map.of(
                "departmentId", route.getDepartment().getId(),
                "departmentName", route.getDepartment().getDepartmentName(),
                "sequenceNumber", route.getSequenceNumber(),
                "applicability", route.getApplicability(),
                "notApplicableReason", Objects.toString(route.getNotApplicableReason(), "")
        )).toList());
        response.put("ambiguousMatches", ambiguousMatches);

        response.put("nextStep",
                "Foreman must review and accept the repair plan before work orders can be released");

        return response;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getJobCard(Long jobCardId) {
        JobCard card = jobCardRepository.findById(jobCardId)
                .orElseThrow(() -> new IllegalArgumentException("Job card not found"));
        Job job = card.getJob();
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        List<Map<String, Object>> parts = jobCardPartRepository
                .findByJobCard_IdOrderByIdAsc(card.getId())
                .stream()
                .map(part -> {
                    Map<String, Object> item = new LinkedHashMap<>();
                    item.put("jobCardPartId", part.getId());
                    item.put("partId", part.getPart() == null ? null : part.getPart().getId());
                    item.put("partNumber", part.getPartNumber());
                    item.put("partCode", part.getPart() == null
                            ? part.getPartNumber() : part.getPart().getPartCode());
                    item.put("partName", part.getPartName());
                    item.put("quantity", part.getQuantity());
                    item.put("unitOfMeasure", part.getUnitOfMeasure());
                    return item;
                })
                .toList();

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("jobCardId", card.getId());
        response.put("jobCardNumber", card.getJobCardNumber());
        response.put("jobId", job.getId());
        response.put("quotationId", card.getApprovedQuotationId());
        response.put("jobCardStatus", card.getJobCardStatus());
        response.put("workDescription", card.getWorkDescription());
        response.put("parts", parts);
        return response;
    }

    private String normalize(String value) {

        if (value == null) {
            return "";
        }

        return value.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", " ")
                .trim()
                .replaceAll("\\s+", " ");
    }

    private record PlannedDepartmentRoute(
            Department department,
            int sequenceNumber,
            String applicability,
            String notApplicableReason,
            String manualWorkDescription,
            String manualWorkInstructions
    ) {}

    private List<PlannedDepartmentRoute> validateDepartmentRoutes(
            Job job,
            List<JobCardCreationRequest.DepartmentRouteRequest> suppliedRoutes
    ) {
        Set<String> expectedDepartments = Set.of(
                "ELECTRICAL", "MECHANIC", "FITTING", "PANELBEATING", "SANDING", "PAINTING");
        Map<String, Department> activeByName = departmentRepository
                .findActiveByCompanyAndWorkshop(
                        job.getCompany().getId(), job.getWorkshop().getId())
                .stream()
                .collect(Collectors.toMap(
                        department -> canonicalDepartment(department.getDepartmentName()),
                        department -> department,
                        (left, right) -> left,
                        LinkedHashMap::new));

        if (!activeByName.keySet().containsAll(expectedDepartments)) {
            Set<String> missing = new LinkedHashSet<>(expectedDepartments);
            missing.removeAll(activeByName.keySet());
            throw new IllegalStateException(
                    "Configure all six workshop departments before creating a job card: "
                            + String.join(", ", missing));
        }
        if (suppliedRoutes == null || suppliedRoutes.size() != expectedDepartments.size()) {
            throw new IllegalArgumentException(
                    "Provide one route decision for Electrical, Mechanic, Fitting, Panel Beating, Sanding and Painting");
        }

        Map<Long, PlannedDepartmentRoute> byDepartmentId = new LinkedHashMap<>();
        int sequence = 1;
        for (JobCardCreationRequest.DepartmentRouteRequest request : suppliedRoutes) {
            if (request.getDepartmentId() == null) {
                throw new IllegalArgumentException("Every department route needs a department ID");
            }
            Department department = departmentRepository
                    .findByIdAndCompany_IdAndWorkshop_IdAndActiveTrue(
                            request.getDepartmentId(), job.getCompany().getId(), job.getWorkshop().getId())
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Department is inactive or belongs to another workshop"));
            String key = canonicalDepartment(department.getDepartmentName());
            if (!expectedDepartments.contains(key) || !activeByName.containsKey(key)) {
                throw new IllegalArgumentException(
                        "Department is not one of the six required workshop departments: "
                                + department.getDepartmentName());
            }
            String applicability = request.getApplicability().trim().toUpperCase(Locale.ROOT);
            if (!Set.of("REQUIRED", "NOT_APPLICABLE").contains(applicability)) {
                throw new IllegalArgumentException("Applicability must be REQUIRED or NOT_APPLICABLE");
            }
            String reason = request.getNotApplicableReason();
            if ("NOT_APPLICABLE".equals(applicability)
                    && (reason == null || reason.isBlank())) {
                throw new IllegalArgumentException(
                        "A reason is required for a department marked Not Applicable");
            }
            PlannedDepartmentRoute route = new PlannedDepartmentRoute(
                    department,
                    sequence++,
                    applicability,
                    "NOT_APPLICABLE".equals(applicability) ? reason.trim() : null,
                    request.getManualWorkDescription(),
                    request.getManualWorkInstructions());
            if (byDepartmentId.putIfAbsent(department.getId(), route) != null) {
                throw new IllegalArgumentException("Each department may be routed only once");
            }
        }

        Set<String> included = byDepartmentId.values().stream()
                .map(route -> canonicalDepartment(route.department().getDepartmentName()))
                .collect(Collectors.toSet());
        if (!included.equals(expectedDepartments)) {
            throw new IllegalArgumentException(
                    "Route decisions must include all six workshop departments");
        }
        if (byDepartmentId.values().stream()
                .noneMatch(route -> "REQUIRED".equals(route.applicability()))) {
            throw new IllegalArgumentException("At least one department must contain required work");
        }
        return new ArrayList<>(byDepartmentId.values());
    }

    private String canonicalDepartment(String name) {
        String normalized = name == null ? "" : name.toUpperCase(Locale.ROOT)
                .replaceAll("[^A-Z0-9]", "");
        return "MECHANICAL".equals(normalized) ? "MECHANIC" : normalized;
    }

    private List<RepairTask> orderTasksByDependencies(
                Map<Long, RepairTask> tasks,
                List<RepairTaskDependency> dependencies
        ) {

        Map<Long, Integer> inDegree = new LinkedHashMap<>();

        Map<Long, List<Long>> dependents = new HashMap<>();

        for (Long taskId : tasks.keySet()) {
                inDegree.put(taskId, 0);
                dependents.put(taskId, new ArrayList<>());
        }

        // Build prerequisite-to-dependent relationships.
        for (RepairTaskDependency dependency : dependencies) {

                Long taskId = dependency.getTask().getId();
                Long prerequisiteId = dependency.getDependsOnTask().getId();

                if (!tasks.containsKey(taskId)
                        || !tasks.containsKey(prerequisiteId)) {
                continue;
                }

                dependents.get(prerequisiteId).add(taskId);

                inDegree.put(
                        taskId,
                        inDegree.get(taskId) + 1
                );
        }

        // Start with tasks that have no prerequisites.
        Queue<Long> readyTasks = new ArrayDeque<>();

        for (Map.Entry<Long, Integer> entry : inDegree.entrySet()) {

                if (entry.getValue() == 0) {
                readyTasks.add(entry.getKey());
                }
        }

        List<RepairTask> orderedTasks = new ArrayList<>();

        while (!readyTasks.isEmpty()) {

                Long currentTaskId = readyTasks.poll();

                orderedTasks.add(tasks.get(currentTaskId));

                for (Long dependentId : dependents.get(currentTaskId)) {

                int remainingDependencies =
                        inDegree.get(dependentId) - 1;

                inDegree.put(dependentId, remainingDependencies);

                if (remainingDependencies == 0) {
                        readyTasks.add(dependentId);
                }
                }
        }

        // Never generate a route containing circular prerequisites.
        if (orderedTasks.size() != tasks.size()) {
                throw new IllegalStateException(
                        "Circular task dependencies detected. "
                                + "Review the repair task dependency configuration."
                );
        }

        return orderedTasks;
        }
}
