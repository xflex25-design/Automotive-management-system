
package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "final_inspections")
@Getter
@Setter
@NoArgsConstructor
public class FinalInspection {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_id", nullable = false)
    private Job job;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "previous_inspection_id")
    private FinalInspection previousInspection;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inspector_employee_id", nullable = false)
    private Employee inspector;

    @Column(name = "inspection_number", nullable = false, unique = true, length = 100)
    private String inspectionNumber;

    @Column(name = "inspection_status", nullable = false, length = 30)
    private String inspectionStatus = "IN_PROGRESS";

    @Column(name = "inspection_decision", length = 20)
    private String inspectionDecision;

    @Column(name = "inspection_notes", columnDefinition = "TEXT")
    private String inspectionNotes;

    @Column(name = "started_at", nullable = false)
    private LocalDateTime startedAt;

    @Column(name = "completed_at")
    private LocalDateTime completedAt;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
