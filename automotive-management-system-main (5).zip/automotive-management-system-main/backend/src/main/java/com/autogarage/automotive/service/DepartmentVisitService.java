
package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.DepartmentArrivalRequest;
import com.autogarage.automotive.dto.DepartmentSendOffRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class DepartmentVisitService {

    private final WorkOrderRepository workOrderRepository;
    private final WorkOrderDepartmentVisitRepository visitRepository;
    private final WorkOrderActivityRepository activityRepository;
    private final EmployeeRepository employeeRepository;
    private final WorkOrderAssignmentRepository assignmentRepository;

    public DepartmentVisitService(
            WorkOrderRepository workOrderRepository,
            WorkOrderDepartmentVisitRepository visitRepository,
            WorkOrderActivityRepository activityRepository,
            EmployeeRepository employeeRepository,
            WorkOrderAssignmentRepository assignmentRepository
    ) {
        this.workOrderRepository = workOrderRepository;
        this.visitRepository = visitRepository;
        this.activityRepository = activityRepository;
        this.employeeRepository = employeeRepository;
        this.assignmentRepository = assignmentRepository;
    }

    @Transactional
    public Map<String, Object> recordArrival(
            Long workOrderId,
            Long departmentId,
            DepartmentArrivalRequest request
    ) {

        ActorIdentity.requireEmployee(request == null ? null : request.employeeId());

        WorkOrder workOrder = workOrderRepository.findById(workOrderId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Work order not found"
                ));
        ActorIdentity.requireCompanyWorkshop(
                workOrder.getJob().getCompany().getId(),
                workOrder.getJob().getWorkshop().getId());

        if (!workOrder.getDepartment().getId().equals(departmentId)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Department does not match this work order"
            );
        }

        if (!List.of("READY", "ASSIGNED")
                .contains(workOrder.getWorkOrderStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Work order is not ready for department arrival"
            );
        }

        if (visitRepository
                .findFirstByWorkOrder_IdAndVisitStatusOrderByVisitNumberDesc(
                        workOrderId, "OPEN"
                ).isPresent()) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "This work order already has an open department visit"
            );
        }

        Employee employee = employeeRepository.findById(request.employeeId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Employee not found"
                ));

        boolean assigned = assignmentRepository
                .existsByWorkOrder_IdAndEmployee_IdAndAssignmentStatusIn(
                        workOrderId,
                        employee.getId(),
                        List.of("ASSIGNED", "ACCEPTED")
                );

        if (!assigned) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Employee is not assigned to this work order"
            );
        }

        int nextVisitNumber = visitRepository
                .findFirstByWorkOrder_IdOrderByVisitNumberDesc(workOrderId)
                .map(visit -> visit.getVisitNumber() + 1)
                .orElse(1);

        LocalDateTime now = LocalDateTime.now();

        WorkOrderDepartmentVisit visit = new WorkOrderDepartmentVisit();
        visit.setWorkOrder(workOrder);
        visit.setDepartment(workOrder.getDepartment());
        visit.setVisitNumber(nextVisitNumber);
        visit.setVisitStatus("OPEN");
        visit.setArrivedAt(now);
        visit.setArrivedBy(employee);
        visit.setArrivalNotes(request.arrivalNotes());

        visit = visitRepository.save(visit);

        WorkOrderActivity activity = new WorkOrderActivity();
        activity.setWorkOrder(workOrder);
        activity.setDepartmentVisit(visit);
        activity.setActivityType("DEPARTMENT_ARRIVAL");
        activity.setPreviousStatus(workOrder.getWorkOrderStatus());
        activity.setNewStatus(workOrder.getWorkOrderStatus());
        activity.setActivityDescription(
                "Vehicle arrived at "
                        + workOrder.getDepartment().getDepartmentName()
                        + ". Visit number: " + nextVisitNumber
        );
        activity.setPerformedBy(employee);

        activityRepository.save(activity);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("visitId", visit.getId());
        response.put("workOrderId", workOrderId);
        response.put("workOrderNumber", workOrder.getWorkOrderNumber());
        response.put("departmentId", departmentId);
        response.put("department", workOrder.getDepartment().getDepartmentName());
        response.put("visitNumber", nextVisitNumber);
        response.put("visitStatus", "OPEN");
        response.put("arrivedAt", now);
        response.put("arrivedBy", employee.getId());
        response.put("arrivalNotes", request.arrivalNotes());

        return response;
    }

    @Transactional
    public Map<String, Object> recordSendOff(
            Long workOrderId,
            Long departmentId,
            Long visitId,
            DepartmentSendOffRequest request
    ) {

        ActorIdentity.requireEmployee(request == null ? null : request.employeeId());

        WorkOrderDepartmentVisit visit = visitRepository
                .findById(visitId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Department visit not found"
                ));

        WorkOrder workOrder = visit.getWorkOrder();
        ActorIdentity.requireCompanyWorkshop(
                workOrder.getJob().getCompany().getId(),
                workOrder.getJob().getWorkshop().getId());

        if (!workOrder.getId().equals(workOrderId)
                || !visit.getDepartment().getId().equals(departmentId)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Department visit does not belong to this work order and department"
            );
        }

        if (!"OPEN".equals(visit.getVisitStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "This department visit has already been sent off"
            );
        }

        if (!"COMPLETED".equals(workOrder.getWorkOrderStatus())) {
                throw new ResponseStatusException(
                        HttpStatus.CONFLICT,
                        "Work must be confirmed as completed before department send-off."
                );
        }

        Employee employee = employeeRepository.findById(request.employeeId())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Employee not found"
                ));

        boolean assigned = assignmentRepository
                .existsByWorkOrder_IdAndEmployee_IdAndAssignmentStatusIn(
                        workOrderId,
                        employee.getId(),
                        List.of("ASSIGNED", "ACCEPTED", "COMPLETED")
                );

        if (!assigned) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Employee is not assigned to this work order"
            );
        }

        LocalDateTime now = LocalDateTime.now();

        visit.setVisitStatus("SENT_OFF");
        visit.setSentOffAt(now);
        visit.setSentOffBy(employee);
        visit.setSendOffNotes(request.sendOffNotes());

        visitRepository.save(visit);

        WorkOrderActivity activity = new WorkOrderActivity();
        activity.setWorkOrder(workOrder);
        activity.setDepartmentVisit(visit);
        activity.setActivityType("DEPARTMENT_SEND_OFF");
        activity.setPreviousStatus(workOrder.getWorkOrderStatus());
        activity.setNewStatus(workOrder.getWorkOrderStatus());
        activity.setActivityDescription(
                "Vehicle sent off from "
                        + visit.getDepartment().getDepartmentName()
                        + ". " + request.sendOffNotes()
        );
        activity.setPerformedBy(employee);

        activityRepository.save(activity);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("visitId", visit.getId());
        response.put("workOrderId", workOrderId);
        response.put("departmentId", departmentId);
        response.put("visitStatus", visit.getVisitStatus());
        response.put("sentOffAt", now);
        response.put("sentOffBy", employee.getId());
        response.put("sendOffNotes", visit.getSendOffNotes());
        response.put("workOrderStatus", workOrder.getWorkOrderStatus());

        return response;
    }

}
