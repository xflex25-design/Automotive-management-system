package com.autogarage.automotive.dto;

public record LinkJobCardPartResponse(
        Long jobCardId,
        Long jobCardPartId,
        Long partId,
        String partCode,
        String partName,
        String linkedBy,
        java.time.LocalDateTime linkedAt
) {}
