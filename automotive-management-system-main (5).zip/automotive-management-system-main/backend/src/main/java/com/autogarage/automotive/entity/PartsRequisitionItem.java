package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "parts_requisition_items")
@Getter
@Setter
@NoArgsConstructor
public class PartsRequisitionItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requisition_id", nullable = false)
    private PartsRequisition requisition;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "part_id", nullable = false)
    private Part part;

    @Column(name = "work_order_id")
    private Long workOrderId;

    @Column(name = "requested_quantity", nullable = false, precision = 12, scale = 2)
    private BigDecimal requestedQuantity;

    @Column(name = "approved_quantity", precision = 12, scale = 2)
    private BigDecimal approvedQuantity;

    @Column(name = "fulfilled_quantity", precision = 12, scale = 2)
    private BigDecimal fulfilledQuantity = BigDecimal.ZERO;

    @Column(name = "unit_of_measure", length = 50)
    private String unitOfMeasure;

    @Column(name = "reason_for_request", columnDefinition = "TEXT")
    private String reasonForRequest;

    @Column(name = "item_status", columnDefinition = "ENUM('PENDING','APPROVED','PARTIALLY_FULFILLED','FULFILLED','REJECTED','CANCELLED')")
    private String itemStatus = "PENDING";

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}
