package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "quotation_approvals")
@Getter
@Setter
@NoArgsConstructor
public class QuotationApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quotation_id", nullable = false)
    private Quotation quotation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "verified_by_employee_id")
    private Employee verifiedBy;

    @Column(name = "approval_status", nullable = false, length = 30)
    private String approvalStatus = "PENDING";

    @Column(name = "customer_name_snapshot", nullable = false, length = 200)
    private String customerNameSnapshot;

    @Column(name = "customer_phone_snapshot", length = 30)
    private String customerPhoneSnapshot;

    @Column(name = "approval_method", nullable = false, length = 40)
    private String approvalMethod = "IN_PERSON";

    @Column(name = "approval_token_hash")
    private String approvalTokenHash;

    @Column(name = "customer_comments", columnDefinition = "TEXT")
    private String customerComments;

    @Column(name = "signature_media_id")
    private Long signatureMediaId;

    @Column(name = "verified_at")
    private LocalDateTime verifiedAt;

    @Column(name = "verification_notes", columnDefinition = "TEXT")
    private String verificationNotes;

    @Column(name = "notification_status", nullable = false, length = 30)
    private String notificationStatus = "NOT_SENT";

    @Column(name = "notification_channel", length = 30)
    private String notificationChannel;

    @Column(name = "notification_sent_at")
    private LocalDateTime notificationSentAt;

    @Column(name = "approval_token_expires_at")
    private LocalDateTime approvalTokenExpiresAt;

    @Column(name = "approved_at")
    private LocalDateTime approvedAt;

    @Column(name = "decision_submitted_at")
    private LocalDateTime decisionSubmittedAt;

    @Column(name = "rejected_at")
    private LocalDateTime rejectedAt;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}