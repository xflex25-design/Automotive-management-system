package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record InventoryAccessoryRequest(

        @NotBlank
        @Size(max = 120)
        String accessoryName,

        Boolean present,

        @Size(max = 255)
        String conditionDescription,

        String remarks

) {}