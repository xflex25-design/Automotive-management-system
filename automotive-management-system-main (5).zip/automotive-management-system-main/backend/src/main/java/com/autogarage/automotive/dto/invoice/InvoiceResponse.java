package com.autogarage.automotive.dto.invoice;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public record InvoiceResponse(
        Long id,
        String invoiceNumber,
        Long jobId,
        String jobNumber,
        Long quotationId,
        Long finalInspectionId,
        String customerName,
        String customerPhone,
        String customerAddress,
        String vehicleRegistration,
        String vehicleMake,
        String currencyCode,
        String invoiceStatus,
        LocalDate invoiceDate,
        LocalDate dueDate,
        BigDecimal subtotal,
        BigDecimal discountAmount,
        BigDecimal taxAmount,
        BigDecimal totalAmount,
        BigDecimal amountPaid,
        BigDecimal balanceDue,
        String notes,
        Long issuedByEmployeeId,
        List<InvoiceItemResponse> items,
        List<PaymentResponse> payments,
        LocalDateTime createdAt
) {}