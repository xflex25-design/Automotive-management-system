package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record ReceiveDispatchRequest(
        @NotNull Long receivedByEmployeeId,
        @NotBlank String signerName,
        Long signatureMediaId,
        String remarks
) {}