package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.invoice.RecordPaymentRequest;
import com.autogarage.automotive.dto.invoice.PaymentResponse;
import com.autogarage.automotive.entity.Employee;
import com.autogarage.automotive.entity.Invoice;
import com.autogarage.automotive.entity.Payment;
import com.autogarage.automotive.repository.EmployeeRepository;
import com.autogarage.automotive.repository.InvoiceRepository;
import com.autogarage.automotive.repository.PaymentRepository;
import com.autogarage.automotive.security.ActorIdentity;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final InvoiceRepository invoiceRepository;
    private final EmployeeRepository employeeRepository;

    @Transactional
    public PaymentResponse recordPayment(Long invoiceId, RecordPaymentRequest request) {

        if (invoiceId == null || request == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Invoice ID and payment details are required."
            );
        }

        if (request.receivedByEmployeeId() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Receiving employee is required."
            );
        }
        ActorIdentity.requireEmployee(request.receivedByEmployeeId());

        if (request.paymentMethod() == null ||
                request.paymentMethod().isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Payment method is required."
            );
        }

        BigDecimal amount = request.amount();

        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Payment amount must be greater than zero."
            );
        }

        String paymentMethod = request.paymentMethod()
                .trim()
                .toUpperCase();

        if (!isValidPaymentMethod(paymentMethod)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Invalid payment method."
            );
        }

        Invoice invoice = invoiceRepository.findByIdForUpdate(invoiceId)
            .orElseThrow(() -> new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Invoice not found."
            ));
        ActorIdentity.requireCompanyWorkshop(
                invoice.getCompany().getId(), invoice.getWorkshop().getId());

        Employee employee = employeeRepository
                .findByIdAndCompanyId(
                        request.receivedByEmployeeId(),
                        invoice.getCompany().getId()
                )
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Employee not found in this company."
                ));

        if (!"ACTIVE".equalsIgnoreCase(employee.getEmploymentStatus())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Only active employees can receive payments."
            );
        }

        if (!employee.getWorkshop().getId()
                .equals(invoice.getWorkshop().getId())) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN,
                    "Employee does not belong to this invoice's workshop."
            );
        }

        String invoiceStatus = invoice.getInvoiceStatus();

        if ("CANCELLED".equalsIgnoreCase(invoiceStatus)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Payments cannot be recorded against a cancelled invoice."
            );
        }

        if ("DRAFT".equalsIgnoreCase(invoiceStatus)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The invoice must be issued before payments can be recorded."
            );
        }

        if ("PAID".equalsIgnoreCase(invoiceStatus)) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "This invoice is already fully paid."
            );
        }

        BigDecimal totalAmount = invoice.getTotalAmount() == null
                ? BigDecimal.ZERO
                : invoice.getTotalAmount();

        BigDecimal amountPaid = invoice.getAmountPaid() == null
                ? BigDecimal.ZERO
                : invoice.getAmountPaid();

        BigDecimal balanceDue = totalAmount.subtract(amountPaid)
                .setScale(2, RoundingMode.HALF_UP);

        if (balanceDue.compareTo(BigDecimal.ZERO) <= 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "This invoice has no outstanding balance."
            );
        }

        amount = amount.setScale(2, RoundingMode.HALF_UP);

        if (amount.compareTo(balanceDue) > 0) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Payment exceeds the outstanding balance of "
                            + balanceDue + " " + invoice.getCurrencyCode() + "."
            );
        }

        Payment payment = new Payment();
        payment.setInvoice(invoice);
        payment.setReceivedBy(employee);
        payment.setPaymentReference(generatePaymentReference(invoice));
        payment.setPaymentMethod(paymentMethod);
        payment.setPaymentStatus("COMPLETED");
        payment.setAmount(amount);
        payment.setCurrencyCode(invoice.getCurrencyCode());
        payment.setTransactionReference(
                request.transactionReference() == null
                        ? null
                        : request.transactionReference().trim()
        );
        payment.setPaymentDate(
                request.paymentDate() == null
                        ? LocalDateTime.now()
                        : request.paymentDate()
        );
        payment.setNotes(request.notes());

        paymentRepository.save(payment);

        BigDecimal updatedAmountPaid = amountPaid.add(amount)
                .setScale(2, RoundingMode.HALF_UP);

        BigDecimal updatedBalance = totalAmount.subtract(updatedAmountPaid)
                .setScale(2, RoundingMode.HALF_UP);

        invoice.setAmountPaid(updatedAmountPaid);
        invoice.setBalanceDue(updatedBalance);

        if (updatedBalance.compareTo(BigDecimal.ZERO) == 0) {
            invoice.setInvoiceStatus("PAID");
        } else {
            invoice.setInvoiceStatus("PARTIALLY_PAID");
        }

        invoiceRepository.save(invoice);

        return new PaymentResponse(
                payment.getId(),
                payment.getPaymentReference(),
                payment.getPaymentMethod(),
                payment.getPaymentStatus(),
                payment.getAmount(),
                payment.getCurrencyCode(),
                payment.getTransactionReference(),
                payment.getPaymentDate(),
                employee.getId(),
                employee.getFirstName() + " " + employee.getLastName(),
                payment.getNotes()
        );
    }

    private boolean isValidPaymentMethod(String paymentMethod) {
        return switch (paymentMethod) {
            case "CASH",
                    "BANK_TRANSFER",
                    "MOBILE_MONEY",
                    "CARD",
                    "CHEQUE",
                    "OTHER" -> true;
            default -> false;
        };
    }

    private String generatePaymentReference(Invoice invoice) {
        return "PAY-" + invoice.getInvoiceNumber()
                + "-" + UUID.randomUUID()
                .toString()
                .substring(0, 8)
                .toUpperCase();
    }
}
