package com.autogarage.automotive.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record CorrectDispatchOrderRequest(

        @NotNull
        Long assignedMechanicEmployeeId,

        Long departmentId,

        String remarks,

        @Valid
        @NotEmpty
        List<CreateDispatchOrderRequest.DispatchItemRequest> items

) {
}