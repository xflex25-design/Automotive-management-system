package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(
    name = "workshop_monitoring_settings",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_monitoring_workshop",
            columnNames = "workshop_id"
        )
    }
)
public class WorkshopMonitoringSetting {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "workshop_id", nullable = false)
    private Workshop workshop;

    @Column(name = "working_days", nullable = false, length = 30)
    private String workingDays = "MON,TUE,WED,THU,FRI";

    @Column(name = "opening_time", nullable = false)
    private LocalTime openingTime = LocalTime.of(8, 0);

    @Column(name = "closing_time", nullable = false)
    private LocalTime closingTime = LocalTime.of(17, 0);

    @Column(name = "stagnation_threshold_minutes", nullable = false)
    private Integer stagnationThresholdMinutes = 120;

    @Column(name = "waiting_reminder_minutes", nullable = false)
    private Integer waitingReminderMinutes = 60;

    @Column(name = "paused_reminder_minutes", nullable = false)
    private Integer pausedReminderMinutes = 60;

    @Column(name = "reminder_repeat_minutes", nullable = false)
    private Integer reminderRepeatMinutes = 60;

    @Column(name = "is_active", nullable = false)
    private Boolean active = true;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;

    public WorkshopMonitoringSetting() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Workshop getWorkshop() {
        return workshop;
    }

    public void setWorkshop(Workshop workshop) {
        this.workshop = workshop;
    }

    public String getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(String workingDays) {
        this.workingDays = workingDays;
    }

    public LocalTime getOpeningTime() {
        return openingTime;
    }

    public void setOpeningTime(LocalTime openingTime) {
        this.openingTime = openingTime;
    }

    public LocalTime getClosingTime() {
        return closingTime;
    }

    public void setClosingTime(LocalTime closingTime) {
        this.closingTime = closingTime;
    }

    public Integer getStagnationThresholdMinutes() {
        return stagnationThresholdMinutes;
    }

    public void setStagnationThresholdMinutes(Integer stagnationThresholdMinutes) {
        this.stagnationThresholdMinutes = stagnationThresholdMinutes;
    }

    public Integer getWaitingReminderMinutes() {
        return waitingReminderMinutes;
    }

    public void setWaitingReminderMinutes(Integer waitingReminderMinutes) {
        this.waitingReminderMinutes = waitingReminderMinutes;
    }

    public Integer getPausedReminderMinutes() {
        return pausedReminderMinutes;
    }

    public void setPausedReminderMinutes(Integer pausedReminderMinutes) {
        this.pausedReminderMinutes = pausedReminderMinutes;
    }

    public Integer getReminderRepeatMinutes() {
        return reminderRepeatMinutes;
    }

    public void setReminderRepeatMinutes(Integer reminderRepeatMinutes) {
        this.reminderRepeatMinutes = reminderRepeatMinutes;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}