
package com.autogarage.automotive.controller;

import com.autogarage.automotive.entity.MediaFile;
import com.autogarage.automotive.service.MediaFileService;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/media")
public class MediaFileController {

    private final MediaFileService mediaFileService;

    public MediaFileController(MediaFileService mediaFileService) {
        this.mediaFileService = mediaFileService;
    }

    @GetMapping("/jobs/{jobId}")
    public ResponseEntity<List<Map<String, Object>>> getJobMedia(
            @PathVariable Long jobId
    ) {
        return ResponseEntity.ok(
                mediaFileService.getJobMedia(jobId)
        );
    }

    @GetMapping("/{mediaFileId}/content")
    public ResponseEntity<Resource> getMediaContent(
            @PathVariable Long mediaFileId
    ) {

        MediaFile media = mediaFileService.getMediaRecord(mediaFileId);
        Resource resource = mediaFileService.getMediaContent(mediaFileId);

        MediaType mediaType;

        try {
            mediaType = MediaType.parseMediaType(media.getMimeType());
        } catch (IllegalArgumentException exception) {
            mediaType = MediaType.APPLICATION_OCTET_STREAM;
        }

        ContentDisposition disposition = ContentDisposition.inline()
                .filename(media.getFileName(), StandardCharsets.UTF_8)
                .build();

        return ResponseEntity.ok()
                .contentType(mediaType)
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        disposition.toString()
                )
                .body(resource);
    }
}
