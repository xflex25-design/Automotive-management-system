package com.autogarage.automotive.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record StockReservationResponse(
        Long reservationId,
        Long jobCardPartId,
        Long partId,
        String partCode,
        String partName,
        Long stockBalanceId,
        Long stockLocationId,
        String stockLocationName,
        BigDecimal quantityReserved,
        String reservationStatus,
        Long reservedByEmployeeId,
        LocalDateTime reservedAt,
        String notes
) {}