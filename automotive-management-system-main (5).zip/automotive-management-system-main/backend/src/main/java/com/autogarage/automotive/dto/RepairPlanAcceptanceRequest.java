package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RepairPlanAcceptanceRequest {

    @NotNull
    private Long foremanEmployeeId;
}