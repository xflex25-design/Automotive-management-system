package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.PurchaseReceipt;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PurchaseReceiptRepository extends JpaRepository<PurchaseReceipt, Long> {
}
