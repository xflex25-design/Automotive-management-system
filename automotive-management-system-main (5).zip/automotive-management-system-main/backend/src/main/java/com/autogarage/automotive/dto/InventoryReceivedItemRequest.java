package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

public record InventoryReceivedItemRequest(

        @NotBlank
        @Size(max = 150)
        String itemName,

        String description,

        @Min(1)
        Integer quantity,

        @Size(max = 255)
        String conditionDescription

) {}