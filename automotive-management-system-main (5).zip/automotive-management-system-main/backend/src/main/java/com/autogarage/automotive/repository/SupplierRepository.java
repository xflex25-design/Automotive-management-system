package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.List;

public interface SupplierRepository extends JpaRepository<Supplier, Long> {
    Optional<Supplier> findByIdAndCompany_IdAndActiveTrue(Long id, Long companyId);
    List<Supplier> findByCompany_IdAndActiveTrueOrderBySupplierNameAsc(Long companyId);
}
