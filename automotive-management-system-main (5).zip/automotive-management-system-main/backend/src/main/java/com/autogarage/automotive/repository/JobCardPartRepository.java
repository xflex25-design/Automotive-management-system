package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.JobCardPart;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface JobCardPartRepository
        extends JpaRepository<JobCardPart, Long> {

    List<JobCardPart> findByJobCard_IdOrderByIdAsc(Long jobCardId);

    Optional<JobCardPart> findByIdAndJobCard_Id(Long id, Long jobCardId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
        SELECT p
        FROM JobCardPart p
        WHERE p.id = :partId
        AND p.jobCard.id = :jobCardId
    """)
    Optional<JobCardPart> findByIdAndJobCard_IdForUpdate(
            @Param("partId") Long partId,
            @Param("jobCardId") Long jobCardId
    );

    boolean existsBySourceQuotationItem_Id(Long quotationItemId);
}