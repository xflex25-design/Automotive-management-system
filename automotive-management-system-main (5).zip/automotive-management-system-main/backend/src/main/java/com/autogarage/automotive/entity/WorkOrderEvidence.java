
package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(
    name = "work_order_evidence",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_work_order_evidence_media",
            columnNames = {"work_order_id", "media_file_id"}
        )
    }
)
public class WorkOrderEvidence {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "work_order_id", nullable = false)
    private WorkOrder workOrder;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "media_file_id", nullable = false)
    private MediaFile mediaFile;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "evidence_requirement_id")
    private WorkOrderEvidenceRequirement evidenceRequirement;

    @Column(name = "evidence_type", nullable = false)
    private String evidenceType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "uploaded_by_employee_id", nullable = false)
    private Employee uploadedBy;

    @Column(columnDefinition = "TEXT")
    private String caption;

    @Column(name = "captured_at")
    private LocalDateTime capturedAt;

    @Column(name = "uploaded_at", insertable = false, updatable = false)
    private LocalDateTime uploadedAt;

    public WorkOrderEvidence() {}

    public Long getId() { return id; }
    public WorkOrder getWorkOrder() { return workOrder; }
    public void setWorkOrder(WorkOrder workOrder) { this.workOrder = workOrder; }
    public MediaFile getMediaFile() { return mediaFile; }
    public void setMediaFile(MediaFile mediaFile) { this.mediaFile = mediaFile; }
    public WorkOrderEvidenceRequirement getEvidenceRequirement() { return evidenceRequirement; }
    public void setEvidenceRequirement(WorkOrderEvidenceRequirement evidenceRequirement) { this.evidenceRequirement = evidenceRequirement; }
    public String getEvidenceType() { return evidenceType; }
    public void setEvidenceType(String evidenceType) { this.evidenceType = evidenceType; }
    public Employee getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(Employee uploadedBy) { this.uploadedBy = uploadedBy; }
    public String getCaption() { return caption; }
    public void setCaption(String caption) { this.caption = caption; }
    public LocalDateTime getCapturedAt() { return capturedAt; }
    public void setCapturedAt(LocalDateTime capturedAt) { this.capturedAt = capturedAt; }
    public LocalDateTime getUploadedAt() { return uploadedAt; }
}
