package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record InventoryAuthorisationRequest(

        @NotBlank
        @Size(max = 60)
        String authorisationType,

        String authorisationText,

        @NotBlank
        @Size(max = 200)
        String authorisedByName,

        @Size(max = 30)
        String authorisedByPhone
) {}