package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.QuotationItemApproval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuotationItemApprovalRepository
        extends JpaRepository<QuotationItemApproval, Long> {

    List<QuotationItemApproval> findByApprovalIdOrderByIdAsc(Long approvalId);

    List<QuotationItemApproval> findByQuotationItemId(Long quotationItemId);

    List<QuotationItemApproval> findByApprovalIdAndItemApprovalStatus(
            Long approvalId,
            String itemApprovalStatus
    );
}