package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.company.CompanySettingsRequest;
import com.autogarage.automotive.dto.company.CompanySettingsResponse;
import com.autogarage.automotive.service.CompanySettingsService;

import lombok.RequiredArgsConstructor;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/companies/{companyId}/settings")
@RequiredArgsConstructor
public class CompanySettingsController {

    private final CompanySettingsService companySettingsService;

    @GetMapping
    public CompanySettingsResponse getSettings(
            @PathVariable Long companyId
    ) {
        return companySettingsService.getSettings(companyId);
    }

    @PutMapping
    public CompanySettingsResponse updateSettings(
            @PathVariable Long companyId,
            @RequestBody CompanySettingsRequest request
    ) {
        return companySettingsService.updateSettings(companyId, request);
    }

    @PostMapping(
            value = "/logo",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public CompanySettingsResponse uploadLogo(
            @PathVariable Long companyId,
            @RequestParam("file") MultipartFile file
    ) {
        return companySettingsService.uploadLogo(companyId, file);
    }
}