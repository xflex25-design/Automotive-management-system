package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.FinalInspection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FinalInspectionRepository
        extends JpaRepository<FinalInspection, Long> {

    List<FinalInspection> findByJob_IdOrderByStartedAtDesc(Long jobId);

    List<FinalInspection> findByJob_Company_IdAndJob_Workshop_IdOrderByStartedAtDesc(
            Long companyId, Long workshopId);

    Optional<FinalInspection> findFirstByJob_IdOrderByStartedAtDesc(Long jobId);

    Optional<FinalInspection> findByIdAndJob_Id(Long id, Long jobId);

    Optional<FinalInspection>
    findFirstByJob_IdAndInspectionStatusOrderByStartedAtDesc(
            Long jobId,
            String inspectionStatus
    );

    boolean existsByInspectionNumber(String inspectionNumber);
}
