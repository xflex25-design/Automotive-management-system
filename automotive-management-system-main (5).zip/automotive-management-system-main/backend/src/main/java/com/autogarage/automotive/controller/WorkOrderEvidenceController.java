package com.autogarage.automotive.controller;

import com.autogarage.automotive.service.WorkOrderEvidenceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/work-orders")
public class WorkOrderEvidenceController {

    private final WorkOrderEvidenceService evidenceService;

    public WorkOrderEvidenceController(
            WorkOrderEvidenceService evidenceService
    ) {
        this.evidenceService = evidenceService;
    }

    @PostMapping(
            value = "/{workOrderId}/evidence",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ResponseEntity<Map<String, Object>> uploadEvidence(
            @PathVariable Long workOrderId,
            @RequestParam Long employeeId,
            @RequestParam(required = false) Long requirementId,
            @RequestParam String evidenceType,
            @RequestParam(required = false) String caption,
            @RequestParam("file") MultipartFile file
    ) throws IOException {

        return ResponseEntity.status(HttpStatus.CREATED).body(
                evidenceService.uploadEvidence(
                        workOrderId,
                        employeeId,
                        requirementId,
                        evidenceType,
                        caption,
                        file
                )
        );
    }

    @GetMapping("/{workOrderId}/evidence")
    public ResponseEntity<List<Map<String, Object>>> getEvidence(
            @PathVariable Long workOrderId
    ) {
        return ResponseEntity.ok(
                evidenceService.getEvidence(workOrderId)
        );
    }
}