package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.FinalInspectionSignoff;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FinalInspectionSignoffRepository
        extends JpaRepository<FinalInspectionSignoff, Long> {

    List<FinalInspectionSignoff>
    findByFinalInspection_IdOrderByDepartment_DepartmentNameAsc(
            Long finalInspectionId
    );

    Optional<FinalInspectionSignoff>
    findByFinalInspection_IdAndDepartment_Id(
            Long finalInspectionId,
            Long departmentId
    );

    long countByFinalInspection_IdAndSignoffStatus(
            Long finalInspectionId,
            String signoffStatus
    );
}