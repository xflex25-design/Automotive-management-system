package com.autogarage.automotive.controller;

import com.autogarage.automotive.entity.WorkOrderActivity;
import com.autogarage.automotive.repository.WorkOrderActivityRepository;
import com.autogarage.automotive.repository.WorkOrderRepository;
import com.autogarage.automotive.security.ActorIdentity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/work-orders")
public class WorkOrderActivityController {

    private final WorkOrderActivityRepository activityRepository;
    private final WorkOrderRepository workOrderRepository;

    public WorkOrderActivityController(
            WorkOrderActivityRepository activityRepository,
            WorkOrderRepository workOrderRepository) {
        this.activityRepository = activityRepository;
        this.workOrderRepository = workOrderRepository;
    }

    @GetMapping("/{workOrderId}/activities")
    public List<Map<String, Object>> getActivities(
            @PathVariable Long workOrderId) {

        var workOrder = workOrderRepository.findById(workOrderId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Work order not found."));
        ActorIdentity.requireCompanyWorkshop(
                workOrder.getJob().getCompany().getId(),
                workOrder.getJob().getWorkshop().getId());

        List<WorkOrderActivity> activities =
                activityRepository.findByWorkOrder_IdOrderByCreatedAtAsc(workOrderId);

        return activities.stream().map(activity -> {
            Map<String, Object> result = new LinkedHashMap<>();

            result.put("activityId", activity.getId());
            result.put("workOrderId", activity.getWorkOrder().getId());

            result.put(
                    "visitId",
                    activity.getDepartmentVisit() != null
                            ? activity.getDepartmentVisit().getId()
                            : null
            );

            result.put("activityType", activity.getActivityType());
            result.put("previousStatus", activity.getPreviousStatus());
            result.put("newStatus", activity.getNewStatus());
            result.put("description", activity.getActivityDescription());

            result.put(
                    "performedByEmployeeId",
                    activity.getPerformedBy() != null
                            ? activity.getPerformedBy().getId()
                            : null
            );

            result.put("createdAt", activity.getCreatedAt());

            return result;
        }).toList();
    }
}
