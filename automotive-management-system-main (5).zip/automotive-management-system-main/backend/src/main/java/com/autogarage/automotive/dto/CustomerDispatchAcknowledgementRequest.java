package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;

public record CustomerDispatchAcknowledgementRequest(
        @NotBlank String signerName,
        String contactNumber,
        Long signatureMediaId,
        String remarks
) {}