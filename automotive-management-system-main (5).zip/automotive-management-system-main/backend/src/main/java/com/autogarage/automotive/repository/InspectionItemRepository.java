package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.InspectionItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface InspectionItemRepository
        extends JpaRepository<InspectionItem, Long> {

    List<InspectionItem> findByInspectionIdOrderByIdAsc(Long inspectionId);

    List<InspectionItem> findByInspectionIdAndRequiresAttention(
            Long inspectionId,
            Boolean requiresAttention
    );
}