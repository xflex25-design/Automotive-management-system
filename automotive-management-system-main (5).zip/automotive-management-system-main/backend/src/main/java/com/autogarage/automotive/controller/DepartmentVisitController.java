package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.DepartmentArrivalRequest;
import com.autogarage.automotive.dto.DepartmentSendOffRequest;
import com.autogarage.automotive.entity.WorkOrderDepartmentVisit;
import com.autogarage.automotive.repository.WorkOrderDepartmentVisitRepository;
import com.autogarage.automotive.repository.WorkOrderRepository;
import com.autogarage.automotive.service.DepartmentVisitService;
import com.autogarage.automotive.security.ActorIdentity;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/work-orders")
public class DepartmentVisitController {

    private final DepartmentVisitService departmentVisitService;
    private final WorkOrderDepartmentVisitRepository visitRepository;
    private final WorkOrderRepository workOrderRepository;

    public DepartmentVisitController(
            DepartmentVisitService departmentVisitService,
            WorkOrderDepartmentVisitRepository visitRepository,
            WorkOrderRepository workOrderRepository
    ) {
        this.departmentVisitService = departmentVisitService;
        this.visitRepository = visitRepository;
        this.workOrderRepository = workOrderRepository;
    }

    @PostMapping("/{workOrderId}/departments/{departmentId}/arrivals")
    public ResponseEntity<Map<String, Object>> recordArrival(
            @PathVariable Long workOrderId,
            @PathVariable Long departmentId,
            @Valid @RequestBody DepartmentArrivalRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(departmentVisitService.recordArrival(
                        workOrderId,
                        departmentId,
                        request
                ));
    }

    @PostMapping("/{workOrderId}/departments/{departmentId}/visits/{visitId}/send-off")
    public ResponseEntity<Map<String, Object>> recordSendOff(
            @PathVariable Long workOrderId,
            @PathVariable Long departmentId,
            @PathVariable Long visitId,
            @Valid @RequestBody DepartmentSendOffRequest request
    ) {
        return ResponseEntity.ok(
                departmentVisitService.recordSendOff(
                        workOrderId,
                        departmentId,
                        visitId,
                        request
                )
        );
    }

    @Transactional(readOnly = true)
    @GetMapping("/{workOrderId}/departments/{departmentId}/visits")
    public ResponseEntity<List<Map<String, Object>>> getDepartmentVisits(
            @PathVariable Long workOrderId,
            @PathVariable Long departmentId
    ) {
        var workOrder = workOrderRepository.findById(workOrderId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Work order not found."
                ));

        if (!workOrder.getDepartment().getId().equals(departmentId)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Department does not belong to this work order."
            );
        }
        ActorIdentity.requireCompanyWorkshop(
                workOrder.getJob().getCompany().getId(),
                workOrder.getJob().getWorkshop().getId());

        List<WorkOrderDepartmentVisit> visits =
                visitRepository.findByWorkOrder_IdOrderByVisitNumberAsc(workOrderId);

        List<Map<String, Object>> result = visits.stream().map(visit -> {
            Map<String, Object> item = new LinkedHashMap<>();

            item.put("visitId", visit.getId());
            item.put("workOrderId", visit.getWorkOrder().getId());
            item.put("departmentId", visit.getDepartment().getId());
            item.put("departmentName", visit.getDepartment().getDepartmentName());
            item.put("visitNumber", visit.getVisitNumber());
            item.put("visitStatus", visit.getVisitStatus());
            item.put("arrivedAt", visit.getArrivedAt());
            item.put("arrivedByEmployeeId",
                    visit.getArrivedBy() != null
                            ? visit.getArrivedBy().getId() : null);
            item.put("arrivalNotes", visit.getArrivalNotes());
            item.put("sentOffAt", visit.getSentOffAt());
            item.put("sentOffByEmployeeId",
                    visit.getSentOffBy() != null
                            ? visit.getSentOffBy().getId() : null);
            item.put("sendOffNotes", visit.getSendOffNotes());

            return item;
        }).toList();

        return ResponseEntity.ok(result);
    }
}
