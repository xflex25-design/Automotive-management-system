package com.autogarage.automotive.dto;

import jakarta.validation.constraints.NotBlank;

public record CustomerQuotationAccessRequest(
        @NotBlank(message = "Approval token is required")
        String token
) {}