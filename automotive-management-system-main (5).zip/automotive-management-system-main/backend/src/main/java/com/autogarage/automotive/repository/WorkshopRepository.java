package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Workshop;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkshopRepository extends JpaRepository<Workshop, Long> {

    List<Workshop> findByCompanyIdAndActiveTrue(Long companyId);
}