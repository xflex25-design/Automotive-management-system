package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.invoice.InvoiceEmailResponse;
import com.autogarage.automotive.entity.Invoice;
import com.autogarage.automotive.repository.InvoiceRepository;
import com.autogarage.automotive.security.ActorIdentity;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.core.io.ByteArrayResource;

import java.math.BigDecimal;
import java.util.Locale;

@Service
@RequiredArgsConstructor
public class InvoiceEmailService {

    private final InvoiceRepository invoiceRepository;
    private final InvoicePdfService invoicePdfService;
    private final JavaMailSender mailSender;

    @Value("${app.mail.from:}")
    private String senderEmail;

    @Transactional(readOnly = true)
    public InvoiceEmailResponse sendInvoice(Long invoiceId) {

        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Invoice not found."
                ));
        ActorIdentity.requireCompanyWorkshop(
                invoice.getCompany().getId(), invoice.getWorkshop().getId());

        String recipient = invoice.getCustomerEmailSnapshot();

        if (recipient == null || recipient.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "This invoice has no customer email address."
            );
        }

        if (!recipient.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "The customer's email address is invalid."
            );
        }

        if (senderEmail == null || senderEmail.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.SERVICE_UNAVAILABLE,
                    "Email sender address has not been configured."
            );
        }

        byte[] pdf = invoicePdfService.generateInvoicePdf(invoiceId);

        try {
            MimeMessage message = mailSender.createMimeMessage();

            MimeMessageHelper helper = new MimeMessageHelper(
                    message,
                    true,
                    "UTF-8"
            );

            helper.setFrom(senderEmail);
            helper.setTo(recipient);
            helper.setSubject(
                    "Invoice " + invoice.getInvoiceNumber()
                            + " - " + invoice.getCompany().getCompanyName()
            );

            String companyName = escapeHtml(
                    invoice.getCompany().getCompanyName()
            );

            String customerName = escapeHtml(
                    invoice.getCustomerNameSnapshot()
            );

            String invoiceNumber = escapeHtml(
                    invoice.getInvoiceNumber()
            );

            String currency = escapeHtml(invoice.getCurrencyCode());

            String total = formatAmount(invoice.getTotalAmount());
            String balance = formatAmount(invoice.getBalanceDue());

            String html = """
                    <html>
                    <body style="font-family:Arial,sans-serif;color:#333;">
                        <h2>%s</h2>
                        <p>Dear %s,</p>
                        <p>Please find attached your invoice.</p>
                        <table style="border-collapse:collapse;width:100%%;">
                            <tr>
                                <td style="padding:8px;border:1px solid #ddd;">
                                    Invoice Number
                                </td>
                                <td style="padding:8px;border:1px solid #ddd;">
                                    %s
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:8px;border:1px solid #ddd;">
                                    Invoice Total
                                </td>
                                <td style="padding:8px;border:1px solid #ddd;">
                                    %s %s
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:8px;border:1px solid #ddd;">
                                    Outstanding Balance
                                </td>
                                <td style="padding:8px;border:1px solid #ddd;">
                                    %s %s
                                </td>
                            </tr>
                        </table>
                        <p>Thank you for choosing us.</p>
                        <p>%s</p>
                    </body>
                    </html>
                    """.formatted(
                    companyName,
                    customerName,
                    invoiceNumber,
                    currency,
                    total,
                    currency,
                    balance,
                    companyName
            );

            helper.setText(html, true);

            helper.addAttachment(
                    "Invoice-" + invoice.getInvoiceNumber() + ".pdf",
                    new ByteArrayResource(pdf),
                    "application/pdf"
            );

            mailSender.send(message);

            return new InvoiceEmailResponse(
                    invoice.getId(),
                    invoice.getInvoiceNumber(),
                    recipient,
                    "SENT",
                    "Invoice email was accepted by the configured mail server."
            );

        } catch (MessagingException | MailException exception) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Unable to send invoice email. Check the email configuration."
            );
        }
    }

    private String formatAmount(BigDecimal amount) {
        BigDecimal value = amount == null
                ? BigDecimal.ZERO
                : amount;

        return String.format(Locale.US, "%,.2f", value);
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
