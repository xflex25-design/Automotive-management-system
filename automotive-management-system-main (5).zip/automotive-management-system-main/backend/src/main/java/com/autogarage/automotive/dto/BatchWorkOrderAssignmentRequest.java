
package com.autogarage.automotive.dto;

import java.util.List;

public class BatchWorkOrderAssignmentRequest {

    private Long assignedByEmployeeId;

    private List<WorkOrderAssignmentGroup> workOrders;

    public Long getAssignedByEmployeeId() {
        return assignedByEmployeeId;
    }

    public void setAssignedByEmployeeId(Long assignedByEmployeeId) {
        this.assignedByEmployeeId = assignedByEmployeeId;
    }

    public List<WorkOrderAssignmentGroup> getWorkOrders() {
        return workOrders;
    }

    public void setWorkOrders(List<WorkOrderAssignmentGroup> workOrders) {
        this.workOrders = workOrders;
    }

    public static class WorkOrderAssignmentGroup {

        private Long workOrderId;

        private List<EmployeeAssignment> assignments;

        public Long getWorkOrderId() {
            return workOrderId;
        }

        public void setWorkOrderId(Long workOrderId) {
            this.workOrderId = workOrderId;
        }

        public List<EmployeeAssignment> getAssignments() {
            return assignments;
        }

        public void setAssignments(List<EmployeeAssignment> assignments) {
            this.assignments = assignments;
        }
    }

    public static class EmployeeAssignment {

        private Long employeeId;

        private String assignmentRole;

        private String remarks;

        public Long getEmployeeId() {
            return employeeId;
        }

        public void setEmployeeId(Long employeeId) {
            this.employeeId = employeeId;
        }

        public String getAssignmentRole() {
            return assignmentRole;
        }

        public void setAssignmentRole(String assignmentRole) {
            this.assignmentRole = assignmentRole;
        }

        public String getRemarks() {
            return remarks;
        }

        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }
    }
}
