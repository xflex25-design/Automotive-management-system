package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.QuotationApproval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;
import java.util.List;
import java.util.Optional;

@Repository
public interface QuotationApprovalRepository
        extends JpaRepository<QuotationApproval, Long> {

    List<QuotationApproval> findByQuotationIdOrderByCreatedAtDesc(
            Long quotationId
    );

    List<QuotationApproval> findByApprovalStatusOrderByCreatedAtDesc(
            String approvalStatus
    );

    Optional<QuotationApproval> findFirstByQuotationIdAndApprovalStatusOrderByCreatedAtDesc(
            Long quotationId,
            String approvalStatus
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT a FROM QuotationApproval a WHERE a.id = :approvalId")
    Optional<QuotationApproval> findByIdForUpdate(
            @Param("approvalId") Long approvalId
    );

    Optional<QuotationApproval> findByApprovalTokenHash(
            String approvalTokenHash
    );

    Optional<QuotationApproval> findFirstByQuotationIdOrderByCreatedAtDesc(
                Long quotationId
        );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
        @Query("""
        SELECT a FROM QuotationApproval a
        WHERE a.approvalTokenHash = :tokenHash
        """)
        Optional<QuotationApproval> findByApprovalTokenHashForUpdate(
                @Param("tokenHash") String tokenHash
        );
}