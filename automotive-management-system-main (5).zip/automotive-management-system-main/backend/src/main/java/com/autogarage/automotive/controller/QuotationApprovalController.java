package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.QuotationApprovalResponse;
import com.autogarage.automotive.dto.VerifyQuotationRequest;
import com.autogarage.automotive.service.QuotationApprovalService;
import com.autogarage.automotive.dto.CustomerQuotationAccessRequest;
import com.autogarage.automotive.dto.CustomerQuotationApprovalView;
import com.autogarage.automotive.dto.SubmitCustomerApprovalRequest;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class QuotationApprovalController {

    private final QuotationApprovalService approvalService;

    public QuotationApprovalController(
            QuotationApprovalService approvalService
    ) {
        this.approvalService = approvalService;
    }

    // 1. Foreman verifies quotation and initiates customer approval.
    @PostMapping(
            "/quotations/{quotationId}/verify-and-request-approval"
    )
    public ResponseEntity<QuotationApprovalResponse> verifyQuotation(
            @PathVariable Long quotationId,
            @Valid @RequestBody VerifyQuotationRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                approvalService.verifyQuotation(quotationId, request)
        );
    }

    // 2. Retrieve all approval requests for a quotation.
    @GetMapping("/quotations/{quotationId}/approvals")
    public ResponseEntity<List<QuotationApprovalResponse>> getQuotationApprovals(
            @PathVariable Long quotationId
    ) {
        return ResponseEntity.ok(
                approvalService.getQuotationApprovals(quotationId)
        );
    }

    // 3. Retrieve one approval request.
    @GetMapping("/quotation-approvals/{approvalId}")
    public ResponseEntity<QuotationApprovalResponse> getApprovalDetails(
            @PathVariable Long approvalId
    ) {
        return ResponseEntity.ok(
                approvalService.getApprovalDetails(approvalId)
        );
    }

    @PostMapping("/customer/quotation-approvals/view")
        public ResponseEntity<CustomerQuotationApprovalView> viewCustomerQuotation(
                @Valid @RequestBody CustomerQuotationAccessRequest request
        ) {
        return ResponseEntity.ok(
                approvalService.getCustomerQuotation(request.token())
        );
        }

    @PostMapping("/customer/quotation-approvals/submit")
        public ResponseEntity<QuotationApprovalResponse> submitCustomerApproval(
                @Valid @RequestBody SubmitCustomerApprovalRequest request
        ) {
        return ResponseEntity.ok(
                approvalService.submitCustomerApproval(request)
        );
        }
}