package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.finalinspection.StartFinalInspectionRequest;
import com.autogarage.automotive.dto.finalinspection.UpdateFinalInspectionItemRequest;
import com.autogarage.automotive.dto.finalinspection.DepartmentSignoffRequest;
import com.autogarage.automotive.dto.finalinspection.GenerateCorrectiveWorkOrdersRequest;

import com.autogarage.automotive.service.FinalInspectionService;
import com.autogarage.automotive.service.FinalInspectionApprovalService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/final-inspections")
public class FinalInspectionController {

    private final FinalInspectionService finalInspectionService;
    private final FinalInspectionApprovalService approvalService;

    public FinalInspectionController(
            FinalInspectionService finalInspectionService,
            FinalInspectionApprovalService approvalService
    ) {
        this.finalInspectionService = finalInspectionService;
        this.approvalService = approvalService;
    }

    @PostMapping("/jobs/{jobId}")
    public ResponseEntity<Map<String, Object>> startInspection(
            @PathVariable Long jobId,
            @RequestBody StartFinalInspectionRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                finalInspectionService.startInspection(jobId, request)
        );
    }

    @GetMapping("/{inspectionId}")
    public ResponseEntity<Map<String, Object>> getInspection(
            @PathVariable Long inspectionId
    ) {
        return ResponseEntity.ok(
                finalInspectionService.getInspection(inspectionId)
        );
    }

    @PatchMapping("/{inspectionId}/items/{itemId}")
    public ResponseEntity<Map<String, Object>> updateChecklistItem(
            @PathVariable Long inspectionId,
            @PathVariable Long itemId,
            @RequestBody UpdateFinalInspectionItemRequest request
    ) {
        return ResponseEntity.ok(
                finalInspectionService.updateChecklistItem(
                        inspectionId,
                        itemId,
                        request
                )
        );
    }

    @GetMapping("/{inspectionId}/signoffs")
    public ResponseEntity<Map<String, Object>> getSignoffs(
            @PathVariable Long inspectionId
    ) {
        return ResponseEntity.ok(
                approvalService.getSignoffs(inspectionId)
        );
    }

    @PostMapping("/{inspectionId}/departments/{departmentId}/signoff")
    public ResponseEntity<Map<String, Object>> submitDepartmentSignoff(
            @PathVariable Long inspectionId,
            @PathVariable Long departmentId,
            @RequestBody DepartmentSignoffRequest request
    ) {
        return ResponseEntity.ok(
                approvalService.submitDepartmentSignoff(
                        inspectionId,
                        departmentId,
                        request
                )
        );
    }

    @PostMapping("/{inspectionId}/corrective-work-orders")
        public ResponseEntity<Map<String, Object>> generateCorrectiveWorkOrders(
                @PathVariable Long inspectionId,
                @RequestBody GenerateCorrectiveWorkOrdersRequest request
        ) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                finalInspectionService.generateCorrectiveWorkOrders(
                        inspectionId,
                        request
                )
        );
        }

    @PostMapping("/{inspectionId}/complete")
    public ResponseEntity<Map<String, Object>> completeInspection(
            @PathVariable Long inspectionId
    ) {
        return ResponseEntity.ok(
                approvalService.completeInspection(inspectionId)
        );
    }
}