package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;

import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {

    List<Invoice> findByJob_IdOrderByInvoiceDateDesc(Long jobId);

    Optional<Invoice> findByIdAndWorkshop_Id(Long id, Long workshopId);

    Optional<Invoice> findByWorkshop_IdAndInvoiceNumber(
            Long workshopId,
            String invoiceNumber
    );

    boolean existsByWorkshop_IdAndInvoiceNumber(
            Long workshopId,
            String invoiceNumber
    );

    List<Invoice> findByInvoiceStatusOrderByInvoiceDateDesc(
            String invoiceStatus
    );

    Optional<Invoice> findByQuotation_Id(Long quotationId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
        @Query("SELECT i FROM Invoice i WHERE i.id = :invoiceId")
        Optional<Invoice> findByIdForUpdate(@Param("invoiceId") Long invoiceId);
}