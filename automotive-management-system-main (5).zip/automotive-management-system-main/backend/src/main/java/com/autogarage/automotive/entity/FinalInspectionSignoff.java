package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(
    name = "final_inspection_signoffs",
    uniqueConstraints = {
        @UniqueConstraint(
            name = "uk_final_signoff_department",
            columnNames = {"final_inspection_id", "department_id"}
        )
    }
)
@Getter
@Setter
@NoArgsConstructor
public class FinalInspectionSignoff {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "final_inspection_id", nullable = false)
    private FinalInspection finalInspection;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id", nullable = false)
    private Department department;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "signed_by_employee_id")
    private Employee signedBy;

    @Column(name = "signoff_status", nullable = false, length = 30)
    private String signoffStatus = "PENDING";

    @Column(name = "signoff_notes", columnDefinition = "TEXT")
    private String signoffNotes;

    @Column(name = "signed_at")
    private LocalDateTime signedAt;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}