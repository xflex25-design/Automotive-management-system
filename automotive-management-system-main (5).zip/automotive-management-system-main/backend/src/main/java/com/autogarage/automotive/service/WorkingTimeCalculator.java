package com.autogarage.automotive.service;

import com.autogarage.automotive.entity.WorkshopMonitoringSetting;
import org.springframework.stereotype.Component;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class WorkingTimeCalculator {

    public long calculateWorkingMinutes(
            LocalDateTime start,
            LocalDateTime end,
            WorkshopMonitoringSetting settings
    ) {
        if (start == null || end == null || !end.isAfter(start)) {
            return 0;
        }

        Set<String> workingDays = Arrays.stream(
                        settings.getWorkingDays().split(",")
                )
                .map(String::trim)
                .map(String::toUpperCase)
                .collect(Collectors.toSet());

        LocalTime openingTime = settings.getOpeningTime();
        LocalTime closingTime = settings.getClosingTime();

        if (!closingTime.isAfter(openingTime)) {
            throw new IllegalArgumentException(
                    "Workshop closing time must be after opening time."
            );
        }

        long totalMinutes = 0;

        LocalDate currentDate = start.toLocalDate();
        LocalDate lastDate = end.toLocalDate();

        while (!currentDate.isAfter(lastDate)) {

            String dayCode = getDayCode(currentDate.getDayOfWeek());

            if (workingDays.contains(dayCode)) {

                LocalDateTime opening = currentDate.atTime(openingTime);
                LocalDateTime closing = currentDate.atTime(closingTime);

                LocalDateTime effectiveStart =
                        start.isAfter(opening) ? start : opening;

                LocalDateTime effectiveEnd =
                        end.isBefore(closing) ? end : closing;

                if (effectiveEnd.isAfter(effectiveStart)) {
                    totalMinutes += Duration.between(
                            effectiveStart,
                            effectiveEnd
                    ).toMinutes();
                }
            }

            currentDate = currentDate.plusDays(1);
        }

        return totalMinutes;
    }

    private String getDayCode(DayOfWeek day) {
        return switch (day) {
            case MONDAY -> "MON";
            case TUESDAY -> "TUE";
            case WEDNESDAY -> "WED";
            case THURSDAY -> "THU";
            case FRIDAY -> "FRI";
            case SATURDAY -> "SAT";
            case SUNDAY -> "SUN";
        };
    }
}