package com.autogarage.automotive.controller;

import com.autogarage.automotive.entity.WorkshopEscalationRule;
import com.autogarage.automotive.entity.WorkshopMonitoringSetting;
import com.autogarage.automotive.repository.WorkshopEscalationRuleRepository;
import com.autogarage.automotive.repository.WorkshopMonitoringSettingRepository;
import com.autogarage.automotive.repository.WorkshopRepository;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalTime;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/workshops/{workshopId}/monitoring")
public class WorkshopMonitoringController {

    private final WorkshopMonitoringSettingRepository settingsRepository;
    private final WorkshopEscalationRuleRepository escalationRepository;
    private final WorkshopRepository workshopRepository;

    public WorkshopMonitoringController(
            WorkshopMonitoringSettingRepository settingsRepository,
            WorkshopEscalationRuleRepository escalationRepository,
            WorkshopRepository workshopRepository
    ) {
        this.settingsRepository = settingsRepository;
        this.escalationRepository = escalationRepository;
        this.workshopRepository = workshopRepository;
    }

    @GetMapping("/settings")
        @Transactional(readOnly = true)
        public Map<String, Object> getSettings(
                @PathVariable Long workshopId
        ) {
        WorkshopMonitoringSetting setting =
                settingsRepository.findByWorkshop_Id(workshopId)
                        .orElseThrow(() -> new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Monitoring settings not found."
                        ));

        return toSettingsMap(setting);
        }

    @PutMapping("/settings")
    @Transactional
    public Map<String, Object> updateSettings(
            @PathVariable Long workshopId,
            @RequestBody SettingsRequest request
    ) {
        if (!workshopRepository.existsById(workshopId)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Workshop not found."
            );
        }

        if (request.openingTime() == null
                || request.closingTime() == null
                || !request.closingTime().isAfter(request.openingTime())
                || request.workingDays() == null
                || request.workingDays().isBlank()
                || !positive(request.stagnationThresholdMinutes())
                || !positive(request.waitingReminderMinutes())
                || !positive(request.pausedReminderMinutes())
                || !positive(request.reminderRepeatMinutes())) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Provide valid working hours, working days and positive monitoring intervals."
            );
        }

        WorkshopMonitoringSetting setting =
                settingsRepository.findByWorkshop_Id(workshopId)
                        .orElseGet(() -> {
                            WorkshopMonitoringSetting created =
                                    new WorkshopMonitoringSetting();
                            created.setWorkshop(
                                    workshopRepository.getReferenceById(workshopId)
                            );
                            return created;
                        });

        setting.setWorkingDays(request.workingDays().toUpperCase());
        setting.setOpeningTime(request.openingTime());
        setting.setClosingTime(request.closingTime());
        setting.setStagnationThresholdMinutes(
                request.stagnationThresholdMinutes()
        );
        setting.setWaitingReminderMinutes(
                request.waitingReminderMinutes()
        );
        setting.setPausedReminderMinutes(
                request.pausedReminderMinutes()
        );
        setting.setReminderRepeatMinutes(
                request.reminderRepeatMinutes()
        );
        setting.setActive(
                request.active() == null || request.active()
        );

        WorkshopMonitoringSetting saved =
                settingsRepository.save(setting);

        return toSettingsMap(saved);
    }

    @GetMapping("/escalation-rules")
        @Transactional(readOnly = true)
        public List<Map<String, Object>> getEscalationRules(
                @PathVariable Long workshopId
        ) {
        return escalationRepository
                .findByWorkshop_IdAndActiveTrueOrderByElapsedMinutesAsc(workshopId)
                .stream()
                .map(this::toEscalationMap)
                .toList();
        }

    @PostMapping("/escalation-rules")
    @Transactional
    public Map<String, Object> createEscalationRule(
                @PathVariable Long workshopId,
                @RequestBody EscalationRuleRequest request
        ) {
        if (!workshopRepository.existsById(workshopId)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Workshop not found."
            );
        }

        if (request.escalationLevel() == null
                || request.escalationLevel() < 1
                || !positive(request.elapsedMinutes())
                || request.priority() == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Provide a valid escalation level, elapsed minutes and priority."
            );
        }

        if (escalationRepository
                .findByWorkshop_IdAndActiveTrueOrderByElapsedMinutesAsc(workshopId)
                .stream()
                .anyMatch(rule -> rule.getEscalationLevel()
                        .equals(request.escalationLevel()))) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "An active rule already exists for this escalation level."
            );
        }

        WorkshopEscalationRule rule = new WorkshopEscalationRule();
        rule.setWorkshop(workshopRepository.getReferenceById(workshopId));
        rule.setEscalationLevel(request.escalationLevel());
        rule.setElapsedMinutes(request.elapsedMinutes());
        rule.setPriority(request.priority());
        rule.setNotifyManager(
                request.notifyManager() != null && request.notifyManager()
        );
        rule.setActive(true);

        return toEscalationMap(escalationRepository.save(rule));
    }

    private Map<String, Object> toSettingsMap(
                WorkshopMonitoringSetting setting
        ) {
        Map<String, Object> response = new LinkedHashMap<>();

        response.put("id", setting.getId());
        response.put("workshopId", setting.getWorkshop().getId());
        response.put("workingDays", setting.getWorkingDays());
        response.put("openingTime", setting.getOpeningTime());
        response.put("closingTime", setting.getClosingTime());
        response.put("stagnationThresholdMinutes",
                setting.getStagnationThresholdMinutes());
        response.put("waitingReminderMinutes",
                setting.getWaitingReminderMinutes());
        response.put("pausedReminderMinutes",
                setting.getPausedReminderMinutes());
        response.put("reminderRepeatMinutes",
                setting.getReminderRepeatMinutes());
        response.put("active", setting.getActive());
        response.put("createdAt", setting.getCreatedAt());
        response.put("updatedAt", setting.getUpdatedAt());

        return response;
    }

    private Map<String, Object> toEscalationMap(
                WorkshopEscalationRule rule
        ) {
        Map<String, Object> response = new LinkedHashMap<>();

        response.put("id", rule.getId());
        response.put("workshopId", rule.getWorkshop().getId());
        response.put("escalationLevel", rule.getEscalationLevel());
        response.put("elapsedMinutes", rule.getElapsedMinutes());
        response.put("priority", rule.getPriority());
        response.put("notifyManager", rule.getNotifyManager());
        response.put("active", rule.getActive());
        response.put("createdAt", rule.getCreatedAt());

        return response;
    }

    private boolean positive(Integer value) {
        return value != null && value > 0;
    }

    public record SettingsRequest(
            String workingDays,
            LocalTime openingTime,
            LocalTime closingTime,
            Integer stagnationThresholdMinutes,
            Integer waitingReminderMinutes,
            Integer pausedReminderMinutes,
            Integer reminderRepeatMinutes,
            Boolean active
    ) {}

    public record EscalationRuleRequest(
            Integer escalationLevel,
            Integer elapsedMinutes,
            WorkshopEscalationRule.Priority priority,
            Boolean notifyManager
    ) {}
}