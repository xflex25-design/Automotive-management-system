package com.autogarage.automotive.dto;

import java.math.BigDecimal;

public record QuotationItemApprovalResponse(

        Long itemApprovalId,
        Long quotationItemId,

        String itemType,
        String description,

        BigDecimal quantity,
        String unitOfMeasure,
        BigDecimal unitPrice,
        BigDecimal lineTotal,

        String itemApprovalStatus,
        String customerComments

) {}