package com.autogarage.automotive.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;

public record VehicleInspectionRequest(

        @NotNull
        Long inspectedByEmployeeId,

        @Size(max = 50)
        String inspectionType,

        String overallCondition,

        String inspectionNotes,

        @Valid
        List<InspectionItemRequest> inspectionItems,

        @Valid
        List<VehicleDamageRequest> damages,

        @Valid
        List<InventoryAccessoryRequest> accessories,

        @Valid
        List<InventoryReceivedItemRequest> receivedItems

) {}