package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.math.BigDecimal;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {

    List<Payment> findByInvoice_IdOrderByPaymentDateDesc(Long invoiceId);

    Optional<Payment> findByIdAndInvoice_Workshop_Id(
            Long paymentId,
            Long workshopId
    );

    List<Payment> findByPaymentStatusOrderByPaymentDateDesc(
            String paymentStatus
    );

    boolean existsByPaymentReference(String paymentReference);

    @Query("""
        SELECT COALESCE(SUM(p.amount), 0)
        FROM Payment p
        WHERE p.invoice.id = :invoiceId
        AND p.paymentStatus = 'COMPLETED'
        """)
        BigDecimal sumCompletedPaymentsByInvoiceId(
        @Param("invoiceId") Long invoiceId
        );
}