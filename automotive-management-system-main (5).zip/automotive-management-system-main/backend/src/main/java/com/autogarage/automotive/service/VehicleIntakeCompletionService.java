package com.autogarage.automotive.service;

import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class VehicleIntakeCompletionService {

    private final JobRepository jobRepository;
    private final VehicleInventoryCardRepository inventoryCardRepository;
    private final InspectionRecordRepository inspectionRecordRepository;
    private final VehicleDamageRecordRepository damageRecordRepository;
    private final InventoryAccessoryRepository accessoryRepository;
    private final MediaFileRepository mediaFileRepository;
    private final InventoryAuthorisationRepository authorisationRepository;
    private final InventorySignatureRepository signatureRepository;

    public VehicleIntakeCompletionService(
            JobRepository jobRepository,
            VehicleInventoryCardRepository inventoryCardRepository,
            InspectionRecordRepository inspectionRecordRepository,
            VehicleDamageRecordRepository damageRecordRepository,
            InventoryAccessoryRepository accessoryRepository,
            MediaFileRepository mediaFileRepository,
            InventoryAuthorisationRepository authorisationRepository,
            InventorySignatureRepository signatureRepository
    ) {
        this.jobRepository = jobRepository;
        this.inventoryCardRepository = inventoryCardRepository;
        this.inspectionRecordRepository = inspectionRecordRepository;
        this.damageRecordRepository = damageRecordRepository;
        this.accessoryRepository = accessoryRepository;
        this.mediaFileRepository = mediaFileRepository;
        this.authorisationRepository = authorisationRepository;
        this.signatureRepository = signatureRepository;
    }

    @Transactional
    public void completeIntake(Long jobId) {

        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Job not found"
                ));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        VehicleInventoryCard card = inventoryCardRepository
                .findByJobId(jobId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Vehicle inventory card not found"
                ));

        if ("COMPLETED".equalsIgnoreCase(card.getIntakeStatus())) {
            return;
        }

        requireText(card.getDriverName(), "Delivering person's name is required");
        requireText(card.getDriverPhone(), "Delivering person's phone number is required");
        if (card.getOdometerReadingIn() == null) {
            throw badRequest("Mileage at arrival is required");
        }
        requireText(card.getFuelLevelIn(), "Fuel level at arrival is required");
        if (card.getReceivedBy() == null || card.getInspectedBy() == null) {
            throw badRequest("Receiving and inspection staff must be recorded");
        }
        if ((card.getWorkRequested() == null || card.getWorkRequested().isBlank())
                && (card.getCustomerComplaints() == null
                || card.getCustomerComplaints().isBlank())) {
            throw badRequest("Requested work or customer complaints are required");
        }

        Set<String> recordedAccessories = accessoryRepository
                .findByInventoryCardIdOrderByIdAsc(card.getId()).stream()
                .map(InventoryAccessory::getAccessoryName)
                .filter(name -> name != null)
                .map(name -> name.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", ""))
                .collect(Collectors.toSet());
        Set<String> requiredAccessories = Set.of(
                "SPAREWHEEL", "JACK", "JACKHANDLE", "TRIANGLES", "WHEELSPANNER",
                "FIREEXTINGUISHER", "TOOLKIT", "WHEELCOVERS", "CARMATS"
        );
        if (!recordedAccessories.containsAll(requiredAccessories)) {
            throw badRequest("Record all standard inventory accessories before submitting intake");
        }

        // 1. An initial inspection must exist.
        List<InspectionRecord> inspections =
                inspectionRecordRepository
                        .findByJobIdAndInspectionTypeIgnoreCase(
                                jobId, "INITIAL"
                        );

        if (inspections.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "An initial vehicle inspection is required"
            );
        }

        // 2. An arrival overview photograph must exist.
        List<MediaFile> overviewPhotos = mediaFileRepository
                .findByInventoryCard_IdAndEvidenceTypeIgnoreCase(
                        card.getId(), "INTAKE_OVERVIEW"
                );

        if (overviewPhotos.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "An intake overview photograph is required"
            );
        }

        // 3. Every recorded damage must have photographic evidence.
        List<VehicleDamageRecord> damages =
                damageRecordRepository
                        .findByInventoryCard_Id(card.getId());

        for (VehicleDamageRecord damage : damages) {

            List<MediaFile> damagePhotos = mediaFileRepository
                    .findByDamageRecord_Id(damage.getId());

            if (damagePhotos.isEmpty()) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        "Missing photograph for damage: "
                                + damage.getDamageLocation()
                );
            }
        }

        // 4. At least one customer authorisation must exist.
        List<InventoryAuthorisation> authorisations =
                authorisationRepository
                        .findByInventoryCard_Id(card.getId());

        if (authorisations.isEmpty()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Customer authorisation is required"
            );
        }

        // All authorisations must be approved.
        boolean allAuthorised = authorisations.stream()
                .allMatch(auth ->
                        "AUTHORISED".equalsIgnoreCase(
                                auth.getAuthorisationStatus()
                        )
                );

        if (!allAuthorised) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "All customer authorisations must be approved"
            );
        }

        // 5 and 6. Customer and receiving employee must both sign.
        List<InventorySignature> signatures =
                signatureRepository
                        .findByInventoryCard_Id(card.getId());

        boolean customerSigned = signatures.stream()
                .anyMatch(signature ->
                        "CUSTOMER".equalsIgnoreCase(
                                signature.getSignerType()
                        )
                );

        boolean employeeSigned = signatures.stream()
                .anyMatch(signature ->
                        "EMPLOYEE".equalsIgnoreCase(
                                signature.getSignerType()
                        )
                );

        if (!customerSigned) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Customer signature is required"
            );
        }

        if (!employeeSigned) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Receiving employee acknowledgement is required"
            );
        }

        // All checks passed. Complete the intake.
        for (InspectionRecord inspection : inspections) {
            inspection.setInspectionStatus("COMPLETED");
        }

        inspectionRecordRepository.saveAll(inspections);

        card.setIntakeStatus("COMPLETED");
        inventoryCardRepository.save(card);

        job.setJobStatus("INTAKE_COMPLETED");
        jobRepository.save(job);
    }

    private static void requireText(String value, String message) {
        if (value == null || value.isBlank()) {
            throw badRequest(message);
        }
    }

    private static ResponseStatusException badRequest(String message) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, message);
    }
}
