package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {

    Optional<Vehicle> findByCompanyIdAndRegistrationNumberIgnoreCase(
            Long companyId,
            String registrationNumber
    );

    boolean existsByCompanyIdAndRegistrationNumberIgnoreCase(
            Long companyId,
            String registrationNumber
    );
}