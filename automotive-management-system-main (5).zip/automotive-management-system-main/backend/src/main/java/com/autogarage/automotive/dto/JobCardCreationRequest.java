package com.autogarage.automotive.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.NotEmpty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class JobCardCreationRequest {

    @NotNull
    private Long jobId;

    @NotNull
    private Long quotationId;

    @NotNull
    private Long preparedByEmployeeId;

    private String workDescription;
    private String inspectionFindings;
    private String repairInstructions;
    private String foremanRemarks;
    private String planNotes;

    @NotEmpty
    private List<@Valid DepartmentRouteRequest> departmentRoutes;

    @Getter
    @Setter
    public static class DepartmentRouteRequest {
        @NotNull
        private Long departmentId;
        @NotNull
        @NotBlank
        private String applicability;
        private String notApplicableReason;
        private String manualWorkDescription;
        private String manualWorkInstructions;
    }
}
