package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.handover.CreateVehicleHandoverRequest;
import com.autogarage.automotive.dto.handover.VehicleHandoverResponse;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.ActorIdentity;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.Locale;
import java.util.UUID;

@Service
public class VehicleHandoverService {

    private final VehicleHandoverRepository handoverRepository;
    private final JobRepository jobRepository;
    private final InvoiceRepository invoiceRepository;
    private final FinalInspectionRepository finalInspectionRepository;
    private final EmployeeRepository employeeRepository;
    private final PaymentRepository paymentRepository;

    public VehicleHandoverService(
            VehicleHandoverRepository handoverRepository,
            JobRepository jobRepository,
            InvoiceRepository invoiceRepository,
            FinalInspectionRepository finalInspectionRepository,
            EmployeeRepository employeeRepository,
            PaymentRepository paymentRepository
    ) {
        this.handoverRepository = handoverRepository;
        this.jobRepository = jobRepository;
        this.invoiceRepository = invoiceRepository;
        this.finalInspectionRepository = finalInspectionRepository;
        this.employeeRepository = employeeRepository;
        this.paymentRepository = paymentRepository;
    }

    @Transactional
    public VehicleHandoverResponse releaseVehicle(
            CreateVehicleHandoverRequest request
    ) {
        validateRequest(request);
        ActorIdentity.requireEmployee(request.releasedByEmployeeId());

        Job job = jobRepository.findByIdForUpdate(request.jobId())
            .orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Job not found."
            ));
        ActorIdentity.requireCompanyWorkshop(
                job.getCompany().getId(), job.getWorkshop().getId());

        if (handoverRepository.existsByJob_Id(job.getId())) {
            throw new ResponseStatusException(
                HttpStatus.CONFLICT,
                "This job already has a completed vehicle handover."
            );
        }

        if (!"READY_FOR_INVOICING".equalsIgnoreCase(job.getJobStatus())) {
            throw new ResponseStatusException(
                HttpStatus.CONFLICT,
                "Vehicle cannot be released. The job is not ready for collection."
            );
        }

        FinalInspection inspection =
            finalInspectionRepository
                .findFirstByJob_IdOrderByStartedAtDesc(job.getId())
                .orElseThrow(() -> new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "No final inspection exists for this job."
                ));

        if (!"COMPLETED".equalsIgnoreCase(inspection.getInspectionStatus())
                || !"PASS".equalsIgnoreCase(inspection.getInspectionDecision())) {
            throw new ResponseStatusException(
                HttpStatus.CONFLICT,
                "The latest final inspection must be completed and passed."
            );
        }

        Invoice invoice = invoiceRepository.findByIdForUpdate(request.invoiceId())
            .orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Invoice not found."
            ));

        if (!invoice.getJob().getId().equals(job.getId())) {
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,
                "The selected invoice does not belong to this job."
            );
        }

        if (invoice.getFinalInspection() == null
                || !invoice.getFinalInspection().getId().equals(inspection.getId())) {
            throw new ResponseStatusException(
                HttpStatus.CONFLICT,
                "The invoice is not linked to the latest passed final inspection."
            );
        }

        validateInvoiceSettlement(invoice);

        Employee releasingEmployee =
            employeeRepository.findByIdAndCompanyId(
                request.releasedByEmployeeId(),
                job.getCompany().getId()
            ).orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND,
                "Releasing employee not found for this company."
            ));

        if (releasingEmployee.getWorkshop() == null
                || !releasingEmployee.getWorkshop().getId()
                    .equals(job.getWorkshop().getId())) {
            throw new ResponseStatusException(
                HttpStatus.FORBIDDEN,
                "The releasing employee does not belong to this workshop."
            );
        }

        if (!"ACTIVE".equalsIgnoreCase(releasingEmployee.getEmploymentStatus())) {
            throw new ResponseStatusException(
                HttpStatus.FORBIDDEN,
                "Only active employees can release vehicles."
            );
        }

        byte[] signature = decodeSignature(request.collectorSignatureBase64());
        String signatureContentType = detectSignatureType(signature);

        LocalDateTime releasedAt = LocalDateTime.now();

        VehicleHandover handover = new VehicleHandover();

        handover.setCompany(job.getCompany());
        handover.setWorkshop(job.getWorkshop());
        handover.setJob(job);
        handover.setVehicle(job.getVehicle());
        handover.setInvoice(invoice);
        handover.setFinalInspection(inspection);
        handover.setReleasedBy(releasingEmployee);

        handover.setHandoverNumber(
            "HO-" + job.getJobNumber() + "-" +
            UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT)
        );

        handover.setCollectorName(request.collectorName().trim());
        handover.setCollectorPhone(request.collectorPhone().trim());
        handover.setCollectorIdType(request.collectorIdType().trim());
        handover.setCollectorIdNumber(request.collectorIdNumber().trim());
        handover.setCollectorRelationship(request.collectorRelationship());

        handover.setCustomerCollected(request.customerCollected());
        handover.setKeysHandedOver(request.keysHandedOver());
        handover.setDocumentsHandedOver(request.documentsHandedOver());

        handover.setVehicleConditionAtRelease(
            request.vehicleConditionAtRelease()
        );

        handover.setCustomerAcknowledged(true);
        handover.setAcknowledgementText(request.acknowledgementText());

        handover.setCollectorSignature(signature);
        handover.setSignatureContentType(signatureContentType);

        handover.setNotes(request.notes());
        handover.setReleasedAt(releasedAt);

        VehicleHandover saved = handoverRepository.save(handover);

        job.setVehicleReleasedAt(releasedAt);
        job.setJobStatus("RELEASED");

        Vehicle vehicle = job.getVehicle();
        vehicle.setVehicleStatus("RELEASED");

        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public VehicleHandoverResponse getHandoverById(Long handoverId) {
        VehicleHandover handover = handoverRepository.findById(handoverId)
            .orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Vehicle handover not found."
            ));
        ActorIdentity.requireCompanyWorkshop(
                handover.getCompany().getId(), handover.getWorkshop().getId());

        return toResponse(handover);
    }

    @Transactional(readOnly = true)
    public VehicleHandoverResponse getHandoverByJobId(Long jobId) {
        VehicleHandover handover = handoverRepository.findByJob_Id(jobId)
            .orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND,
                "No vehicle handover exists for this job."
            ));
        ActorIdentity.requireCompanyWorkshop(
                handover.getCompany().getId(), handover.getWorkshop().getId());

        return toResponse(handover);
    }

    private void validateInvoiceSettlement(Invoice invoice) {
        if (!"PAID".equalsIgnoreCase(invoice.getInvoiceStatus())) {
            throw new ResponseStatusException(
                HttpStatus.CONFLICT,
                "The invoice must be fully paid before vehicle release."
            );
        }

        BigDecimal total = zeroIfNull(invoice.getTotalAmount());
        BigDecimal paid = zeroIfNull(invoice.getAmountPaid());
        BigDecimal balance = zeroIfNull(invoice.getBalanceDue());

        if (total.compareTo(BigDecimal.ZERO) <= 0
                || balance.compareTo(BigDecimal.ZERO) != 0
                || paid.compareTo(total) != 0) {
            throw new ResponseStatusException(
                HttpStatus.CONFLICT,
                "Invoice totals do not show full settlement."
            );
        }

        BigDecimal completedPayments =
            paymentRepository.sumCompletedPaymentsByInvoiceId(invoice.getId());

        if (completedPayments == null
                || completedPayments.compareTo(total) != 0) {
            throw new ResponseStatusException(
                HttpStatus.CONFLICT,
                "Completed payment records do not reconcile with the invoice total."
            );
        }
    }

    private void validateRequest(CreateVehicleHandoverRequest request) {
        if (request == null
                || request.jobId() == null
                || request.invoiceId() == null
                || request.releasedByEmployeeId() == null) {
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,
                "Job, invoice and releasing employee are required."
            );
        }

        requireText(request.collectorName(), "Collector name");
        requireText(request.collectorPhone(), "Collector phone");
        requireText(request.collectorIdType(), "Collector ID type");
        requireText(request.collectorIdNumber(), "Collector ID number");

        if (!Boolean.TRUE.equals(request.keysHandedOver())) {
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,
                "Confirm that the vehicle keys have been handed over."
            );
        }

        if (!Boolean.TRUE.equals(request.customerAcknowledged())) {
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,
                "Customer acknowledgement is required."
            );
        }

        requireText(request.acknowledgementText(), "Acknowledgement text");
        requireText(request.collectorSignatureBase64(), "Collector signature");
    }

    private void requireText(String value, String fieldName) {
        if (value == null || value.isBlank()) {
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,
                fieldName + " is required."
            );
        }
    }

    private byte[] decodeSignature(String encodedSignature) {
        try {
            String value = encodedSignature.trim();

            if (value.startsWith("data:")) {
                int commaIndex = value.indexOf(',');
                if (commaIndex < 0) {
                    throw new IllegalArgumentException("Invalid signature data URL.");
                }
                value = value.substring(commaIndex + 1);
            }

            byte[] decoded = Base64.getDecoder().decode(value);

            if (decoded.length == 0 || decoded.length > 512 * 1024) {
                throw new IllegalArgumentException("Signature must not exceed 512 KB.");
            }

            return decoded;
        } catch (IllegalArgumentException exception) {
            throw new ResponseStatusException(
                HttpStatus.BAD_REQUEST,
                "The collector signature is invalid or exceeds 512 KB."
            );
        }
    }

    private String detectSignatureType(byte[] signature) {
        boolean png = signature.length >= 8
            && (signature[0] & 0xFF) == 0x89
            && signature[1] == 0x50
            && signature[2] == 0x4E
            && signature[3] == 0x47;

        boolean jpeg = signature.length >= 3
            && (signature[0] & 0xFF) == 0xFF
            && (signature[1] & 0xFF) == 0xD8
            && (signature[2] & 0xFF) == 0xFF;

        if (png) {
            return "image/png";
        }

        if (jpeg) {
            return "image/jpeg";
        }

        throw new ResponseStatusException(
            HttpStatus.BAD_REQUEST,
            "Signature must be a PNG or JPEG image."
        );
    }

    private BigDecimal zeroIfNull(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    private VehicleHandoverResponse toResponse(VehicleHandover handover) {
        Job job = handover.getJob();
        Vehicle vehicle = handover.getVehicle();

        return new VehicleHandoverResponse(
            handover.getId(),
            handover.getHandoverNumber(),

            job.getId(),
            job.getJobNumber(),

            vehicle.getId(),
            vehicle.getRegistrationNumber(),
            vehicle.getMake(),
            vehicle.getModel(),

            handover.getInvoice().getId(),
            handover.getInvoice().getInvoiceNumber(),

            handover.getFinalInspection().getId(),

            handover.getCollectorName(),
            handover.getCollectorPhone(),
            handover.getCollectorIdType(),
            handover.getCollectorIdNumber(),
            handover.getCollectorRelationship(),
            handover.getCustomerCollected(),

            handover.getKeysHandedOver(),
            handover.getDocumentsHandedOver(),
            handover.getVehicleConditionAtRelease(),

            handover.getCustomerAcknowledged(),
            handover.getAcknowledgementText(),
            handover.getCollectorSignature() != null,

            handover.getReleasedBy().getId(),
            handover.getReleasedAt(),
            handover.getNotes()
        );
    }
}
