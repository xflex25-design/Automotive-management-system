package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.*;
import com.autogarage.automotive.service.PartsAvailabilityService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class PartsAvailabilityController {
    private final PartsAvailabilityService partsService;

    public PartsAvailabilityController(PartsAvailabilityService partsService) {
        this.partsService = partsService;
    }

    @GetMapping("/job-cards/{jobCardId}/parts/availability")
    public PartsAvailabilityResponse checkAvailability(@PathVariable Long jobCardId) {
        return partsService.checkAvailability(jobCardId);
    }

    @PatchMapping("/job-cards/{jobCardId}/parts/{jobCardPartId}/catalog-part")
    public LinkJobCardPartResponse linkCatalogPart(
            @PathVariable Long jobCardId,
            @PathVariable Long jobCardPartId,
            @Valid @RequestBody LinkJobCardPartRequest request
    ) {
        return partsService.linkCatalogPart(jobCardId, jobCardPartId, request);
    }

    @PostMapping("/jobs/{jobId}/parts/requisitions")
    public ResponseEntity<PartsRequisitionResponse> createShortageRequisition(
            @PathVariable Long jobId,
            @Valid @RequestBody CreatePartsRequisitionRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(partsService.createShortageRequisition(jobId, request));
    }

    @PostMapping("/parts/requisitions/{requisitionId}/purchase-orders")
    public ResponseEntity<PurchaseOrderResponse> placeOutsideOrder(
            @PathVariable Long requisitionId,
            @Valid @RequestBody CreatePurchaseOrderRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(partsService.placeOutsideOrder(requisitionId, request));
    }

    @PostMapping("/parts/purchase-orders/{purchaseOrderId}/receipts")
    public ResponseEntity<PurchaseReceiptResponse> receiveDelivery(
            @PathVariable Long purchaseOrderId,
            @Valid @RequestBody ReceivePurchaseOrderRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(partsService.receiveDelivery(purchaseOrderId, request));
    }

    @PostMapping("/job-cards/{jobCardId}/parts/{jobCardPartId}/reservations")
    public StockReservationResponse reserveStock(
            @PathVariable Long jobCardId,
            @PathVariable Long jobCardPartId,
            @Valid @RequestBody ReserveStockRequest request
    ) {
        return partsService.reserveStock(jobCardId, jobCardPartId, request);
    }

    @GetMapping("/job-cards/{jobCardId}/parts/reservations")
    public List<StockReservationResponse> getJobReservations(
            @PathVariable Long jobCardId
    ) {
        return partsService.getJobReservations(jobCardId);
    }

    @PostMapping("/stock-reservations/{reservationId}/release")
    public StockReservationResponse releaseReservation(
            @PathVariable Long reservationId,
            @Valid @RequestBody ReleaseStockReservationRequest request
    ) {
        return partsService.releaseReservation(reservationId, request);
    }

    @PatchMapping("/parts/requisitions/{requisitionId}/cancel")
    public PartsRequisitionResponse cancelRequisition(
            @PathVariable Long requisitionId,
            @Valid @RequestBody CancelPartsRequisitionRequest request
    ) {
        return partsService.cancelRequisition(requisitionId, request);
    }
}
