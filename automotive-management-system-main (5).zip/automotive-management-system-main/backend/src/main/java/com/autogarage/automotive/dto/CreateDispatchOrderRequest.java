package com.autogarage.automotive.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;

public record CreateDispatchOrderRequest(
        @NotNull Long jobId,
        @NotNull Long createdByEmployeeId,
        @NotNull Long assignedMechanicEmployeeId,
        Long departmentId,
        String remarks,
        @NotEmpty List<@Valid DispatchItemRequest> items
) {
    public record DispatchItemRequest(
            @NotNull Long stockReservationId,
            @DecimalMin("0.00") BigDecimal unitSellingPrice,
            @DecimalMin("0.00") BigDecimal amountSold,
            String remarks
    ) {}
}