package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.VehicleInspectionRequest;
import com.autogarage.automotive.dto.VehicleInspectionResponse;
import com.autogarage.automotive.service.VehicleInspectionService;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/intake/jobs")
public class VehicleInspectionController {

    private final VehicleInspectionService inspectionService;

    public VehicleInspectionController(
            VehicleInspectionService inspectionService
    ) {
        this.inspectionService = inspectionService;
    }

    @PostMapping("/{jobId}/inspection")
    public ResponseEntity<VehicleInspectionResponse> createInspection(
            @PathVariable Long jobId,
            @Valid @RequestBody VehicleInspectionRequest request
    ) {

        VehicleInspectionResponse response =
                inspectionService.createInspection(jobId, request);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(response);
    }
}