package com.autogarage.automotive.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "job_card_parts")
@Getter
@Setter
@NoArgsConstructor
public class JobCardPart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "job_card_id", nullable = false)
    private JobCard jobCard;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "part_id")
    private Part part;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "source_quotation_item_id")
    private QuotationItem sourceQuotationItem;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "part_catalog_linked_by_employee_id")
    private Employee partCatalogLinkedBy;

    @Column(name = "part_catalog_linked_at")
    private LocalDateTime partCatalogLinkedAt;

    @Column(name = "part_category", nullable = false, length = 30)
    private String partCategory;

    @Column(name = "part_name", nullable = false, length = 200)
    private String partName;

    @Column(name = "part_number", length = 100)
    private String partNumber;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal quantity = BigDecimal.ONE;

    @Column(name = "unit_of_measure", length = 30)
    private String unitOfMeasure = "UNIT";

    @Column(name = "required_for", length = 255)
    private String requiredFor;

    @Column(columnDefinition = "TEXT")
    private String remarks;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}