package com.autogarage.automotive.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.List;

public record SubmitCustomerApprovalRequest(

        @NotBlank(message = "Approval token is required")
        String token,

        @NotEmpty(message = "You must decide on every quotation item")
        List<@Valid CustomerItemDecisionRequest> decisions,

        @Size(max = 4000)
        String customerComments

) {}