package com.autogarage.automotive.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.util.List;

public record ReceivePurchaseOrderRequest(
        @NotNull Long receivedByEmployeeId,
        @NotNull Long stockLocationId,
        @Size(max = 150) String supplierDeliveryReference,
        String notes,
        @NotEmpty List<@Valid PurchaseReceiptLineRequest> items
) {
    public record PurchaseReceiptLineRequest(
            @NotNull Long purchaseOrderItemId,
            @NotNull @Positive BigDecimal quantityDelivered,
            @NotNull @DecimalMin("0.00") BigDecimal quantityAccepted,
            @DecimalMin("0.00") BigDecimal unitCost,
            String discrepancyNotes
    ) {}
}
