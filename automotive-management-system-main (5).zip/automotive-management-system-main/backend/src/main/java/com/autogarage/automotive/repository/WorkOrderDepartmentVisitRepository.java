
package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.WorkOrderDepartmentVisit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WorkOrderDepartmentVisitRepository
        extends JpaRepository<WorkOrderDepartmentVisit, Long> {

    List<WorkOrderDepartmentVisit>
    findByWorkOrder_IdOrderByVisitNumberAsc(Long workOrderId);

    Optional<WorkOrderDepartmentVisit>
    findFirstByWorkOrder_IdAndVisitStatusOrderByVisitNumberDesc(
            Long workOrderId,
            String visitStatus
    );

    Optional<WorkOrderDepartmentVisit>
    findFirstByWorkOrder_IdOrderByVisitNumberDesc(Long workOrderId);

    List<WorkOrderDepartmentVisit>
    findByDepartment_IdAndVisitStatusOrderByArrivedAtAsc(
            Long departmentId,
            String visitStatus
    );
}
