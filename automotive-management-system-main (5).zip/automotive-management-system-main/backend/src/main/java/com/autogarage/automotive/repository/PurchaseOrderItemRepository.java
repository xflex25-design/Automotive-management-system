package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.PurchaseOrderItem;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface PurchaseOrderItemRepository extends JpaRepository<PurchaseOrderItem, Long> {
    List<PurchaseOrderItem> findByPurchaseOrder_IdOrderByIdAsc(Long purchaseOrderId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select i from PurchaseOrderItem i where i.id = :itemId and i.purchaseOrder.id = :orderId")
    Optional<PurchaseOrderItem> lockItem(
            @Param("orderId") Long orderId,
            @Param("itemId") Long itemId
    );

    @Query("select coalesce(sum(i.quantityOrdered), 0) from PurchaseOrderItem i where i.requisitionItem.id = :requisitionItemId and i.purchaseOrder.purchaseOrderStatus <> 'CANCELLED'")
    BigDecimal sumOrderedByRequisitionItem(@Param("requisitionItemId") Long requisitionItemId);
}
