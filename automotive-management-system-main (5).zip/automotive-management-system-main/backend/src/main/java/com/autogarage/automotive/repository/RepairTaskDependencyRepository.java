package com.autogarage.automotive.repository;

import com.autogarage.automotive.entity.RepairTaskDependency;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface RepairTaskDependencyRepository
        extends JpaRepository<RepairTaskDependency, Long> {

    List<RepairTaskDependency> findByTask_Id(Long taskId);

    List<RepairTaskDependency> findByTask_IdIn(List<Long> taskIds);

    List<RepairTaskDependency> findByDependsOnTask_Id(Long taskId);
}