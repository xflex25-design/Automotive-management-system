-- Add verification, notification, and token-expiry metadata to customer approvals.
ALTER TABLE quotation_approvals
    ADD COLUMN verified_by_employee_id BIGINT DEFAULT NULL,
    ADD COLUMN verified_at DATETIME DEFAULT NULL,
    ADD COLUMN verification_notes TEXT DEFAULT NULL,
    ADD COLUMN notification_status VARCHAR(30) NOT NULL DEFAULT 'NOT_SENT',
    ADD COLUMN notification_channel VARCHAR(30) DEFAULT NULL,
    ADD COLUMN notification_sent_at DATETIME DEFAULT NULL,
    ADD COLUMN approval_token_expires_at DATETIME DEFAULT NULL,
    ADD COLUMN decision_submitted_at DATETIME DEFAULT NULL,
    ADD KEY idx_quotation_approval_verifier (verified_by_employee_id),
    ADD CONSTRAINT fk_quotation_approval_verifier
        FOREIGN KEY (verified_by_employee_id) REFERENCES employees(id);
