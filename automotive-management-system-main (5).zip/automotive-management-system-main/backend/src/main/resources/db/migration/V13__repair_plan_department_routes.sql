CREATE TABLE repair_plan_department_routes (
    id BIGINT NOT NULL AUTO_INCREMENT,
    repair_plan_id BIGINT NOT NULL,
    department_id BIGINT NOT NULL,
    sequence_number INT NOT NULL,
    applicability VARCHAR(20) NOT NULL,
    not_applicable_reason TEXT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_repair_plan_department (repair_plan_id, department_id),
    UNIQUE KEY uk_repair_plan_sequence (repair_plan_id, sequence_number),
    CONSTRAINT chk_repair_route_applicability
        CHECK (applicability IN ('REQUIRED', 'NOT_APPLICABLE')),
    CONSTRAINT chk_repair_route_na_reason
        CHECK (applicability <> 'NOT_APPLICABLE'
            OR (not_applicable_reason IS NOT NULL AND CHAR_LENGTH(TRIM(not_applicable_reason)) > 0)),
    CONSTRAINT fk_repair_route_plan
        FOREIGN KEY (repair_plan_id) REFERENCES repair_plans (id),
    CONSTRAINT fk_repair_route_department
        FOREIGN KEY (department_id) REFERENCES departments (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
