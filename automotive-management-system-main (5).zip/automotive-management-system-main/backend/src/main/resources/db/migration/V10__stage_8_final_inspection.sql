-- V1 is a legacy full-schema snapshot and already contains the first versions
-- of final_inspections, final_inspection_items, and the invoice foreign key.
-- Evolve those tables to the Stage 8 model instead of creating them again.

ALTER TABLE final_inspections
    ADD COLUMN inspector_employee_id BIGINT DEFAULT NULL,
    ADD COLUMN inspection_decision VARCHAR(20) DEFAULT NULL,
    ADD COLUMN inspection_notes TEXT DEFAULT NULL,
    ADD COLUMN started_at DATETIME DEFAULT NULL,
    ADD COLUMN completed_at DATETIME DEFAULT NULL,
    ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP;

UPDATE final_inspections
SET inspector_employee_id = inspected_by_employee_id,
    inspection_decision = CASE
        WHEN inspection_status = 'PASSED' THEN 'PASS'
        WHEN inspection_status IN ('FAILED', 'REQUIRES_REWORK') THEN 'FAIL'
        ELSE NULL
    END,
    inspection_notes = overall_remarks,
    started_at = COALESCE(inspection_date, created_at, CURRENT_TIMESTAMP),
    completed_at = inspection_date;

ALTER TABLE final_inspections
    MODIFY COLUMN inspector_employee_id BIGINT NOT NULL,
    MODIFY COLUMN inspection_status VARCHAR(30) NOT NULL DEFAULT 'IN_PROGRESS',
    MODIFY COLUMN started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ADD KEY idx_final_inspection_inspector (inspector_employee_id),
    ADD CONSTRAINT fk_final_inspection_inspector
        FOREIGN KEY (inspector_employee_id) REFERENCES employees(id);

-- Preserve existing checklist data while adding the fields used by the new API.
ALTER TABLE final_inspection_items
    ADD COLUMN responsible_department_id BIGINT DEFAULT NULL,
    ADD COLUMN checked_by_employee_id BIGINT DEFAULT NULL,
    ADD COLUMN item_code VARCHAR(50) DEFAULT NULL,
    ADD COLUMN item_name VARCHAR(255) DEFAULT NULL,
    ADD COLUMN check_status VARCHAR(30) DEFAULT NULL,
    ADD COLUMN comments TEXT DEFAULT NULL,
    ADD COLUMN reinspection_required TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP;

UPDATE final_inspection_items
SET item_code = CONCAT('LEGACY-', id),
    item_name = check_item,
    check_status = COALESCE(inspection_result, 'PENDING'),
    comments = observations,
    reinspection_required = COALESCE(requires_rework, 0);

ALTER TABLE final_inspection_items
    MODIFY COLUMN item_code VARCHAR(50) NOT NULL,
    MODIFY COLUMN item_name VARCHAR(255) NOT NULL,
    MODIFY COLUMN check_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    ADD KEY idx_final_item_department (responsible_department_id),
    ADD CONSTRAINT fk_final_item_department
        FOREIGN KEY (responsible_department_id) REFERENCES departments(id),
    ADD CONSTRAINT fk_final_item_employee
        FOREIGN KEY (checked_by_employee_id) REFERENCES employees(id);

CREATE TABLE final_inspection_signoffs (
    id BIGINT NOT NULL AUTO_INCREMENT,
    final_inspection_id BIGINT NOT NULL,
    department_id BIGINT NOT NULL,
    signed_by_employee_id BIGINT DEFAULT NULL,
    signoff_status VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    signoff_notes TEXT DEFAULT NULL,
    signed_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_final_signoff_department (final_inspection_id, department_id),
    KEY idx_final_signoff_department (department_id),
    CONSTRAINT fk_final_signoff_inspection
        FOREIGN KEY (final_inspection_id) REFERENCES final_inspections(id),
    CONSTRAINT fk_final_signoff_department
        FOREIGN KEY (department_id) REFERENCES departments(id),
    CONSTRAINT fk_final_signoff_employee
        FOREIGN KEY (signed_by_employee_id) REFERENCES employees(id)
);

-- V1 already created the invoice-to-inspection foreign key.
