-- Link an invoice to the quotation it was issued from.
ALTER TABLE invoices
    ADD COLUMN quotation_id BIGINT DEFAULT NULL AFTER job_id,
    ADD KEY idx_invoice_quotation (quotation_id),
    ADD CONSTRAINT fk_invoice_quotation
        FOREIGN KEY (quotation_id) REFERENCES quotations(id);
