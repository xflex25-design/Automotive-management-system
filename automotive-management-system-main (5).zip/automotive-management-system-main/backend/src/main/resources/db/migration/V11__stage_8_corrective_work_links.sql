
-- Stage 8: Link reinspection attempts to previous inspections.

ALTER TABLE final_inspections
    ADD COLUMN previous_inspection_id BIGINT DEFAULT NULL,
    ADD KEY idx_final_inspection_previous (previous_inspection_id),
    ADD CONSTRAINT fk_final_inspection_previous
        FOREIGN KEY (previous_inspection_id)
        REFERENCES final_inspections(id);

-- Link failed checklist items to corrective work orders.

ALTER TABLE final_inspection_items
    ADD COLUMN corrective_work_order_id BIGINT DEFAULT NULL,
    ADD KEY idx_final_item_corrective_work_order (corrective_work_order_id),
    ADD CONSTRAINT fk_final_item_corrective_work_order
        FOREIGN KEY (corrective_work_order_id)
        REFERENCES work_orders(id);
