CREATE TABLE stock_reservations (
    id BIGINT NOT NULL AUTO_INCREMENT,
    job_card_part_id BIGINT NOT NULL,
    stock_balance_id BIGINT NOT NULL,
    quantity_reserved DECIMAL(12,2) NOT NULL,
    reservation_status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    reserved_by_employee_id BIGINT NOT NULL,
    reserved_at DATETIME NOT NULL,
    released_by_employee_id BIGINT NULL,
    released_at DATETIME NULL,
    consumed_at DATETIME NULL,
    notes TEXT NULL,

    PRIMARY KEY (id),

    KEY idx_stock_reservation_job_part (job_card_part_id),
    KEY idx_stock_reservation_balance_status (stock_balance_id, reservation_status),

    CONSTRAINT fk_stock_reservation_job_card_part
        FOREIGN KEY (job_card_part_id) REFERENCES job_card_parts(id),

    CONSTRAINT fk_stock_reservation_balance
        FOREIGN KEY (stock_balance_id) REFERENCES stock_balances(id),

    CONSTRAINT fk_stock_reservation_reserved_by
        FOREIGN KEY (reserved_by_employee_id) REFERENCES employees(id),

    CONSTRAINT fk_stock_reservation_released_by
        FOREIGN KEY (released_by_employee_id) REFERENCES employees(id),

    CONSTRAINT chk_stock_reservation_quantity
        CHECK (quantity_reserved > 0),

    CONSTRAINT chk_stock_reservation_status
        CHECK (reservation_status IN ('ACTIVE', 'RELEASED', 'CONSUMED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;