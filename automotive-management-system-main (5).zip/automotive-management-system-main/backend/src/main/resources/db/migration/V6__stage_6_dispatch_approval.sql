-- Stage 6: Dispatch approval and controlled stock issue

ALTER TABLE dispatch_orders
    MODIFY COLUMN dispatch_status ENUM(
        'DRAFT',
        'PENDING_APPROVAL',
        'APPROVED',
        'REJECTED',
        'DISPATCHED',
        'ISSUED',
        'RECEIVED',
        'CANCELLED'
    ) DEFAULT 'DRAFT',

    ADD COLUMN created_by_employee_id BIGINT NULL,
    ADD COLUMN assigned_mechanic_employee_id BIGINT NULL,
    ADD COLUMN approved_by_employee_id BIGINT NULL,
    ADD COLUMN approved_at DATETIME NULL,
    ADD COLUMN issued_at DATETIME NULL,
    ADD COLUMN rejection_reason TEXT NULL,

    ADD CONSTRAINT fk_dispatch_created_by
        FOREIGN KEY (created_by_employee_id)
        REFERENCES employees(id),

    ADD CONSTRAINT fk_dispatch_assigned_mechanic
        FOREIGN KEY (assigned_mechanic_employee_id)
        REFERENCES employees(id),

    ADD CONSTRAINT fk_dispatch_approved_by
        FOREIGN KEY (approved_by_employee_id)
        REFERENCES employees(id);


ALTER TABLE dispatch_order_items
    MODIFY COLUMN quantity_dispatched DECIMAL(12,2) NULL,
    ADD COLUMN stock_reservation_id BIGINT NULL,
    ADD COLUMN unit_selling_price DECIMAL(14,2) NULL,
    ADD COLUMN amount_sold DECIMAL(14,2) NULL,

    ADD CONSTRAINT fk_dispatch_item_reservation
        FOREIGN KEY (stock_reservation_id)
        REFERENCES stock_reservations(id),

    ADD UNIQUE KEY uq_dispatch_item_reservation
        (stock_reservation_id);


ALTER TABLE dispatch_signatures
    MODIFY COLUMN signer_type ENUM(
        'AUTHORISED_BY',
        'DISPATCHED_BY',
        'RECEIVED_BY',
        'ACCOUNTS_ACKNOWLEDGEMENT',
        'CUSTOMER_ACKNOWLEDGEMENT'
    ) NOT NULL;