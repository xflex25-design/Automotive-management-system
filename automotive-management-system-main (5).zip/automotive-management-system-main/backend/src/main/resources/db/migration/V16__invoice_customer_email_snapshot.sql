-- Keep a copy of the customer's email on each invoice for historical records.
ALTER TABLE invoices
    ADD COLUMN customer_email_snapshot VARCHAR(255) DEFAULT NULL
        AFTER customer_phone_snapshot;
