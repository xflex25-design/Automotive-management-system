CREATE TABLE repair_task_catalogue (
    id BIGINT NOT NULL AUTO_INCREMENT,
    department_id BIGINT NOT NULL,
    task_code VARCHAR(80) NOT NULL,
    task_name VARCHAR(200) NOT NULL,
    description TEXT DEFAULT NULL,
    default_instructions TEXT DEFAULT NULL,
    estimated_hours DECIMAL(8,2) DEFAULT NULL,
    requires_parts TINYINT(1) NOT NULL DEFAULT 0,
    requires_evidence TINYINT(1) NOT NULL DEFAULT 1,
    requires_final_inspection TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_repair_task_code (task_code),
    KEY idx_repair_task_department (department_id),
    CONSTRAINT fk_repair_task_department
        FOREIGN KEY (department_id) REFERENCES departments(id)
);

CREATE TABLE repair_task_dependencies (
    id BIGINT NOT NULL AUTO_INCREMENT,
    task_id BIGINT NOT NULL,
    depends_on_task_id BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_repair_task_dependency (task_id, depends_on_task_id),
    CONSTRAINT fk_repair_task_dependency_task
        FOREIGN KEY (task_id) REFERENCES repair_task_catalogue(id),
    CONSTRAINT fk_repair_task_dependency_parent
        FOREIGN KEY (depends_on_task_id) REFERENCES repair_task_catalogue(id)
);

CREATE TABLE repair_task_keywords (
    id BIGINT NOT NULL AUTO_INCREMENT,
    repair_task_id BIGINT NOT NULL,
    keyword VARCHAR(150) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_repair_task_keyword (repair_task_id),
    CONSTRAINT fk_repair_task_keyword_task
        FOREIGN KEY (repair_task_id) REFERENCES repair_task_catalogue(id)
);
