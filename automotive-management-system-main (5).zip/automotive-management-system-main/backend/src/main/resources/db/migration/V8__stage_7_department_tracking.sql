
-- ============================================================
-- STAGE 7: DEPARTMENT TRACKING AND WORKSHOP ACTIVITY
-- ============================================================

-- 1. Add WAITING to work order statuses
ALTER TABLE work_orders
MODIFY COLUMN work_order_status ENUM(
    'BLOCKED',
    'READY',
    'ASSIGNED',
    'IN_PROGRESS',
    'WAITING',
    'PAUSED',
    'AWAITING_CONFIRMATION',
    'COMPLETED',
    'REJECTED',
    'CANCELLED'
) DEFAULT 'BLOCKED';

-- 2. Add NOT_APPLICABLE to work order confirmation decisions
ALTER TABLE work_order_confirmations
MODIFY COLUMN confirmation_status ENUM(
    'COMPLETED',
    'REJECTED',
    'RETURNED_FOR_REWORK',
    'NOT_APPLICABLE'
) NOT NULL;

-- 3. Department visit tracking
-- Each work order can visit a department multiple times.
CREATE TABLE work_order_department_visits (
    id BIGINT NOT NULL AUTO_INCREMENT,

    work_order_id BIGINT NOT NULL,
    department_id BIGINT NOT NULL,

    visit_number INT NOT NULL,

    visit_status ENUM(
        'OPEN',
        'SENT_OFF'
    ) NOT NULL DEFAULT 'OPEN',

    arrived_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    arrived_by_employee_id BIGINT NOT NULL,

    sent_off_at DATETIME NULL,
    sent_off_by_employee_id BIGINT NULL,

    arrival_notes TEXT NULL,
    send_off_notes TEXT NULL,

    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),

    UNIQUE KEY uk_work_order_visit_number (
        work_order_id,
        visit_number
    ),

    KEY idx_department_visit_status (
        department_id,
        visit_status
    ),

    KEY idx_work_order_visit_arrival (
        work_order_id,
        arrived_at
    ),

    CONSTRAINT fk_department_visit_work_order
        FOREIGN KEY (work_order_id)
        REFERENCES work_orders(id),

    CONSTRAINT fk_department_visit_department
        FOREIGN KEY (department_id)
        REFERENCES departments(id),

    CONSTRAINT fk_department_visit_arrived_by
        FOREIGN KEY (arrived_by_employee_id)
        REFERENCES employees(id),

    CONSTRAINT fk_department_visit_sent_off_by
        FOREIGN KEY (sent_off_by_employee_id)
        REFERENCES employees(id)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;


-- 4. Work order activity history
-- Records status changes, notes, pauses, resumes,
-- arrivals, send-offs, and other workshop activities.
CREATE TABLE work_order_activities (
    id BIGINT NOT NULL AUTO_INCREMENT,

    work_order_id BIGINT NOT NULL,
    department_visit_id BIGINT NULL,

    activity_type VARCHAR(60) NOT NULL,

    previous_status VARCHAR(50) NULL,
    new_status VARCHAR(50) NULL,

    activity_description TEXT NULL,

    performed_by_employee_id BIGINT NULL,

    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (id),

    KEY idx_work_order_activity_date (
        work_order_id,
        created_at
    ),

    KEY idx_department_visit_activity_date (
        department_visit_id,
        created_at
    ),

    CONSTRAINT fk_work_order_activity_work_order
        FOREIGN KEY (work_order_id)
        REFERENCES work_orders(id),

    CONSTRAINT fk_work_order_activity_visit
        FOREIGN KEY (department_visit_id)
        REFERENCES work_order_department_visits(id),

    CONSTRAINT fk_work_order_activity_employee
        FOREIGN KEY (performed_by_employee_id)
        REFERENCES employees(id)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci;
