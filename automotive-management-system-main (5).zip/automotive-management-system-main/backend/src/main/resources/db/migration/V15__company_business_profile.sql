-- The V1 baseline predates the company profile fields mapped by Company.
-- Add them through a new migration so existing installations upgrade safely.

ALTER TABLE companies
    ADD COLUMN vat_rate DECIMAL(5,2) NOT NULL DEFAULT 16.00,
    ADD COLUMN vat_number VARCHAR(100) DEFAULT NULL,
    ADD COLUMN website VARCHAR(255) DEFAULT NULL,
    ADD COLUMN bank_name VARCHAR(150) DEFAULT NULL,
    ADD COLUMN bank_branch VARCHAR(150) DEFAULT NULL,
    ADD COLUMN bank_account_name VARCHAR(150) DEFAULT NULL,
    ADD COLUMN bank_account_number VARCHAR(100) DEFAULT NULL,
    ADD COLUMN bank_swift_code VARCHAR(50) DEFAULT NULL,
    ADD COLUMN logo_data LONGBLOB DEFAULT NULL,
    ADD COLUMN logo_content_type VARCHAR(100) DEFAULT NULL;
