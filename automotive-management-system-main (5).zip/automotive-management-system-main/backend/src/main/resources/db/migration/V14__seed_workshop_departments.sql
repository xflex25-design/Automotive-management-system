-- Seed the six workflow departments for every active workshop.
-- The unique key makes this safe for workshops that already have some departments.
INSERT INTO departments (
    company_id,
    workshop_id,
    department_name,
    department_code,
    description,
    is_active
)
SELECT
    workshop.company_id,
    workshop.id,
    department.department_name,
    department.department_code,
    department.description,
    1
FROM workshops workshop
CROSS JOIN (
    SELECT 'Electrical' AS department_name, 'ELECTRICAL' AS department_code,
           'Electrical diagnosis and repairs.' AS description
    UNION ALL SELECT 'Mechanic', 'MECHANIC', 'Mechanical servicing and repairs.'
    UNION ALL SELECT 'Fitting', 'FITTING', 'Parts fitting and assembly.'
    UNION ALL SELECT 'Panel Beating', 'PANELBEATING', 'Panel beating and body repairs.'
    UNION ALL SELECT 'Sanding', 'SANDING', 'Surface preparation and sanding.'
    UNION ALL SELECT 'Painting', 'PAINTING', 'Vehicle painting and finishing.'
) department
LEFT JOIN departments existing
    ON existing.workshop_id = workshop.id
    AND existing.department_code = department.department_code
WHERE workshop.is_active = 1
  AND existing.id IS NULL;
