-- Workshop working hours and monitoring configuration
CREATE TABLE workshop_monitoring_settings (
    id BIGINT NOT NULL AUTO_INCREMENT,
    workshop_id BIGINT NOT NULL,
    working_days VARCHAR(30) NOT NULL DEFAULT 'MON,TUE,WED,THU,FRI',
    opening_time TIME NOT NULL DEFAULT '08:00:00',
    closing_time TIME NOT NULL DEFAULT '17:00:00',
    stagnation_threshold_minutes INT NOT NULL DEFAULT 120,
    waiting_reminder_minutes INT NOT NULL DEFAULT 60,
    paused_reminder_minutes INT NOT NULL DEFAULT 60,
    reminder_repeat_minutes INT NOT NULL DEFAULT 60,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_monitoring_workshop (workshop_id),
    CONSTRAINT fk_monitoring_workshop
        FOREIGN KEY (workshop_id) REFERENCES workshops(id),
    CONSTRAINT chk_monitoring_threshold
        CHECK (stagnation_threshold_minutes > 0),
    CONSTRAINT chk_monitoring_reminders
        CHECK (
            waiting_reminder_minutes > 0
            AND paused_reminder_minutes > 0
            AND reminder_repeat_minutes > 0
        )
);

-- Configurable escalation levels
CREATE TABLE workshop_escalation_rules (
    id BIGINT NOT NULL AUTO_INCREMENT,
    workshop_id BIGINT NOT NULL,
    escalation_level INT NOT NULL,
    elapsed_minutes INT NOT NULL,
    priority ENUM('LOW','NORMAL','HIGH','URGENT') NOT NULL,
    notify_manager TINYINT(1) NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_escalation_level (workshop_id, escalation_level),
    CONSTRAINT fk_escalation_workshop
        FOREIGN KEY (workshop_id) REFERENCES workshops(id),
    CONSTRAINT chk_escalation_minutes
        CHECK (elapsed_minutes > 0)
);

-- Reminder and escalation audit history
CREATE TABLE work_order_reminders (
    id BIGINT NOT NULL AUTO_INCREMENT,
    work_order_id BIGINT NOT NULL,
    employee_id BIGINT DEFAULT NULL,
    reminder_type ENUM(
        'WAITING',
        'PAUSED',
        'STAGNANT',
        'ESCALATION'
    ) NOT NULL,
    escalation_level INT NOT NULL DEFAULT 0,
    priority ENUM('LOW','NORMAL','HIGH','URGENT') NOT NULL DEFAULT 'NORMAL',
    reminder_message VARCHAR(1000) NOT NULL,
    sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at DATETIME DEFAULT NULL,
    acknowledged_by_employee_id BIGINT DEFAULT NULL,
    PRIMARY KEY (id),
    KEY idx_reminder_work_order (work_order_id, sent_at),
    KEY idx_reminder_employee (employee_id, acknowledged_at),
    CONSTRAINT fk_reminder_work_order
        FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
    CONSTRAINT fk_reminder_employee
        FOREIGN KEY (employee_id) REFERENCES employees(id),
    CONSTRAINT fk_reminder_ack_employee
        FOREIGN KEY (acknowledged_by_employee_id) REFERENCES employees(id)
);