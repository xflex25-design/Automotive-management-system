INSERT INTO roles (role_name, description)
VALUES
    ('Manager', 'Workshop manager; may approve or reject dispatch orders.'),
    ('Boss', 'Workshop boss; may approve or reject dispatch orders.'),
    ('Foreman', 'Workshop foreman; prepares job cards and dispatch orders.'),
    ('Stores', 'Stores employee; receives and issues workshop parts.'),
    ('Accounts', 'Accounts employee; acknowledges dispatch documents.')
ON DUPLICATE KEY UPDATE description = VALUES(description);
