ALTER TABLE job_card_parts
    ADD COLUMN part_id BIGINT NULL AFTER job_card_id,
    ADD COLUMN part_catalog_linked_by_employee_id BIGINT NULL,
    ADD COLUMN part_catalog_linked_at DATETIME NULL,
    ADD KEY idx_job_card_parts_catalog_part (part_id),
    ADD CONSTRAINT fk_job_card_parts_catalog_part
        FOREIGN KEY (part_id) REFERENCES parts (id),
    ADD CONSTRAINT fk_job_card_parts_catalog_linker
        FOREIGN KEY (part_catalog_linked_by_employee_id) REFERENCES employees (id);

-- Link existing job-card lines where their part number already matches the
-- workshop/company part catalogue code. Unmatched lines stay unlinked and the
-- availability API asks staff to resolve them explicitly.
UPDATE job_card_parts jcp
JOIN job_cards jc ON jc.id = jcp.job_card_id
JOIN jobs j ON j.id = jc.job_id
JOIN parts p ON p.company_id = j.company_id
             AND p.part_code = jcp.part_number
             AND p.is_active = 1
SET jcp.part_id = p.id,
    jcp.unit_of_measure = p.unit_of_measure
WHERE jcp.part_number IS NOT NULL;

CREATE TABLE purchase_receipts (
    id BIGINT NOT NULL AUTO_INCREMENT,
    purchase_order_id BIGINT NOT NULL,
    receipt_number VARCHAR(100) NOT NULL,
    received_by_employee_id BIGINT NOT NULL,
    stock_location_id BIGINT NOT NULL,
    supplier_delivery_reference VARCHAR(150) NULL,
    received_at DATETIME NOT NULL,
    notes TEXT NULL,
    created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_purchase_receipt_number (receipt_number),
    KEY idx_purchase_receipt_order (purchase_order_id),
    KEY idx_purchase_receipt_received_at (received_at),
    CONSTRAINT fk_purchase_receipt_order
        FOREIGN KEY (purchase_order_id) REFERENCES purchase_orders (id),
    CONSTRAINT fk_purchase_receipt_receiver
        FOREIGN KEY (received_by_employee_id) REFERENCES employees (id),
    CONSTRAINT fk_purchase_receipt_location
        FOREIGN KEY (stock_location_id) REFERENCES stock_locations (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE purchase_receipt_items (
    id BIGINT NOT NULL AUTO_INCREMENT,
    receipt_id BIGINT NOT NULL,
    purchase_order_item_id BIGINT NOT NULL,
    quantity_delivered DECIMAL(12,2) NOT NULL,
    quantity_accepted DECIMAL(12,2) NOT NULL,
    quantity_rejected DECIMAL(12,2) NOT NULL,
    discrepancy_notes TEXT NULL,
    PRIMARY KEY (id),
    KEY idx_purchase_receipt_item_receipt (receipt_id),
    KEY idx_purchase_receipt_item_order_item (purchase_order_item_id),
    CONSTRAINT fk_purchase_receipt_item_receipt
        FOREIGN KEY (receipt_id) REFERENCES purchase_receipts (id),
    CONSTRAINT fk_purchase_receipt_item_order_item
        FOREIGN KEY (purchase_order_item_id) REFERENCES purchase_order_items (id),
    CONSTRAINT chk_purchase_receipt_quantities_nonnegative
        CHECK (quantity_delivered > 0 AND quantity_accepted >= 0 AND quantity_rejected >= 0),
    CONSTRAINT chk_purchase_receipt_quantities_balance
        CHECK (quantity_accepted + quantity_rejected = quantity_delivered)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
