﻿ALTER TABLE parts_requisitions
    ADD COLUMN cancelled_by_employee_id BIGINT NULL,
    ADD COLUMN cancelled_at DATETIME NULL,
    ADD COLUMN cancellation_reason TEXT NULL;

ALTER TABLE parts_requisitions
    ADD CONSTRAINT fk_parts_requisition_cancelled_by
    FOREIGN KEY (cancelled_by_employee_id)
    REFERENCES employees(id);

CREATE INDEX idx_parts_requisitions_cancelled_by
    ON parts_requisitions(cancelled_by_employee_id);
