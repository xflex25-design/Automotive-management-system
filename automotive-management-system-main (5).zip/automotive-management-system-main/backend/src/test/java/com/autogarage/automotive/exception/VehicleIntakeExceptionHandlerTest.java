package com.autogarage.automotive.exception;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class VehicleIntakeExceptionHandlerTest {

    @Test
    void unknownApiPathReturnsNotFoundInsteadOfUnexpectedServerError() throws Exception {
        MockMvc mockMvc = MockMvcBuilders
                .standaloneSetup(new ProbeController())
                .setControllerAdvice(new VehicleIntakeExceptionHandler())
                .build();

        mockMvc.perform(get("/unknown-api-route"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("API route not found"));
    }

    @RestController
    private static class ProbeController {
        @GetMapping("/probe")
        String probe() {
            return "ok";
        }
    }
}
