package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.PartsAvailabilityResponse;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.WorkshopPrincipal;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.*;

class PartsAvailabilityServiceTest {
    private JobCardRepository jobCardRepository;
    private JobCardPartRepository jobCardPartRepository;
    private PartRepository partRepository;
    private StockBalanceRepository stockBalanceRepository;
    private PartsRequisitionRepository requisitionRepository;
    private PartsRequisitionItemRepository requisitionItemRepository;
    private PurchaseOrderRepository purchaseOrderRepository;
    private PurchaseOrderItemRepository purchaseOrderItemRepository;
    private PurchaseReceiptRepository receiptRepository;
    private PurchaseReceiptItemRepository receiptItemRepository;
    private StockLocationRepository stockLocationRepository;
    private StockMovementRepository stockMovementRepository;
    private SupplierRepository supplierRepository;
    private EmployeeRepository employeeRepository;
    private PartsAvailabilityService service;
    private StockReservationRepository stockReservationRepository;

    @BeforeEach
    void setUp() {
        authenticateAsEmployee(5L);

        jobCardRepository = mock(JobCardRepository.class);
        jobCardPartRepository = mock(JobCardPartRepository.class);
        partRepository = mock(PartRepository.class);
        stockBalanceRepository = mock(StockBalanceRepository.class);
        requisitionRepository = mock(PartsRequisitionRepository.class);
        requisitionItemRepository = mock(PartsRequisitionItemRepository.class);
        purchaseOrderRepository = mock(PurchaseOrderRepository.class);
        purchaseOrderItemRepository = mock(PurchaseOrderItemRepository.class);
        receiptRepository = mock(PurchaseReceiptRepository.class);
        receiptItemRepository = mock(PurchaseReceiptItemRepository.class);
        stockLocationRepository = mock(StockLocationRepository.class);
        stockMovementRepository = mock(StockMovementRepository.class);
        supplierRepository = mock(SupplierRepository.class);
        employeeRepository = mock(EmployeeRepository.class);
        stockReservationRepository = mock(StockReservationRepository.class);
        service = new PartsAvailabilityService(
                jobCardRepository,
                jobCardPartRepository,
                partRepository,
                stockBalanceRepository,
                requisitionRepository,
                requisitionItemRepository,
                purchaseOrderRepository,
                purchaseOrderItemRepository,
                receiptRepository,
                receiptItemRepository,
                stockLocationRepository,
                stockMovementRepository,
                supplierRepository,
                employeeRepository,
                stockReservationRepository
        );
    }

    private void authenticateAsEmployee(Long employeeId) {
        WorkshopPrincipal principal = new WorkshopPrincipal(
                5L,
                employeeId,
                1L,
                2L,
                "Alex Foreman",
                "alex@example.test",
                "{noop}test",
                true,
                false,
                List.of(new SimpleGrantedAuthority("ROLE_FOREMAN"))
        );
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        securityContext.setAuthentication(
                new UsernamePasswordAuthenticationToken(principal, principal.getPassword(), principal.getAuthorities())
        );
        SecurityContextHolder.setContext(securityContext);
    }

    @AfterEach
    void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void availabilityAggregatesDuplicatePartLinesAndSubtractsReservedStock() {
        JobCard card = card(40L, 400L, 1L, 2L);
        Part part = part(7L, 1L, true, "BRK-01", "Brake pad");
        JobCardPart first = requirement(101L, part, "BRAKES", "Brake pad", "2");
        JobCardPart second = requirement(102L, part, "BRAKES", "Brake pad", "3");
        StockBalance balance = mock(StockBalance.class);
        when(balance.getQuantityOnHand()).thenReturn(new BigDecimal("7"));
        when(balance.getQuantityReserved()).thenReturn(new BigDecimal("3"));

        when(jobCardRepository.findById(40L)).thenReturn(Optional.of(card));
        when(jobCardPartRepository.findByJobCard_IdOrderByIdAsc(40L))
                .thenReturn(List.of(first, second));
        when(stockBalanceRepository.findActiveBalances(7L, 2L)).thenReturn(List.of(balance));

        PartsAvailabilityResponse response = service.checkAvailability(40L);

        assertEquals(400L, response.jobId());
        assertEquals(40L, response.jobCardId());
        assertEquals(1, response.parts().size());
        PartsAvailabilityResponse.Line line = response.parts().getFirst();
        assertEquals(List.of(101L, 102L), line.jobCardPartIds());
        assertEquals(new BigDecimal("5.00"), line.requiredQuantity());
        assertEquals(new BigDecimal("7.00"), line.quantityOnHand());
        assertEquals(new BigDecimal("3.00"), line.quantityReserved());
        assertEquals(new BigDecimal("4.00"), line.quantityAvailable());
        assertEquals(new BigDecimal("1.00"), line.quantityShort());
        assertEquals("PARTIAL", line.availabilityStatus());
    }

    @Test
    void availabilityRejectsAnUnlinkedJobCardPart() {
        JobCard card = card(40L, 400L, 1L, 2L);
        JobCardPart unlinked = requirement(101L, null, "BRAKES", "Brake pad", "1");
        when(jobCardRepository.findById(40L)).thenReturn(Optional.of(card));
        when(jobCardPartRepository.findByJobCard_IdOrderByIdAsc(40L))
                .thenReturn(List.of(unlinked));

        ResponseStatusException error = assertThrows(
                ResponseStatusException.class, () -> service.checkAvailability(40L));

        assertEquals(HttpStatus.BAD_REQUEST, error.getStatusCode());
        assertTrue(error.getReason().contains("not linked to a stock catalogue part"));
        verifyNoInteractions(stockBalanceRepository);
    }

    @Test
    void availabilityReturnsNotFoundForAnUnknownJobCard() {
        when(jobCardRepository.findById(404L)).thenReturn(Optional.empty());

        ResponseStatusException error = assertThrows(
                ResponseStatusException.class, () -> service.checkAvailability(404L));

        assertEquals(HttpStatus.NOT_FOUND, error.getStatusCode());
    }

    @Test
    void catalogLinkAssociatesTheJobCardLineWithAnActiveCompanyPart() {
        JobCard card = card(40L, 400L, 1L, 2L);
        JobCardPart requirement = requirement(101L, null, "BRAKES", "Brake pad", "1");
        Part part = part(7L, 1L, true, "BRK-01", "Brake pad");
        when(part.getUnitOfMeasure()).thenReturn("EACH");
        Employee linker = employee(5L, 1L, 2L, "ACTIVE");
        when(linker.getFirstName()).thenReturn("Alex");
        when(linker.getLastName()).thenReturn("Foreman");
        when(jobCardRepository.findById(40L)).thenReturn(Optional.of(card));
        when(employeeRepository.findByIdAndCompanyId(5L, 1L)).thenReturn(Optional.of(linker));
        when(jobCardPartRepository.findByIdAndJobCard_Id(101L, 40L))
                .thenReturn(Optional.of(requirement));
        when(partRepository.findByIdAndCompany_IdAndActiveTrue(7L, 1L))
                .thenReturn(Optional.of(part));

        var response = service.linkCatalogPart(40L, 101L,
                new com.autogarage.automotive.dto.LinkJobCardPartRequest(7L, 5L));

        assertEquals(40L, response.jobCardId());
        assertEquals(7L, response.partId());
        verify(requirement).setPart(part);
        verify(requirement).setPartCatalogLinkedBy(linker);
        verify(requirement).setPartCatalogLinkedAt(any());
        verify(requirement).setUnitOfMeasure("EACH");
    }

    @Test
    void shortageRequisitionRequestsOnlyTheQuantityUnavailableInStores() {
        JobCard card = card(40L, 400L, 1L, 2L);
        when(card.getJobCardNumber()).thenReturn("JC-40");
        Part part = part(7L, 1L, true, "BRK-01", "Brake pad");
        when(part.getUnitOfMeasure()).thenReturn("EACH");
        JobCardPart requirement = requirement(101L, part, "BRAKES", "Brake pad", "4");
        Employee requester = employee(5L, 1L, 2L, "ACTIVE");
        StockBalance balance = mock(StockBalance.class);
        when(balance.getQuantityOnHand()).thenReturn(new BigDecimal("2"));
        when(balance.getQuantityReserved()).thenReturn(new BigDecimal("1"));
        when(jobCardRepository.findByJobIdForUpdate(400L)).thenReturn(Optional.of(card));
        when(requisitionRepository.findFirstByJob_IdAndRequisitionStatusIn(anyLong(), anyList()))
                .thenReturn(Optional.empty());
        when(employeeRepository.findByIdAndCompanyId(5L, 1L)).thenReturn(Optional.of(requester));
        when(jobCardPartRepository.findByJobCard_IdOrderByIdAsc(40L)).thenReturn(List.of(requirement));
        when(stockBalanceRepository.lockActiveBalances(7L, 2L)).thenReturn(List.of(balance));
        when(requisitionRepository.saveAndFlush(any(PartsRequisition.class))).thenAnswer(invocation -> {
            PartsRequisition saved = invocation.getArgument(0);
            saved.setId(500L);
            return saved;
        });
        when(requisitionItemRepository.save(any(PartsRequisitionItem.class))).thenAnswer(invocation -> {
            PartsRequisitionItem saved = invocation.getArgument(0);
            saved.setId(600L);
            return saved;
        });

        var response = service.createShortageRequisition(400L,
                new com.autogarage.automotive.dto.CreatePartsRequisitionRequest(
                        5L, "HIGH", null, "Job card shortage"));

        assertEquals("SUBMITTED", response.status());
        assertEquals(1, response.items().size());
        assertEquals(new BigDecimal("3.00"), response.items().getFirst().shortageQuantity());
        assertEquals("HIGH", captureSavedRequisitionPriority());
    }

    @Test
    void acceptedSupplierDeliveryIncreasesStockAndRecordsMovement() {
        authenticateAsEmployee(8L);
        Company company = mock(Company.class);
        Workshop workshop = mock(Workshop.class);
        when(company.getId()).thenReturn(1L);
        when(workshop.getId()).thenReturn(2L);
        PurchaseOrder order = new PurchaseOrder();
        order.setId(90L);
        order.setCompany(company);
        order.setWorkshop(workshop);
        order.setPurchaseOrderStatus("SENT_TO_SUPPLIER");
        order.setPurchaseOrderNumber("PO-90");
        when(purchaseOrderRepository.findByIdForUpdate(90L)).thenReturn(Optional.of(order));
        Employee receiver = employee(8L, 1L, 2L, "ACTIVE");
        when(employeeRepository.findByIdAndCompanyId(8L, 1L)).thenReturn(Optional.of(receiver));
        StockLocation location = mock(StockLocation.class);
        when(location.getId()).thenReturn(3L);
        when(stockLocationRepository.lockActiveLocation(3L, 2L)).thenReturn(Optional.of(location));
        Part part = part(7L, 1L, true, "BRK-01", "Brake pad");
        PurchaseOrderItem orderItem = new PurchaseOrderItem();
        orderItem.setId(91L);
        orderItem.setPart(part);
        orderItem.setQuantityOrdered(new BigDecimal("4.00"));
        orderItem.setQuantityReceived(BigDecimal.ZERO);
        orderItem.setUnitPrice(new BigDecimal("25.00"));
        when(purchaseOrderItemRepository.findByPurchaseOrder_IdOrderByIdAsc(90L))
                .thenReturn(List.of(orderItem));
        when(purchaseOrderItemRepository.lockItem(90L, 91L)).thenReturn(Optional.of(orderItem));
        when(purchaseOrderItemRepository.save(orderItem)).thenReturn(orderItem);
        when(receiptRepository.saveAndFlush(any(PurchaseReceipt.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(stockBalanceRepository.lockPartAtLocation(7L, 3L)).thenReturn(List.of());
        when(stockBalanceRepository.save(any(StockBalance.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(purchaseOrderRepository.save(order)).thenReturn(order);

        var response = service.receiveDelivery(90L,
                new com.autogarage.automotive.dto.ReceivePurchaseOrderRequest(
                        8L, 3L, "DEL-TEST", null,
                        List.of(new com.autogarage.automotive.dto.ReceivePurchaseOrderRequest.PurchaseReceiptLineRequest(
                                91L, new BigDecimal("2"), new BigDecimal("2"), null, null))));

        assertEquals("PARTIALLY_RECEIVED", response.purchaseOrderStatus());
        assertEquals(new BigDecimal("2.00"), response.items().getFirst().quantityAccepted());
        verify(stockBalanceRepository).save(argThat(balance ->
                balance.getQuantityOnHand().compareTo(new BigDecimal("2.00")) == 0));
        verify(stockMovementRepository).save(argThat(movement ->
                "PURCHASE_RECEIPT".equals(movement.getMovementType())
                        && movement.getQuantity().compareTo(new BigDecimal("2.00")) == 0));
    }

    @Test
    void outsidePurchaseOrderUsesRemainingRequisitionQuantityAndCalculatesTotals() {
        Company company = mock(Company.class);
        when(company.getId()).thenReturn(1L);
        when(company.getCurrencyCode()).thenReturn("ZMW");
        Workshop workshop = mock(Workshop.class);
        when(workshop.getId()).thenReturn(2L);
        PartsRequisition requisition = mock(PartsRequisition.class);
        when(requisition.getId()).thenReturn(600L);
        when(requisition.getCompany()).thenReturn(company);
        when(requisition.getWorkshop()).thenReturn(workshop);
        when(requisition.getRequisitionStatus()).thenReturn("SUBMITTED");
        when(requisitionRepository.findByIdForUpdate(600L)).thenReturn(Optional.of(requisition));
        Supplier supplier = mock(Supplier.class);
        when(supplier.getSupplierName()).thenReturn("Local Supplier");
        when(supplierRepository.findByIdAndCompany_IdAndActiveTrue(3L, 1L))
                .thenReturn(Optional.of(supplier));
        Employee buyer = employee(5L, 1L, 2L, "ACTIVE");
        when(employeeRepository.findByIdAndCompanyId(5L, 1L)).thenReturn(Optional.of(buyer));
        Part part = part(7L, 1L, true, "BRK-01", "Brake pad");
        PartsRequisitionItem reqItem = new PartsRequisitionItem();
        reqItem.setId(601L);
        reqItem.setRequisition(requisition);
        reqItem.setPart(part);
        reqItem.setRequestedQuantity(new BigDecimal("5.00"));
        when(requisitionItemRepository.findByIdAndRequisition_Id(601L, 600L))
                .thenReturn(Optional.of(reqItem));
        when(purchaseOrderItemRepository.sumOrderedByRequisitionItem(601L))
                .thenReturn(new BigDecimal("1.00"));
        when(purchaseOrderRepository.saveAndFlush(any(PurchaseOrder.class))).thenAnswer(invocation -> {
            PurchaseOrder saved = invocation.getArgument(0);
            saved.setId(700L);
            return saved;
        });
        when(purchaseOrderItemRepository.save(any(PurchaseOrderItem.class))).thenAnswer(invocation -> {
            PurchaseOrderItem saved = invocation.getArgument(0);
            saved.setId(701L);
            return saved;
        });
        when(purchaseOrderRepository.save(any(PurchaseOrder.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        var response = service.placeOutsideOrder(600L,
                new com.autogarage.automotive.dto.CreatePurchaseOrderRequest(
                        3L, 5L, null, "SUP-REF", "Order remaining shortage",
                        List.of(new com.autogarage.automotive.dto.CreatePurchaseOrderRequest.PurchaseOrderLineRequest(
                                601L, new BigDecimal("2"), new BigDecimal("25"), new BigDecimal("5")))));

        assertEquals(700L, response.purchaseOrderId());
        assertEquals("SENT_TO_SUPPLIER", response.status());
        assertEquals(new BigDecimal("50.00"), response.subtotal());
        assertEquals(new BigDecimal("5.00"), response.taxAmount());
        assertEquals(new BigDecimal("55.00"), response.totalAmount());
        assertEquals(new BigDecimal("2.00"), response.items().getFirst().quantityOrdered());
    }

    private String captureSavedRequisitionPriority() {
        var captured = org.mockito.ArgumentCaptor.forClass(PartsRequisition.class);
        verify(requisitionRepository).saveAndFlush(captured.capture());
        return captured.getValue().getPriority();
    }

    private JobCard card(Long cardId, Long jobId, Long companyId, Long workshopId) {
        JobCard card = mock(JobCard.class);
        Job job = mock(Job.class);
        Company company = mock(Company.class);
        Workshop workshop = mock(Workshop.class);
        when(card.getId()).thenReturn(cardId);
        when(card.getJob()).thenReturn(job);
        when(job.getId()).thenReturn(jobId);
        when(job.getJobNumber()).thenReturn("JOB-TEST-" + jobId);
        when(job.getCompany()).thenReturn(company);
        when(job.getWorkshop()).thenReturn(workshop);
        when(company.getId()).thenReturn(companyId);
        when(workshop.getId()).thenReturn(workshopId);
        return card;
    }

    private Part part(Long id, Long companyId, boolean active, String code, String name) {
        Part part = mock(Part.class);
        Company company = mock(Company.class);
        when(part.getId()).thenReturn(id);
        when(part.getCompany()).thenReturn(company);
        when(company.getId()).thenReturn(companyId);
        when(part.getActive()).thenReturn(active);
        when(part.getPartCode()).thenReturn(code);
        when(part.getPartName()).thenReturn(name);
        return part;
    }

    private Employee employee(Long id, Long companyId, Long workshopId, String status) {
        Employee employee = mock(Employee.class);
        Company company = mock(Company.class);
        Workshop workshop = mock(Workshop.class);
        when(employee.getId()).thenReturn(id);
        when(employee.getCompany()).thenReturn(company);
        when(employee.getWorkshop()).thenReturn(workshop);
        when(employee.getEmploymentStatus()).thenReturn(status);
        when(company.getId()).thenReturn(companyId);
        when(workshop.getId()).thenReturn(workshopId);
        return employee;
    }

    private JobCardPart requirement(Long id, Part part, String category, String name, String quantity) {
        JobCardPart requirement = mock(JobCardPart.class);
        when(requirement.getId()).thenReturn(id);
        when(requirement.getPart()).thenReturn(part);
        when(requirement.getPartCategory()).thenReturn(category);
        when(requirement.getPartName()).thenReturn(name);
        when(requirement.getQuantity()).thenReturn(new BigDecimal(quantity));
        return requirement;
    }
}
