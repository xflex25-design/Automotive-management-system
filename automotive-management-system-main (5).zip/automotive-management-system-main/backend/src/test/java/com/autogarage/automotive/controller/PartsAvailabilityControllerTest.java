package com.autogarage.automotive.controller;

import com.autogarage.automotive.dto.*;
import com.autogarage.automotive.service.PartsAvailabilityService;
import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

class PartsAvailabilityControllerTest {
    private PartsAvailabilityService service;
    private MockMvc mockMvc;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        service = mock(PartsAvailabilityService.class);
        mockMvc = MockMvcBuilders.standaloneSetup(new PartsAvailabilityController(service)).build();
        objectMapper = new ObjectMapper();
    }

    @Test
    void getAvailabilityIsMappedToTheJobCardPartsRoute() throws Exception {
        when(service.checkAvailability(40L)).thenReturn(
                new PartsAvailabilityResponse(400L, "JOB-400", 40L, List.of()));

        var result = mockMvc.perform(get("/api/job-cards/40/parts/availability"))
                .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        verify(service).checkAvailability(40L);
    }

    @Test
    void patchCatalogPartAcceptsTheLinkRequest() throws Exception {
        when(service.linkCatalogPart(eq(40L), eq(101L), any(LinkJobCardPartRequest.class)))
                .thenReturn(new LinkJobCardPartResponse(40L, 101L, 7L,
                        "BRK-01", "Brake pad", "Alex Foreman", null));

        var result = mockMvc.perform(patch("/api/job-cards/40/parts/101/catalog-part")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(
                                new LinkJobCardPartRequest(7L, 5L))))
                .andReturn();

        assertEquals(200, result.getResponse().getStatus());
        verify(service).linkCatalogPart(eq(40L), eq(101L), any(LinkJobCardPartRequest.class));
    }

    @Test
    void postRequisitionUsesTheJobPartsRouteAndCreatedStatus() throws Exception {
        when(service.createShortageRequisition(eq(400L), any(CreatePartsRequisitionRequest.class)))
                .thenReturn(new PartsRequisitionResponse(500L, "PR-500", 400L,
                        "SUBMITTED", null, List.of()));

        var result = mockMvc.perform(post("/api/jobs/400/parts/requisitions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"requestedByEmployeeId":5,"priority":"HIGH","purpose":"Shortage"}
                                """))
                .andReturn();

        assertEquals(201, result.getResponse().getStatus());
        verify(service).createShortageRequisition(eq(400L), any(CreatePartsRequisitionRequest.class));
    }

    @Test
    void postPurchaseOrderUsesTheRequisitionRouteAndCreatedStatus() throws Exception {
        when(service.placeOutsideOrder(eq(500L), any(CreatePurchaseOrderRequest.class)))
                .thenReturn(new PurchaseOrderResponse(700L, "PO-700", "SENT_TO_SUPPLIER",
                        "Local Supplier", null, BigDecimal.ZERO, BigDecimal.ZERO,
                        BigDecimal.ZERO, List.of()));

        var result = mockMvc.perform(post("/api/parts/requisitions/500/purchase-orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"supplierId":3,"createdByEmployeeId":5,"items":[{"requisitionItemId":601,"quantityOrdered":2,"unitPrice":25.00,"taxAmount":0.00}]}
                                """))
                .andReturn();

        assertEquals(201, result.getResponse().getStatus());
        verify(service).placeOutsideOrder(eq(500L), any(CreatePurchaseOrderRequest.class));
    }

    @Test
    void postReceiptUsesThePurchaseOrderRouteAndCreatedStatus() throws Exception {
        when(service.receiveDelivery(eq(700L), any(ReceivePurchaseOrderRequest.class)))
                .thenReturn(new PurchaseReceiptResponse(800L, "GRN-800", 700L,
                        "PARTIALLY_RECEIVED", null, List.of()));

        var result = mockMvc.perform(post("/api/parts/purchase-orders/700/receipts")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"receivedByEmployeeId":8,"stockLocationId":3,"items":[{"purchaseOrderItemId":701,"quantityDelivered":2,"quantityAccepted":2,"unitCost":25.00}]}
                                """))
                .andReturn();

        assertEquals(201, result.getResponse().getStatus());
        verify(service).receiveDelivery(eq(700L), any(ReceivePurchaseOrderRequest.class));
    }
}
