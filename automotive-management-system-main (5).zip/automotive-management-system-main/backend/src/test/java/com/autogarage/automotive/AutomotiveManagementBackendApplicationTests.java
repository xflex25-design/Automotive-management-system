package com.autogarage.automotive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomotiveManagementBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
