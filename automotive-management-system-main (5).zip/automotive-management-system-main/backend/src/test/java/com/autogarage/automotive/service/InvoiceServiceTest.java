package com.autogarage.automotive.service;

import com.autogarage.automotive.dto.invoice.CreateInvoiceRequest;
import com.autogarage.automotive.entity.*;
import com.autogarage.automotive.repository.*;
import com.autogarage.automotive.security.WorkshopPrincipal;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class InvoiceServiceTest {
    private InvoiceRepository invoiceRepository;
    private InvoiceItemRepository invoiceItemRepository;
    private JobRepository jobRepository;
    private FinalInspectionRepository finalInspectionRepository;
    private QuotationRepository quotationRepository;
    private QuotationItemRepository quotationItemRepository;
    private EmployeeRepository employeeRepository;
    private InvoiceService service;

    @BeforeEach
    void setUp() {
        WorkshopPrincipal principal = new WorkshopPrincipal(
                5L,
                5L,
                1L,
                2L,
                "Alex Foreman",
                "alex@example.test",
                "{noop}test",
                true,
                false,
                List.of(new SimpleGrantedAuthority("ROLE_FOREMAN"))
        );
        SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
        securityContext.setAuthentication(
                new UsernamePasswordAuthenticationToken(
                        principal, principal.getPassword(), principal.getAuthorities())
        );
        SecurityContextHolder.setContext(securityContext);

        invoiceRepository = mock(InvoiceRepository.class);
        invoiceItemRepository = mock(InvoiceItemRepository.class);
        jobRepository = mock(JobRepository.class);
        finalInspectionRepository = mock(FinalInspectionRepository.class);
        quotationRepository = mock(QuotationRepository.class);
        quotationItemRepository = mock(QuotationItemRepository.class);
        employeeRepository = mock(EmployeeRepository.class);
        service = new InvoiceService(
                invoiceRepository,
                invoiceItemRepository,
                jobRepository,
                finalInspectionRepository,
                quotationRepository,
                quotationItemRepository,
                employeeRepository
        );
    }

    @AfterEach
    void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void issuedQuotationCanBeInvoicedWithoutPerQuotationCustomerApproval() {
        Company company = mock(Company.class);
        when(company.getId()).thenReturn(1L);
        Workshop workshop = mock(Workshop.class);
        when(workshop.getId()).thenReturn(2L);
        Customer customer = mock(Customer.class);
        when(customer.getCustomerType()).thenReturn("INDIVIDUAL");
        when(customer.getFirstName()).thenReturn("Alex");
        when(customer.getLastName()).thenReturn("Customer");
        when(customer.getPhone()).thenReturn("0977000000");

        Job job = mock(Job.class);
        when(job.getId()).thenReturn(40L);
        when(job.getCompany()).thenReturn(company);
        when(job.getWorkshop()).thenReturn(workshop);
        when(job.getCustomer()).thenReturn(customer);
        when(job.getCustomerNameSnapshot()).thenReturn("Alex Customer");
        when(job.getJobStatus()).thenReturn("READY_FOR_INVOICING");
        when(jobRepository.findByIdForUpdate(40L)).thenReturn(Optional.of(job));

        FinalInspection inspection = mock(FinalInspection.class);
        when(inspection.getInspectionStatus()).thenReturn("COMPLETED");
        when(inspection.getInspectionDecision()).thenReturn("PASS");
        when(finalInspectionRepository.findFirstByJob_IdOrderByStartedAtDesc(40L))
                .thenReturn(Optional.of(inspection));

        Quotation quotation = mock(Quotation.class);
        when(quotation.getId()).thenReturn(50L);
        when(quotation.getJob()).thenReturn(job);
        when(quotation.getQuotationStatus()).thenReturn("ISSUED");
        when(quotation.getCurrencyCode()).thenReturn("ZMW");
        when(quotationRepository.findByIdForUpdate(50L)).thenReturn(Optional.of(quotation));
        when(invoiceRepository.findByQuotation_Id(50L)).thenReturn(Optional.empty());

        Employee employee = mock(Employee.class);
        when(employee.getEmploymentStatus()).thenReturn("ACTIVE");
        when(employee.getWorkshop()).thenReturn(workshop);
        when(employeeRepository.findByIdAndCompanyId(5L, 1L)).thenReturn(Optional.of(employee));

        QuotationItem item = new QuotationItem();
        item.setQuotation(quotation);
        item.setItemType("PART");
        item.setDescription("Brake pads");
        item.setQuantity(new BigDecimal("2"));
        item.setUnitOfMeasure("UNIT");
        item.setUnitPrice(new BigDecimal("100"));
        item.setDiscountAmount(BigDecimal.ZERO);
        item.setTaxAmount(new BigDecimal("16"));
        when(quotationItemRepository.findByQuotationIdOrderByIdAsc(50L)).thenReturn(List.of(item));
        when(invoiceRepository.save(any(Invoice.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(invoiceItemRepository.save(any(InvoiceItem.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        Invoice invoice = service.createInvoice(new CreateInvoiceRequest(
                40L, 50L, 5L, null, null));

        assertEquals(new BigDecimal("200.00"), invoice.getSubtotal());
        assertEquals(new BigDecimal("16.00"), invoice.getTaxAmount());
        assertEquals(new BigDecimal("216.00"), invoice.getTotalAmount());
        verify(invoiceItemRepository).save(any(InvoiceItem.class));
    }
}
