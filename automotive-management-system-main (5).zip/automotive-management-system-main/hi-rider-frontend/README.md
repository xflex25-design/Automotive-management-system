# Hi-Rider Workshop Frontend

This React/TanStack Start frontend connects to the Spring Boot API in `../backend`.
The frontend reads and writes workshop records through the API; it does not connect
to MySQL directly.

## Run locally on Windows

1. Start MySQL on port `3307` and start the Spring Boot backend on port `8080`.
2. Open PowerShell in this `hi-rider-frontend` folder and run:

   ```powershell
   npm install
   npm run dev
   ```

3. Open `http://localhost:3000` and sign in with an active workshop user account.

Vite proxies frontend requests from `/backend-api` to `http://localhost:8080`.
To use a different API address, copy `.env.example` to `.env.local` and update
`VITE_API_URL`; restart the dev server after changing it. The API base URL is not
a secret. Do not put database passwords or API user credentials in frontend
environment files.

The sign-in form authenticates against `GET /api/auth/me` using the workshop
account's email or username and password. The browser keeps the Basic Auth
credential in memory only and clears it on sign-out, reload, or an unauthorized
response. Workshop/company/employee IDs come from the authenticated identity;
they are not configured in the frontend.

The backend must have an active user linked to an employee, workshop, and company.
See `../backend/DATABASE-SETUP.md` for database setup and account requirements.

## Production

Set `VITE_API_URL` to the deployed API origin when building the frontend. Configure
the backend's `FRONTEND_ORIGINS` to the frontend's exact HTTPS origin. Use HTTPS
for Basic Auth credentials outside local development.
