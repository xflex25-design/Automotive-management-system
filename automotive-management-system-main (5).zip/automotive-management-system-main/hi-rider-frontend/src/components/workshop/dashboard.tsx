import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  ArrowUpRight,
  Plus,
  SlidersHorizontal,
  ClipboardList,
  Package,
  Wrench,
  ShieldCheck,
  Clock,
  FileText,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useWorkspace } from "./workspace-context";
import {
  PageHeading,
  SectionHeading,
  Metrics,
  metricIcons,
  DataTable,
  VehicleCell,
  Status,
  ProgressBar,
  LineChart,
  ExportButton,
  DateFilter,
  TableFooter,
  ViewAllVehicles,
} from "./shared";
import { VehicleDetail } from "./vehicle-detail";
import { canApproveDispatch, workflowStages } from "@/lib/workshop";
import { getApiIdentity } from "@/lib/api";

export function DepartmentCards() {
  const { workflows, loading } = useWorkspace();
  const departments = useMemo(() => {
    const orders = workflows.flatMap((plan) =>
      Array.isArray(plan["workOrders"]) ? (plan["workOrders"] as Record<string, unknown>[]) : [],
    );
    const grouped = new Map<string, Record<string, unknown>[]>();
    for (const order of orders) {
      const name = String(order["departmentName"] ?? "Unassigned");
      grouped.set(name, [...(grouped.get(name) ?? []), order]);
    }
    return Array.from(grouped, ([name, rows]) => {
      const completed = rows.filter((row) =>
        ["COMPLETED", "CONFIRMED"].includes(String(row["status"]).toUpperCase()),
      ).length;
      return {
        name,
        active: rows.length - completed,
        completed,
        pending: rows.filter((row) =>
          ["READY", "BLOCKED"].includes(String(row["status"]).toUpperCase()),
        ).length,
        efficiency: rows.length ? Math.round((completed / rows.length) * 100) : 0,
      };
    });
  }, [workflows]);
  if (!departments.length) {
    return (
      <div className="empty-state">
        {loading ? "Loading workshop records…" : "No department work orders yet."}
      </div>
    );
  }
  return (
    <div className="department-grid">
      {departments.map((dept) => (
        <div className="department-card" key={dept.name}>
          <div className="flex items-center gap-2">
            <Wrench size={14} className="text-primary" />
            <h3>{dept.name}</h3>
          </div>
          <div className="dept-count">
            {dept.active}
            <span className="text-[10px] text-muted-foreground font-normal ml-2">active jobs</span>
          </div>
          <p>
            {dept.completed} completed · {dept.pending} pending
          </p>
          <ProgressBar value={dept.efficiency} />
          <div className="flex justify-between mt-2 text-[10px] text-muted-foreground">
            <span>Completion rate</span>
            <span>{dept.efficiency}%</span>
          </div>
        </div>
      ))}
    </div>
  );
}

export function Dashboard() {
  const w = useWorkspace();
  const role = w.role;
  const {
    vehicles,
    jobs,
    requisitions,
    inspections,
    activities,
    foreman,
    dispatches,
    invoices,
    handovers,
    loading,
    error,
    workflowOptions,
    api,
    refresh,
  } = w;
  const [period, setPeriod] = useState("This week");
  const [detail, setDetail] = useState<string | null>(null);
  const [stageFilter, setStageFilter] = useState(false);
  const [approvingDispatch, setApprovingDispatch] = useState<number | null>(null);
  const pending = requisitions.filter((r) => r.status === "Pending").length;
  const isForeman = role === "Foreman";
  const isManagement = canApproveDispatch(role);
  const employeeId = getApiIdentity()?.employeeId ?? 0;
  const employeeName = getApiIdentity()?.displayName ?? "";
  const shownVehicles = vehicles
    .filter((vehicle) => {
      if (stageFilter) {
        return jobs.some(
          (job) =>
            job.vehicleId === vehicle.id &&
            !["COMPLETED", "CANCELLED"].includes(job.status.toUpperCase()),
        );
      }
      return true;
    })
    .slice(0, 5);
  const activeJobs = jobs.filter(
    (job) => !["COMPLETED", "CANCELLED", "CLOSED"].includes(job.status.toUpperCase()),
  ).length;
  const pendingDispatches = dispatches.filter(
    (dispatch) => String(dispatch["status"]).toUpperCase() === "PENDING_APPROVAL",
  );
  const awaitingRelease = invoices.filter(
    (invoice) =>
      Number(invoice["balanceDue"] ?? 0) <= 0 &&
      !handovers.some((handover) => Number(handover["jobId"]) === Number(invoice["jobId"])),
  ).length;
  const trend = useMemo(() => {
    const now = new Date();
    const parsed = (value: string) => {
      const numeric = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
      if (numeric) return new Date(Number(numeric[3]), Number(numeric[2]) - 1, Number(numeric[1]));
      const date = new Date(value);
      return Number.isNaN(date.getTime()) ? null : date;
    };
    const points = Array.from({ length: 6 }, (_, index) => {
      const date = new Date(now);
      if (period === "This week") date.setDate(now.getDate() - (5 - index));
      else date.setDate(now.getDate() - (5 - index) * 7);
      date.setHours(0, 0, 0, 0);
      const next = new Date(date);
      if (period !== "This week") next.setDate(next.getDate() + 7);
      else next.setDate(next.getDate() + 1);
      const count = vehicles.filter((vehicle) => {
        const received = parsed(vehicle.received);
        return received && received >= date && received < next;
      }).length;
      return {
        label:
          period === "This week"
            ? new Intl.DateTimeFormat(undefined, { weekday: "short" }).format(date)
            : new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(date),
        count,
      };
    });
    return points;
  }, [period, vehicles]);
  const stageCounts = workflowStages
    .map((name, stage) => ({
      name,
      value: vehicles.filter((vehicle) => vehicle.stage === stage).length,
    }))
    .filter((item) => item.value > 0);
  const heading = isForeman ? "Foreman Dashboard" : `${role} Dashboard`;
  const subtitle = isForeman
    ? `Intake & workshop control · ${foreman}`
    : "Workshop operations & workflow oversight";
  const metrics = isForeman
    ? [
        {
          label: "Vehicles received",
          value: vehicles.length,
          note: "Backend vehicle records",
          icon: metricIcons.Car,
        },
        {
          label: "Active job cards",
          value: activeJobs,
          note: "Open backend job cards",
          icon: metricIcons.Wrench,
        },
        {
          label: "Awaiting parts",
          value: requisitions.filter((request) =>
            ["Pending", "Approved", "Ordered"].includes(request.status),
          ).length,
          note: "Parts requested for workshop jobs",
          icon: metricIcons.Package,
        },
        {
          label: "Ready for inspection",
          value: inspections.filter((inspection) => inspection.result === "Pending").length,
          note: "Backend inspections in progress",
          icon: metricIcons.ClipboardCheck,
        },
      ]
    : [
        {
          label: "Total vehicles",
          value: vehicles.length,
          note: "Backend vehicle records",
          icon: metricIcons.Car,
        },
        {
          label: "Currently in repair",
          value: activeJobs,
          note: "Open backend job cards",
          icon: metricIcons.Wrench,
        },
        {
          label: "Open parts requests",
          value: requisitions.filter((request) =>
            ["Pending", "Approved", "Ordered"].includes(request.status),
          ).length,
          note: "Purchase and receiving progress",
          icon: metricIcons.Package,
        },
        {
          label: "Awaiting release",
          value: awaitingRelease,
          note: "Paid invoices awaiting handover",
          icon: metricIcons.ClipboardCheck,
        },
      ];
  return (
    <>
      <PageHeading title={heading} subtitle={subtitle}>
        <Button variant="outline" asChild>
          <Link to="/departments">
            <Wrench />
            Department workload
          </Link>
        </Button>
        {isForeman && (
          <Button asChild>
            <Link to="/registration">
              <Plus />
              Register vehicle
            </Link>
          </Button>
        )}
      </PageHeading>
      {error && (
        <div className="attention-band">
          <div>
            <strong>Workshop records could not be loaded</strong>
            <p>{error}</p>
          </div>
          <Button variant="outline" onClick={() => void refresh()}>
            Retry
          </Button>
        </div>
      )}
      <Metrics items={metrics} />
      <div className="attention-band">
        {isManagement ? <ShieldCheck size={18} /> : <Clock size={18} />}
        <div>
          <strong>
            {isManagement
              ? "Dispatch orders await manager or boss approval"
              : "Keep the workshop moving"}
          </strong>
          <p>
            {isManagement
              ? `${pendingDispatches.length} dispatches are waiting for your decision.`
              : "Review workshop records and open parts requests."}
          </p>
        </div>
        {isManagement ? (
          <Button
            variant="link"
            size="sm"
            className="band-action"
            onClick={() =>
              document.getElementById("dispatch-approvals")?.scrollIntoView({ behavior: "smooth" })
            }
          >
            Approve dispatches <ArrowRight size={13} />
          </Button>
        ) : (
          <Button variant="link" size="sm" className="band-action" asChild>
            <Link to="/requisitions">
              View parts requests
              <ArrowRight size={13} />
            </Link>
          </Button>
        )}
      </div>
      <div className="overview-grid">
        <section className="overview-section">
          <SectionHeading
            title="Vehicle intake"
            subtitle={
              period === "This week"
                ? "Vehicle intake · last 6 days"
                : "Vehicle intake · last 6 weeks"
            }
          >
            <DateFilter value={period} onChange={setPeriod} />
          </SectionHeading>
          {loading && vehicles.length === 0 ? (
            <div className="empty-state">Loading vehicle records…</div>
          ) : vehicles.length === 0 ? (
            <div className="empty-state">No vehicle intake records yet.</div>
          ) : (
            <LineChart
              values={trend.map((point) => point.count)}
              labels={trend.map((point) => point.label)}
            />
          )}
          <div className="flex justify-between items-center mt-2">
            <div className="chart-key">
              <span />
              Vehicles received
            </div>
            <span className="text-[11px] text-muted-foreground">
              {trend.reduce((total, point) => total + point.count, 0)} in this period
            </span>
          </div>
        </section>
        <section className="overview-section">
          <SectionHeading title="Workshop at a glance" subtitle="Current vehicle distribution">
            <Button asChild variant="link" size="sm">
              <Link to="/workflow">
                View workflow
                <ArrowUpRight size={13} />
              </Link>
            </Button>
          </SectionHeading>
          {stageCounts.length ? (
            stageCounts.map((item) => (
              <div className="stage-row" key={item.name}>
                <span>{item.name}</span>
                <ProgressBar value={vehicles.length ? (item.value / vehicles.length) * 100 : 0} />
                <strong>{item.value}</strong>
              </div>
            ))
          ) : (
            <div className="empty-state">No vehicle workflow records yet.</div>
          )}
        </section>
      </div>
      <section className="table-section">
        <SectionHeading title="Recent vehicles" subtitle="Latest intake and workshop activity">
          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setStageFilter((v) => !v)}
              aria-pressed={stageFilter}
            >
              <SlidersHorizontal />
              {stageFilter ? "All vehicles" : "In repair"}
            </Button>
            <ExportButton filename="workshop-overview" rows={vehicles} />
            <ViewAllVehicles />
          </div>
        </SectionHeading>
        <DataTable
          headers={["Vehicle", "Customer", "Received", "Current stage", "Department", ""]}
          empty={shownVehicles.length === 0}
        >
          {shownVehicles.map((vehicle) => (
            <tr key={vehicle.id}>
              <td>
                <VehicleCell vehicle={vehicle} />
              </td>
              <td>{vehicle.customer}</td>
              <td className="text-muted-foreground">{vehicle.received.replace(" 2026", "")}</td>
              <td>
                <Status>
                  {
                    [
                      "Intake",
                      "Quotation",
                      "Awaiting approval",
                      "Inventory card",
                      "Job card",
                      "Parts requisition",
                      "Awaiting parts",
                      "Procurement",
                      "Parts dispatch",
                      "In repair",
                      "Inspection",
                      "Awaiting release",
                    ][vehicle.stage]
                  }
                </Status>
              </td>
              <td>{vehicle.department}</td>
              <td>
                <Button
                  variant="ghost"
                  size="icon"
                  title={`View ${vehicle.plate}`}
                  aria-label={`View ${vehicle.plate}`}
                  onClick={() => setDetail(vehicle.id)}
                >
                  <ArrowUpRight />
                </Button>
              </td>
            </tr>
          ))}
        </DataTable>
        <TableFooter count={shownVehicles.length} label="recent vehicles" />
      </section>
      {isManagement && (
        <section className="table-section" id="dispatch-approvals">
          <SectionHeading
            title="Parts dispatch approvals"
            subtitle="Approve dispatch orders before issue"
          >
            <Button variant="outline" size="sm" onClick={() => void refresh()}>
              Refresh
            </Button>
          </SectionHeading>
          <DataTable
            headers={["Dispatch", "Job", "Department", "Status", "Action"]}
            empty={!pendingDispatches.length}
          >
            {pendingDispatches.map((dispatch) => {
              const dispatchId = Number(dispatch["dispatchOrderId"] ?? dispatch["id"]);
              const jobId = Number(dispatch["jobId"]);
              const job = jobs.find((candidate) => candidate.backendJobId === jobId);
              const vehicle = job
                ? vehicles.find((candidate) => candidate.id === job.vehicleId)
                : undefined;
              return (
                <tr key={dispatchId}>
                  <td className="cell-title">{String(dispatch["dispatchNumber"] ?? dispatchId)}</td>
                  <td>
                    {vehicle
                      ? `${vehicle.plate} · ${vehicle.customer}`
                      : String(dispatch["jobNumber"] ?? jobId)}
                  </td>
                  <td>{String(dispatch["departmentName"] ?? "—")}</td>
                  <td>
                    <Status>{String(dispatch["status"] ?? "Pending")}</Status>
                  </td>
                  <td>
                    <Button
                      size="sm"
                      disabled={approvingDispatch === dispatchId}
                      onClick={async () => {
                        if (!Number.isSafeInteger(employeeId) || employeeId <= 0) {
                          toast.error(
                            "Your signed-in account must be linked to an active employee before approving dispatches.",
                          );
                          return;
                        }
                        setApprovingDispatch(dispatchId);
                        try {
                          await api.dispatchAction(dispatchId, "approve", {
                            approvedByEmployeeId: employeeId,
                            signerName: employeeName,
                            remarks: "Approved from Management dashboard",
                          });
                          await refresh();
                          toast.success("Dispatch approved.");
                        } catch (approvalError) {
                          toast.error(
                            approvalError instanceof Error
                              ? approvalError.message
                              : "Could not approve dispatch.",
                          );
                        } finally {
                          setApprovingDispatch(null);
                        }
                      }}
                    >
                      Approve
                    </Button>
                  </td>
                </tr>
              );
            })}
          </DataTable>
        </section>
      )}
      <section>
        <SectionHeading
          title="Department workload"
          subtitle="Work coordinated by foremen, across the workshop"
        >
          <Button asChild variant="link" size="sm">
            <Link to="/departments">
              View performance
              <ArrowUpRight size={13} />
            </Link>
          </Button>
        </SectionHeading>
        <DepartmentCards />
      </section>
      {!isForeman && (
        <div className="overview-grid mt-7">
          <section>
            <SectionHeading title="Recent activity" />
            {activities.slice(0, 3).map((a, i) => (
              <div className="activity-row" key={i}>
                <ClipboardList />
                <div className="flex-1">
                  <p>{a.text}</p>
                  <small>{a.detail}</small>
                </div>
                <small>{a.time}</small>
              </div>
            ))}
          </section>
          <section>
            <SectionHeading title="Operational priorities" />
            {[
              {
                icon: Clock,
                count: pending,
                label: "submitted shortage requests",
                detail: "Ready to order from a supplier",
              },
              {
                icon: Package,
                count: pendingDispatches.length,
                label: "dispatches pending approval",
                detail: "Awaiting management decision",
              },
              {
                icon: FileText,
                count: awaitingRelease,
                label: "vehicles awaiting handover",
                detail: "Paid invoices without a recorded handover",
              },
            ]
              .filter((priority) => priority.count > 0)
              .map((priority) => {
                const Icon = priority.icon;
                return (
                  <div className="activity-row" key={priority.label}>
                    <Icon />
                    <div>
                      <p>
                        {priority.count} {priority.label}
                      </p>
                      <small>{priority.detail}</small>
                    </div>
                  </div>
                );
              })}
            {!pending && !pendingDispatches.length && !awaitingRelease && (
              <div className="empty-state">No outstanding priorities.</div>
            )}
          </section>
        </div>
      )}
      <VehicleDetail id={detail} onClose={() => setDetail(null)} />
    </>
  );
}
