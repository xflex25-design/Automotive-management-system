import { useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import {
  ArrowUpRight,
  Search,
  Plus,
  Check,
  ShieldCheck,
  Clock,
  Package,
  FileText,
  Download,
  Wrench,
  ArrowRight,
  Save,
  Truck,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectTrigger,
  SelectContent,
  SelectValue,
  SelectItem,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useWorkspace } from "./workspace-context";
import {
  PageHeading,
  SectionHeading,
  Metrics,
  metricIcons,
  DataTable,
  VehicleCell,
  Status,
  TableFooter,
  ProgressBar,
  Workflow,
  ExportButton,
  exportCsv,
} from "./shared";
import { DepartmentCards } from "./dashboard";
import { VehicleDetail } from "./vehicle-detail";
import {
  workflowStages,
  departmentStats,
  canAuthorizeRelease,
  canApproveDispatch,
  money,
} from "@/lib/workshop";
import { getApiIdentity, type WorkOrderReminder } from "@/lib/api";

export function VehiclesPage() {
  const w = useWorkspace();
  const [query, setQuery] = useState("");
  const [stage, setStage] = useState("All");
  const [detail, setDetail] = useState<string | null>(null);
  const [release, setRelease] = useState<string | null>(null);
  const filtered = w.vehicles.filter(
    (v) =>
      `${v.make} ${v.id} ${v.plate} ${v.customer}`
        .toLowerCase()
        .includes(`${query} ${w.search}`.trim().toLowerCase()) &&
      (stage === "All" || String(v.stage) === stage),
  );
  return (
    <>
      <PageHeading
        title="Vehicle Records"
        subtitle="Complete vehicle history, customer details and workshop records"
      >
        <ExportButton filename="vehicle-records" rows={w.vehicles} />
        {w.role === "Foreman" && (
          <Button asChild>
            <Link to="/registration">
              <Plus />
              Register vehicle
            </Link>
          </Button>
        )}
      </PageHeading>
      <div className="toolbar">
        <div className="filter-search">
          <Search />
          <Input
            aria-label="Search vehicle records"
            placeholder="Search vehicle, registration or customer..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <Select value={stage} onValueChange={setStage}>
          <SelectTrigger className="w-[220px]" aria-label="Filter workflow stage">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="All">All workflow stages</SelectItem>
            {workflowStages.map((s, i) => (
              <SelectItem key={s} value={String(i)}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <DataTable
        headers={["Vehicle", "Customer", "Received", "Current stage", "Foreman", "Actions"]}
        empty={filtered.length === 0}
      >
        {filtered.map((v) => (
          <tr key={v.id}>
            <td>
              <VehicleCell vehicle={v} />
            </td>
            <td>{v.customer}</td>
            <td>{v.received}</td>
            <td>
              <Status>{v.released ? "Released" : (workflowStages[v.stage] ?? "Intake")}</Status>
            </td>
            <td>{v.foreman}</td>
            <td>
              <div className="flex gap-2">
                {v.stage === 11 && !v.released && canAuthorizeRelease(w.role) && (
                  <Button variant="outline" size="sm" onClick={() => setRelease(v.id)}>
                    Authorize release
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  title={`View ${v.plate}`}
                  aria-label={`View ${v.plate}`}
                  onClick={() => setDetail(v.id)}
                >
                  <ArrowUpRight />
                </Button>
              </div>
            </td>
          </tr>
        ))}
      </DataTable>
      <TableFooter count={filtered.length} label="vehicles" />
      <VehicleDetail id={detail} onClose={() => setDetail(null)} />
      <Dialog
        open={!!release}
        onOpenChange={(o) => {
          if (!o) setRelease(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Invoice & vehicle release</DialogTitle>
            <DialogDescription>
              Management final authorization · {release && w.vehicleFor(release)?.plate}
            </DialogDescription>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!release || !canAuthorizeRelease(w.role)) return;
              const data = new FormData(e.currentTarget);
              w.setVehicles((prev) =>
                prev.map((v) => (v.id === release ? { ...v, released: true } : v)),
              );
              w.addActivity(
                "Vehicle release authorized",
                `${release} · Invoice ${String(data.get("invoice"))}`,
              );
              toast.success("Final release authorized and invoice reference recorded.");
              setRelease(null);
            }}
          >
            <label className="field">
              <span>Invoice reference *</span>
              <Input required name="invoice" placeholder="e.g. INV-2026-1042" />
            </label>
            <label className="flex items-center gap-3 text-xs mt-5">
              <input type="checkbox" required />
              Inspection passed and final release approved by management
            </label>
            <div className="flex justify-end mt-5">
              <Button type="submit">
                <Check />
                Authorize release
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}

export function ApprovalPage() {
  const w = useWorkspace();
  const [filter, setFilter] = useState("PENDING_APPROVAL");
  const [selected, setSelected] = useState<Record<string, unknown> | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const [saving, setSaving] = useState(false);
  const authority = canApproveDispatch(w.role);
  const pending = w.dispatches.filter(
    (dispatch) => String(dispatch["status"]).toUpperCase() === "PENDING_APPROVAL",
  );
  const shown = w.dispatches.filter((dispatch) => {
    const status = String(dispatch["status"] ?? "").toUpperCase();
    const job = w.jobs.find((item) => item.backendJobId === Number(dispatch["jobId"]));
    const vehicle = job && w.vehicleFor(job.vehicleId);
    return (
      (filter === "ALL" || status === filter) &&
      `${dispatch["dispatchNumber"]} ${dispatch["jobId"]} ${vehicle?.plate ?? ""} ${vehicle?.customer ?? ""}`
        .toLowerCase()
        .includes(w.search.toLowerCase())
    );
  });
  async function decide(approved: boolean) {
    if (!selected || !authority) return;
    const actor = getApiIdentity();
    const dispatchId = Number(selected["dispatchOrderId"]);
    if (!actor?.employeeId || !dispatchId) {
      toast.error("Sign in with an active workshop employee account to decide dispatch orders.");
      return;
    }
    if (!approved && !rejectionReason.trim()) {
      toast.error("Enter a reason for rejecting this dispatch order.");
      return;
    }
    setSaving(true);
    try {
      const payload = approved
        ? {
            approvedByEmployeeId: actor.employeeId,
            signerName: actor.displayName,
            remarks: "Approved from dispatch approvals",
          }
        : {
            rejectedByEmployeeId: actor.employeeId,
            signerName: actor.displayName,
            reason: rejectionReason.trim(),
          };
      await w.api.dispatchAction(dispatchId, approved ? "approve" : "reject", payload);
      await w.refresh();
      setSelected(null);
      setRejectionReason("");
      toast.success(approved ? "Dispatch order approved." : "Dispatch order rejected.");
    } catch (cause) {
      toast.error(cause instanceof Error ? cause.message : "Could not save the dispatch decision.");
    } finally {
      setSaving(false);
    }
  }
  return (
    <>
      <PageHeading
        title="Dispatch Order Approvals"
        subtitle="Managers and the boss review foreman-prepared dispatch orders before stores issues parts."
      >
        <ExportButton filename="dispatch-approvals" rows={w.dispatches} />
      </PageHeading>
      <div className="attention-band">
        <ShieldCheck size={22} />
        <div>
          <strong>{pending.length} dispatch orders are waiting for approval</strong>
          <p>
            {authority
              ? "Approve or reject each dispatch order before stores issues the parts."
              : "Only an account with Manager or Boss authority can approve or reject dispatch orders."}
          </p>
        </div>
      </div>
      <Metrics
        items={[
          {
            label: "Awaiting approval",
            value: pending.length,
            note: "Foreman-submitted dispatches",
            icon: metricIcons.Clock,
          },
          {
            label: "Approved",
            value: w.dispatches.filter(
              (dispatch) => String(dispatch["status"]).toUpperCase() === "APPROVED",
            ).length,
            note: "Ready for stores to issue",
            icon: metricIcons.ClipboardCheck,
          },
          {
            label: "Rejected",
            value: w.dispatches.filter(
              (dispatch) => String(dispatch["status"]).toUpperCase() === "REJECTED",
            ).length,
            note: "Returned for correction",
            icon: metricIcons.FileText,
          },
          {
            label: "Issued / received",
            value: w.dispatches.filter((dispatch) =>
              ["ISSUED", "RECEIVED"].includes(String(dispatch["status"]).toUpperCase()),
            ).length,
            note: "Parts sent to a department",
            icon: metricIcons.Package,
          },
        ]}
      />
      <div className="toolbar">
        <h2 className="text-sm font-semibold">Dispatch approval queue</h2>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[180px]" aria-label="Approval queue status">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {["PENDING_APPROVAL", "APPROVED", "REJECTED", "ISSUED", "RECEIVED", "ALL"].map((s) => (
              <SelectItem value={s} key={s}>
                {s === "ALL" ? "All dispatches" : s.replaceAll("_", " ")}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <DataTable
        headers={["Dispatch order", "Vehicle / job", "Parts", "Status", "Action"]}
        empty={shown.length === 0}
      >
        {shown.map((dispatch) => {
          const dispatchId = Number(dispatch["dispatchOrderId"]);
          const job = w.jobs.find((item) => item.backendJobId === Number(dispatch["jobId"]));
          const parts = Array.isArray(dispatch["items"])
            ? (dispatch["items"] as Record<string, unknown>[])
            : [];
          const isPending = String(dispatch["status"]).toUpperCase() === "PENDING_APPROVAL";
          return (
            <tr key={dispatchId}>
              <td className="cell-title">{String(dispatch["dispatchNumber"] ?? dispatchId)}</td>
              <td>
                {job ? (
                  <VehicleCell vehicle={w.vehicleFor(job.vehicleId)} />
                ) : (
                  `Job ${String(dispatch["jobId"] ?? "—")}`
                )}
              </td>
              <td>
                {parts
                  .map(
                    (part) =>
                      `${String(part["description"] ?? "Part")} × ${String(part["quantityRequested"] ?? "—")}`,
                  )
                  .join(", ") || "—"}
              </td>
              <td>
                <Status>{String(dispatch["status"] ?? "Unknown")}</Status>
              </td>
              <td>
                {isPending && (
                  <Button
                    size="sm"
                    disabled={!authority || saving}
                    onClick={() => {
                      setSelected(dispatch);
                      setRejectionReason("");
                    }}
                  >
                    Review / decide <ArrowRight size={13} />
                  </Button>
                )}
              </td>
            </tr>
          );
        })}
      </DataTable>
      <TableFooter count={shown.length} label="dispatch orders" />
      <Dialog
        open={!!selected}
        onOpenChange={(open) => {
          if (!open && !saving) {
            setSelected(null);
            setRejectionReason("");
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Dispatch {String(selected?.["dispatchNumber"] ?? "")}</DialogTitle>
            <DialogDescription>
              Manager or Boss approval is required before stores issues the parts.
            </DialogDescription>
          </DialogHeader>
          <p className="text-sm">Status: {String(selected?.["status"] ?? "")}</p>
          <label className="field">
            <span>Rejection reason (required only when rejecting)</span>
            <Textarea
              rows={3}
              value={rejectionReason}
              onChange={(event) => setRejectionReason(event.target.value)}
              disabled={saving}
            />
          </label>
          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => void decide(false)}
              disabled={!authority || saving}
            >
              {saving ? "Saving…" : "Reject order"}
            </Button>
            <Button onClick={() => void decide(true)} disabled={!authority || saving}>
              {saving ? "Saving…" : "Approve order"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export function WorkflowPage() {
  const w = useWorkspace();
  const [vehicleId, setVehicleId] = useState(w.vehicles[0]?.id ?? "");
  const v = w.vehicleFor(vehicleId);
  return (
    <>
      <PageHeading
        title="Workflow Tracking"
        subtitle="From vehicle intake to invoice and final release"
      >
        <ExportButton
          filename="workflow-tracking"
          rows={w.vehicles.map((v) => ({
            vehicle: v.plate,
            customer: v.customer,
            stage: workflowStages[v.stage],
            department: v.department,
            foreman: v.foreman,
          }))}
        />
      </PageHeading>
      <div className="toolbar">
        <div>
          <h2 className="text-sm font-semibold">Vehicle workflow</h2>
          <p className="text-xs text-muted-foreground mt-1">
            {v?.customer} · {v?.foreman}
          </p>
        </div>
        <Select value={vehicleId} onValueChange={setVehicleId}>
          <SelectTrigger className="w-[270px]" aria-label="Track vehicle">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {w.vehicles.map((v) => (
              <SelectItem key={v.id} value={v.id}>
                {v.make} · {v.plate}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      {v && (
        <>
          <div className="attention-band">
            <Truck size={18} />
            <div>
              <strong>
                {v.make} · {v.plate}
              </strong>
              <p>
                Current stage: {v.released ? "Released" : workflowStages[v.stage]} · Expected
                completion: {v.due}
              </p>
            </div>
            <Status>{`${v.progress}% complete`}</Status>
          </div>
          <Workflow stage={v.stage} />
        </>
      )}
      <section className="table-section mt-8">
        <SectionHeading
          title="All vehicles"
          subtitle="Live position within the official 12-stage workshop process"
        />
        <DataTable
          headers={["Vehicle", "Current stage", "Department", "Progress", "Expected completion"]}
        >
          {w.vehicles.map((v) => (
            <tr key={v.id}>
              <td>
                <VehicleCell vehicle={v} />
              </td>
              <td>
                <Status>{v.released ? "Released" : (workflowStages[v.stage] ?? "Intake")}</Status>
              </td>
              <td>{v.department}</td>
              <td>
                <div className="w-[100px]">
                  <ProgressBar value={v.progress} />
                  <div className="text-[10px] mt-2 text-muted-foreground">{v.progress}%</div>
                </div>
              </td>
              <td>{v.due}</td>
            </tr>
          ))}
        </DataTable>
      </section>
    </>
  );
}

export function DepartmentsPage() {
  const w = useWorkspace();
  const [selected, setSelected] = useState("All");
  const [detail, setDetail] = useState<string | null>(null);
  return (
    <>
      <PageHeading
        title="Department Performance"
        subtitle="Mechanical, panel beating, fitting, painting and sanding"
      >
        <ExportButton filename="department-performance" rows={departmentStats} />
      </PageHeading>
      <DepartmentCards />
      <section className="table-section mt-8">
        <SectionHeading
          title="Department overview"
          subtitle="Work coordinated and recorded by the foremen"
        />
        <DataTable
          headers={[
            "Department",
            "Assigned vehicles",
            "In progress",
            "Completed jobs",
            "Pending work",
            "Delays",
            "Completion rate",
          ]}
        >
          {departmentStats.map((d) => (
            <tr key={d.name}>
              <td className="cell-title">{d.name}</td>
              <td>{d.active + d.pending}</td>
              <td>{d.active}</td>
              <td>{d.completed}</td>
              <td>{d.pending}</td>
              <td>{d.delays}</td>
              <td>
                <div className="flex items-center gap-3">
                  <div className="w-[80px]">
                    <ProgressBar value={d.efficiency} />
                  </div>
                  {d.efficiency}%
                </div>
              </td>
            </tr>
          ))}
        </DataTable>
      </section>
      <section className="table-section">
        <SectionHeading title="Department assignments">
          <Select value={selected} onValueChange={setSelected}>
            <SelectTrigger className="w-[180px]" aria-label="Select department">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All departments</SelectItem>
              {departmentStats.map((d) => (
                <SelectItem key={d.name} value={d.name}>
                  {d.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </SectionHeading>
        <DataTable
          headers={["Job card", "Vehicle", "Department", "Work instructions", "Status", "Actions"]}
        >
          {w.jobs
            .filter((j) => selected === "All" || j.department === selected)
            .map((j) => (
              <tr key={j.id}>
                <td className="cell-title">{j.id}</td>
                <td>
                  <VehicleCell vehicle={w.vehicleFor(j.vehicleId)} />
                </td>
                <td>{j.department}</td>
                <td className="whitespace-normal max-w-[260px]">{j.work}</td>
                <td>
                  <Status>{j.status}</Status>
                </td>
                <td>
                  <Button
                    variant="ghost"
                    size="icon"
                    aria-label={`View ${j.id}`}
                    title="View vehicle"
                    onClick={() => setDetail(j.vehicleId)}
                  >
                    <ArrowUpRight />
                  </Button>
                </td>
              </tr>
            ))}
        </DataTable>
      </section>
      <VehicleDetail id={detail} onClose={() => setDetail(null)} />
    </>
  );
}

export function WorkshopPage() {
  const w = useWorkspace();
  const employeeId = getApiIdentity()?.employeeId ?? 0;
  const employees = (w.workflowOptions["employees"] ?? []) as Record<string, unknown>[];
  const workOrders: Record<string, unknown>[] = w.workflows.flatMap((plan) =>
    (Array.isArray(plan["workOrders"])
      ? (plan["workOrders"] as Record<string, unknown>[])
      : []
    ).map(
      (order) =>
        ({
          ...order,
          planId: Number(plan["repairPlanId"]),
          planStatus: String(plan["repairPlanStatus"]),
          jobId: Number(plan["jobId"]),
        }) as Record<string, unknown>,
    ),
  );
  const run = (action: () => Promise<unknown>, success: string) =>
    void action()
      .then(async () => {
        await w.refresh();
        toast.success(success);
      })
      .catch((error: Error) => toast.error(error.message));
  return (
    <>
      <PageHeading
        title="Workshop Progress"
        subtitle="Repair plan, work orders and department visits from the backend"
      >
        <ExportButton filename="workshop-progress" rows={w.jobs} />
      </PageHeading>
      <div className="mb-5 max-w-sm rounded-md border border-border p-3 text-sm">
        <span className="text-muted-foreground">Actions are recorded as </span>
        <strong>{getApiIdentity()?.displayName ?? "Signed-in employee"}</strong>
      </div>
      <section className="table-section mt-8">
        <SectionHeading title="Repair plan work orders" />
        <DataTable
          headers={[
            "Work order",
            "Vehicle",
            "Department",
            "Status",
            "Assignments / visits / evidence",
          ]}
          empty={workOrders.length === 0}
        >
          {workOrders.map((order) => {
            const job = w.jobs.find((item) => item.backendJobId === order["jobId"]);
            const vehicle = job && w.vehicleFor(job.vehicleId);
            const assignments = Array.isArray(order["assignments"])
              ? (order["assignments"] as Record<string, unknown>[])
              : [];
            const visits = Array.isArray(order["departmentVisits"])
              ? (order["departmentVisits"] as Record<string, unknown>[])
              : [];
            const activeVisit = visits.find((visit) => visit["status"] === "OPEN");
            const evidence = Array.isArray(order["evidence"])
              ? (order["evidence"] as Record<string, unknown>[])
              : [];
            const sessions = Array.isArray(order["activities"])
              ? (order["activities"] as Record<string, unknown>[])
              : [];
            const id = Number(order["workOrderId"]);
            const departmentId = Number(order["departmentId"]);
            const reminders = (w.workOrderReminders.get(id) ?? []) as WorkOrderReminder[];
            return (
              <tr key={id}>
                <td className="cell-title">
                  <strong>{String(order["workOrderNumber"])}</strong>
                  <br />
                  {String(order["taskTitle"])}
                  <p className="text-xs text-muted-foreground mt-1">
                    {String(order["workInstructions"] ?? order["workDescription"] ?? "")}
                  </p>
                </td>
                <td>
                  <VehicleCell vehicle={vehicle} />
                </td>
                <td>{String(order["departmentName"])}</td>
                <td>
                  <Status>{String(order["status"])}</Status>
                </td>
                <td>
                  <p className="text-xs">
                    {assignments.map((a) => String(a["employeeName"])).join(", ") ||
                      "No assignment"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {visits.map((v) => `${v["departmentName"]} · ${v["status"]}`).join("; ") ||
                      "No department visit"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {evidence.length} evidence files · {sessions.length} activity records
                  </p>
                  {reminders.length > 0 && (
                    <div className="mt-2 space-y-2 rounded-md border border-border p-2">
                      <p className="text-xs font-semibold">Stagnation reminders</p>
                      {reminders.map((reminder) => {
                        const assignedToCurrentEmployee =
                          reminder.employeeId === Number(employeeId);
                        const acknowledged = !!reminder.acknowledgedAt;
                        return (
                          <div key={reminder.id} className="rounded bg-muted/40 p-2 text-xs">
                            <p>
                              <strong>{reminder.priority}</strong> · Escalation{" "}
                              {reminder.escalationLevel} ·{" "}
                              {new Date(reminder.sentAt).toLocaleString()}
                            </p>
                            <p className="mt-1">{reminder.message}</p>
                            {acknowledged ? (
                              <p className="mt-1 text-muted-foreground">
                                Acknowledged {new Date(reminder.acknowledgedAt!).toLocaleString()}
                              </p>
                            ) : assignedToCurrentEmployee ? (
                              <Button
                                size="sm"
                                variant="outline"
                                className="mt-2"
                                onClick={() =>
                                  run(
                                    () =>
                                      w.api.acknowledgeReminder(reminder.id, Number(employeeId)),
                                    "Reminder acknowledged.",
                                  )
                                }
                              >
                                Acknowledge reminder
                              </Button>
                            ) : (
                              <p className="mt-1 text-muted-foreground">
                                Assigned employee: {reminder.employeeId ?? "Unassigned"}
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                  {String(order["planStatus"]) === "DRAFT" && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        run(
                          () => w.api.acceptRepairPlan(Number(order["planId"]), Number(employeeId)),
                          "Repair plan accepted.",
                        )
                      }
                    >
                      Accept repair plan
                    </Button>
                  )}
                  <div className="flex flex-wrap gap-1 mt-2">
                    <Select
                      value=""
                      onValueChange={(value) =>
                        run(
                          () =>
                            w.api.assignWorkOrder(
                              id,
                              Number(value),
                              "TECHNICIAN",
                              Number(employeeId),
                            ),
                          "Work order assigned.",
                        )
                      }
                    >
                      <SelectTrigger className="h-8 w-40">
                        <SelectValue placeholder="Assign employee" />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.map((e) => (
                          <SelectItem key={String(e["id"])} value={String(e["id"])}>
                            {String(e["name"])}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {!activeVisit &&
                      (String(order["status"]) === "READY" ||
                        String(order["status"]) === "ASSIGNED") && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            run(
                              () =>
                                w.api.arriveAtDepartment(
                                  id,
                                  departmentId,
                                  "Vehicle arrived at department",
                                  Number(employeeId),
                                ),
                              "Department arrival recorded.",
                            )
                          }
                        >
                          Record arrival
                        </Button>
                      )}
                    {activeVisit &&
                      ["READY", "ASSIGNED", "PAUSED", "WAITING"].includes(
                        String(order["status"]),
                      ) && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            run(
                              () =>
                                w.api.workOrderAction(
                                  id,
                                  String(order["status"]) === "PAUSED" ? "resume" : "start",
                                  "Workshop work started",
                                  Number(employeeId),
                                ),
                              "Work started.",
                            )
                          }
                        >
                          {String(order["status"]) === "PAUSED" ? "Resume" : "Start"}
                        </Button>
                      )}
                    {activeVisit && String(order["status"]) === "IN_PROGRESS" && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            run(
                              () =>
                                w.api.workOrderAction(
                                  id,
                                  "pause",
                                  "Work paused",
                                  Number(employeeId),
                                ),
                              "Work paused.",
                            )
                          }
                        >
                          Pause
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            run(
                              () =>
                                w.api.workOrderAction(
                                  id,
                                  "waiting",
                                  "Waiting for parts or information",
                                  Number(employeeId),
                                ),
                              "Work marked waiting.",
                            )
                          }
                        >
                          Waiting
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => {
                            const notes = window.prompt("Completion notes");
                            if (notes)
                              run(
                                () => w.api.submitWorkOrder(id, notes, Number(employeeId)),
                                "Submitted for confirmation.",
                              );
                          }}
                        >
                          Submit completion
                        </Button>
                      </>
                    )}
                    {activeVisit && String(order["status"]) === "AWAITING_CONFIRMATION" && (
                      <Button
                        size="sm"
                        onClick={() =>
                          run(
                            () =>
                              w.api.confirmWorkOrder(
                                id,
                                "Work completion confirmed",
                                Number(employeeId),
                              ),
                            "Work order completed.",
                          )
                        }
                      >
                        Confirm completion
                      </Button>
                    )}
                    {activeVisit && String(order["status"]) === "COMPLETED" && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          run(
                            () =>
                              w.api.sendOffDepartment(
                                id,
                                departmentId,
                                Number(activeVisit["visitId"]),
                                "Department work completed",
                                Number(employeeId),
                              ),
                            "Department send-off recorded.",
                          )
                        }
                      >
                        Send off
                      </Button>
                    )}
                    {activeVisit && (
                      <label className="text-xs">
                        <span className="sr-only">Upload work photo evidence</span>
                        <Input
                          className="h-8 w-48"
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file)
                              run(
                                () =>
                                  w.api.uploadWorkEvidence(
                                    id,
                                    file,
                                    "Work order evidence",
                                    Number(employeeId),
                                  ),
                                "Evidence uploaded.",
                              );
                            e.currentTarget.value = "";
                          }}
                        />
                      </label>
                    )}
                  </div>
                  {sessions.length > 0 && (
                    <ul className="mt-2 text-xs">
                      {sessions.map((session) => (
                        <li key={String(session["sessionId"])}>
                          {String(session["startedAt"])} · {String(session["sessionStatus"])} ·{" "}
                          {String(session["durationMinutes"])} min
                        </li>
                      ))}
                    </ul>
                  )}
                </td>
              </tr>
            );
          })}
        </DataTable>
      </section>
    </>
  );
}

type DispatchPreparationLine = {
  jobCardPartId: number;
  partId: number;
  partName: string;
  required: number;
  alreadyReserved: number;
  available: number;
  reserveQuantity: number;
  stockLocationId: string;
};

type DispatchPreparation = {
  jobCardId: number;
  jobId: number;
  jobCardNumber: string;
  vehicleId: string;
  lines: DispatchPreparationLine[];
  existingReservations: Record<string, unknown>[];
  departmentId: string;
  mechanicId: string;
};

export function ProcurementPage() {
  const w = useWorkspace();
  const options = w.workflowOptions as {
    suppliers?: Array<{ supplierId: number; supplierName: string }>;
    stockLocations?: Array<{ stockLocationId: number; locationName: string }>;
    departments?: Array<{ id: number; name: string }>;
    employees?: Array<{ id: number; name: string; jobTitle?: string }>;
  };
  const suppliers = options.suppliers ?? [];
  const locations = options.stockLocations ?? [];
  const departments = options.departments ?? [];
  const employeeOptions = options.employees ?? [];
  const mechanics = employeeOptions.filter((employee) =>
    /mechanic|technician/i.test(employee.jobTitle ?? ""),
  );
  const mechanicOptions = mechanics.length ? mechanics : employeeOptions;
  const requests = w.requisitions;
  const orders = w.purchaseOrders;
  const identity = getApiIdentity();
  const employeeId = Number(identity?.employeeId ?? 0);
  const employeeName = identity?.displayName ?? "Signed-in employee";
  const [dispatchDraft, setDispatchDraft] = useState<DispatchPreparation | null>(null);
  const [loadingDispatchCard, setLoadingDispatchCard] = useState<number | null>(null);
  const [dispatchBusy, setDispatchBusy] = useState<number | null>(null);
  const jobCards = w.jobs.filter((job) => job.backendJobCardId && job.backendJobId);
  const reportError = (error: unknown) =>
    toast.error(error instanceof Error ? error.message : "The backend request failed.");

  const prepareDispatch = async (job: (typeof jobCards)[number]) => {
    const jobCardId = Number(job.backendJobCardId);
    const jobId = Number(job.backendJobId);
    const activeDispatches = w.dispatches.filter(
      (dispatch) =>
        Number(dispatch["jobId"]) === jobId &&
        ["PENDING_APPROVAL", "APPROVED", "ISSUED"].includes(
          String(dispatch["status"] ?? "").toUpperCase(),
        ),
    );
    if (activeDispatches.length) {
      toast.error("This job already has a dispatch awaiting approval, issue, or mechanic receipt.");
      return;
    }

    setLoadingDispatchCard(jobCardId);
    try {
      const [availability, card, existingReservations] = await Promise.all([
        w.api.checkPartsAvailability(jobCardId),
        w.api.getJobCard(jobCardId),
        w.api.getJobReservations(jobCardId),
      ]);
      const availableByPartId = new Map<number, Record<string, unknown>>(
        (Array.isArray(availability["parts"]) ? availability["parts"] : []).map((line) => [
          Number((line as Record<string, unknown>)["partId"]),
          line as Record<string, unknown>,
        ]),
      );
      const reservedByRequirement = new Map<number, number>();
      for (const reservation of existingReservations) {
        const requirementId = Number(reservation["jobCardPartId"]);
        reservedByRequirement.set(
          requirementId,
          (reservedByRequirement.get(requirementId) ?? 0) +
            Number(reservation["quantityReserved"] ?? 0),
        );
      }
      const freeByPartId = new Map<number, number>();
      for (const [partId, line] of availableByPartId) {
        freeByPartId.set(partId, Number(line["quantityAvailableToReserve"] ?? 0));
      }
      const partRows = Array.isArray(card["parts"])
        ? (card["parts"] as Record<string, unknown>[])
        : [];
      const lines: DispatchPreparationLine[] = partRows.map((part) => {
        const partId = Number(part["partId"]);
        const jobCardPartId = Number(part["jobCardPartId"]);
        const required = Number(part["quantity"] ?? 0);
        const alreadyReserved = reservedByRequirement.get(jobCardPartId) ?? 0;
        const remainingRequirement = Math.max(0, required - alreadyReserved);
        const available = Math.min(remainingRequirement, freeByPartId.get(partId) ?? 0);
        freeByPartId.set(partId, Math.max(0, (freeByPartId.get(partId) ?? 0) - available));
        return {
          jobCardPartId,
          partId,
          partName: String(part["partName"] ?? part["partCode"] ?? "Part"),
          required,
          alreadyReserved,
          available,
          reserveQuantity: available,
          stockLocationId: String(locations[0]?.stockLocationId ?? ""),
        };
      });
      const jobDispatches = w.dispatches.filter((dispatch) => Number(dispatch["jobId"]) === jobId);
      const attachedReservationIds = new Set(
        jobDispatches.flatMap((dispatch) =>
          (Array.isArray(dispatch["items"]) ? (dispatch["items"] as Record<string, unknown>[]) : [])
            .map((item) => Number(item["stockReservationId"]))
            .filter((id) => id > 0),
        ),
      );
      const unusedReservations = existingReservations.filter(
        (reservation) => !attachedReservationIds.has(Number(reservation["reservationId"])),
      );
      if (!lines.length && !unusedReservations.length) {
        throw new Error(
          "The job card has no linked parts or active stock reservations to dispatch.",
        );
      }
      setDispatchDraft({
        jobCardId,
        jobId,
        jobCardNumber: String(card["jobCardNumber"] ?? job.id),
        vehicleId: job.vehicleId,
        lines,
        existingReservations: unusedReservations,
        departmentId: String(departments[0]?.id ?? ""),
        mechanicId: String(mechanicOptions[0]?.id ?? ""),
      });
    } catch (error) {
      reportError(error);
    } finally {
      setLoadingDispatchCard(null);
    }
  };

  const createDispatch = async () => {
    if (!dispatchDraft) return;
    if (!Number.isSafeInteger(employeeId) || employeeId <= 0) {
      toast.error("Sign in with an active foreman employee account to create a dispatch.");
      return;
    }
    if (!dispatchDraft.departmentId || !dispatchDraft.mechanicId) {
      toast.error("Choose the destination department and assigned mechanic.");
      return;
    }
    if (dispatchDraft.lines.some((line) => line.reserveQuantity > 0 && !line.stockLocationId)) {
      toast.error("Choose a stock location for each part to reserve.");
      return;
    }
    const jobCardId = dispatchDraft.jobCardId;
    setDispatchBusy(jobCardId);
    try {
      for (const line of dispatchDraft.lines) {
        if (line.reserveQuantity <= 0) continue;
        await w.api.reservePart(
          jobCardId,
          line.jobCardPartId,
          Number(line.stockLocationId),
          line.reserveQuantity,
        );
      }
      const allReservations = await w.api.getJobReservations(jobCardId);
      const jobDispatches = w.dispatches.filter(
        (dispatch) => Number(dispatch["jobId"]) === dispatchDraft.jobId,
      );
      const attachedReservationIds = new Set(
        jobDispatches.flatMap((dispatch) =>
          (Array.isArray(dispatch["items"]) ? (dispatch["items"] as Record<string, unknown>[]) : [])
            .map((item) => Number(item["stockReservationId"]))
            .filter((id) => id > 0),
        ),
      );
      const reservationIds = allReservations
        .filter(
          (reservation) =>
            String(reservation["reservationStatus"] ?? "").toUpperCase() === "ACTIVE" &&
            !attachedReservationIds.has(Number(reservation["reservationId"])),
        )
        .map((reservation) => Number(reservation["reservationId"]));
      if (!reservationIds.length) {
        throw new Error("Reserve at least one available part before creating the dispatch order.");
      }
      await w.api.createDispatch(
        dispatchDraft.jobId,
        Number(dispatchDraft.mechanicId),
        Number(dispatchDraft.departmentId),
        reservationIds,
      );
      setDispatchDraft(null);
      await w.refresh();
      toast.success("Dispatch order created and sent for manager or boss approval.");
    } catch (error) {
      reportError(error);
    } finally {
      setDispatchBusy(null);
    }
  };

  const runDispatchAction = async (
    dispatchId: number,
    action: "resubmit" | "issue" | "receive" | "accounts-acknowledgement",
    body: Record<string, unknown>,
    successMessage: string,
  ) => {
    setDispatchBusy(dispatchId);
    try {
      await w.api.dispatchAction(dispatchId, action, body);
      await w.refresh();
      toast.success(successMessage);
    } catch (error) {
      reportError(error);
    } finally {
      setDispatchBusy(null);
    }
  };
  return (
    <>
      <PageHeading
        title="Procurement & Parts Dispatch"
        subtitle="Order identified stock shortages, receive deliveries into stores, then prepare the dispatch order for manager or boss approval."
      >
        <ExportButton filename="procurement-dispatch" rows={requests} />
      </PageHeading>
      <Metrics
        items={[
          {
            label: "Ready to purchase",
            value: requests.filter((r) => ["Pending", "Approved"].includes(r.status)).length,
            note: "Submitted shortage requests ready to order",
            icon: metricIcons.ClipboardCheck,
          },
          {
            label: "On order",
            value: orders.length,
            note: "Awaiting delivery",
            icon: metricIcons.Package,
          },
          {
            label: "Parts dispatched",
            value: w.dispatches.length,
            note: "Backend dispatch orders",
            icon: metricIcons.Wrench,
          },
          {
            label: "Requisitions",
            value: requests.length,
            note: "Backend records matching this view",
            icon: metricIcons.FileText,
          },
        ]}
      />
      <DataTable
        headers={["Requisition", "Part / item", "Vehicle", "Quantity", "Status", "Purchase order"]}
        empty={requests.length === 0}
      >
        {requests.map((r) => (
          <tr key={r.id}>
            <td className="cell-title">{r.id}</td>
            <td>{r.part}</td>
            <td>
              <VehicleCell vehicle={w.vehicleFor(r.vehicleId)} />
            </td>
            <td>{r.quantity}</td>
            <td>
              <Status>{r.status}</Status>
            </td>
            <td>
              {["Pending", "Approved"].includes(r.status) &&
                r.backendId &&
                (r.lines?.length ?? 0) > 0 &&
                suppliers.length > 0 && (
                  <form
                    className="flex flex-wrap gap-2"
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const form = new FormData(e.currentTarget);
                      try {
                        await w.api.createPurchaseOrder(
                          Number(r.backendId),
                          Number(form.get("supplier")),
                          (r.lines ?? []).map((line) => ({
                            requisitionItemId: line.id,
                            quantityOrdered: line.quantity,
                            unitPrice: Number(form.get(`unitPrice-${line.id}`)),
                            taxAmount: 0,
                          })),
                          String(form.get("reference") ?? ""),
                        );
                        await w.refresh();
                        toast.success("Purchase order created.");
                      } catch (error) {
                        reportError(error);
                      }
                    }}
                  >
                    <select name="supplier" required aria-label="Supplier" className="field-input">
                      <option value="">Supplier</option>
                      {suppliers.map((supplier) => (
                        <option key={supplier.supplierId} value={supplier.supplierId}>
                          {supplier.supplierName}
                        </option>
                      ))}
                    </select>
                    {(r.lines ?? []).map((line) => (
                      <Input
                        key={line.id}
                        name={`unitPrice-${line.id}`}
                        type="number"
                        min="0"
                        step="0.01"
                        required
                        aria-label={`Unit price for ${line.name}`}
                        placeholder={`${line.name} unit price`}
                      />
                    ))}
                    <Input
                      name="reference"
                      aria-label="Supplier reference"
                      placeholder="Supplier ref"
                    />
                    <Button size="sm">Create PO</Button>
                  </form>
                )}
            </td>
          </tr>
        ))}
      </DataTable>
      <TableFooter count={requests.length} label="backend requisitions" />
      <SectionHeading title="Purchase orders" />
      <DataTable
        headers={["Order", "Supplier", "Status", "Items", "Receive"]}
        empty={!orders.length}
      >
        {orders.map((order) => {
          const items = Array.isArray(order["items"])
            ? (order["items"] as Array<Record<string, unknown>>)
            : [];
          const id = Number(order["purchaseOrderId"]);
          return (
            <tr key={id}>
              <td className="cell-title">{String(order["purchaseOrderNumber"] ?? id)}</td>
              <td>{String(order["supplierName"] ?? "")}</td>
              <td>
                <Status>{String(order["status"] ?? "")}</Status>
              </td>
              <td>
                {items
                  .map(
                    (item) =>
                      `${String(item["partName"] ?? item["partCode"])} × ${String(item["quantityOrdered"] ?? "")}`,
                  )
                  .join(", ")}
              </td>
              <td>
                {locations.length > 0 && String(order["status"]).toUpperCase() !== "RECEIVED" && (
                  <form
                    className="flex gap-2"
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const form = new FormData(e.currentTarget);
                      try {
                        await w.api.receivePurchaseOrder(
                          id,
                          Number(form.get("location")),
                          items.map((item) => ({
                            purchaseOrderItemId: Number(item["purchaseOrderItemId"]),
                            quantityDelivered:
                              Number(item["quantityOrdered"]) -
                              Number(item["quantityReceived"] ?? 0),
                            quantityAccepted:
                              Number(item["quantityOrdered"]) -
                              Number(item["quantityReceived"] ?? 0),
                          })),
                          String(form.get("deliveryRef") ?? ""),
                        );
                        await w.refresh();
                        toast.success("Purchase order receipt recorded.");
                      } catch (error) {
                        reportError(error);
                      }
                    }}
                  >
                    <select
                      name="location"
                      required
                      aria-label="Receiving stock location"
                      className="field-input"
                    >
                      <option value="">Location</option>
                      {locations.map((location) => (
                        <option key={location.stockLocationId} value={location.stockLocationId}>
                          {location.locationName}
                        </option>
                      ))}
                    </select>
                    <Input
                      name="deliveryRef"
                      aria-label="Delivery reference"
                      placeholder="Delivery ref"
                    />
                    <Button size="sm">Receive</Button>
                  </form>
                )}
              </td>
            </tr>
          );
        })}
      </DataTable>
      <section className="table-section mt-8">
        <SectionHeading
          title="Create dispatch orders"
          subtitle="Reserve available stock for a job card, then send the dispatch book to the manager or boss for approval."
        />
        <DataTable
          headers={["Job card", "Vehicle", "Parts", "Action"]}
          empty={jobCards.length === 0}
        >
          {jobCards.map((job) => {
            const cardId = Number(job.backendJobCardId);
            const jobId = Number(job.backendJobId);
            const vehicle = w.vehicleFor(job.vehicleId);
            const alreadyPending = w.dispatches.some(
              (dispatch) =>
                Number(dispatch["jobId"]) === jobId &&
                ["PENDING_APPROVAL", "APPROVED", "ISSUED"].includes(
                  String(dispatch["status"] ?? "").toUpperCase(),
                ),
            );
            return (
              <tr key={cardId}>
                <td className="cell-title">{job.id}</td>
                <td>
                  <VehicleCell vehicle={vehicle} />
                </td>
                <td>{job.parts?.length ?? 0} job-card part lines</td>
                <td>
                  {w.role === "Foreman" && (
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={
                        alreadyPending || loadingDispatchCard === cardId || !locations.length
                      }
                      onClick={() => void prepareDispatch(job)}
                    >
                      {loadingDispatchCard === cardId
                        ? "Loading stock…"
                        : alreadyPending
                          ? "Dispatch in progress"
                          : "Prepare dispatch"}
                    </Button>
                  )}
                </td>
              </tr>
            );
          })}
        </DataTable>
        {w.role === "Foreman" && !locations.length && (
          <p className="mt-3 text-sm text-muted-foreground">
            Configure an active stock location before reserving parts.
          </p>
        )}
      </section>

      <section className="table-section mt-8">
        <SectionHeading
          title="Dispatch order book"
          subtitle="Approval, stock issue, mechanic receipt, and the date the dispatch document reaches accounts."
        />
        <DataTable
          headers={[
            "Dispatch",
            "Vehicle / department",
            "Parts",
            "Status",
            "Arrived at accounts",
            "Action",
          ]}
          empty={w.dispatches.length === 0}
        >
          {w.dispatches.map((dispatch) => {
            const id = Number(dispatch["dispatchOrderId"] ?? dispatch["id"]);
            const jobId = Number(dispatch["jobId"]);
            const job = w.jobs.find((item) => item.backendJobId === jobId);
            const vehicle = job && w.vehicleFor(job.vehicleId);
            const status = String(dispatch["status"] ?? "").toUpperCase();
            const items = Array.isArray(dispatch["items"])
              ? (dispatch["items"] as Record<string, unknown>[])
              : [];
            const assignedMechanicId = Number(dispatch["assignedMechanicId"]);
            let action: ReactNode = null;
            if (status === "APPROVED" && w.role === "Stores") {
              action = (
                <Button
                  size="sm"
                  disabled={dispatchBusy === id}
                  onClick={() =>
                    void runDispatchAction(
                      id,
                      "issue",
                      { issuedByEmployeeId: employeeId, signerName: employeeName },
                      "Parts issued from stores.",
                    )
                  }
                >
                  Issue parts
                </Button>
              );
            } else if (
              status === "ISSUED" &&
              w.role === "Mechanic" &&
              assignedMechanicId === employeeId
            ) {
              action = (
                <Button
                  size="sm"
                  disabled={dispatchBusy === id}
                  onClick={() =>
                    void runDispatchAction(
                      id,
                      "receive",
                      { receivedByEmployeeId: employeeId, signerName: employeeName },
                      "Mechanic receipt recorded.",
                    )
                  }
                >
                  Confirm receipt
                </Button>
              );
            } else if (
              ["APPROVED", "ISSUED", "RECEIVED"].includes(status) &&
              !dispatch["accountsArrivedAt"] &&
              w.role === "Accounts"
            ) {
              action = (
                <Button
                  size="sm"
                  disabled={dispatchBusy === id}
                  onClick={() =>
                    void runDispatchAction(
                      id,
                      "accounts-acknowledgement",
                      { acknowledgedByEmployeeId: employeeId, signerName: employeeName },
                      "Dispatch arrival recorded by accounts.",
                    )
                  }
                >
                  Mark arrived at accounts
                </Button>
              );
            } else if (status === "REJECTED" && w.role === "Foreman") {
              action = (
                <Button
                  size="sm"
                  variant="outline"
                  disabled={dispatchBusy === id}
                  onClick={() =>
                    void runDispatchAction(id, "resubmit", {}, "Dispatch resubmitted for approval.")
                  }
                >
                  Resubmit
                </Button>
              );
            }
            return (
              <tr key={id}>
                <td className="cell-title">{String(dispatch["dispatchNumber"] ?? id)}</td>
                <td>
                  <VehicleCell vehicle={vehicle} />
                  <p className="text-xs text-muted-foreground">
                    {String(dispatch["departmentName"] ?? "Workshop")}
                  </p>
                </td>
                <td>
                  {items
                    .map(
                      (item) =>
                        `${String(item["description"] ?? "Part")} × ${String(item["quantityRequested"] ?? "")}`,
                    )
                    .join(", ")}
                </td>
                <td>
                  <Status>{status}</Status>
                </td>
                <td>
                  {dispatch["accountsArrivedAt"]
                    ? new Date(String(dispatch["accountsArrivedAt"])).toLocaleString()
                    : "Not recorded"}
                </td>
                <td>{action}</td>
              </tr>
            );
          })}
        </DataTable>
      </section>

      <Dialog
        open={!!dispatchDraft}
        onOpenChange={(open) => {
          if (!open) setDispatchDraft(null);
        }}
      >
        <DialogContent className="modal-scroll max-w-4xl">
          <DialogHeader>
            <DialogTitle>Prepare dispatch order</DialogTitle>
            <DialogDescription>
              {dispatchDraft
                ? `${dispatchDraft.jobCardNumber} · ${w.vehicleFor(dispatchDraft.vehicleId)?.plate ?? "Vehicle"}`
                : "Reserve parts from stores and assign the destination."}
            </DialogDescription>
          </DialogHeader>
          {dispatchDraft && (
            <div className="space-y-4">
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="field">
                  <span>Department</span>
                  <select
                    className="field-input"
                    value={dispatchDraft.departmentId}
                    onChange={(event) =>
                      setDispatchDraft({ ...dispatchDraft, departmentId: event.target.value })
                    }
                  >
                    <option value="">Choose department</option>
                    {departments.map((department) => (
                      <option key={department.id} value={department.id}>
                        {department.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="field">
                  <span>Assigned mechanic</span>
                  <select
                    className="field-input"
                    value={dispatchDraft.mechanicId}
                    onChange={(event) =>
                      setDispatchDraft({ ...dispatchDraft, mechanicId: event.target.value })
                    }
                  >
                    <option value="">Choose mechanic</option>
                    {mechanicOptions.map((employee) => (
                      <option key={employee.id} value={employee.id}>
                        {employee.name}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="space-y-3">
                {dispatchDraft.lines.map((line, index) => (
                  <div
                    key={line.jobCardPartId}
                    className="grid gap-2 rounded-md border p-3 sm:grid-cols-[1fr_100px_130px_150px] sm:items-end"
                  >
                    <div>
                      <strong>{line.partName}</strong>
                      <p className="text-xs text-muted-foreground">
                        Required {line.required} · Already reserved {line.alreadyReserved} ·
                        Available to reserve {line.available}
                      </p>
                    </div>
                    <label className="field">
                      <span>Reserve qty</span>
                      <Input
                        type="number"
                        min="0"
                        max={line.available}
                        step="0.01"
                        value={line.reserveQuantity}
                        onChange={(event) => {
                          const next = [...dispatchDraft.lines];
                          next[index] = {
                            ...line,
                            reserveQuantity: Math.min(
                              line.available,
                              Math.max(0, Number(event.target.value)),
                            ),
                          };
                          setDispatchDraft({ ...dispatchDraft, lines: next });
                        }}
                      />
                    </label>
                    <label className="field">
                      <span>Stock location</span>
                      <select
                        className="field-input"
                        value={line.stockLocationId}
                        onChange={(event) => {
                          const next = [...dispatchDraft.lines];
                          next[index] = { ...line, stockLocationId: event.target.value };
                          setDispatchDraft({ ...dispatchDraft, lines: next });
                        }}
                      >
                        <option value="">Choose</option>
                        {locations.map((location) => (
                          <option key={location.stockLocationId} value={location.stockLocationId}>
                            {location.locationName}
                          </option>
                        ))}
                      </select>
                    </label>
                    <span className="text-xs text-muted-foreground">
                      Pick the location that holds this stock.
                    </span>
                  </div>
                ))}
                {!dispatchDraft.lines.length && (
                  <p className="text-sm text-muted-foreground">
                    No unreserved part lines. Existing active reservations will be used.
                  </p>
                )}
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setDispatchDraft(null)}>
                  Cancel
                </Button>
                <Button
                  disabled={dispatchBusy === dispatchDraft.jobCardId}
                  onClick={() => void createDispatch()}
                >
                  {dispatchBusy === dispatchDraft.jobCardId ? "Creating…" : "Create dispatch order"}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

export function ReportsPage() {
  const w = useWorkspace();
  const reports = [
    {
      name: "Workshop operations report",
      description: "Vehicle intake, current stage, departments and completion dates",
      data: w.vehicles,
      filename: "workshop-operations",
    },
    {
      name: "Parts requisitions & approvals",
      description: "Requested parts, quantities, values and authorization status",
      data: w.requisitions,
      filename: "parts-requisitions",
    },
    {
      name: "Department performance",
      description: "Active, completed and delayed work by department",
      data: departmentStats,
      filename: "department-performance",
    },
    {
      name: "Customer quotations",
      description: "Quotation values and customer approval records",
      data: w.quotations,
      filename: "customer-quotations",
    },
    {
      name: "Vehicle inspection results",
      description: "Foreman inspections, final checks and completion notes",
      data: w.inspections,
      filename: "vehicle-inspections",
    },
  ];
  return (
    <>
      <PageHeading
        title="Operational Reports"
        subtitle="Workshop and business reporting · November 2026"
      />
      {reports.map((r) => (
        <div className="report-row" key={r.name}>
          <FileText size={23} />
          <div>
            <h2>{r.name}</h2>
            <p>{r.description}</p>
          </div>
          <Button
            variant="outline"
            className="report-action"
            onClick={() => exportCsv(r.filename, r.data)}
          >
            <Download />
            Download CSV
          </Button>
        </div>
      ))}
    </>
  );
}

export function AlertsPage() {
  const w = useWorkspace();
  return (
    <>
      <PageHeading
        title="Operational Alerts"
        subtitle="Outstanding approvals, vehicle delays and release priorities"
      />
      <section>
        <SectionHeading title="Requires attention" />
        <div className="attention-band">
          <ShieldCheck size={20} />
          <div>
            <strong>
              {
                w.dispatches.filter(
                  (dispatch) => String(dispatch["status"]).toUpperCase() === "PENDING_APPROVAL",
                ).length
              }{" "}
              dispatch orders awaiting manager or boss approval
            </strong>
            <p>
              Parts requisitions are submitted from detected stock shortages and can be ordered
              directly.
            </p>
          </div>
          <Button asChild variant="link" className="band-action">
            <Link to="/approvals">
              Review dispatches
              <ArrowRight />
            </Link>
          </Button>
        </div>
        <div className="attention-band">
          <Clock size={20} />
          <div>
            <strong>Nissan Navara · BAL 5643 · Completion delayed</strong>
            <p>Rear quarter panel on order. Expected completion was 10 November.</p>
          </div>
          <Button asChild variant="link" className="band-action">
            <Link to="/procurement">
              View procurement
              <ArrowRight />
            </Link>
          </Button>
        </div>
        <div className="attention-band">
          <Truck size={20} />
          <div>
            <strong>
              {w.vehicles.filter((v) => v.stage === 11 && !v.released).length} vehicles awaiting
              final release authorization
            </strong>
            <p>Management approval and invoice reference are required.</p>
          </div>
          <Button asChild variant="link" className="band-action">
            <Link to="/vehicles">
              View vehicles
              <ArrowRight />
            </Link>
          </Button>
        </div>
      </section>
      <section className="mt-8">
        <SectionHeading title="Recent workshop activity" />
        {w.activities.map((a, i) => (
          <div className="activity-row" key={i}>
            <FileText />
            <div className="flex-1">
              <p>{a.text}</p>
              <small>{a.detail}</small>
            </div>
            <small>{a.time}</small>
          </div>
        ))}
      </section>
    </>
  );
}
