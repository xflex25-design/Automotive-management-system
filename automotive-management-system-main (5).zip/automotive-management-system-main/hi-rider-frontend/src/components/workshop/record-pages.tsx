import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  Plus,
  Search,
  ArrowUpRight,
  Send,
  Check,
  ShieldCheck,
  Save,
  X,
  Printer,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { backendApi } from "@/lib/api";
import { useWorkspace } from "./workspace-context";
import { PageHeading, DataTable, VehicleCell, Status, TableFooter, ExportButton } from "./shared";
import { VehicleDetail } from "./vehicle-detail";

const QUOTATION_VAT_RATE = 16;
type QuotationDraftLine = {
  item: string;
  description: string;
  quantity: string;
  unitPrice: string;
};
const initialQuotationLines = (): QuotationDraftLine[] => [
  { quantity: "1", item: "air filter", description: "ford", unitPrice: "450.00" },
  { quantity: "1", item: "oil filter", description: "ford", unitPrice: "250.00" },
  { quantity: "1", item: "fuel filter", description: "ford", unitPrice: "250.00" },
  { quantity: "1", item: "cabin filter", description: "ford", unitPrice: "350.00" },
  { quantity: "2", item: "wipers", description: "ford", unitPrice: "350.00" },
  { quantity: "1", item: "brake pads", description: "ford", unitPrice: "1950.00" },
  { quantity: "1", item: "brake pads", description: "ford", unitPrice: "1950.00" },
  { quantity: "1", item: "brake booster", description: "ford", unitPrice: "1950.00" },
  { quantity: "1", item: "labour", description: "ford", unitPrice: "2000.00" },
];
const emptyQuotationLine = (): QuotationDraftLine => ({
  item: "",
  description: "",
  quantity: "1",
  unitPrice: "",
});
type PaperQuotationFields = {
  companyName: string;
  address: string;
  email: string;
  phone: string;
  bankName: string;
  accountNumber: string;
  vatNumber: string;
  quoteNo: string;
  date: string;
  salesperson: string;
  billTo1: string;
  billTo2: string;
  shipTo1: string;
  shipTo2: string;
  shipTo3: string;
  preparedBy: string;
  signature: string;
  invoiceReference: string;
};
type PaperInventoryFields = {
  jobNo: string;
  registrationNo: string;
  make: string;
  date: string;
  ownedBy: string;
  driver: string;
  accessories: Array<{ name: string; present: "" | "Present" | "Missing"; quantity?: string }>;
  fuelIn: string;
  fuelOut: string;
  kmsIn: string;
  kmsOut: string;
  damages: Array<{ area: string; type: string }>;
  jobToBeDone: string[];
  additional: Array<{ name: string; present: "" | "Present" | "Missing" }>;
  remarks: string[];
  deliveredBy: string;
  deliveredSignature: string;
  deliveredTel: string;
  receivedCheckedBy: string;
  collectedBy: string;
  collectedSignature: string;
  collectedDate: string;
  collectedPhone: string;
  releasedBy: string;
  timeOut: string;
};
type PaperInventoryRecord = {
  id: string;
  vehicleId: string;
  items: string;
  condition: string;
  date: string;
  paperFields: PaperInventoryFields;
};
const initialPaperFields = (): PaperQuotationFields => ({
  companyName: "Hirider 4x4 World (Kwacha)",
  address: "Makeni Road, Lusaka",
  email: "mkessa@hotmail.com",
  phone: "+260 966 766 693",
  bankName: "Access Bank",
  accountNumber: "0060211407831",
  vatNumber: "1004021290",
  quoteNo: "12844",
  date: "13/10/2026",
  salesperson: "PRECIOUS",
  billTo1: "RTSA",
  billTo2: "RTSA",
  shipTo1: "RTSA",
  shipTo2: "FORD RANGER",
  shipTo3: "BAK 6213",
  preparedBy: "PRECIOUS",
  signature: "",
  invoiceReference: "",
});
const roundMoney = (amount: number) => Math.round((amount + Number.EPSILON) * 100) / 100;
import {
  money,
  canDecideParts,
  departments as workshopDepartments,
  type Requisition,
  type Quotation,
  type Vehicle,
  type Inspection,
  type JobCard,
} from "@/lib/workshop";
import { getApiIdentity } from "@/lib/api";

type RecordKind = "quotations" | "inventory" | "jobs" | "requisitions" | "inspections";
const config = {
  quotations: {
    title: "Quotation Management",
    subtitle: "Prepare and issue one or more quotations against the authorized intake",
    singular: "quotation",
    headers: ["Quotation", "Vehicle", "Customer", "Amount", "Status", "Actions"],
  },
  inventory: {
    title: "Vehicle Inventory / Intake",
    subtitle: "Vehicle condition, belongings, signatures and intake authorization",
    singular: "inventory card",
    headers: ["Inventory card", "Vehicle", "Items recorded", "Created", "Actions"],
  },
  jobs: {
    title: "Job Card Management",
    subtitle: "Assign repair work to the relevant workshop departments",
    singular: "job card",
    headers: ["Job card", "Vehicle", "Work instructions", "Status", "Actions"],
  },
  requisitions: {
    title: "Parts Requisitions",
    subtitle:
      "Shortage requests generated after checking job-card parts against store availability",
    singular: "parts requisition",
    headers: ["Requisition", "Vehicle", "Part / item", "Qty", "Status", "Actions"],
  },
  inspections: {
    title: "Vehicle Inspections",
    subtitle: "Final checks, inspection results and foreman sign-off",
    singular: "inspection",
    headers: ["Inspection", "Vehicle", "Foreman", "Date", "Result", "Actions"],
  },
};
export function RecordsPage({ kind }: { kind: RecordKind }) {
  const w = useWorkspace();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("All");
  const [create, setCreate] = useState(false);
  const [detail, setDetail] = useState<string | null>(null);
  const [request, setRequest] = useState<Requisition | null>(null);
  const [selectedInspection, setSelectedInspection] = useState<Inspection | null>(null);
  const [paperQuote, setPaperQuote] = useState<Quotation | null>(null);
  const [recordDetail, setRecordDetail] = useState<{ title: string; body: ReactNode } | null>(null);
  const [saving, setSaving] = useState(false);
  const c = config[kind];
  const records =
    kind === "quotations"
      ? w.quotations
      : kind === "inventory"
        ? w.inventory
        : kind === "jobs"
          ? w.jobs
          : kind === "requisitions"
            ? w.requisitions
            : w.inspections;
  const matches = (row: { id: string; vehicleId: string; status?: string; result?: string }) => {
    const vehicle = w.vehicleFor(row.vehicleId);
    return (
      `${row.id} ${vehicle?.make} ${vehicle?.plate} ${vehicle?.customer}`
        .toLowerCase()
        .includes(`${query} ${w.search}`.trim().toLowerCase()) &&
      (filter === "All" || row.status === filter || row.result === filter)
    );
  };
  const count = records.filter(matches).length;
  const choices =
    kind === "quotations"
      ? ["Draft", "Issued", "Superseded", "Cancelled"]
      : kind === "requisitions"
        ? ["Pending", "Approved", "Rejected", "Ordered", "Dispatched"]
        : kind === "jobs"
          ? ["In progress", "Awaiting parts", "Complete"]
          : kind === "inspections"
            ? ["Pending", "Passed", "Rework required"]
            : [];
  async function sendQuote(q: Quotation) {
    if (!q.backendId) {
      toast.error("Save this quotation to the backend before issuing it.");
      return;
    }
    try {
      await backendApi.issueQuotation(q.backendId);
      await w.refresh();
      w.addActivity("Quotation issued", q.id);
      toast.success("Quotation issued. The intake authorization applies to this job.");
    } catch (cause) {
      toast.error(cause instanceof Error ? cause.message : "Could not issue quotation.");
    }
  }
  return (
    <>
      <PageHeading title={c.title} subtitle={c.subtitle}>
        <ExportButton filename={kind} rows={records} />
        {w.role === "Foreman" && kind !== "inventory" && (
          <Button onClick={() => setCreate(true)}>
            <Plus />
            New {c.singular}
          </Button>
        )}
      </PageHeading>
      {w.loading && (
        <div className="space-y-3" aria-label="Loading backend records">
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
          <Skeleton className="h-12 w-full" />
        </div>
      )}
      {w.error && (
        <div
          role="alert"
          className="rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive"
        >
          {w.error}{" "}
          <Button size="sm" variant="outline" onClick={() => void w.refresh()}>
            Retry
          </Button>
        </div>
      )}
      <div className="toolbar">
        <div className="filter-search">
          <Search />
          <Input
            aria-label={`Search ${c.title}`}
            placeholder={`Search ${c.title.toLowerCase()}...`}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        {choices.length > 0 && (
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-[175px]" aria-label="Filter status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All statuses</SelectItem>
              {choices.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>
      <DataTable headers={c.headers} empty={count === 0}>
        {kind === "quotations" &&
          w.quotations.filter(matches).map((q) => (
            <tr key={q.id}>
              <td className="cell-title">{q.id}</td>
              <td>
                <VehicleCell vehicle={w.vehicleFor(q.vehicleId)} />
              </td>
              <td>{w.vehicleFor(q.vehicleId)?.customer}</td>
              <td className="cell-title">{money(q.amount)}</td>
              <td>
                <Status>{q.status}</Status>
              </td>
              <td>
                <div className="flex items-center gap-1">
                  {w.role === "Foreman" && q.status === "Draft" && (
                    <Button size="sm" variant="outline" onClick={() => void sendQuote(q)}>
                      <Send />
                      Issue quotation
                    </Button>
                  )}
                  {kind === "quotations" && (
                    <Button size="sm" variant="outline" onClick={() => setPaperQuote(q)}>
                      <Printer />
                      Print / Preview
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    title="Quotation details"
                    aria-label={`View ${q.id}`}
                    onClick={() =>
                      setRecordDetail({
                        title: q.id,
                        body: (
                          <>
                            <VehicleCell vehicle={w.vehicleFor(q.vehicleId)} />
                            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                              <p>
                                <span className="text-muted-foreground">Bill To</span>
                                <br />
                                {w.vehicleFor(q.vehicleId)?.customer}
                              </p>
                              <p>
                                <span className="text-muted-foreground">Ship To</span>
                                <br />
                                {w.vehicleFor(q.vehicleId)?.customer}
                                <br />
                                {w.vehicleFor(q.vehicleId)?.make} ·{" "}
                                {w.vehicleFor(q.vehicleId)?.plate}
                              </p>
                              <p>
                                <span className="text-muted-foreground">Date</span>
                                <br />
                                {q.quotationDate
                                  ? new Date(q.quotationDate).toLocaleDateString()
                                  : "—"}
                              </p>
                              <p>
                                <span className="text-muted-foreground">Prepared By</span>
                                <br />
                                {q.preparedByName ?? "—"}
                              </p>
                            </div>
                            <div className="mt-4 overflow-x-auto rounded-md border">
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead>Qty</TableHead>
                                    <TableHead>Item</TableHead>
                                    <TableHead>Description</TableHead>
                                    <TableHead>Unit Price</TableHead>
                                    <TableHead>Total</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {(q.items ?? []).map((item, index) => (
                                    <TableRow key={`${q.id}-${index}`}>
                                      <TableCell>{item.quantity}</TableCell>
                                      <TableCell>{item.item}</TableCell>
                                      <TableCell>{item.description}</TableCell>
                                      <TableCell>{money(item.unitPrice)}</TableCell>
                                      <TableCell>
                                        {money(item.lineTotal ?? item.quantity * item.unitPrice)}
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </div>
                            <div className="ml-auto mt-4 grid w-full max-w-xs grid-cols-2 gap-y-2 text-sm">
                              <span>Subtotal</span>
                              <span className="text-right">{money(q.subtotal ?? q.amount)}</span>
                              <span>VAT</span>
                              <span className="text-right">{money(q.taxAmount ?? 0)}</span>
                              <strong>Total</strong>
                              <strong className="text-right">{money(q.amount)}</strong>
                            </div>
                            <p className="mt-5 text-center text-sm">Thank you for your business.</p>
                            <div className="mt-3">
                              <Status>{q.status}</Status>
                            </div>
                            {q.approvalReference && (
                              <p className="mt-4 text-muted-foreground">{q.approvalReference}</p>
                            )}
                          </>
                        ),
                      })
                    }
                  >
                    <ArrowUpRight />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        {kind === "inventory" &&
          w.inventory.filter(matches).map((i) => (
            <tr key={i.id}>
              <td className="cell-title">{i.id}</td>
              <td>
                <VehicleCell vehicle={w.vehicleFor(i.vehicleId)} />
              </td>
              <td>
                <div className="max-w-[280px] whitespace-normal leading-relaxed">{i.items}</div>
              </td>
              <td>{i.date}</td>
              <td>
                <Button
                  variant="ghost"
                  size="icon"
                  title="Inventory details"
                  aria-label={`View ${i.id}`}
                  onClick={() =>
                    setRecordDetail({
                      title: i.id,
                      body: (
                        <>
                          <VehicleCell vehicle={w.vehicleFor(i.vehicleId)} />
                          <h3 className="font-semibold mt-5 mb-2">
                            Vehicle belongings & accessories
                          </h3>
                          <p>{i.items}</p>
                          <h3 className="font-semibold mt-5 mb-2">Condition record</h3>
                          <p>{i.condition}</p>
                        </>
                      ),
                    })
                  }
                >
                  <ArrowUpRight />
                </Button>
              </td>
            </tr>
          ))}
        {kind === "jobs" &&
          w.jobs.filter(matches).map((j) => (
            <tr key={j.id}>
              <td className="cell-title">{j.id}</td>
              <td>
                <VehicleCell vehicle={w.vehicleFor(j.vehicleId)} />
              </td>
              <td>{j.work}</td>
              <td>
                <Status>{j.status}</Status>
              </td>
              <td>
                <Button
                  variant="ghost"
                  size="icon"
                  title="Job card details"
                  aria-label={`View ${j.id}`}
                  onClick={() =>
                    setRecordDetail({
                      title: j.id,
                      body: (
                        <>
                          <VehicleCell vehicle={w.vehicleFor(j.vehicleId)} />
                          <p className="mt-5">{j.work}</p>
                          <div className="mt-4">
                            <Status>{j.status}</Status>
                          </div>
                        </>
                      ),
                    })
                  }
                >
                  <ArrowUpRight />
                </Button>
              </td>
            </tr>
          ))}
        {kind === "requisitions" &&
          w.requisitions.filter(matches).map((r) => (
            <tr key={r.id}>
              <td className="cell-title">{r.id}</td>
              <td>
                <VehicleCell vehicle={w.vehicleFor(r.vehicleId)} />
              </td>
              <td>{r.part}</td>
              <td>{r.quantity}</td>
              <td>
                <Status>{r.status}</Status>
              </td>
              <td>
                <Button variant="outline" size="sm" onClick={() => setRequest(r)}>
                  View request
                  <ArrowUpRight size={12} />
                </Button>
              </td>
            </tr>
          ))}
        {kind === "inspections" &&
          w.inspections.filter(matches).map((i) => (
            <tr key={i.id}>
              <td className="cell-title">{i.id}</td>
              <td>
                <VehicleCell vehicle={w.vehicleFor(i.vehicleId)} />
              </td>
              <td>{i.foreman}</td>
              <td>{i.date}</td>
              <td>
                <Status>{i.result}</Status>
              </td>
              <td>
                <Button
                  variant="ghost"
                  size="icon"
                  title="Inspection details"
                  aria-label={`View ${i.id}`}
                  onClick={() => setSelectedInspection(i)}
                >
                  <ArrowUpRight />
                </Button>
              </td>
            </tr>
          ))}
      </DataTable>
      <TableFooter count={count} />
      {kind === "inventory" && (
        <div className="attention-band mt-6">
          <ShieldCheck size={18} />
          <div>
            <strong>Customer authorization comes first</strong>
            <p>Inventory cards are generated by the backend during vehicle intake.</p>
          </div>
        </div>
      )}
      {kind === "requisitions" && (
        <div className="attention-band mt-6">
          <ShieldCheck size={18} />
          <div>
            <strong>Requisitions are created for identified shortages</strong>
            <p>
              Submitted shortages can be ordered from a supplier. Manager or Boss approval applies
              to the dispatch order before stores issues parts.
            </p>
          </div>
        </div>
      )}
      {kind !== "inventory" && (
        <CreateRecord kind={kind} open={create} onClose={() => setCreate(false)} />
      )}
      <VehicleDetail id={detail} onClose={() => setDetail(null)} />
      <RequestDetail request={request} onClose={() => setRequest(null)} allowDecision={false} />
      <InspectionDetail
        inspection={selectedInspection}
        onClose={() => setSelectedInspection(null)}
      />
      <Dialog
        open={!!recordDetail}
        onOpenChange={(o) => {
          if (!o) setRecordDetail(null);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{recordDetail?.title}</DialogTitle>
            <DialogDescription>Workshop record details</DialogDescription>
          </DialogHeader>
          <div className="text-sm leading-relaxed">{recordDetail?.body}</div>
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!paperQuote}
        onOpenChange={(isOpen) => {
          if (!isOpen) setPaperQuote(null);
        }}
      >
        <DialogContent className="modal-scroll max-w-6xl sm:max-w-6xl">
          <DialogHeader>
            <DialogTitle>Quotation preview</DialogTitle>
            <DialogDescription>Paper quotation layout</DialogDescription>
          </DialogHeader>
          {paperQuote && (
            <PaperQuotationPreview quotation={paperQuote} onPrint={() => window.print()} />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

const inventoryAccessories = [
  "Sparewheel",
  "Jack",
  "Jack handle",
  "Triangles",
  "Wheel spanner",
  "Fire extinguisher",
  "Tool kit",
  "Wheel covers",
  "Car mats",
];
const newPaperInventoryFields = (): PaperInventoryFields => ({
  jobNo: "",
  registrationNo: "",
  make: "",
  date: (() => {
    const today = new Date();
    return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  })(),
  ownedBy: "",
  driver: "",
  accessories: inventoryAccessories.map((name) => ({
    name,
    present: "",
    ...(name === "Wheel covers" || name === "Car mats" ? { quantity: "" } : {}),
  })),
  fuelIn: "",
  fuelOut: "",
  kmsIn: "",
  kmsOut: "",
  damages: Array.from({ length: 14 }, () => ({ area: "", type: "" })),
  jobToBeDone: Array.from({ length: 14 }, () => ""),
  additional: Array.from({ length: 5 }, () => ({ name: "", present: "" })),
  remarks: ["", ""],
  deliveredBy: "",
  deliveredSignature: "",
  deliveredTel: "",
  receivedCheckedBy: "",
  collectedBy: "",
  collectedSignature: "",
  collectedDate: "",
  collectedPhone: "",
  releasedBy: "",
  timeOut: "",
});

function NewVehicleInventory({
  open,
  onClose,
  onSave,
}: {
  open: boolean;
  onClose: () => void;
  onSave: (fields: PaperInventoryFields) => void;
}) {
  const [fields, setFields] = useState(newPaperInventoryFields);
  const setField = <K extends keyof PaperInventoryFields>(key: K, value: PaperInventoryFields[K]) =>
    setFields((current) => ({ ...current, [key]: value }));
  const input = "h-9";
  const statusOptions = ["Present", "Missing"] as const;
  const renderStatus = (
    value: "" | "Present" | "Missing",
    onChange: (value: "Present" | "Missing") => void,
    label: string,
  ) => (
    <div
      role="group"
      aria-label={label}
      className="flex items-center gap-3 whitespace-nowrap text-sm"
    >
      {statusOptions.map((status) => (
        <label key={status} className="flex items-center gap-1">
          <input
            type="radio"
            name={label}
            checked={value === status}
            onChange={() => onChange(status)}
          />
          {status === "Present" ? "✓" : "✗"} {status}
        </label>
      ))}
    </div>
  );
  const renderText = (label: string, value: string, onChange: (value: string) => void) => (
    <label className="field min-w-0">
      <span>{label}</span>
      <Input value={value} onChange={(event) => onChange(event.target.value)} />
    </label>
  );
  const renderFuel = (label: string, value: string, onChange: (value: string) => void) => (
    <fieldset className="space-y-2">
      <legend className="text-sm font-medium">{label}</legend>
      <div className="flex flex-wrap gap-x-5 gap-y-2">
        {["E", "1/4", "1/2", "3/4", "F"].map((option) => (
          <label key={option} className="flex items-center gap-2 text-sm">
            <input
              type="radio"
              name={label}
              checked={value === option}
              onChange={() => onChange(option)}
            />
            {option}
          </label>
        ))}
      </div>
    </fieldset>
  );
  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="modal-scroll max-w-6xl sm:max-w-6xl">
        <DialogHeader>
          <DialogTitle>New vehicle inventory</DialogTitle>
          <DialogDescription>VEHICLE INVENTORY</DialogDescription>
        </DialogHeader>
        <form
          className="space-y-5"
          onSubmit={(event) => {
            event.preventDefault();
            onSave(fields);
          }}
        >
          <header className="space-y-1 border-b pb-4 text-center">
            <p className="text-lg font-bold">Hirider 4x4 World</p>
            <p>Kafue Road</p>
            <p>Cell +260 966 766 693</p>
            <p>Email mkessa@hotmail.com</p>
            <h2 className="pt-2 text-xl font-bold tracking-wide">VEHICLE INVENTORY</h2>
          </header>
          <section className="space-y-3">
            {renderText("JOB No.", fields.jobNo, (value) => setField("jobNo", value))}
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {renderText("Registration No.", fields.registrationNo, (value) =>
                setField("registrationNo", value),
              )}
              {renderText("Make", fields.make, (value) => setField("make", value))}
              {renderText("Date", fields.date, (value) => setField("date", value))}
              {renderText("Owned by", fields.ownedBy, (value) => setField("ownedBy", value))}
              {renderText("Driver", fields.driver, (value) => setField("driver", value))}
            </div>
          </section>
          <section className="space-y-3">
            <h3 className="font-semibold">ACCESSORIES</h3>
            <div className="overflow-x-auto rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead>
                    <TableHead>Present (✓) / Missing (✗)</TableHead>
                    <TableHead>Quantity</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {fields.accessories.map((item, index) => (
                    <TableRow key={item.name}>
                      <TableCell>{item.name}</TableCell>
                      <TableCell>
                        {renderStatus(
                          item.present,
                          (present) =>
                            setField(
                              "accessories",
                              fields.accessories.map((row, i) =>
                                i === index ? { ...row, present } : row,
                              ),
                            ),
                          `${item.name} status`,
                        )}
                      </TableCell>
                      <TableCell>
                        {item.quantity !== undefined && (
                          <Input
                            className={input}
                            aria-label={`${item.name} quantity`}
                            value={item.quantity}
                            onChange={(event) =>
                              setField(
                                "accessories",
                                fields.accessories.map((row, i) =>
                                  i === index ? { ...row, quantity: event.target.value } : row,
                                ),
                              )
                            }
                          />
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </section>
          <section className="grid gap-5 rounded-md border p-4 sm:grid-cols-2">
            {renderFuel("FUEL IN", fields.fuelIn, (value) => setField("fuelIn", value))}
            {renderFuel("FUEL OUT", fields.fuelOut, (value) => setField("fuelOut", value))}
            {renderText("KMS/Miles IN", fields.kmsIn, (value) => setField("kmsIn", value))}
            {renderText("KMS/Miles OUT", fields.kmsOut, (value) => setField("kmsOut", value))}
          </section>
          <section className="space-y-3">
            <h3 className="font-semibold">DAMAGES</h3>
            <p className="text-sm text-muted-foreground">C = Chip, D = Dent, S = Scratch</p>
            <div className="grid gap-2 sm:grid-cols-2">
              {fields.damages.map((damage, index) => (
                <div key={index} className="grid grid-cols-[1fr_110px] items-end gap-2">
                  <label className="field">
                    <span>Area {index + 1}</span>
                    <Input
                      value={damage.area}
                      onChange={(event) =>
                        setField(
                          "damages",
                          fields.damages.map((row, i) =>
                            i === index ? { ...row, area: event.target.value } : row,
                          ),
                        )
                      }
                    />
                  </label>
                  <label className="field">
                    <span>C / D / S</span>
                    <select
                      className="h-9 rounded-md border bg-background px-3 text-sm"
                      value={damage.type}
                      onChange={(event) =>
                        setField(
                          "damages",
                          fields.damages.map((row, i) =>
                            i === index ? { ...row, type: event.target.value } : row,
                          ),
                        )
                      }
                    >
                      <option value=""></option>
                      <option value="C">C</option>
                      <option value="D">D</option>
                      <option value="S">S</option>
                    </select>
                  </label>
                </div>
              ))}
            </div>
          </section>
          <section className="space-y-3">
            <h3 className="font-semibold">JOB TO BE DONE</h3>
            <div className="grid gap-2 sm:grid-cols-2">
              {fields.jobToBeDone.map((line, index) => (
                <label className="field" key={index}>
                  <span>Line {index + 1}</span>
                  <Input
                    value={line}
                    onChange={(event) =>
                      setField(
                        "jobToBeDone",
                        fields.jobToBeDone.map((value, i) =>
                          i === index ? event.target.value : value,
                        ),
                      )
                    }
                  />
                </label>
              ))}
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setField("jobToBeDone", [...fields.jobToBeDone, ""])}
            >
              <Plus /> Add line
            </Button>
          </section>
          <section className="space-y-3">
            <h3 className="font-semibold">ADDITIONAL</h3>
            <div className="space-y-2">
              {fields.additional.map((item, index) => (
                <div key={index} className="grid items-end gap-3 sm:grid-cols-[1fr_auto]">
                  {renderText(`Item ${index + 1}`, item.name, (name) =>
                    setField(
                      "additional",
                      fields.additional.map((row, i) => (i === index ? { ...row, name } : row)),
                    ),
                  )}
                  {renderStatus(
                    item.present,
                    (present) =>
                      setField(
                        "additional",
                        fields.additional.map((row, i) =>
                          i === index ? { ...row, present } : row,
                        ),
                      ),
                    `Additional item ${index + 1} status`,
                  )}
                </div>
              ))}
            </div>
          </section>
          <section className="space-y-3">
            <h3 className="font-semibold">Remarks</h3>
            {fields.remarks.map((remark, index) => (
              <label className="field" key={index}>
                <span>Line {index + 1}</span>
                <Input
                  value={remark}
                  onChange={(event) =>
                    setField(
                      "remarks",
                      fields.remarks.map((value, i) => (i === index ? event.target.value : value)),
                    )
                  }
                />
              </label>
            ))}
          </section>
          <section className="space-y-3 rounded-md border p-4">
            <h3 className="font-semibold">Customer&apos;s Conditions</h3>
            <h3 className="font-semibold">Service Management</h3>
          </section>
          <section className="space-y-4">
            <h3 className="font-semibold">DELIVERED BY</h3>
            <div className="grid gap-3 sm:grid-cols-3">
              {renderText("Name", fields.deliveredBy, (value) => setField("deliveredBy", value))}
              {renderText("Signature", fields.deliveredSignature, (value) =>
                setField("deliveredSignature", value),
              )}
              {renderText("Tel", fields.deliveredTel, (value) => setField("deliveredTel", value))}
            </div>
            {renderText("RECEIVED & CHECKED BY", fields.receivedCheckedBy, (value) =>
              setField("receivedCheckedBy", value),
            )}
            <h3 className="font-semibold">COLLECTED BY</h3>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {renderText("Name", fields.collectedBy, (value) => setField("collectedBy", value))}
              {renderText("Signature", fields.collectedSignature, (value) =>
                setField("collectedSignature", value),
              )}
              {renderText("Date", fields.collectedDate, (value) =>
                setField("collectedDate", value),
              )}
              {renderText("Phone No", fields.collectedPhone, (value) =>
                setField("collectedPhone", value),
              )}
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {renderText("Released by", fields.releasedBy, (value) =>
                setField("releasedBy", value),
              )}
              {renderText("Time Out (Hrs)", fields.timeOut, (value) => setField("timeOut", value))}
            </div>
          </section>
          <div className="flex justify-end gap-2 border-t pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              <Save /> Save inventory
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function PaperInventoryView({ fields }: { fields: PaperInventoryFields }) {
  return (
    <div className="space-y-4">
      <header className="text-center">
        <strong>Hirider 4x4 World</strong>
        <p>Kafue Road</p>
        <p>Cell +260 966 766 693</p>
        <p>Email mkessa@hotmail.com</p>
        <strong>VEHICLE INVENTORY</strong>
      </header>
      <div className="grid gap-2 sm:grid-cols-3">
        {[
          ["JOB No.", fields.jobNo],
          ["Registration No.", fields.registrationNo],
          ["Make", fields.make],
          ["Date", fields.date],
          ["Owned by", fields.ownedBy],
          ["Driver", fields.driver],
        ].map(([label, value]) => (
          <p key={label}>
            <strong>{label}</strong>: {value}
          </p>
        ))}
      </div>
      <h3 className="font-semibold">ACCESSORIES</h3>
      {fields.accessories.map((item) => (
        <p key={item.name}>
          {item.name}:{" "}
          {item.present === "Present" ? "✓ Present" : item.present === "Missing" ? "✗ Missing" : ""}
          {item.quantity ? ` · Quantity ${item.quantity}` : ""}
        </p>
      ))}
      <div className="grid gap-2 sm:grid-cols-2">
        <p>FUEL IN: {fields.fuelIn}</p>
        <p>FUEL OUT: {fields.fuelOut}</p>
        <p>KMS/Miles IN: {fields.kmsIn}</p>
        <p>KMS/Miles OUT: {fields.kmsOut}</p>
      </div>
      <h3 className="font-semibold">DAMAGES (C = Chip, D = Dent, S = Scratch)</h3>
      {fields.damages
        .filter((row) => row.area || row.type)
        .map((row, index) => (
          <p key={index}>
            {row.area} {row.type}
          </p>
        ))}
      <h3 className="font-semibold">JOB TO BE DONE</h3>
      {fields.jobToBeDone.filter(Boolean).map((line, index) => (
        <p key={index}>{line}</p>
      ))}
      <h3 className="font-semibold">ADDITIONAL</h3>
      {fields.additional.map((item, index) => (
        <p key={index}>
          {item.name} {item.present === "Present" ? "✓" : item.present === "Missing" ? "✗" : ""}
        </p>
      ))}
      <h3 className="font-semibold">Remarks</h3>
      {fields.remarks.map((line, index) => (
        <p key={index}>{line}</p>
      ))}
      <h3 className="font-semibold">Customer&apos;s Conditions</h3>
      <h3 className="font-semibold">Service Management</h3>
      <p>
        DELIVERED BY: {fields.deliveredBy} · Signature: {fields.deliveredSignature} · Tel:{" "}
        {fields.deliveredTel}
      </p>
      <p>RECEIVED &amp; CHECKED BY: {fields.receivedCheckedBy}</p>
      <p>
        COLLECTED BY: {fields.collectedBy} · Signature: {fields.collectedSignature} · Date:{" "}
        {fields.collectedDate} · Phone No: {fields.collectedPhone}
      </p>
      <p>
        Released by: {fields.releasedBy} · Time Out (Hrs): {fields.timeOut}
      </p>
    </div>
  );
}

function CreateRecord({
  kind,
  open,
  onClose,
}: {
  kind: RecordKind;
  open: boolean;
  onClose: () => void;
}) {
  const w = useWorkspace();
  const [vehicleId, setVehicleId] = useState("");
  const [selectedQuotationId, setSelectedQuotationId] = useState("");
  const [saving, setSaving] = useState(false);
  const [departmentRoutes, setDepartmentRoutes] = useState<
    Record<
      number,
      {
        applicability: string;
        notApplicableReason: string;
        manualWorkDescription: string;
        manualWorkInstructions: string;
      }
    >
  >({});
  const [quotationLines, setQuotationLines] = useState<QuotationDraftLine[]>(initialQuotationLines);
  const [paperFields, setPaperFields] = useState<PaperQuotationFields>(initialPaperFields);
  const editedPaperFields = useRef(new Set<string>());
  const c = config[kind];
  const availableDepartments = Array.isArray(w.workflowOptions["departments"])
    ? (w.workflowOptions["departments"] as Record<string, unknown>[])
    : [];
  const routeDepartments = workshopDepartments
    .map((canonicalName) =>
      availableDepartments.find(
        (department) =>
          String(department["name"] ?? "").toLowerCase() === canonicalName.toLowerCase(),
      ),
    )
    .filter((department): department is Record<string, unknown> => !!department);
  useEffect(() => {
    if (!open || kind !== "quotations") return;
    let active = true;
    void backendApi
      .getCompanySettings()
      .then((settings) => {
        const settingFields: Record<string, string> = {
          companyName: "companyName",
          address: "address",
          email: "email",
          phone: "phone",
          bankName: "bankName",
          accountNumber: "bankAccountNumber",
          vatNumber: "vatNumber",
        };
        if (active)
          setPaperFields((current) => {
            const next = { ...current };
            for (const [field, source] of Object.entries(settingFields) as [
              keyof PaperQuotationFields,
              string,
            ][]) {
              const value = settings[source];
              if (!editedPaperFields.current.has(field) && typeof value === "string" && value)
                next[field] = value;
            }
            return next;
          });
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, [kind, open]);
  useEffect(() => {
    if (open && kind === "quotations") {
      setQuotationLines(initialQuotationLines());
      setPaperFields(initialPaperFields());
      editedPaperFields.current = new Set();
      setVehicleId("");
      setSelectedQuotationId("");
    }
    if (open && kind === "jobs") setDepartmentRoutes({});
  }, [kind, open]);
  useEffect(() => {
    if (!open || kind !== "quotations") return;
    const name = getApiIdentity()?.displayName ?? "";
    if (!name) return;
    setPaperFields((current) => ({
      ...current,
      ...(editedPaperFields.current.has("salesperson") ? {} : { salesperson: name }),
      ...(editedPaperFields.current.has("preparedBy") ? {} : { preparedBy: name }),
    }));
  }, [kind, open, w.workflowOptions]);
  const eligible = w.vehicles.filter(
    (v) =>
      !v.released &&
      (kind === "jobs"
        ? w.inventory.some(
            (i) => i.vehicleId === v.id && i.status?.toUpperCase() === "COMPLETED",
          ) && w.quotations.some((q) => q.vehicleId === v.id && q.status === "Issued")
        : kind === "requisitions"
          ? w.jobs.some((j) => j.vehicleId === v.id)
          : kind === "inspections"
            ? v.stage === 7
            : true),
  );
  const quoteSubtotal = roundMoney(
    quotationLines.reduce(
      (sum, line) => sum + (Number(line.quantity) || 0) * (Number(line.unitPrice) || 0),
      0,
    ),
  );
  const quoteTax = roundMoney(
    quotationLines.reduce((sum, line) => {
      const lineSubtotal = roundMoney((Number(line.quantity) || 0) * (Number(line.unitPrice) || 0));
      return sum + roundMoney((lineSubtotal * QUOTATION_VAT_RATE) / 100);
    }, 0),
  );
  const quoteTotal = roundMoney(quoteSubtotal + quoteTax);
  const validQuotationLines = quotationLines.filter(
    (line) =>
      line.item.trim() &&
      line.description.trim() &&
      Number.isFinite(Number(line.quantity)) &&
      Number(line.quantity) > 0 &&
      Number.isFinite(Number(line.unitPrice)) &&
      Number(line.unitPrice) > 0,
  );
  const hasPartialLine = quotationLines.some(
    (line) =>
      (line.item.trim() || line.description.trim() || line.unitPrice.trim()) &&
      !validQuotationLines.includes(line),
  );
  const quoteMissingMessage = [
    !vehicleId ? "Select a registered vehicle." : "",
    validQuotationLines.length === 0
      ? "Add at least one valid line with an item, description, positive quantity and price."
      : "",
    hasPartialLine ? "Complete or remove each partially filled line." : "",
  ]
    .filter(Boolean)
    .join(" ");
  const updatePaperField = (field: string, value: string) => {
    editedPaperFields.current.add(field);
    setPaperFields((current) => ({ ...current, [field]: value }));
  };
  const fillFromVehicle = (field: string, value: string) => {
    if (!editedPaperFields.current.has(field))
      setPaperFields((current) => ({ ...current, [field]: value }));
  };
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const v = eligible.find((v) => v.id === vehicleId);
    if (!v) {
      toast.error("Select an eligible vehicle.");
      return;
    }
    const f = new FormData(e.currentTarget);
    const text = (name: string) => String(f.get(name) ?? "");
    const save = async (operation: () => Promise<unknown>, successMessage: string) => {
      setSaving(true);
      try {
        await operation();
        await w.refresh();
        w.addActivity(`${c.singular} saved`, `${w.foreman} · ${v.plate}`);
        toast.success(successMessage);
        setVehicleId("");
        setSelectedQuotationId("");
        onClose();
      } catch (cause) {
        toast.error(cause instanceof Error ? cause.message : `Could not save ${c.singular}.`);
      } finally {
        setSaving(false);
      }
    };
    if (kind === "quotations") {
      if (hasPartialLine) {
        toast.error("Complete or remove each partially filled line.");
        return;
      }
      const normalizedLines = validQuotationLines.map((line) => ({
        ...line,
        quantity: Number(line.quantity),
        unitPrice: Number(line.unitPrice),
      }));
      if (!normalizedLines.length) {
        toast.error("Add at least one quotation line item.");
        return;
      }
      const refs = w.backendRefs[v.id];
      if (!refs?.jobId) {
        toast.error("This vehicle has no saved backend job. Complete intake first.");
        return;
      }
      const items = normalizedLines.map((line) => ({
        itemType:
          line.item.trim().toLowerCase() === "labour" ? ("LABOUR" as const) : ("PART" as const),
        item: line.item.trim(),
        description: line.description.trim(),
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        lineTotal: roundMoney(line.quantity * line.unitPrice),
        taxAmount: roundMoney(
          (roundMoney(line.quantity * line.unitPrice) * QUOTATION_VAT_RATE) / 100,
        ),
      }));
      const quote: Quotation = {
        id: `DRAFT-${Date.now()}`,
        vehicleId: v.id,
        amount: quoteTotal,
        subtotal: quoteSubtotal,
        taxAmount: quoteTax,
        description: items.map((item) => item.description).join("; "),
        preparedByName: paperFields["preparedBy"],
        paperFields,
        items,
        status: "Draft",
      };
      await save(
        () => backendApi.createQuotation(refs.jobId!, quote),
        "Quotation draft saved. Issue it when ready.",
      );
      return;
    }
    if (kind === "jobs") {
      const refs = w.backendRefs[v.id];
      const quotation = w.quotations.find(
        (candidate) => candidate.id === selectedQuotationId && candidate.status === "Issued",
      );
      const issuedQuotationId = quotation?.backendId;
      if (!refs?.jobId || !issuedQuotationId) {
        toast.error("Select an issued quotation belonging to this vehicle.");
        return;
      }
      if (routeDepartments.length !== workshopDepartments.length) {
        toast.error(
          "The backend has not returned all six active workshop departments yet. Retry after workflow options load.",
        );
        return;
      }
      const routes = routeDepartments.map((department) => {
        const departmentId = Number(department["id"]);
        const route = departmentRoutes[departmentId];
        if (!route?.applicability)
          throw new Error(
            `Choose whether ${String(department["name"])} is required or not applicable.`,
          );
        if (route.applicability === "NOT_APPLICABLE" && !route.notApplicableReason.trim()) {
          throw new Error(`Enter why ${String(department["name"])} is not applicable.`);
        }
        if (route.applicability === "REQUIRED" && !route.manualWorkDescription.trim()) {
          throw new Error(`Describe the work for ${String(department["name"])}.`);
        }
        return {
          departmentId,
          applicability: route.applicability as "REQUIRED" | "NOT_APPLICABLE",
          ...(route.applicability === "NOT_APPLICABLE"
            ? { notApplicableReason: route.notApplicableReason.trim() }
            : {
                manualWorkDescription: route.manualWorkDescription.trim(),
                manualWorkInstructions:
                  route.manualWorkInstructions.trim() || text("description").trim(),
              }),
        };
      });
      if (!routes.some((route) => route.applicability === "REQUIRED")) {
        toast.error("Mark at least one department as required for this job.");
        return;
      }
      const workDescription = text("description").trim();
      const job: JobCard = {
        id: `DRAFT-${Date.now()}`,
        vehicleId: v.id,
        department: routes
          .filter((route) => route.applicability === "REQUIRED")
          .map((route) => route.departmentId)
          .join(","),
        work: workDescription,
        status: "Pending",
        due: text("due") || "To be confirmed",
        departmentRoutes: routes,
      };
      await save(
        () => backendApi.createJobCard(job, { ...refs, quotationId: issuedQuotationId }, routes),
        "Job card and department routes saved.",
      );
      return;
    }
    if (kind === "requisitions") {
      const refs = w.backendRefs[v.id];
      if (!refs?.jobId || !refs.jobCardId) {
        toast.error("A saved job card is required before checking parts availability.");
        return;
      }
      if (!text("description").trim()) {
        toast.error("Enter why the unavailable parts are needed.");
        return;
      }
      await save(async () => {
        const availability = await w.api.checkPartsAvailability(refs.jobCardId!);
        const lines = Array.isArray(availability["parts"])
          ? (availability["parts"] as Record<string, unknown>[])
          : [];
        const shortages = lines.filter((line) => Number(line["quantityShort"] ?? 0) > 0);
        if (!shortages.length) {
          throw new Error(
            "No parts shortage was found. Use Procurement & Dispatch to reserve available stock and create the dispatch order.",
          );
        }
        return w.api.createRequisition(refs.jobId!, {
          id: `DRAFT-${Date.now()}`,
          vehicleId: v.id,
          part: shortages.map((line) => String(line["partName"] ?? "Part")).join(", "),
          quantity: shortages.reduce(
            (total, line) => total + Number(line["quantityShort"] ?? 0),
            0,
          ),
          department: "Workshop",
          reason: text("description").trim(),
          amount: 0,
          foreman: w.foreman,
          status: "Pending",
          date: new Date().toLocaleDateString("en-GB"),
        });
      }, "Parts shortage request submitted for procurement.");
      return;
    }
    if (kind === "inspections") {
      const refs = w.backendRefs[v.id];
      if (!refs?.jobId) {
        toast.error("This vehicle has no backend job to inspect.");
        return;
      }
      await save(() => backendApi.startFinalInspection(refs.jobId!), "Final inspection started.");
      return;
    }
    if (kind === "inventory") {
      toast.error(
        "Inventory cards are created and completed through Vehicle Registration & Intake.",
      );
    }
  }
  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) onClose();
      }}
    >
      <DialogContent
        className={kind === "quotations" ? "modal-scroll max-w-6xl sm:max-w-6xl" : "modal-scroll"}
      >
        <DialogHeader>
          <DialogTitle>New {c.singular}</DialogTitle>
          {kind !== "quotations" && (
            <DialogDescription>{w.foreman} · 11 November 2026</DialogDescription>
          )}
        </DialogHeader>
        {kind === "quotations" ? (
          <form onSubmit={submit} className="space-y-5">
            <div className="rounded-md border p-4">
              <h3 className="mb-3 font-semibold">Company header</h3>
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {(
                  [
                    ["companyName", "Company name"],
                    ["address", "Address"],
                    ["email", "Email"],
                    ["phone", "Phone"],
                    ["bankName", "Bank Details"],
                    ["accountNumber", "Account Number"],
                    ["vatNumber", "VAT"],
                  ] as const
                ).map(([field, label]) => (
                  <label className="field" key={field}>
                    <span>{label}</span>
                    <Input
                      value={paperFields[field] ?? ""}
                      onChange={(event) => updatePaperField(field, event.target.value)}
                    />
                    <small className="text-muted-foreground">
                      Kept in the quotation print metadata; not a dedicated quotation field.
                    </small>
                  </label>
                ))}
              </div>
            </div>
            <div className="grid gap-4 rounded-md border p-4 lg:grid-cols-[1fr_2fr]">
              <h3 className="text-xl font-bold">Quote</h3>
              <div className="grid gap-3 sm:grid-cols-3">
                {(
                  [
                    ["date", "Date"],
                    ["quoteNo", "Quote No."],
                    ["salesperson", "Salesperson"],
                  ] as const
                ).map(([field, label]) => (
                  <label className="field" key={field}>
                    <span>{label}</span>
                    <Input
                      value={paperFields[field] ?? ""}
                      onChange={(event) => updatePaperField(field, event.target.value)}
                    />
                    {field === "quoteNo" && (
                      <small className="text-muted-foreground">
                        The backend generates the saved quotation number; your value remains in
                        print metadata.
                      </small>
                    )}
                    {field === "date" && (
                      <small className="text-muted-foreground">
                        The create request has no date field; this value is kept for printing.
                      </small>
                    )}
                    {field === "salesperson" && (
                      <small className="text-muted-foreground">
                        Backend attribution uses the configured employee ID; this printed name is
                        retained in quotation metadata.
                      </small>
                    )}
                  </label>
                ))}
              </div>
            </div>
            <div className="grid gap-4 rounded-md border p-4 lg:grid-cols-2">
              <section className="space-y-3">
                <h3 className="font-semibold">Bill To</h3>
                {(["billTo1", "billTo2"] as const).map((field, index) => (
                  <label className="field" key={field}>
                    <span>Line {index + 1}</span>
                    <Input
                      value={paperFields[field] ?? ""}
                      onChange={(event) => updatePaperField(field, event.target.value)}
                    />
                    {index === 1 && (
                      <small className="text-muted-foreground">
                        The backend has no second Bill To line; kept for printing.
                      </small>
                    )}
                    {index === 0 && (
                      <small className="text-muted-foreground">
                        The backend uses the linked customer; this printed line is retained in
                        quotation metadata.
                      </small>
                    )}
                  </label>
                ))}
              </section>
              <section className="space-y-3">
                <h3 className="font-semibold">Ship To</h3>
                <label className="field">
                  <span>Registered vehicle *</span>
                  <Select
                    value={vehicleId}
                    onValueChange={(nextId) => {
                      setVehicleId(nextId);
                      const selected = eligible.find((vehicle) => vehicle.id === nextId);
                      if (!selected) return;
                      fillFromVehicle("billTo1", selected.customer);
                      fillFromVehicle("shipTo1", selected.customer);
                      fillFromVehicle("shipTo2", selected.make);
                      fillFromVehicle("shipTo3", selected.plate);
                    }}
                  >
                    <SelectTrigger aria-label="Registered vehicle">
                      <SelectValue placeholder="Select a registered vehicle" />
                    </SelectTrigger>
                    <SelectContent>
                      {eligible.map((vehicle) => (
                        <SelectItem key={vehicle.id} value={vehicle.id}>
                          {vehicle.make} · {vehicle.plate} · {vehicle.customer}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </label>
                {w.vehicles.length === 0 ? (
                  <p className="flex items-center gap-2 text-sm text-muted-foreground">
                    No vehicles loaded. Check that the backend is running and register a vehicle
                    first.
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={() => void w.refresh()}
                    >
                      Retry
                    </Button>
                  </p>
                ) : eligible.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    No eligible registered vehicles are available.
                  </p>
                ) : null}
                {(
                  [
                    ["shipTo1", "Line 1 · Customer"],
                    ["shipTo2", "Line 2 · Vehicle make/model"],
                    ["shipTo3", "Line 3 · Registration number"],
                  ] as const
                ).map(([field, label]) => (
                  <label className="field" key={field}>
                    <span>{label}</span>
                    <Input
                      value={paperFields[field] ?? ""}
                      onChange={(event) => updatePaperField(field, event.target.value)}
                    />
                    <small className="text-muted-foreground">
                      The saved job supplies the linked customer and vehicle; this typed value is
                      retained for printing.
                    </small>
                  </label>
                ))}
              </section>
            </div>
            <section className="space-y-3">
              <h3 className="font-semibold">Line items</h3>
              <div className="overflow-x-auto rounded-md border">
                <Table className="min-w-[1040px] table-fixed">
                  <colgroup>
                    <col className="w-[76px]" />
                    <col className="w-[250px]" />
                    <col className="w-[340px]" />
                    <col className="w-[175px]" />
                    <col className="w-[175px]" />
                  </colgroup>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Qty</TableHead>
                      <TableHead>Item</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Unit Price</TableHead>
                      <TableHead>Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {quotationLines.map((line, index) => (
                      <TableRow key={index}>
                        <TableCell>
                          <Input
                            aria-label={`Line ${index + 1} quantity`}
                            type="number"
                            step="0.01"
                            value={line.quantity}
                            onChange={(event) =>
                              setQuotationLines((lines) =>
                                lines.map((current, row) =>
                                  row === index
                                    ? { ...current, quantity: event.target.value }
                                    : current,
                                ),
                              )
                            }
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Input
                              aria-label={`Line ${index + 1} item`}
                              maxLength={80}
                              value={line.item}
                              onChange={(event) =>
                                setQuotationLines((lines) =>
                                  lines.map((current, row) =>
                                    row === index
                                      ? { ...current, item: event.target.value }
                                      : current,
                                  ),
                                )
                              }
                            />
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              aria-label={`Remove line ${index + 1}`}
                              onClick={() =>
                                setQuotationLines((lines) =>
                                  lines.filter((_, row) => row !== index),
                                )
                              }
                            >
                              <X />
                            </Button>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            aria-label={`Line ${index + 1} description`}
                            maxLength={255}
                            value={line.description}
                            onChange={(event) =>
                              setQuotationLines((lines) =>
                                lines.map((current, row) =>
                                  row === index
                                    ? { ...current, description: event.target.value }
                                    : current,
                                ),
                              )
                            }
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <span>K</span>
                            <Input
                              className="min-w-0 flex-1"
                              aria-label={`Line ${index + 1} unit price in ZMW`}
                              type="number"
                              step="0.01"
                              value={line.unitPrice}
                              onChange={(event) =>
                                setQuotationLines((lines) =>
                                  lines.map((current, row) =>
                                    row === index
                                      ? { ...current, unitPrice: event.target.value }
                                      : current,
                                  ),
                                )
                              }
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Input
                            aria-label={`Line ${index + 1} total`}
                            readOnly
                            value={money(
                              (Number(line.quantity) || 0) * (Number(line.unitPrice) || 0),
                            )}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setQuotationLines((lines) => [...lines, emptyQuotationLine()])}
              >
                <Plus /> Add line
              </Button>
            </section>
            <div className="ml-auto grid max-w-sm grid-cols-2 gap-y-2 rounded-md border p-4 text-sm">
              <span>Subtotal</span>
              <Input aria-label="Subtotal" readOnly value={money(quoteSubtotal)} />
              <span>VAT (16%)</span>
              <Input aria-label="VAT" readOnly value={money(quoteTax)} />
              <strong>Total</strong>
              <Input aria-label="Total" readOnly value={money(quoteTotal)} />
            </div>
            <div className="grid gap-3 rounded-md border p-4 sm:grid-cols-2">
              {(["preparedBy", "signature", "invoiceReference"] as const).map((field) => (
                <label className="field" key={field}>
                  <span>
                    {field === "preparedBy"
                      ? "Prepared By"
                      : field === "signature"
                        ? "Signature"
                        : "Invoice reference"}
                  </span>
                  <Input
                    value={paperFields[field] ?? ""}
                    onChange={(event) => updatePaperField(field, event.target.value)}
                  />
                  {field !== "preparedBy" && (
                    <small className="text-muted-foreground">
                      The backend has no dedicated field; this value is retained for printing.
                    </small>
                  )}
                  {field === "preparedBy" && (
                    <small className="text-muted-foreground">
                      Backend attribution uses the configured employee ID; this printed name is
                      retained in quotation metadata.
                    </small>
                  )}
                </label>
              ))}
              <p className="self-end text-sm">Thank you for your business.</p>
            </div>
            {quoteMissingMessage && (
              <p className="text-sm text-muted-foreground">{quoteMissingMessage}</p>
            )}
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={!vehicleId || validQuotationLines.length === 0}>
                <Save /> Save quotation
              </Button>
            </div>
          </form>
        ) : (
          <form onSubmit={submit} className="space-y-4">
            <label className="field">
              <span>Vehicle *</span>
              <Select
                value={vehicleId}
                onValueChange={(next) => {
                  setVehicleId(next);
                  setSelectedQuotationId("");
                }}
              >
                <SelectTrigger aria-label="Vehicle">
                  <SelectValue placeholder="Select a vehicle" />
                </SelectTrigger>
                <SelectContent>
                  {eligible.map((v) => (
                    <SelectItem key={v.id} value={v.id}>
                      {v.make} · {v.plate}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </label>
            {eligible.length === 0 && (
              <p className="text-xs text-muted-foreground">
                {kind === "inventory"
                  ? "Inventory cards are created through Vehicle Registration & Intake."
                  : kind === "jobs"
                    ? "No completed intake with an issued quotation is awaiting a job card."
                    : kind === "inspections"
                      ? "No vehicles are currently awaiting inspection."
                      : "No eligible vehicle records are available."}
              </p>
            )}
            {kind === "inventory" ? (
              <>
                <p className="text-sm text-muted-foreground">
                  Inventory cards are created automatically during vehicle intake.
                </p>
              </>
            ) : (
              <>
                {kind === "requisitions" && (
                  <p className="text-sm text-muted-foreground">
                    The system checks the job card against store availability first. A purchase
                    requisition is submitted only for identified shortages; available parts go to
                    the dispatch order process.
                  </p>
                )}
                {kind === "jobs" && (
                  <>
                    <label className="field">
                      <span>Issued quotation *</span>
                      <Select value={selectedQuotationId} onValueChange={setSelectedQuotationId}>
                        <SelectTrigger aria-label="Issued quotation">
                          <SelectValue placeholder="Select an issued quote" />
                        </SelectTrigger>
                        <SelectContent>
                          {w.quotations
                            .filter(
                              (quote) => quote.vehicleId === vehicleId && quote.status === "Issued",
                            )
                            .map((quote) => (
                              <SelectItem key={quote.id} value={quote.id}>
                                {quote.id} · {money(quote.amount)}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </label>
                    <section className="space-y-3 rounded-md border p-4">
                      <div>
                        <h3 className="font-semibold">Department workflow routing</h3>
                        <p className="mt-1 text-xs text-muted-foreground">
                          Choose required or not applicable for each of the six departments. Give a
                          reason for each N/A route and specify work for every required route.
                        </p>
                      </div>
                      {routeDepartments.map((department) => {
                        const departmentId = Number(department["id"]);
                        const name = String(department["name"]);
                        const route = departmentRoutes[departmentId] ?? {
                          applicability: "",
                          notApplicableReason: "",
                          manualWorkDescription: "",
                          manualWorkInstructions: "",
                        };
                        return (
                          <div
                            key={departmentId}
                            className="grid gap-3 rounded-md bg-muted/30 p-3 sm:grid-cols-2"
                          >
                            <div className="field">
                              <span>{name} *</span>
                              <Select
                                value={route.applicability}
                                onValueChange={(value) =>
                                  setDepartmentRoutes((previous) => ({
                                    ...previous,
                                    [departmentId]: { ...route, applicability: value },
                                  }))
                                }
                              >
                                <SelectTrigger aria-label={`${name} applicability`}>
                                  <SelectValue placeholder="Select route" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="REQUIRED">Required</SelectItem>
                                  <SelectItem value="NOT_APPLICABLE">Not applicable</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            {route.applicability === "NOT_APPLICABLE" ? (
                              <label className="field">
                                <span>Why N/A? *</span>
                                <Input
                                  value={route.notApplicableReason}
                                  onChange={(event) =>
                                    setDepartmentRoutes((previous) => ({
                                      ...previous,
                                      [departmentId]: {
                                        ...route,
                                        notApplicableReason: event.target.value,
                                      },
                                    }))
                                  }
                                  placeholder={`Reason ${name} is not required`}
                                  required
                                />
                              </label>
                            ) : route.applicability === "REQUIRED" ? (
                              <>
                                <label className="field">
                                  <span>Work required *</span>
                                  <Input
                                    value={route.manualWorkDescription}
                                    onChange={(event) =>
                                      setDepartmentRoutes((previous) => ({
                                        ...previous,
                                        [departmentId]: {
                                          ...route,
                                          manualWorkDescription: event.target.value,
                                        },
                                      }))
                                    }
                                    placeholder={`Work for ${name}`}
                                    required
                                  />
                                </label>
                                <label className="field sm:col-span-2">
                                  <span>Instructions</span>
                                  <Textarea
                                    rows={2}
                                    value={route.manualWorkInstructions}
                                    onChange={(event) =>
                                      setDepartmentRoutes((previous) => ({
                                        ...previous,
                                        [departmentId]: {
                                          ...route,
                                          manualWorkInstructions: event.target.value,
                                        },
                                      }))
                                    }
                                    placeholder="Department work instructions"
                                  />
                                </label>
                              </>
                            ) : null}
                          </div>
                        );
                      })}
                    </section>
                  </>
                )}
                <label className="field">
                  <span>
                    {kind === "jobs"
                      ? "Work instructions"
                      : kind === "requisitions"
                        ? "Reason for requesting parts"
                        : "Inspection findings & completion notes"}{" "}
                    *
                  </span>
                  <Textarea name="description" required rows={3} />
                </label>
                {kind === "inspections" && (
                  <p className="text-sm text-muted-foreground">
                    Starting an inspection creates the backend checklist. Checklist outcomes are
                    recorded through the backend inspection workflow.
                  </p>
                )}
              </>
            )}
            <div className="flex justify-end gap-2 pt-3">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={!vehicleId || saving}>
                <Save />
                {saving
                  ? "Saving…"
                  : kind === "requisitions"
                    ? "Check and request missing parts"
                    : kind === "jobs"
                      ? "Create job card"
                      : "Save record"}
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}

function PaperQuotationPreview({
  quotation,
  onPrint,
}: {
  quotation: Quotation;
  onPrint: () => void;
}) {
  const fields = {
    ...initialPaperFields(),
    ...(quotation.paperFields ?? {}),
  } as PaperQuotationFields;
  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <Button type="button" variant="outline" onClick={onPrint}>
          <Printer /> Print
        </Button>
      </div>
      <article className="space-y-5 rounded-md border bg-white p-6 text-foreground">
        <header className="border-b pb-4">
          <h2 className="text-xl font-bold">{fields.companyName}</h2>
          <p>{fields.address}</p>
          <p>
            {fields.email} · {fields.phone}
          </p>
          <p>
            {fields.bankName} · {fields.accountNumber}
          </p>
          <p>VAT: {fields.vatNumber}</p>
        </header>
        <div className="grid gap-4 sm:grid-cols-[1fr_2fr]">
          <h3 className="text-2xl font-bold">Quote</h3>
          <div className="grid gap-3 sm:grid-cols-3">
            <div>
              <span className="text-muted-foreground">Date</span>
              <p>{fields.date}</p>
            </div>
            <div>
              <span className="text-muted-foreground">Quote No.</span>
              <p>{fields.quoteNo}</p>
              {fields.quoteNo !== quotation.id && (
                <small className="text-muted-foreground">Backend assigned: {quotation.id}</small>
              )}
            </div>
            <div>
              <span className="text-muted-foreground">Salesperson</span>
              <p>{fields.salesperson}</p>
            </div>
          </div>
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <section>
            <h3 className="font-semibold">Bill To</h3>
            <p>{fields.billTo1}</p>
            <p>{fields.billTo2}</p>
          </section>
          <section>
            <h3 className="font-semibold">Ship To</h3>
            <p>{fields.shipTo1}</p>
            <p>{fields.shipTo2}</p>
            <p>{fields.shipTo3}</p>
          </section>
        </div>
        <div className="overflow-x-auto">
          <Table className="min-w-[720px]">
            <TableHeader>
              <TableRow>
                <TableHead>Qty</TableHead>
                <TableHead>Item</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Unit Price</TableHead>
                <TableHead>Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(quotation.items ?? []).map((item, index) => (
                <TableRow key={`${quotation.id}-paper-${index}`}>
                  <TableCell>{item.quantity}</TableCell>
                  <TableCell>{item.item}</TableCell>
                  <TableCell>{item.description}</TableCell>
                  <TableCell>{money(item.unitPrice)}</TableCell>
                  <TableCell>{money(item.quantity * item.unitPrice)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <div className="ml-auto grid max-w-xs grid-cols-2 gap-y-2 text-sm">
          <span>Subtotal</span>
          <span className="text-right">{money(quotation.subtotal ?? quotation.amount)}</span>
          <span>VAT (16%)</span>
          <span className="text-right">{money(quotation.taxAmount ?? 0)}</span>
          <strong>Total</strong>
          <strong className="text-right">{money(quotation.amount)}</strong>
        </div>
        <footer className="grid gap-5 border-t pt-4 sm:grid-cols-2">
          <div>
            <span className="text-muted-foreground">Prepared By</span>
            <p>{fields.preparedBy}</p>
          </div>
          <div>
            <span className="text-muted-foreground">Signature</span>
            <p>{fields.signature}</p>
          </div>
          <div>
            <span className="text-muted-foreground">Invoice reference</span>
            <p>{fields.invoiceReference}</p>
          </div>
          <p className="self-end text-sm">Thank you for your business.</p>
        </footer>
      </article>
    </div>
  );
}

function InspectionDetail({
  inspection,
  onClose,
}: {
  inspection: Inspection | null;
  onClose: () => void;
}) {
  const w = useWorkspace();
  const [statuses, setStatuses] = useState<Record<number, "PASS" | "FAIL">>({});
  const [comments, setComments] = useState<Record<number, string>>({});
  const [departments, setDepartments] = useState<Record<number, string>>({});
  const id = inspection?.backendId;
  const stored = id ? w.inspectionDetails.get(id) : undefined;
  const details = stored?.["details"] as Record<string, unknown> | undefined;
  const signoffData = stored?.["signoffs"] as Record<string, unknown> | undefined;
  const checklist = Array.isArray(details?.["checklist"])
    ? (details["checklist"] as Record<string, unknown>[])
    : [];
  const signoffs = Array.isArray(signoffData?.["signoffs"])
    ? (signoffData["signoffs"] as Record<string, unknown>[])
    : [];
  const options = (w.workflowOptions["departments"] ?? []) as Record<string, unknown>[];
  const run = (action: () => Promise<unknown>, message: string) =>
    void action()
      .then(async () => {
        await w.refresh();
        toast.success(message);
      })
      .catch((error: Error) => toast.error(error.message));
  return (
    <Dialog
      open={!!inspection}
      onOpenChange={(open) => {
        if (!open) {
          setStatuses({});
          setComments({});
          setDepartments({});
          onClose();
        }
      }}
    >
      <DialogContent className="modal-scroll max-w-4xl">
        <DialogHeader>
          <DialogTitle>Final inspection · {inspection?.id}</DialogTitle>
          <DialogDescription>
            {w.vehicleFor(inspection?.vehicleId ?? "")?.plate} ·{" "}
            {String(details?.["inspectionStatus"] ?? inspection?.result ?? "")} ·{" "}
            {String(details?.["inspectionDecision"] ?? "Decision pending")}
          </DialogDescription>
        </DialogHeader>
        {!details ? (
          <Button variant="outline" onClick={() => void w.refresh()}>
            Load checklist
          </Button>
        ) : (
          <>
            <div className="max-h-[45vh] space-y-3 overflow-auto">
              {checklist.map((item) => {
                const itemId = Number(item["id"]);
                const saved = String(item["checkStatus"] ?? "PENDING");
                const status =
                  statuses[itemId] ?? (saved === "PASS" || saved === "FAIL" ? saved : undefined);
                return (
                  <div key={itemId} className="rounded-md border p-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <strong>
                          {String(item["itemCode"])} · {String(item["itemName"])}
                        </strong>
                        <p className="text-xs text-muted-foreground">
                          {String(item["inspectionCategory"])} · {saved}
                        </p>
                      </div>
                      <Select
                        value={status ?? ""}
                        onValueChange={(value: "PASS" | "FAIL") =>
                          setStatuses((prev) => ({ ...prev, [itemId]: value }))
                        }
                      >
                        <SelectTrigger className="w-36">
                          <SelectValue placeholder="Set result" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="PASS">Pass</SelectItem>
                          <SelectItem value="FAIL">Fail</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="mt-2 flex gap-2">
                      <Input
                        placeholder="Comments"
                        value={comments[itemId] ?? String(item["comments"] ?? "")}
                        onChange={(e) =>
                          setComments((prev) => ({ ...prev, [itemId]: e.target.value }))
                        }
                      />
                      {status === "FAIL" && (
                        <Select
                          value={
                            departments[itemId] ?? String(item["responsibleDepartmentId"] ?? "")
                          }
                          onValueChange={(value) =>
                            setDepartments((prev) => ({ ...prev, [itemId]: value }))
                          }
                        >
                          <SelectTrigger className="w-52">
                            <SelectValue placeholder="Responsible department" />
                          </SelectTrigger>
                          <SelectContent>
                            {options.map((d) => (
                              <SelectItem key={String(d["id"])} value={String(d["id"])}>
                                {String(d["name"])}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                      {status && (
                        <Button
                          size="sm"
                          onClick={() => {
                            const dept =
                              departments[itemId] ?? String(item["responsibleDepartmentId"] ?? "");
                            if (status === "FAIL" && !dept) {
                              toast.error("Select the responsible department for a failed item.");
                              return;
                            }
                            run(
                              () =>
                                w.api.updateInspectionItem(
                                  id!,
                                  itemId,
                                  status,
                                  comments[itemId] ?? String(item["comments"] ?? ""),
                                  dept ? Number(dept) : undefined,
                                ),
                              "Inspection item updated.",
                            );
                          }}
                        >
                          Save
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
            <h3 className="font-semibold">Department sign-offs</h3>
            <div className="space-y-2">
              {signoffs.map((item) => {
                const departmentId = Number(item["departmentId"]);
                return (
                  <div
                    className="flex items-center justify-between gap-2 rounded border p-2"
                    key={departmentId}
                  >
                    <span>
                      {String(item["departmentName"])} · {String(item["signoffStatus"])}
                    </span>
                    {String(item["signoffStatus"]) === "PENDING" && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          run(
                            () =>
                              w.api.signoffInspectionDepartment(
                                id!,
                                departmentId,
                                "Final inspection department sign-off",
                              ),
                            "Department sign-off recorded.",
                          )
                        }
                      >
                        Sign off
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
            <div className="flex flex-wrap justify-end gap-2">
              <Button
                variant="outline"
                onClick={() =>
                  run(
                    () => w.api.createCorrectiveWorkOrders(id!),
                    "Corrective work orders generated.",
                  )
                }
              >
                Generate corrective work orders
              </Button>
              <Button
                onClick={() =>
                  run(() => w.api.completeInspection(id!), "Final inspection completed.")
                }
              >
                Complete inspection
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function RequestDetail({
  request,
  onClose,
  allowDecision,
}: {
  request: Requisition | null;
  onClose: () => void;
  allowDecision: boolean;
}) {
  const w = useWorkspace();
  const [rejection, setRejection] = useState(false);
  const [note, setNote] = useState("");
  const current = w.requisitions.find((r) => r.id === request?.id);
  function decide(status: "Approved" | "Rejected") {
    if (!current || !canDecideParts(w.role)) return;
    if (status === "Rejected" && !note.trim()) {
      toast.error("Please record the reason for rejection.");
      return;
    }
    toast.error(
      `The backend does not provide a requisition ${status.toLowerCase()} endpoint. No decision was saved.`,
    );
  }
  return (
    <Dialog
      open={!!current}
      onOpenChange={(o) => {
        if (!o) {
          setRejection(false);
          setNote("");
          onClose();
        }
      }}
    >
      <DialogContent className="modal-scroll">
        <DialogHeader>
          <DialogTitle>Parts request · {current?.id}</DialogTitle>
          <DialogDescription>Submitted {current?.date}</DialogDescription>
        </DialogHeader>
        {current && (
          <>
            <VehicleCell vehicle={w.vehicleFor(current.vehicleId)} />
            <dl className="detail-grid">
              <div>
                <dt>Part / item</dt>
                <dd>{current.part}</dd>
              </div>
              <div>
                <dt>Requested quantity</dt>
                <dd>{current.quantity}</dd>
              </div>
            </dl>
            <div className="detail-notes">
              <strong>Reason for requesting parts</strong>
              <p className="mt-2">{current.reason}</p>
            </div>
            <Status>{current.status}</Status>
            {current.decisionNote && (
              <p className="text-xs text-muted-foreground">Decision note: {current.decisionNote}</p>
            )}
            {allowDecision && current.status === "Pending" && canDecideParts(w.role) && (
              <>
                {rejection && (
                  <label className="field">
                    <span>Rejection reason *</span>
                    <Textarea
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="Explain why this request is being rejected"
                    />
                  </label>
                )}
                <div className="flex justify-end gap-2 mt-3">
                  <Button
                    variant="outline"
                    onClick={() => (rejection ? decide("Rejected") : setRejection(true))}
                  >
                    {rejection ? "Confirm rejection" : "Reject request"}
                  </Button>
                  <Button onClick={() => decide("Approved")}>
                    <Check />
                    Approve request
                  </Button>
                </div>
              </>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
