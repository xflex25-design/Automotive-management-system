import { type ReactNode } from "react";
import {
  ArrowUpRight,
  ChevronRight,
  Car,
  Check,
  Download,
  FileText,
  Wrench,
  Package,
  ClipboardCheck,
  Clock,
  CalendarDays,
  type LucideIcon,
} from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { workflowStages, stageOwners, type Vehicle } from "@/lib/workshop";

export function PageHeading({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children?: ReactNode;
}) {
  return (
    <>
      <div className="breadcrumb">
        <span>Workspace</span>
        <ChevronRight size={12} />
        <span>{title}</span>
      </div>
      <div className="page-heading">
        <div>
          <h1>{title}</h1>
          <p>{subtitle}</p>
        </div>
        <div className="heading-actions">{children}</div>
      </div>
    </>
  );
}
export function SectionHeading({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children?: ReactNode;
}) {
  return (
    <div className="section-heading">
      <div>
        <h2>{title}</h2>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}
export function Status({ children: value }: { children: string | undefined }) {
  const children = value ?? "Intake";
  const neutral = ["Draft", "Rejected", "On hold", "Rework required"].includes(children);
  const outline = [
    "Awaiting approval",
    "Awaiting parts",
    "Pending",
    "Customer Authorization",
  ].includes(children);
  return (
    <span className={`status ${neutral ? "status-neutral" : outline ? "status-outline" : ""}`}>
      {["Approved", "Complete", "Passed", "Released"].includes(children) && <Check size={11} />}
      {children}
    </span>
  );
}
export function Metrics({
  items,
}: {
  items: { label: string; value: string | number; note: string; icon: LucideIcon }[];
}) {
  return (
    <div className="metric-grid">
      {items.map((item) => (
        <div className="metric-card" key={item.label}>
          <div className="metric-icon">
            <item.icon />
          </div>
          <div className="metric-label">{item.label}</div>
          <div className="metric-value">{item.value}</div>
          <div className="metric-note">{item.note}</div>
        </div>
      ))}
    </div>
  );
}
export const metricIcons = { Car, FileText, Wrench, Package, ClipboardCheck, Clock };
export function ProgressBar({ value }: { value: number }) {
  return (
    <div className="progress-track">
      <progress max={100} value={value} aria-label={`${value}% complete`} />
    </div>
  );
}
export function DataTable({
  headers,
  children,
  empty = false,
}: {
  headers: string[];
  children: ReactNode;
  empty?: boolean;
}) {
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            {headers.map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
      {empty && <div className="empty-state">No records match your selection.</div>}
    </div>
  );
}
export function VehicleCell({ vehicle }: { vehicle?: Vehicle | undefined }) {
  return (
    <div>
      <div className="cell-title">{vehicle?.make ?? "Vehicle"}</div>
      <div className="cell-subtitle">
        {vehicle?.plate ?? "—"} · {vehicle?.id ?? "—"}
      </div>
    </div>
  );
}
export function TableFooter({ count, label = "records" }: { count: number; label?: string }) {
  return (
    <div className="table-footer">
      <span>
        Showing {count} {label}
      </span>
      <span>Updated 11 Nov 2026</span>
    </div>
  );
}
export function LineChart({ values, labels }: { values: number[]; labels: string[] }) {
  const chartValues = values.length === 6 ? values : [0, 0, 0, 0, 0, 0];
  const chartLabels = labels.length === 6 ? labels : ["", "", "", "", "", ""];
  const max = Math.max(1, ...chartValues);
  const points = chartValues.map((value, index) => ({
    x: 35 + index * 94,
    y: 134 - (value / max) * 112,
  }));
  const line = `M${points.map(({ x, y }) => `${x},${y}`).join("L")}`;
  const area = `${line}L505 134H35Z`;
  return (
    <svg
      className="chart"
      viewBox="0 0 520 170"
      role="img"
      aria-label={`Vehicles received: ${chartValues.join(", ")}`}
    >
      <path className="chart-grid" d="M35 20H505 M35 58H505 M35 96H505 M35 134H505" />
      <text x="5" y="23">
        {max}
      </text>
      <text x="5" y="61">
        {Math.round(max * (2 / 3))}
      </text>
      <text x="10" y="99">
        {Math.round(max / 3)}
      </text>
      <text x="10" y="137">
        0
      </text>
      <path className="chart-area" d={area} />
      <path className="chart-line" d={line} />
      {points.map(({ x, y }, i) => (
        <circle className="chart-point" key={i} cx={x} cy={y} r="3.4" />
      ))}
      {chartLabels.map((day, i) => (
        <text key={`${day}-${i}`} x={35 + i * 94} y="159" textAnchor="middle">
          {day}
        </text>
      ))}
    </svg>
  );
}
export function Workflow({ stage }: { stage: number }) {
  return (
    <div className="workflow-list">
      {workflowStages.map((name, index) => (
        <div
          key={name}
          className={`workflow-step ${index < stage ? "step-done" : index === stage ? "step-current" : ""}`}
        >
          <span className="step-number">
            {index < stage ? <Check size={13} /> : String(index + 1).padStart(2, "0")}
          </span>
          <div>
            <h3>{name}</h3>
            <p>{stageOwners[index]}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
export function ExportButton({
  filename,
  rows,
}: {
  filename: string;
  rows: Record<string, unknown>[];
}) {
  return (
    <Button variant="outline" onClick={() => exportCsv(filename, rows)}>
      <Download />
      Export report
    </Button>
  );
}
export function exportCsv(filename: string, rows: Record<string, unknown>[]) {
  if (rows.length === 0) return;
  const first = rows[0];
  if (!first) return;
  const keys = Object.keys(first);
  const escape = (value: unknown) => {
    const text = String(value ?? "");
    return `"${(/^[=+@-]/.test(text) ? "'" : "") + text.replaceAll('"', '""')}"`;
  };
  const data = [
    keys.map(escape).join(","),
    ...rows.map((row) => keys.map((key) => escape(row[key])).join(",")),
  ].join("\r\n");
  const url = URL.createObjectURL(new Blob([data], { type: "text/csv;charset=utf-8;" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = `${filename}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}
export function ViewAllVehicles() {
  return (
    <Button asChild variant="link" size="sm">
      <Link to="/vehicles">
        View all vehicles
        <ArrowUpRight size={13} />
      </Link>
    </Button>
  );
}
export function DateFilter({
  value,
  onChange,
}: {
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={() => onChange(value === "This week" ? "This month" : "This week")}
    >
      <CalendarDays />
      {value}
    </Button>
  );
}
