import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  backendApi,
  clearApiAuthentication,
  setApiCredentials,
  setApiIdentity,
  type AuthIdentity,
} from "@/lib/api";

type AuthContextValue = { identity: AuthIdentity; logout: () => void };
const AuthContext = createContext<AuthContextValue | null>(null);
const demoMode = import.meta.env.MODE !== "test" && import.meta.env["VITE_DEMO_MODE"] === "true";
const demoIdentity: AuthIdentity = {
  userId: 0,
  employeeId: null,
  companyId: 0,
  workshopId: null,
  displayName: "Demo Manager",
  authorities: ["ROLE_MANAGER"],
};

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error("useAuth must be used inside AuthGate");
  return value;
}

export function AuthGate({ children }: { children: ReactNode }) {
  const [identity, setIdentity] = useState<AuthIdentity | null>(() =>
    demoMode ? demoIdentity : null,
  );
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const handleUnauthorized = () => {
      clearApiAuthentication();
      setIdentity(null);
      setPassword("");
      setError("Your session is no longer authorized. Sign in again.");
    };
    window.addEventListener("backend:unauthorized", handleUnauthorized);
    return () => window.removeEventListener("backend:unauthorized", handleUnauthorized);
  }, []);

  const logout = () => {
    if (demoMode) {
      setIdentity(demoIdentity);
      return;
    }
    clearApiAuthentication();
    setIdentity(null);
    setPassword("");
    setError("");
  };

  const activeIdentity = demoMode ? demoIdentity : identity;
  const context = useMemo(
    () => (activeIdentity ? { identity: activeIdentity, logout } : null),
    [activeIdentity],
  );

  async function signIn(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setApiCredentials(username.trim(), password);
    try {
      const currentUser = await backendApi.getCurrentUser();
      if (!currentUser.userId || !currentUser.companyId || !currentUser.employeeId) {
        throw new Error("This account is not linked to an active workshop employee.");
      }
      setApiIdentity(currentUser);
      setIdentity(currentUser);
      setPassword("");
    } catch (cause) {
      clearApiAuthentication();
      setError(cause instanceof Error ? cause.message : "Sign in failed. Check your credentials.");
    } finally {
      setSubmitting(false);
    }
  }

  if (demoMode && context)
    return <AuthContext.Provider value={context}>{children}</AuthContext.Provider>;

  if (!identity || !context) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-background px-4 py-8">
        <form
          onSubmit={signIn}
          className="w-full max-w-sm space-y-5 rounded-xl border bg-card p-6 shadow-sm"
        >
          <div>
            <p className="text-sm font-semibold text-primary">HI RIDER 4X4 WORLD</p>
            <h1 className="mt-2 text-2xl font-semibold">Workshop sign in</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Use your workshop account to continue.
            </p>
          </div>
          <label className="field">
            <span>Email or username</span>
            <Input
              autoComplete="username"
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              required
            />
          </label>
          <label className="field">
            <span>Password</span>
            <Input
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              required
            />
          </label>
          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}
          <Button className="w-full" type="submit" disabled={submitting}>
            {submitting ? "Signing in…" : "Sign in"}
          </Button>
          <p className="text-xs text-muted-foreground">
            Credentials are kept in memory for this page session and are cleared when you sign out
            or reload.
          </p>
        </form>
      </main>
    );
  }

  return <AuthContext.Provider value={context}>{children}</AuthContext.Provider>;
}
