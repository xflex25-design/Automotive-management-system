import { useState, type ReactNode } from "react";
import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Car,
  FileText,
  Archive,
  ClipboardList,
  Package,
  Wrench,
  ClipboardCheck,
  FolderOpen,
  ChartNoAxesColumnIncreasing,
  GitBranch,
  ShieldCheck,
  Search,
  Menu,
  X,
  Bell,
  MessageSquare,
  UserRound,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWorkspace } from "./workspace-context";
import { canApproveDispatch } from "@/lib/workshop";
import { useAuth } from "./auth-gate";

const operationalLinks = [
  { title: "Vehicle Registration", to: "/registration", icon: Car },
  { title: "Quotations", to: "/quotations", icon: FileText },
  { title: "Inventory Cards", to: "/inventory", icon: Archive },
  { title: "Job Cards", to: "/job-cards", icon: ClipboardList },
  { title: "Parts Requisitions", to: "/requisitions", icon: Package },
  { title: "Procurement & Dispatch", to: "/procurement", icon: Archive },
  { title: "Workshop Progress", to: "/workshop", icon: Wrench },
  { title: "Inspections", to: "/inspections", icon: ClipboardCheck },
  { title: "Vehicle Records", to: "/vehicles", icon: FolderOpen },
] as const;
const oversightLinks = [
  { title: "Vehicle Overview", to: "/vehicles", icon: Car },
  { title: "Quotations", to: "/quotations", icon: FileText },
  { title: "Inventory Cards", to: "/inventory", icon: Archive },
  { title: "Job Cards", to: "/job-cards", icon: ClipboardList },
  { title: "Workflow Tracking", to: "/workflow", icon: GitBranch },
  { title: "Workshop Progress", to: "/workshop", icon: Wrench },
  { title: "Department Performance", to: "/departments", icon: ChartNoAxesColumnIncreasing },
  { title: "Parts Requisitions", to: "/requisitions", icon: Package },
  { title: "Dispatch Approvals", to: "/approvals", icon: ShieldCheck },
  { title: "Procurement & Dispatch", to: "/procurement", icon: Archive },
  { title: "Inspection Results", to: "/inspections", icon: ClipboardCheck },
] as const;
export function AppShell({ children }: { children: ReactNode }) {
  const { identity, logout } = useAuth();
  const { role, foreman, search, setSearch } = useWorkspace();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const pageTitle =
    pathname === "/management"
      ? "Management Dashboard"
      : pathname === "/director" || pathname === "/approvals"
        ? "Management Dashboard"
        : pathname === "/"
          ? "Foreman Dashboard"
          : (pathname.split("/").filter(Boolean).at(-1) ?? "Workshop")
              .replaceAll("-", " ")
              .replace(/\b\w/g, (letter) => letter.toUpperCase());
  const profileLabel = identity.displayName || foreman;
  const initials = profileLabel
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const isManagement = canApproveDispatch(role);
  const home = isManagement ? "/management" : "/";
  const links = isManagement ? oversightLinks : operationalLinks;
  return (
    <div className="app-shell">
      {open && <div className="sidebar-backdrop" onClick={() => setOpen(false)} />}
      <aside className={`app-sidebar ${open ? "sidebar-open" : ""}`}>
        <Button
          className="mobile-close"
          variant="navigation"
          size="icon"
          title="Close navigation"
          aria-label="Close navigation"
          onClick={() => setOpen(false)}
        >
          <X />
        </Button>
        <div className="brand">
          <div className="brand-name">
            Hi Rider 4x4<span className="block">World</span>
          </div>
          <div className="brand-subtitle">VEHICLE GARAGE MANAGEMENT</div>
        </div>
        <div className="sidebar-label">
          {role === "Foreman" ? "Workshop workspace" : "Business workspace"}
        </div>
        <nav className="sidebar-nav" aria-label="Main navigation">
          <Link
            to={home}
            activeOptions={{ exact: true }}
            className="sidebar-link"
            onClick={() => setOpen(false)}
          >
            <LayoutDashboard />
            Dashboard
          </Link>
          {links.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="sidebar-link"
              onClick={() => setOpen(false)}
            >
              <item.icon />
              {item.title}
            </Link>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="text-[10px] text-navy-muted mb-1">SIGNED IN ACCOUNT</div>
          <div className="truncate text-sm font-medium text-white">{identity.displayName}</div>
          <div className="mt-1 text-xs text-navy-muted">{role}</div>
        </div>
      </aside>
      <div className="app-body">
        <header className="app-topbar">
          <div className="topbar-brand">
            <Button
              variant="navigation"
              size="icon"
              className="mobile-menu"
              aria-label="Open navigation"
              title="Open navigation"
              onClick={() => setOpen(true)}
            >
              <Menu />
            </Button>
            <img
              className="topbar-logo"
              src="/hirider-logo-official.jpeg"
              alt="Hi Rider 4x4 World"
            />
            <span className="topbar-divider" />
            <h1 className="topbar-page-title">{pageTitle}</h1>
          </div>
          <form
            className="global-search"
            role="search"
            onSubmit={(e) => {
              e.preventDefault();
              navigate({ to: "/vehicles" });
            }}
          >
            <Search size={19} aria-hidden="true" />
            <input
              aria-label="Search vehicles, customers, quotations, job cards"
              placeholder="Search vehicles, customers, quotations, job cards..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <button
              type="button"
              className="global-search-clear"
              aria-label="Clear search"
              title="Clear search"
              disabled={!search}
              onClick={() => setSearch("")}
            >
              <X size={16} />
            </button>
          </form>
          <div className="topbar-actions">
            <button
              type="button"
              className="topbar-action"
              aria-label="Notifications"
              title="Notifications"
            >
              <Bell size={19} />
              <span className="topbar-notification-badge" />
            </button>
            <button
              type="button"
              className="topbar-action topbar-optional-action"
              aria-label="Messages"
              title="Messages"
            >
              <MessageSquare size={19} />
            </button>
            <details className="topbar-profile">
              <summary
                className="topbar-action topbar-profile-trigger"
                aria-label="User profile menu"
              >
                <span className="topbar-avatar">{initials || "U"}</span>
              </summary>
              <div className="topbar-profile-menu">
                <button type="button">
                  <UserRound size={16} /> Profile
                </button>
                <div className="topbar-menu-divider" />
                <button type="button" onClick={logout}>
                  Sign out
                </button>
              </div>
            </details>
          </div>
        </header>
        <main className="workspace">{children}</main>
      </div>
    </div>
  );
}
