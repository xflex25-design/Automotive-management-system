import { useRef, useState, type FormEvent } from "react";
import { useNavigate } from "@tanstack/react-router";
import { ArrowRight, ClipboardCheck, Plus, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PageHeading } from "./shared";
import { useWorkspace } from "./workspace-context";
import { getApiIdentity, type BackendIntakeResponse } from "@/lib/api";

const standardAccessories = [
  "Sparewheel",
  "Jack",
  "Jack handle",
  "Triangles",
  "Wheel spanner",
  "Fire extinguisher",
  "Tool kit",
  "Wheel covers",
  "Car mats",
] as const;

const fuelLevels = ["E", "1/4", "1/2", "3/4", "F"] as const;

type DamageDraft = {
  key: string;
  damageType: string;
  damageLocation: string;
  description: string;
  photo: File | null;
};

type IntakeProgress = {
  job?: BackendIntakeResponse;
  inspectionId?: number;
  damageRecords: Array<{ damageRecordId: number; damageType: string; damageLocation: string }>;
  overviewUploaded: boolean;
  uploadedDamageIds: number[];
  authorisationId?: number;
  customerSignatureMediaId?: number;
  employeeSignatureMediaId?: number;
  customerSignatureRecorded: boolean;
  employeeSignatureRecorded: boolean;
  completed: boolean;
};

const blankProgress = (): IntakeProgress => ({
  damageRecords: [],
  overviewUploaded: false,
  uploadedDamageIds: [],
  customerSignatureRecorded: false,
  employeeSignatureRecorded: false,
  completed: false,
});

function newDamage(): DamageDraft {
  return {
    key: crypto.randomUUID(),
    damageType: "",
    damageLocation: "",
    description: "",
    photo: null,
  };
}

function mediaIdFrom(response: Record<string, unknown>) {
  const id = Number(response["mediaId"] ?? response["mediaFileId"]);
  if (!Number.isSafeInteger(id) || id <= 0)
    throw new Error("The backend did not return the uploaded image ID.");
  return id;
}

function recordIdFrom(response: Record<string, unknown>) {
  const id = Number(response["damageRecordId"]);
  if (!Number.isSafeInteger(id) || id <= 0)
    throw new Error("The backend did not return a damage record ID.");
  return id;
}

export function IntakePage() {
  const { vehicles, foreman, addActivity, registerVehicle, api, refresh } = useWorkspace();
  const navigate = useNavigate();
  const formRef = useRef<HTMLFormElement>(null);
  const progressRef = useRef<IntakeProgress>(blankProgress());
  const [progress, setProgress] = useState<IntakeProgress>(progressRef.current);
  const [saving, setSaving] = useState(false);
  const [noVisibleDamage, setNoVisibleDamage] = useState(false);
  const [damageRows, setDamageRows] = useState<DamageDraft[]>([newDamage()]);
  const [accessoryStatus, setAccessoryStatus] = useState<Record<string, string>>({});
  const [accessoryCondition, setAccessoryCondition] = useState<Record<string, string>>({});
  const [overviewPhoto, setOverviewPhoto] = useState<File | null>(null);
  const [customerSignature, setCustomerSignature] = useState<File | null>(null);
  const [employeeSignature, setEmployeeSignature] = useState<File | null>(null);
  const [customerAccepted, setCustomerAccepted] = useState(false);
  const locked = !!progress.job;

  function updateProgress(update: Partial<IntakeProgress>) {
    const next = { ...progressRef.current, ...update };
    progressRef.current = next;
    setProgress(next);
  }

  function setDamageRow(key: string, update: Partial<DamageDraft>) {
    setDamageRows((rows) => rows.map((row) => (row.key === key ? { ...row, ...update } : row)));
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!formRef.current) return;
    if (!customerAccepted) {
      toast.error("Record the customer’s acceptance of the intake conditions before submitting.");
      return;
    }
    if (!progressRef.current.overviewUploaded && !overviewPhoto) {
      toast.error("Add an arrival overview photo before submitting the intake.");
      return;
    }
    if (!noVisibleDamage) {
      if (damageRows.length === 0) {
        toast.error("Record each visible damage or select ‘No visible damage’. ");
        return;
      }
      if (damageRows.some((damage) => !damage.damageType || !damage.damageLocation.trim())) {
        toast.error("Complete the damage type and location for every visible damage.");
        return;
      }
      const savedDamageIds = new Set(progressRef.current.uploadedDamageIds);
      if (
        damageRows.some(
          (damage, index) =>
            !savedDamageIds.has(progressRef.current.damageRecords[index]?.damageRecordId ?? -1) &&
            !damage.photo,
        )
      ) {
        toast.error("Add a photo for every recorded damage.");
        return;
      }
    }
    if (standardAccessories.some((accessory) => !accessoryStatus[accessory])) {
      toast.error("Record whether all nine standard accessories are present or missing.");
      return;
    }
    if (!progressRef.current.customerSignatureMediaId && !customerSignature) {
      toast.error("Capture or upload the customer’s signature.");
      return;
    }
    if (!progressRef.current.employeeSignatureMediaId && !employeeSignature) {
      toast.error("Capture or upload the receiving employee’s acknowledgement signature.");
      return;
    }

    const form = new FormData(formRef.current);
    const plate = String(form.get("plate") ?? "")
      .trim()
      .toUpperCase();
    if (
      !progressRef.current.job &&
      vehicles.some((vehicle) => vehicle.plate.toUpperCase() === plate && !vehicle.released)
    ) {
      toast.error("This registration already has an active workshop record.");
      return;
    }

    setSaving(true);
    try {
      let current = progressRef.current;
      const customerName = String(form.get("customer") ?? "").trim();
      const customerPhone = String(form.get("phone") ?? "").trim();
      const additionalItems = String(form.get("additionalItems") ?? "")
        .split(/\r?\n/)
        .map((item) => item.trim())
        .filter(Boolean);

      if (!current.job) {
        const intake = await registerVehicle({
          id: `INTAKE-${Date.now()}`,
          plate,
          make: String(form.get("make") ?? "").trim(),
          customer: customerName,
          phone: customerPhone,
          email: String(form.get("email") ?? "").trim(),
          received: new Date().toLocaleDateString("en-GB"),
          stage: 0,
          department: "Unassigned",
          due: "",
          progress: 0,
          foreman,
          complaints: String(form.get("complaints") ?? "").trim(),
          damage: String(form.get("remarks") ?? "").trim(),
          ...(String(form.get("vin") ?? "").trim() ? { vin: String(form.get("vin")).trim() } : {}),
          odometer: Number(form.get("odometer")),
          color: String(form.get("colour") ?? "").trim(),
          deliveredBy: String(form.get("deliveredBy") ?? "").trim(),
          delivererPhone: String(form.get("delivererPhone") ?? "").trim(),
          ownerName: String(form.get("ownerName") ?? "").trim() || customerName,
          fuelIn: String(form.get("fuelIn") ?? ""),
          receivedByName: foreman,
        });
        current = { ...current, job: intake };
        updateProgress(current);
      }

      const intakeJob = current.job;
      if (!intakeJob) throw new Error("The backend did not return the saved intake job.");
      const jobId = intakeJob.jobId;
      if (!current.inspectionId) {
        const inspection = await api.createInitialInspection(jobId, {
          overallCondition:
            String(form.get("remarks") ?? "").trim() ||
            (noVisibleDamage ? "No visible damage" : "Damage recorded in intake checklist"),
          inspectionNotes: String(form.get("complaints") ?? "").trim(),
          damages: noVisibleDamage
            ? []
            : damageRows.map((damage) => ({
                damageType: damage.damageType,
                damageLocation: damage.damageLocation.trim(),
                damageDescription: damage.description.trim() || undefined,
              })),
          accessories: standardAccessories.map((accessory) => ({
            accessoryName: accessory,
            present: accessoryStatus[accessory] === "PRESENT",
            ...(accessoryCondition[accessory]?.trim()
              ? { conditionDescription: accessoryCondition[accessory].trim() }
              : accessoryStatus[accessory] === "MISSING"
                ? { conditionDescription: "Not present at arrival" }
                : {}),
          })),
          receivedItems: additionalItems.map((item) => ({ itemName: item, quantity: 1 })),
        });
        const damageRecords = Array.isArray(inspection["damageRecords"])
          ? (inspection["damageRecords"] as Array<Record<string, unknown>>).map((damage) => ({
              damageRecordId: recordIdFrom(damage),
              damageType: String(damage["damageType"] ?? ""),
              damageLocation: String(damage["damageLocation"] ?? ""),
            }))
          : [];
        const inspectionId = Number(inspection["inspectionId"]);
        if (!Number.isSafeInteger(inspectionId) || inspectionId <= 0)
          throw new Error("The backend did not return the initial inspection ID.");
        current = { ...current, inspectionId, damageRecords };
        updateProgress(current);
      }

      if (!current.overviewUploaded) {
        if (!overviewPhoto)
          throw new Error("Re-select the arrival overview photo to continue this saved intake.");
        await api.uploadIntakePhoto(
          jobId,
          current.inspectionId!,
          overviewPhoto,
          "INTAKE_OVERVIEW",
          "Vehicle condition at arrival",
        );
        current = { ...current, overviewUploaded: true };
        updateProgress(current);
      }

      if (!noVisibleDamage) {
        const uploaded = new Set(current.uploadedDamageIds);
        for (const [index, damage] of damageRows.entries()) {
          const record = current.damageRecords[index];
          if (!record)
            throw new Error(
              "The backend did not return a matching record for every damage item. Contact an administrator before retrying this intake.",
            );
          if (uploaded.has(record.damageRecordId)) continue;
          if (!damage.photo)
            throw new Error(
              `Re-select the photo for damage at ${damage.damageLocation} to continue.`,
            );
          await api.uploadIntakePhoto(
            jobId,
            current.inspectionId!,
            damage.photo,
            "DAMAGE",
            `${damage.damageType}: ${damage.damageLocation}`,
            record.damageRecordId,
          );
          uploaded.add(record.damageRecordId);
          current = { ...current, uploadedDamageIds: [...uploaded] };
          updateProgress(current);
        }
      }

      if (!current.authorisationId) {
        const authorisation = await api.createIntakeAuthorisation(
          jobId,
          customerName,
          customerPhone,
          "I authorise the work requested on this vehicle inventory. I permit the workshop to use necessary materials and operate the vehicle for testing and inspection. I confirm that I have removed valuables from the vehicle.",
        );
        const authorisationId = Number(authorisation["authorisationId"]);
        if (!Number.isSafeInteger(authorisationId) || authorisationId <= 0)
          throw new Error("The backend did not return the customer authorisation ID.");
        current = { ...current, authorisationId };
        updateProgress(current);
      }

      if (!current.customerSignatureMediaId) {
        if (!customerSignature)
          throw new Error("Re-select the customer signature image to continue this saved intake.");
        const photo = await api.uploadIntakePhoto(
          jobId,
          current.inspectionId!,
          customerSignature,
          "SIGNATURE",
          "Customer work authorisation signature",
        );
        current = { ...current, customerSignatureMediaId: mediaIdFrom(photo) };
        updateProgress(current);
      }
      if (!current.customerSignatureRecorded) {
        const authorisationId = current.authorisationId;
        if (!authorisationId) throw new Error("The customer authorisation record is missing.");
        await api.recordIntakeSignature(jobId, {
          authorisationId,
          signerType: "CUSTOMER",
          signerName: customerName,
          signatureMediaId: current.customerSignatureMediaId!,
          remarks: "Customer accepted the intake conditions and authorised requested work.",
        });
        current = { ...current, customerSignatureRecorded: true };
        updateProgress(current);
      }

      if (!current.employeeSignatureMediaId) {
        if (!employeeSignature)
          throw new Error(
            "Re-select the employee acknowledgement signature image to continue this saved intake.",
          );
        const photo = await api.uploadIntakePhoto(
          jobId,
          current.inspectionId!,
          employeeSignature,
          "SIGNATURE",
          "Receiving employee acknowledgement",
        );
        current = { ...current, employeeSignatureMediaId: mediaIdFrom(photo) };
        updateProgress(current);
      }
      if (!current.employeeSignatureRecorded) {
        const identity = getApiIdentity();
        await api.recordIntakeSignature(jobId, {
          signerType: "EMPLOYEE",
          signerName: identity?.displayName || foreman,
          signatureMediaId: current.employeeSignatureMediaId!,
          remarks: "Vehicle received and checked against the inventory record.",
        });
        current = { ...current, employeeSignatureRecorded: true };
        updateProgress(current);
      }

      if (!current.completed) {
        await api.completeIntake(jobId);
        current = { ...current, completed: true };
        updateProgress(current);
      }

      addActivity(
        `Vehicle intake completed: ${intakeJob.registrationNumber}`,
        `${foreman} · ${intakeJob.jobNumber}`,
      );
      toast.success(`${intakeJob.registrationNumber} intake completed and ready for quotation.`);
      await refresh();
      navigate({ to: "/vehicles" });
    } catch (cause) {
      toast.error(
        cause instanceof Error
          ? cause.message
          : "Vehicle intake could not be completed. Your saved progress is retained on this page.",
      );
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <PageHeading
        title="Vehicle Registration & Intake"
        subtitle="Complete the vehicle inventory and customer acceptance before submitting intake."
      >
        <Button variant="outline" onClick={() => navigate({ to: "/vehicles" })}>
          Vehicle records <ArrowRight />
        </Button>
      </PageHeading>
      <form ref={formRef} onSubmit={submit}>
        <div className="form-layout">
          <div>
            <section className="form-section">
              <h2>01 · Customer and delivery</h2>
              <div className="field-grid">
                <label className="field">
                  <span>Customer full name *</span>
                  <Input
                    name="customer"
                    placeholder="Customer full name"
                    required
                    disabled={locked}
                  />
                </label>
                <label className="field">
                  <span>Customer phone *</span>
                  <Input type="tel" name="phone" placeholder="+260" required disabled={locked} />
                </label>
                <label className="field">
                  <span>Email address</span>
                  <Input
                    type="email"
                    name="email"
                    placeholder="customer@example.com"
                    disabled={locked}
                  />
                </label>
                <label className="field">
                  <span>Registered owner *</span>
                  <Input name="ownerName" placeholder="Vehicle owner" required disabled={locked} />
                </label>
                <label className="field">
                  <span>Delivered by *</span>
                  <Input
                    name="deliveredBy"
                    placeholder="Name of driver / person delivering"
                    required
                    disabled={locked}
                  />
                </label>
                <label className="field">
                  <span>Deliverer phone number *</span>
                  <Input
                    type="tel"
                    name="delivererPhone"
                    placeholder="Phone number"
                    required
                    disabled={locked}
                  />
                </label>
              </div>
            </section>
            <section className="form-section">
              <h2>02 · Vehicle and arrival details</h2>
              <div className="field-grid">
                <label className="field">
                  <span>Registration number *</span>
                  <Input name="plate" placeholder="e.g. BAK 6213" required disabled={locked} />
                </label>
                <label className="field">
                  <span>Make and model *</span>
                  <Input name="make" placeholder="e.g. Ford Ranger" required disabled={locked} />
                </label>
                <label className="field">
                  <span>Chassis / VIN number</span>
                  <Input name="vin" placeholder="Vehicle identification number" disabled={locked} />
                </label>
                <label className="field">
                  <span>Odometer reading on arrival (km) *</span>
                  <Input
                    name="odometer"
                    type="number"
                    min="0"
                    step="1"
                    placeholder="e.g. 124500"
                    required
                    disabled={locked}
                  />
                </label>
                <label className="field">
                  <span>Fuel level on arrival *</span>
                  <select
                    className="h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
                    name="fuelIn"
                    required
                    disabled={locked}
                    defaultValue=""
                  >
                    <option value="" disabled>
                      Select fuel level
                    </option>
                    {fuelLevels.map((level) => (
                      <option key={level} value={level}>
                        {level}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="field">
                  <span>Vehicle colour</span>
                  <Input name="colour" placeholder="e.g. White" disabled={locked} />
                </label>
                <label className="field field-wide">
                  <span>Work requested / customer complaints *</span>
                  <Textarea
                    name="complaints"
                    rows={3}
                    placeholder="Record the customer's concerns and requested repairs"
                    required
                    disabled={locked}
                  />
                </label>
              </div>
            </section>
            <section className="form-section">
              <h2>03 · Inventory accessories</h2>
              <p className="text-sm text-muted-foreground">
                Record present or missing for each item on the paper vehicle inventory.
              </p>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {standardAccessories.map((accessory) => (
                  <div className="rounded-md border border-border p-3" key={accessory}>
                    <label className="field">
                      <span>{accessory} *</span>
                      <select
                        className="h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
                        value={accessoryStatus[accessory] ?? ""}
                        onChange={(event) =>
                          setAccessoryStatus((previous) => ({
                            ...previous,
                            [accessory]: event.target.value,
                          }))
                        }
                        required
                        disabled={locked}
                      >
                        <option value="" disabled>
                          Choose status
                        </option>
                        <option value="PRESENT">Present</option>
                        <option value="MISSING">Missing</option>
                      </select>
                    </label>
                    <Input
                      className="mt-2"
                      aria-label={`${accessory} condition`}
                      placeholder="Condition / remarks (optional)"
                      value={accessoryCondition[accessory] ?? ""}
                      onChange={(event) =>
                        setAccessoryCondition((previous) => ({
                          ...previous,
                          [accessory]: event.target.value,
                        }))
                      }
                      disabled={locked}
                    />
                  </div>
                ))}
              </div>
              <label className="field mt-4">
                <span>Additional items left in vehicle</span>
                <Textarea
                  name="additionalItems"
                  rows={3}
                  placeholder="List each item on a separate line"
                  disabled={locked}
                />
              </label>
            </section>
            <section className="form-section">
              <h2>04 · Vehicle condition and damage</h2>
              <label className="flex items-start gap-3 rounded-md border border-border p-3 text-sm">
                <Checkbox
                  checked={noVisibleDamage}
                  onCheckedChange={(checked) => {
                    const selected = checked === true;
                    setNoVisibleDamage(selected);
                    if (!selected && damageRows.length === 0) setDamageRows([newDamage()]);
                  }}
                  disabled={locked}
                />
                <span>No visible damage found at intake</span>
              </label>
              {!noVisibleDamage && (
                <div className="mt-4 space-y-4">
                  {damageRows.map((damage, index) => (
                    <div className="rounded-md border border-border p-4" key={damage.key}>
                      <div className="mb-3 flex items-center justify-between">
                        <h3 className="font-medium">Damage {index + 1}</h3>
                        {damageRows.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              setDamageRows((rows) => rows.filter((row) => row.key !== damage.key))
                            }
                            disabled={locked}
                          >
                            <Trash2 /> Remove
                          </Button>
                        )}
                      </div>
                      <div className="field-grid">
                        <label className="field">
                          <span>Damage type *</span>
                          <select
                            className="h-9 w-full rounded-md border border-input bg-transparent px-3 text-sm"
                            value={damage.damageType}
                            onChange={(event) =>
                              setDamageRow(damage.key, { damageType: event.target.value })
                            }
                            required
                            disabled={locked}
                          >
                            <option value="">Select type</option>
                            <option value="CHIP">Chip</option>
                            <option value="DENT">Dent</option>
                            <option value="SCRATCH">Scratch</option>
                            <option value="OTHER">Other</option>
                          </select>
                        </label>
                        <label className="field">
                          <span>Damage location *</span>
                          <Input
                            value={damage.damageLocation}
                            placeholder="e.g. left rear door"
                            onChange={(event) =>
                              setDamageRow(damage.key, { damageLocation: event.target.value })
                            }
                            required
                            disabled={locked}
                          />
                        </label>
                        <label className="field field-wide">
                          <span>Description</span>
                          <Textarea
                            rows={2}
                            value={damage.description}
                            onChange={(event) =>
                              setDamageRow(damage.key, { description: event.target.value })
                            }
                            disabled={locked}
                          />
                        </label>
                        <label className="field field-wide">
                          <span>
                            Damage photo{" "}
                            {progress.uploadedDamageIds.includes(
                              progress.damageRecords[index]?.damageRecordId ?? -1,
                            )
                              ? "· uploaded"
                              : "*"}
                          </span>
                          <Input
                            type="file"
                            accept="image/jpeg,image/png,image/webp"
                            onChange={(event) =>
                              setDamageRow(damage.key, { photo: event.target.files?.[0] ?? null })
                            }
                            required={
                              !progress.uploadedDamageIds.includes(
                                progress.damageRecords[index]?.damageRecordId ?? -1,
                              )
                            }
                            disabled={
                              locked &&
                              progress.uploadedDamageIds.includes(
                                progress.damageRecords[index]?.damageRecordId ?? -1,
                              )
                            }
                          />
                        </label>
                      </div>
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setDamageRows((rows) => [...rows, newDamage()])}
                    disabled={locked}
                  >
                    <Plus /> Add damage
                  </Button>
                </div>
              )}
              <label className="field mt-4">
                <span>General remarks</span>
                <Textarea
                  name="remarks"
                  rows={3}
                  placeholder="Other observations about the vehicle at arrival"
                  disabled={locked}
                />
              </label>
              <label className="field mt-4">
                <span>Arrival overview photo *</span>
                <Input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={(event) => setOverviewPhoto(event.target.files?.[0] ?? null)}
                  required={!progress.overviewUploaded}
                  disabled={locked && progress.overviewUploaded}
                />
                {progress.overviewUploaded && (
                  <small className="text-muted-foreground">Overview photo uploaded.</small>
                )}
              </label>
            </section>
            <section className="form-section">
              <h2>05 · Customer acceptance and signatures</h2>
              <div className="rounded-md bg-muted/50 p-4 text-sm leading-6">
                The customer authorises the work requested on this intake, permits the workshop to
                use necessary materials and operate the vehicle for testing and inspection, and
                confirms that valuables have been removed. Any additional work identified later will
                be quoted separately; this intake does not approve each quotation automatically.
              </div>
              <label className="mt-4 flex items-start gap-3 text-sm">
                <Checkbox
                  checked={customerAccepted}
                  onCheckedChange={(checked) => setCustomerAccepted(checked === true)}
                  disabled={locked}
                />
                <span>Customer has read and accepted the intake conditions above. *</span>
              </label>
              <div className="field-grid mt-4">
                <label className="field">
                  <span>Customer signature image *</span>
                  <Input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    onChange={(event) => setCustomerSignature(event.target.files?.[0] ?? null)}
                    required={!progress.customerSignatureMediaId}
                    disabled={locked && !!progress.customerSignatureMediaId}
                  />
                  <small className="text-muted-foreground">
                    Upload a photo or scan of the signed paper form.
                  </small>
                </label>
                <label className="field">
                  <span>Received and checked by *</span>
                  <Input value={foreman} readOnly />
                </label>
                <label className="field field-wide">
                  <span>Employee acknowledgement signature image *</span>
                  <Input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    onChange={(event) => setEmployeeSignature(event.target.files?.[0] ?? null)}
                    required={!progress.employeeSignatureMediaId}
                    disabled={locked && !!progress.employeeSignatureMediaId}
                  />
                  <small className="text-muted-foreground">
                    Upload the receiving staff member’s signature from the paper inventory form.
                  </small>
                </label>
              </div>
            </section>
            {progress.job && (
              <div className="mb-4 rounded-md border border-primary/30 bg-primary/5 p-4 text-sm">
                Intake draft {progress.job.jobNumber} is saved. Keep this page open and retry after
                correcting the indicated issue; completed steps are retained.
              </div>
            )}
            <div className="flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate({ to: "/vehicles" })}
                disabled={saving}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving || progress.completed}>
                <Save />
                {saving ? "Saving intake…" : progress.job ? "Continue intake" : "Submit intake"}
              </Button>
            </div>
          </div>
          <aside className="intake-aside">
            <ClipboardCheck size={24} className="mb-4 text-primary" />
            <h3>Vehicle inventory intake</h3>
            <p>Received {new Date().toLocaleDateString("en-GB")}</p>
            <p>
              Received and checked by
              <br />
              <strong className="text-foreground">{foreman}</strong>
            </p>
            <div className="mt-6 border-t border-border pt-6">
              <h3>Submission checklist</h3>
              <p>
                Customer and deliverer details
                <br />
                Vehicle, mileage and fuel
                <br />
                All nine accessories
                <br />
                Condition and damage photos
                <br />
                Overview photograph
                <br />
                Customer acceptance and signatures
              </p>
            </div>
            <div className="mt-6 border-t border-border pt-6">
              <h3>Next stage</h3>
              <p>
                Quotation. Further quotations can be added for extra work without repeating intake
                authorization.
              </p>
            </div>
          </aside>
        </div>
      </form>
    </>
  );
}
