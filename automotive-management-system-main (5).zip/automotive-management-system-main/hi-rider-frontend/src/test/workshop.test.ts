import { describe, expect, it } from "vitest";
import {
  userCategories,
  foremen,
  departments,
  workflowStages,
  canApproveDispatch,
  canAuthorizeRelease,
  workspaceRoleFromAuthorities,
} from "@/lib/workshop";

describe("Workshop workflow model", () => {
  it("includes staff roles used by workshop operations", () => {
    expect(userCategories).toEqual([
      "Foreman",
      "Mechanic",
      "Stores",
      "Accounts",
      "Management",
      "Boss",
      "Staff",
    ]);
  });

  it("supports four foreman accounts", () => {
    expect(foremen).toEqual(["Foreman 01", "Foreman 02", "Foreman 03", "Foreman 04"]);
  });

  it("uses the six workshop departments even where a role shares a department name", () => {
    expect(departments).toEqual([
      "Electrical",
      "Mechanic",
      "Fitting",
      "Panel Beating",
      "Sanding",
      "Painting",
    ]);
    expect(departments).toContain("Mechanic");
    expect(userCategories).not.toContain("Electrical");
  });

  it("keeps the eight workflow stages in architecture order", () => {
    expect(workflowStages).toEqual([
      "Vehicle Inventory / Intake",
      "Quotation",
      "Customer Authorization Check",
      "Job Card and Department Routing",
      "Parts Availability, Purchase and Receiving",
      "Dispatch Order and Manager Approval",
      "Department Workflow and Monitoring",
      "Final Inspection and Sign-off",
    ]);
  });

  it("allows managers and bosses to approve dispatch orders", () => {
    expect(canApproveDispatch("Management")).toBe(true);
    expect(canApproveDispatch("Boss")).toBe(true);
    expect(canApproveDispatch("Foreman")).toBe(false);
    expect(canApproveDispatch("Stores")).toBe(false);
  });

  it("maps backend authority names to the workspace account role", () => {
    expect(workspaceRoleFromAuthorities(["ROLE_BOSS"])).toBe("Boss");
    expect(workspaceRoleFromAuthorities(["ROLE_MANAGER"])).toBe("Management");
    expect(workspaceRoleFromAuthorities(["ROLE_FOREMAN"])).toBe("Foreman");
    expect(workspaceRoleFromAuthorities(["ROLE_STORES"])).toBe("Stores");
    expect(workspaceRoleFromAuthorities([])).toBe("Staff");
  });

  it("reserves vehicle release authorization to Management", () => {
    expect(canAuthorizeRelease("Management")).toBe(true);
    expect(canAuthorizeRelease("Boss")).toBe(false);
    expect(canAuthorizeRelease("Foreman")).toBe(false);
  });
});
