import { afterEach, describe, expect, it, vi } from "vitest";
import { backendApi, clearApiAuthentication, setApiCredentials, setApiIdentity } from "@/lib/api";

const identity = {
  userId: 8,
  employeeId: 14,
  companyId: 12,
  workshopId: 34,
  displayName: "Workshop Foreman",
  authorities: ["ROLE_FOREMAN"],
};

function jsonResponse(body: unknown) {
  return {
    ok: true,
    status: 200,
    headers: new Headers({ "content-type": "application/json" }),
    json: async () => body,
    text: async () => JSON.stringify(body),
  } as Response;
}

afterEach(() => {
  clearApiAuthentication();
  vi.unstubAllGlobals();
});

describe("workflow backend API contracts", () => {
  it("loads records through the company and workshop scoped aggregate endpoint", async () => {
    setApiCredentials("foreman@example.test", "secret");
    setApiIdentity(identity);
    const body = {
      vehicles: [],
      jobCards: [],
      requisitions: [],
      inspections: [],
      inventory: [],
      parts: [],
      purchaseOrders: [],
      options: { departments: [], employees: [], suppliers: [], stockLocations: [] },
    };
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse(body));
    vi.stubGlobal("fetch", fetchMock);

    const records = await backendApi.loadRecords();

    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(String(fetchMock.mock.calls[0]?.[0])).toContain(
      "/api/companies/12/workflow-records?workshopId=34",
    );
    expect(records.vehicles).toEqual(body.vehicles);
    expect(records.options).toEqual(body.options);
    expect(records.remindersByWorkOrder).toBeInstanceOf(Map);
  });

  it("loads repair plans from the implemented repair-plan resource and reads workflow fields", async () => {
    setApiCredentials("foreman@example.test", "secret");
    const body = {
      repairPlanId: 73,
      repairPlanNumber: "RP-0073",
      repairPlanStatus: "DRAFT",
      jobId: 51,
      jobCardId: 60,
      workOrders: [{ workOrderId: 91, departmentName: "Mechanic", status: "READY" }],
      departmentRoutes: [{ departmentName: "Electrical", applicability: "NOT_APPLICABLE" }],
    };
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse(body));
    vi.stubGlobal("fetch", fetchMock);

    const plan = await backendApi.getRepairPlan(73);

    expect(String(fetchMock.mock.calls[0]?.[0])).toContain("/api/repair-plans/73");
    expect(plan["repairPlanStatus"]).toBe("DRAFT");
    expect(plan["workOrders"]).toEqual(body.workOrders);
    expect(plan["departmentRoutes"]).toEqual(body.departmentRoutes);
  });

  it("uses the implemented job-card detail route for linking quoted parts", async () => {
    setApiCredentials("foreman@example.test", "secret");
    setApiIdentity(identity);
    const fetchMock = vi.fn().mockResolvedValue(
      jsonResponse({
        jobCardId: 60,
        jobId: 51,
        parts: [{ jobCardPartId: 92, partNumber: "FLT-01", quantity: 1 }],
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const card = await backendApi.getJobCard(60);

    expect(String(fetchMock.mock.calls[0]?.[0])).toContain("/api/job-cards/60");
    expect(card["parts"]).toEqual([{ jobCardPartId: 92, partNumber: "FLT-01", quantity: 1 }]);
  });

  it("uses backend routes for department visits, evidence, activity, and assignments", async () => {
    setApiCredentials("foreman@example.test", "secret");
    setApiIdentity(identity);
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse([]));
    vi.stubGlobal("fetch", fetchMock);

    await backendApi.getDepartmentVisits(91, 3);
    await backendApi.getWorkOrderEvidence(91);
    await backendApi.getWorkOrderActivities(91);
    await backendApi.getWorkOrderAssignments(91);

    expect(fetchMock.mock.calls.map(([url]) => String(url))).toEqual([
      "/backend-api/api/work-orders/91/departments/3/visits",
      "/backend-api/api/work-orders/91/evidence",
      "/backend-api/api/work-orders/91/activities",
      "/backend-api/api/work-order-assignments/work-orders/91",
    ]);
  });

  it("connects reservations and accounts dispatch acknowledgement to backend routes", async () => {
    setApiCredentials("accounts@example.test", "secret");
    setApiIdentity({ ...identity, authorities: ["ROLE_ACCOUNTS"] });
    const fetchMock = vi.fn().mockResolvedValue(jsonResponse([]));
    vi.stubGlobal("fetch", fetchMock);

    await backendApi.getJobReservations(60);
    await backendApi.dispatchAction(77, "accounts-acknowledgement", {
      acknowledgedByEmployeeId: 14,
      signerName: "Accounts Clerk",
    });

    expect(fetchMock.mock.calls.map(([url]) => String(url))).toEqual([
      "/backend-api/api/job-cards/60/parts/reservations",
      "/backend-api/api/dispatch-orders/77/accounts-acknowledgement",
    ]);
  });
});
