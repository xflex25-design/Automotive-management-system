import type {
  CatalogPart,
  Inspection,
  InventoryCard,
  JobCard,
  Quotation,
  Requisition,
  Vehicle,
} from "./workshop";

const configuredApiUrl = import.meta.env["VITE_API_URL"]?.replace(/\/$/, "") ?? "";
const apiPrefix = import.meta.env.DEV ? "/backend-api" : configuredApiUrl;

export type AuthIdentity = {
  userId: number;
  employeeId: number | null;
  companyId: number;
  workshopId: number | null;
  displayName: string;
  authorities: string[];
};

let basicAuthorization: string | null = null;
let authenticatedIdentity: AuthIdentity | null = null;

function encodeBasicCredentials(username: string, password: string) {
  const bytes = new TextEncoder().encode(`${username}:${password}`);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return `Basic ${btoa(binary)}`;
}

export function setApiCredentials(username: string, password: string) {
  basicAuthorization = encodeBasicCredentials(username, password);
  authenticatedIdentity = null;
}

export function setApiIdentity(identity: AuthIdentity) {
  authenticatedIdentity = identity;
}

export function clearApiAuthentication() {
  basicAuthorization = null;
  authenticatedIdentity = null;
}

export function hasApiCredentials() {
  return basicAuthorization !== null;
}

export function getApiIdentity() {
  return authenticatedIdentity;
}

export class ApiError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

export async function apiFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  if (import.meta.env.MODE !== "test" && import.meta.env["VITE_DEMO_MODE"] === "true") {
    throw new ApiError("Backend requests are disabled in local demo mode.", 0);
  }
  const headers = new Headers(init.headers);
  if (basicAuthorization) headers.set("Authorization", basicAuthorization);
  if (init.body && !(init.body instanceof FormData))
    headers.set("Content-Type", "application/json");
  const response = await fetch(`${apiPrefix}/api${path}`, { ...init, headers });
  if (!response.ok) {
    if (response.status === 401 && typeof window !== "undefined") {
      window.dispatchEvent(new Event("backend:unauthorized"));
    }
    const contentType = response.headers.get("content-type") ?? "";
    const message = contentType.includes("json")
      ? await response
          .json()
          .then((body) => body.message ?? body.detail ?? body.error ?? JSON.stringify(body))
          .catch(() => "")
      : await response.text().catch(() => "");
    throw new ApiError(message || `Backend request failed (${response.status})`, response.status);
  }
  if (response.status === 204) return undefined as T;
  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) return response.json() as Promise<T>;
  return (await response.text()) as T;
}

export type BackendRefs = {
  jobId?: number;
  vehicleId?: number;
  customerId?: number;
  inventoryCardId?: number;
  quotationId?: number;
  jobCardId?: number;
  requisitionId?: number;
  inspectionId?: number;
  repairPlanId?: number;
  invoiceId?: number;
  handoverId?: number;
};

export type BackendIntakeResponse = {
  [field: string]: unknown;
  jobId: number;
  jobNumber: string;
  customerId: number;
  customerName: string;
  vehicleId: number;
  registrationNumber: string;
  inventoryCardId: number;
  jobStatus: string;
  intakeStatus: string;
  dateReceived: string;
};

export type WorkflowRecordsResponse = {
  vehicles: Record<string, unknown>[];
  jobCards: Record<string, unknown>[];
  requisitions: Record<string, unknown>[];
  inspections: Record<string, unknown>[];
  inventory: Record<string, unknown>[];
  parts: Record<string, unknown>[];
  purchaseOrders: Record<string, unknown>[];
  options: Record<string, unknown>;
};

export type WorkOrderReminder = {
  id: number;
  workOrderId: number;
  workOrderNumber: string;
  employeeId: number | null;
  reminderType: string;
  escalationLevel: number;
  priority: string;
  message: string;
  sentAt: string;
  acknowledgedAt: string | null;
  acknowledgedByEmployeeId: number | null;
};

export const requiredId = (name: string, value: string | undefined) => {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id <= 0) {
    throw new Error(`Set ${name} in hi-rider-frontend/.env before creating backend records.`);
  }
  return id;
};

export const configuredCompanyId = () => {
  const id = getApiIdentity()?.companyId;
  if (!id) throw new Error("The signed-in account has no company assigned.");
  return id;
};
const companyId = configuredCompanyId;
const workshopId = () => {
  const id = getApiIdentity()?.workshopId;
  if (!id) throw new Error("The signed-in account has no workshop assigned.");
  return id;
};
const userId = () => {
  const id = getApiIdentity()?.userId;
  if (!id) throw new Error("Sign in with an active workshop account before continuing.");
  return id;
};
const employeeId = () => {
  const id = getApiIdentity()?.employeeId;
  if (!id) throw new Error("The signed-in account is not linked to an active employee.");
  return id;
};

export function toCreateVehicleRequest(vehicle: Vehicle) {
  const name = vehicle.customer.trim().split(/\s+/);
  return {
    companyId: companyId(),
    workshopId: workshopId(),
    createdByUserId: userId(),
    receivedByEmployeeId: employeeId(),
    customer: {
      customerType: "INDIVIDUAL",
      firstName: name[0] ?? vehicle.customer,
      lastName: name.slice(1).join(" "),
      phone: vehicle.phone,
      email: vehicle.email || null,
    },
    vehicle: {
      registrationNumber: vehicle.plate,
      make: vehicle.make,
      color: vehicle.color || null,
      vin: vehicle.vin || null,
      vehicleType: "4x4",
    },
    ownerName: vehicle.ownerName?.trim() || vehicle.customer,
    broughtInByName: vehicle.deliveredBy?.trim() ?? "",
    broughtInByPhone: vehicle.delivererPhone?.trim() ?? "",
    priority: "NORMAL",
    reportedProblem: vehicle.complaints,
    odometerReadingIn: vehicle.odometer ?? null,
    fuelLevelIn: vehicle.fuelIn?.trim() || null,
    workRequested: vehicle.complaints,
    customerComplaints: vehicle.complaints,
    generalRemarks: vehicle.damage,
  };
}

export function mapVehicleResponse(response: BackendIntakeResponse, previous: Vehicle): Vehicle {
  return {
    ...previous,
    id: response.jobNumber || String(response.jobId),
    plate: response.registrationNumber || previous.plate,
    customer: response.customerName || previous.customer,
    received: response.dateReceived
      ? new Date(response.dateReceived).toLocaleDateString("en-GB")
      : previous.received,
  };
}

export function toCreateQuotationRequest(quotation: Quotation, part?: CatalogPart) {
  const items: NonNullable<Quotation["items"]> = quotation.items?.length
    ? quotation.items
    : [
        {
          itemType: quotation.catalogPartId ? ("PART" as const) : ("LABOUR" as const),
          item: part?.name ?? quotation.description,
          description: quotation.description,
          quantity: quotation.quantity ?? 1,
          unitPrice: quotation.catalogPartId
            ? quotation.amount / (quotation.quantity ?? 1)
            : quotation.amount,
        },
      ];
  return {
    preparedByEmployeeId: employeeId(),
    foremanNotes: quotation.paperFields
      ? `PAPER_QUOTATION:${JSON.stringify(quotation.paperFields)}`
      : undefined,
    items: items.map((item) => ({
      itemType: item.itemType,
      itemCode: item.item || null,
      description: item.description,
      quantity: item.quantity,
      unitOfMeasure: item.itemType === "LABOUR" ? "JOB" : "UNIT",
      unitPrice: item.unitPrice,
    })),
  };
}

export function mapQuotationResponse(
  response: Record<string, unknown>,
  previous: Quotation,
): Quotation {
  const total = Number(response["totalAmount"] ?? previous.amount);
  const subtotal = Number(response["subtotal"] ?? previous.subtotal ?? previous.amount);
  const taxAmount = Number(response["taxAmount"] ?? previous.taxAmount ?? 0);
  const responseItems = Array.isArray(response["items"])
    ? (response["items"] as Record<string, unknown>[])
    : null;
  const quotationDate =
    String(response["issueDate"] ?? response["createdAt"] ?? "") || previous.quotationDate;
  const preparedByName =
    String(response["preparedByName"] ?? previous.preparedByName ?? "") || undefined;
  const notes = String(response["foremanNotes"] ?? "");
  const paperMetadata = notes.startsWith("PAPER_QUOTATION:")
    ? (() => {
        try {
          const value: unknown = JSON.parse(notes.slice("PAPER_QUOTATION:".length));
          return value && typeof value === "object" && !Array.isArray(value)
            ? (value as Record<string, string>)
            : undefined;
        } catch {
          return undefined;
        }
      })()
    : undefined;
  const backendId = Number(response["quotationId"] ?? previous.backendId);
  const status = String(response["quotationStatus"] ?? "DRAFT").toUpperCase();
  return {
    ...previous,
    ...(Number.isSafeInteger(backendId) && backendId > 0 ? { backendId } : {}),
    id: String(response["quotationNumber"] ?? response["quotationId"] ?? previous.id),
    amount: Number.isFinite(total) ? total : previous.amount,
    subtotal: Number.isFinite(subtotal) ? subtotal : previous.amount,
    taxAmount: Number.isFinite(taxAmount) ? taxAmount : 0,
    discountAmount: Number(response["discountAmount"] ?? 0),
    ...(quotationDate ? { quotationDate } : {}),
    ...(preparedByName ? { preparedByName } : {}),
    ...(paperMetadata ? { paperFields: paperMetadata } : {}),
    ...(responseItems
      ? {
          items: responseItems.map((item) => ({
            itemType: String(item["itemType"] ?? "OTHER").toUpperCase() as
              "PART" | "LABOUR" | "SERVICE" | "OTHER",
            item: String(item["itemCode"] ?? ""),
            description: String(item["description"] ?? ""),
            quantity: Number(item["quantity"] ?? 0),
            unitPrice: Number(item["unitPrice"] ?? 0),
            discountAmount: Number(item["discountAmount"] ?? 0),
            lineTotal:
              Number(item["quantity"] ?? 0) * Number(item["unitPrice"] ?? 0) -
              Number(item["discountAmount"] ?? 0),
            taxAmount: Number(item["taxAmount"] ?? 0),
          })),
        }
      : {}),
    status:
      status === "CANCELLED"
        ? "Cancelled"
        : status === "SUPERSEDED"
          ? "Superseded"
          : status === "ISSUED" || status === "APPROVED" || status === "PENDING_APPROVAL"
            ? "Issued"
            : "Draft",
  };
}

export type DepartmentRouteInput = {
  departmentId: number;
  applicability: "REQUIRED" | "NOT_APPLICABLE";
  notApplicableReason?: string;
  manualWorkDescription?: string;
  manualWorkInstructions?: string;
};

export function toCreateJobCardRequest(
  job: JobCard,
  refs: BackendRefs,
  departmentRoutes: DepartmentRouteInput[],
) {
  if (!refs.jobId || !refs.quotationId) {
    throw new Error("A backend job and quotation are required before creating a job card.");
  }
  return {
    jobId: refs.jobId,
    quotationId: refs.quotationId,
    preparedByEmployeeId: employeeId(),
    workDescription: job.work,
    repairInstructions: job.work,
    foremanRemarks: `Department: ${job.department}`,
    departmentRoutes,
  };
}

export function toCreateRequisitionRequest(requisition: Requisition) {
  return {
    requestedByEmployeeId: employeeId(),
    priority: "NORMAL",
    purpose: `${requisition.part} x ${requisition.quantity}: ${requisition.reason}`,
  };
}

export function toStartInspectionRequest() {
  return { inspectorEmployeeId: employeeId() };
}

export function mapInventoryResponse(
  response: Record<string, unknown>,
  previous: InventoryCard,
): InventoryCard {
  return {
    ...previous,
    id: String(response["inventoryCardId"] ?? response["id"] ?? previous.id),
  };
}

export function mapJobCardResponse(response: Record<string, unknown>, previous: JobCard): JobCard {
  return {
    ...previous,
    id: String(response["jobCardNumber"] ?? response["jobCardId"] ?? response["id"] ?? previous.id),
  };
}

export function mapRequisitionResponse(
  response: Record<string, unknown>,
  previous: Requisition,
): Requisition {
  const status = String(
    response["status"] ?? response["requisitionStatus"] ?? "PENDING",
  ).toUpperCase();
  return {
    ...previous,
    id: String(response["requisitionNumber"] ?? response["requisitionId"] ?? previous.id),
    status:
      status === "APPROVED"
        ? "Approved"
        : status === "REJECTED"
          ? "Rejected"
          : status === "ORDERED"
            ? "Ordered"
            : status === "DISPATCHED"
              ? "Dispatched"
              : "Pending",
  };
}

export function mapInspectionResponse(
  response: Record<string, unknown>,
  previous: Inspection,
): Inspection {
  const decision = String(
    response["inspectionDecision"] ?? response["inspectionStatus"] ?? "",
  ).toUpperCase();
  return {
    ...previous,
    id: String(response["inspectionNumber"] ?? response["inspectionId"] ?? previous.id),
    result:
      decision.includes("REWORK") || decision.includes("FAIL")
        ? "Rework required"
        : previous.result,
  };
}

export const backendApi = {
  getCurrentUser: () => apiFetch<AuthIdentity>("/auth/me"),
  getCompanySettings: () => apiFetch<Record<string, unknown>>(`/companies/${companyId()}/settings`),
  getWorkflowRecords: () =>
    apiFetch<WorkflowRecordsResponse>(
      `/companies/${companyId()}/workflow-records?workshopId=${workshopId()}`,
    ),
  getWorkOrderReminders: (workOrderId: number) =>
    apiFetch<WorkOrderReminder[]>(`/work-order-reminders/work-orders/${workOrderId}`),
  getEmployeeReminders: (employeeId: number) =>
    apiFetch<WorkOrderReminder[]>(`/work-order-reminders/employees/${employeeId}/pending`),
  acknowledgeReminder: (reminderId: number, actorId = employeeId()) =>
    apiFetch<WorkOrderReminder>(
      `/work-order-reminders/${reminderId}/acknowledge?employeeId=${actorId}`,
      { method: "PUT" },
    ),
  loadRecords: async () => {
    const records = await backendApi.getWorkflowRecords();
    const {
      vehicles,
      jobCards,
      requisitions,
      inspections,
      inventory,
      parts,
      purchaseOrders,
      options,
    } = records;
    if (
      ![vehicles, jobCards, requisitions, inspections, inventory, parts, purchaseOrders].every(
        Array.isArray,
      ) ||
      !options ||
      typeof options !== "object" ||
      Array.isArray(options)
    ) {
      throw new ApiError(
        "The workflow-records response is missing required lists or workflow options.",
        502,
      );
    }
    const quotesByJob = await Promise.all(
      vehicles
        .filter((v) => v["jobId"])
        .map(async (v) => {
          const quotes = await apiFetch<Record<string, unknown>[]>(
            `/jobs/${v["jobId"]}/quotations`,
          );
          return [Number(v["jobId"]), quotes] as const;
        }),
    );
    const workflows = await Promise.all(
      jobCards
        .filter((card) => card["repairPlanId"])
        .map(async (card) => backendApi.getRepairPlan(Number(card["repairPlanId"]))),
    );
    const rawWorkOrders = workflows.flatMap((workflow) =>
      Array.isArray(workflow["workOrders"])
        ? (workflow["workOrders"] as Record<string, unknown>[])
        : [],
    );
    const workOrderDetails = await Promise.all(
      rawWorkOrders
        .filter((workOrder) => Number(workOrder["workOrderId"]) > 0)
        .map(async (workOrder) => {
          const workOrderId = Number(workOrder["workOrderId"]);
          const departmentId = Number(workOrder["departmentId"]);
          const [visits, evidence, activities, assignments, reminders] = await Promise.all([
            departmentId > 0
              ? backendApi.getDepartmentVisits(workOrderId, departmentId)
              : Promise.resolve([]),
            backendApi.getWorkOrderEvidence(workOrderId),
            backendApi.getWorkOrderActivities(workOrderId),
            backendApi.getWorkOrderAssignments(workOrderId),
            backendApi.getWorkOrderReminders(workOrderId),
          ]);
          return {
            workOrderId,
            order: {
              ...workOrder,
              departmentVisits: visits.map((visit) => ({
                ...visit,
                status: visit["visitStatus"],
              })),
              evidence,
              activities,
              assignments,
            } as Record<string, unknown>,
            reminders,
          } as const;
        }),
    );
    const workOrders = workOrderDetails.map((detail) => detail.order);
    const enrichedWorkflows: Record<string, unknown>[] = workflows.map((workflow) => {
      const planWorkOrders = Array.isArray(workflow["workOrders"])
        ? (workflow["workOrders"] as Record<string, unknown>[])
        : [];
      return {
        ...workflow,
        workOrders: planWorkOrders.map(
          (order) =>
            workOrders.find(
              (detail) => Number(detail["workOrderId"]) === Number(order["workOrderId"]),
            ) ?? order,
        ),
      };
    });
    const reminderRows = workOrderDetails.map(
      ({ workOrderId, reminders }) => [workOrderId, reminders] as const,
    );
    const inspectionDetails = await Promise.all(
      inspections.map(async (item) => {
        const id = Number(item["inspectionId"]);
        const [details, signoffs] = await Promise.all([
          apiFetch<Record<string, unknown>>(`/final-inspections/${id}`),
          apiFetch<Record<string, unknown>>(`/final-inspections/${id}/signoffs`),
        ]);
        return [id, { details, signoffs }] as const;
      }),
    );
    const dispatchesByJob = await Promise.all(
      vehicles
        .filter((v) => v["jobId"])
        .map(
          async (v) =>
            [
              Number(v["jobId"]),
              await apiFetch<Record<string, unknown>[]>(`/dispatch-orders/jobs/${v["jobId"]}`),
            ] as const,
        ),
    );
    const invoicesByJob = await Promise.all(
      vehicles
        .filter((v) => v["jobId"])
        .map(
          async (v) =>
            [
              Number(v["jobId"]),
              await apiFetch<Record<string, unknown>[]>(`/invoices/job/${v["jobId"]}`),
            ] as const,
        ),
    );
    const handoversByJob = await Promise.all(
      vehicles
        .filter((v) => v["jobId"])
        .map(async (v) => {
          const jobId = Number(v["jobId"]);
          const handover = await apiFetch<Record<string, unknown>>(`/handovers/job/${jobId}`).catch(
            (error) => {
              if (error instanceof ApiError && error.status === 404) return null;
              throw error;
            },
          );
          return [jobId, handover] as const;
        }),
    );
    return {
      vehicles,
      jobCards,
      requisitions,
      inspections,
      inventory,
      parts,
      purchaseOrders,
      options,
      workflows: enrichedWorkflows,
      remindersByWorkOrder: new Map(reminderRows),
      inspectionDetails: new Map(inspectionDetails),
      dispatchesByJob: new Map(dispatchesByJob),
      invoicesByJob: new Map(invoicesByJob),
      handoversByJob: new Map(handoversByJob),
      quotesByJob: new Map(quotesByJob),
    };
  },
  getJobCard: (jobCardId: number) => apiFetch<Record<string, unknown>>(`/job-cards/${jobCardId}`),
  getDepartmentVisits: (workOrderId: number, departmentId: number) =>
    apiFetch<Record<string, unknown>[]>(
      `/work-orders/${workOrderId}/departments/${departmentId}/visits`,
    ),
  getWorkOrderEvidence: (workOrderId: number) =>
    apiFetch<Record<string, unknown>[]>(`/work-orders/${workOrderId}/evidence`),
  getWorkOrderActivities: (workOrderId: number) =>
    apiFetch<Record<string, unknown>[]>(`/work-orders/${workOrderId}/activities`),
  getWorkOrderAssignments: (workOrderId: number) =>
    apiFetch<Record<string, unknown>[]>(`/work-order-assignments/work-orders/${workOrderId}`),
  getRepairPlan: async (repairPlanId: number) => {
    const plan = await apiFetch<Record<string, unknown>>(`/repair-plans/${repairPlanId}`);
    if (
      Number(plan["repairPlanId"]) !== repairPlanId ||
      !Array.isArray(plan["workOrders"]) ||
      !Array.isArray(plan["departmentRoutes"])
    ) {
      throw new ApiError(
        "The repair-plan response is missing its workflow routes or work orders.",
        502,
      );
    }
    return plan;
  },
  acceptRepairPlan: (repairPlanId: number, actorId = employeeId()) =>
    apiFetch<Record<string, unknown>>(`/repair-plans/${repairPlanId}/accept`, {
      method: "POST",
      body: JSON.stringify({ foremanEmployeeId: actorId }),
    }),
  assignWorkOrder: (
    workOrderId: number,
    assignedEmployeeId: number,
    role: string,
    actorId = employeeId(),
  ) =>
    apiFetch<Record<string, unknown>>("/work-order-assignments/batch", {
      method: "POST",
      body: JSON.stringify({
        assignedByEmployeeId: actorId,
        workOrders: [
          { workOrderId, assignments: [{ employeeId: assignedEmployeeId, assignmentRole: role }] },
        ],
      }),
    }),
  workOrderAction: (
    workOrderId: number,
    action: "start" | "pause" | "resume" | "waiting",
    notes: string,
    actorId = employeeId(),
  ) =>
    apiFetch<Record<string, unknown>>(`/work-orders/${workOrderId}/${action}`, {
      method: "POST",
      body: JSON.stringify({ employeeId: actorId, notes }),
    }),
  arriveAtDepartment: (
    workOrderId: number,
    departmentId: number,
    arrivalNotes: string,
    actorId = employeeId(),
  ) =>
    apiFetch<Record<string, unknown>>(
      `/work-orders/${workOrderId}/departments/${departmentId}/arrivals`,
      { method: "POST", body: JSON.stringify({ employeeId: actorId, arrivalNotes }) },
    ),
  sendOffDepartment: (
    workOrderId: number,
    departmentId: number,
    visitId: number,
    sendOffNotes: string,
    actorId = employeeId(),
  ) =>
    apiFetch<Record<string, unknown>>(
      `/work-orders/${workOrderId}/departments/${departmentId}/visits/${visitId}/send-off`,
      { method: "POST", body: JSON.stringify({ employeeId: actorId, sendOffNotes }) },
    ),
  submitWorkOrder: (workOrderId: number, completionNotes: string, actorId = employeeId()) =>
    apiFetch<Record<string, unknown>>(`/work-orders/${workOrderId}/submit-completion`, {
      method: "POST",
      body: JSON.stringify({ employeeId: actorId, completionNotes }),
    }),
  confirmWorkOrder: (workOrderId: number, reason: string, actorId = employeeId()) =>
    apiFetch<Record<string, unknown>>(`/work-orders/${workOrderId}/confirm`, {
      method: "POST",
      body: JSON.stringify({ employeeId: actorId, decision: "COMPLETED", reason }),
    }),
  uploadWorkEvidence: (
    workOrderId: number,
    file: File,
    caption: string,
    actorId = employeeId(),
  ) => {
    const body = new FormData();
    body.set("employeeId", String(actorId));
    body.set("evidenceType", "PHOTO");
    body.set("caption", caption);
    body.set("file", file);
    return apiFetch<Record<string, unknown>>(`/work-orders/${workOrderId}/evidence`, {
      method: "POST",
      body,
    });
  },
  updateInspectionItem: (
    inspectionId: number,
    itemId: number,
    checkStatus: "PASS" | "FAIL",
    comments: string,
    responsibleDepartmentId?: number,
  ) =>
    apiFetch<Record<string, unknown>>(`/final-inspections/${inspectionId}/items/${itemId}`, {
      method: "PATCH",
      body: JSON.stringify({
        employeeId: employeeId(),
        checkStatus,
        comments,
        responsibleDepartmentId,
      }),
    }),
  signoffInspectionDepartment: (inspectionId: number, departmentId: number, signoffNotes: string) =>
    apiFetch<Record<string, unknown>>(
      `/final-inspections/${inspectionId}/departments/${departmentId}/signoff`,
      {
        method: "POST",
        body: JSON.stringify({ employeeId: employeeId(), signoffStatus: "APPROVED", signoffNotes }),
      },
    ),
  completeInspection: (inspectionId: number) =>
    apiFetch<Record<string, unknown>>(`/final-inspections/${inspectionId}/complete`, {
      method: "POST",
    }),
  createCorrectiveWorkOrders: (inspectionId: number) =>
    apiFetch<Record<string, unknown>>(`/final-inspections/${inspectionId}/corrective-work-orders`, {
      method: "POST",
      body: JSON.stringify({ employeeId: employeeId() }),
    }),
  createPurchaseOrder: (
    requisitionId: number,
    supplierId: number,
    items: Array<{
      requisitionItemId: number;
      quantityOrdered: number;
      unitPrice: number;
      taxAmount?: number;
    }>,
    supplierReference?: string,
  ) =>
    apiFetch<Record<string, unknown>>(`/parts/requisitions/${requisitionId}/purchase-orders`, {
      method: "POST",
      body: JSON.stringify({
        supplierId,
        createdByEmployeeId: employeeId(),
        supplierReference,
        items,
      }),
    }),
  receivePurchaseOrder: (
    purchaseOrderId: number,
    stockLocationId: number,
    items: Array<{
      purchaseOrderItemId: number;
      quantityDelivered: number;
      quantityAccepted: number;
    }>,
    supplierDeliveryReference?: string,
  ) =>
    apiFetch<Record<string, unknown>>(`/parts/purchase-orders/${purchaseOrderId}/receipts`, {
      method: "POST",
      body: JSON.stringify({
        receivedByEmployeeId: employeeId(),
        stockLocationId,
        supplierDeliveryReference,
        items,
      }),
    }),
  checkPartsAvailability: (jobCardId: number) =>
    apiFetch<Record<string, unknown>>(`/job-cards/${jobCardId}/parts/availability`),
  getJobReservations: (jobCardId: number) =>
    apiFetch<Record<string, unknown>[]>(`/job-cards/${jobCardId}/parts/reservations`),
  reservePart: (
    jobCardId: number,
    jobCardPartId: number,
    stockLocationId: number,
    quantity: number,
  ) =>
    apiFetch<Record<string, unknown>>(
      `/job-cards/${jobCardId}/parts/${jobCardPartId}/reservations`,
      {
        method: "POST",
        body: JSON.stringify({ reservedByEmployeeId: employeeId(), stockLocationId, quantity }),
      },
    ),
  createDispatch: (
    jobId: number,
    mechanicId: number,
    departmentId: number,
    reservationIds: number[],
  ) =>
    apiFetch<Record<string, unknown>>("/dispatch-orders", {
      method: "POST",
      body: JSON.stringify({
        jobId,
        createdByEmployeeId: employeeId(),
        assignedMechanicEmployeeId: mechanicId,
        departmentId,
        items: reservationIds.map((stockReservationId) => ({ stockReservationId })),
      }),
    }),
  dispatchAction: (
    dispatchId: number,
    action: "approve" | "reject" | "resubmit" | "issue" | "receive" | "accounts-acknowledgement",
    body: Record<string, unknown>,
  ) =>
    apiFetch<Record<string, unknown>>(`/dispatch-orders/${dispatchId}/${action}`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  createInitialInspection: (
    jobId: number,
    inspection: {
      overallCondition: string;
      inspectionNotes: string;
      damages: Array<{ damageType: string; damageLocation: string; description?: string }>;
      accessories: Array<{
        accessoryName: string;
        present: boolean;
        conditionDescription?: string;
      }>;
      receivedItems: Array<{ itemName: string; quantity?: number; conditionDescription?: string }>;
    },
  ) =>
    apiFetch<Record<string, unknown>>(`/intake/jobs/${jobId}/inspection`, {
      method: "POST",
      body: JSON.stringify({
        inspectedByEmployeeId: employeeId(),
        inspectionType: "INITIAL",
        ...inspection,
      }),
    }),
  uploadIntakePhoto: (
    jobId: number,
    inspectionId: number,
    file: File,
    evidenceType: string,
    caption: string,
    damageRecordId?: number,
  ) => {
    const body = new FormData();
    body.set("file", file);
    const query = new URLSearchParams({
      inspectionId: String(inspectionId),
      uploadedByEmployeeId: String(employeeId()),
      evidenceType,
      caption,
    });
    if (damageRecordId) query.set("damageRecordId", String(damageRecordId));
    return apiFetch<Record<string, unknown>>(`/intake/jobs/${jobId}/photos?${query}`, {
      method: "POST",
      body,
    });
  },
  createIntakeAuthorisation: (
    jobId: number,
    authorisedByName: string,
    authorisedByPhone: string,
    authorisationText: string,
  ) =>
    apiFetch<Record<string, unknown>>(`/intake/jobs/${jobId}/authorisations`, {
      method: "POST",
      body: JSON.stringify({
        authorisationType: "CUSTOMER_WORK_AUTHORIZATION",
        authorisationText,
        authorisedByName,
        authorisedByPhone,
      }),
    }),
  recordIntakeSignature: (
    jobId: number,
    input: {
      authorisationId?: number;
      signerType: "CUSTOMER" | "EMPLOYEE";
      signerName: string;
      signatureMediaId: number;
      remarks?: string;
    },
  ) =>
    apiFetch<Record<string, unknown>>(`/intake/jobs/${jobId}/signatures`, {
      method: "POST",
      body: JSON.stringify({
        ...input,
        employeeId: input.signerType === "EMPLOYEE" ? employeeId() : null,
      }),
    }),
  completeIntake: (jobId: number) =>
    apiFetch<Record<string, unknown>>(`/intake/jobs/${jobId}/complete`, { method: "POST" }),
  createInvoice: (jobId: number, quotationId: number) =>
    apiFetch<Record<string, unknown>>("/invoices", {
      method: "POST",
      body: JSON.stringify({ jobId, quotationId, issuedByEmployeeId: employeeId() }),
    }),
  recordPayment: (invoiceId: number, amount: number, transactionReference: string) =>
    apiFetch<Record<string, unknown>>(`/invoices/${invoiceId}/payments`, {
      method: "POST",
      body: JSON.stringify({
        receivedByEmployeeId: employeeId(),
        paymentMethod: "CASH",
        amount,
        transactionReference,
        paymentDate: new Date().toISOString(),
      }),
    }),
  createHandover: (input: Record<string, unknown>) =>
    apiFetch<Record<string, unknown>>("/handovers", {
      method: "POST",
      body: JSON.stringify({ ...input, releasedByEmployeeId: employeeId() }),
    }),
  createIntake: (vehicle: Vehicle) =>
    apiFetch<BackendIntakeResponse>("/intake/vehicles", {
      method: "POST",
      body: JSON.stringify(toCreateVehicleRequest(vehicle)),
    }),
  createQuotation: (jobId: number, quotation: Quotation, part?: CatalogPart) =>
    apiFetch<Record<string, unknown>>(`/jobs/${jobId}/quotations`, {
      method: "POST",
      body: JSON.stringify(toCreateQuotationRequest(quotation, part)),
    }),
  issueQuotation: (quotationId: number) =>
    apiFetch<Record<string, unknown>>(`/quotations/${quotationId}/issue`, { method: "PUT" }),
  createJobCard: (job: JobCard, refs: BackendRefs, departmentRoutes: DepartmentRouteInput[]) =>
    apiFetch<Record<string, unknown>>("/job-cards", {
      method: "POST",
      body: JSON.stringify(toCreateJobCardRequest(job, refs, departmentRoutes)),
    }),
  linkJobCardPart: (jobCardId: number, jobCardPartId: number, partId: number) =>
    apiFetch<Record<string, unknown>>(
      `/job-cards/${jobCardId}/parts/${jobCardPartId}/catalog-part`,
      {
        method: "PATCH",
        body: JSON.stringify({ partId, linkedByEmployeeId: employeeId() }),
      },
    ),
  createRequisition: (jobId: number, requisition: Requisition) =>
    apiFetch<Record<string, unknown>>(`/jobs/${jobId}/parts/requisitions`, {
      method: "POST",
      body: JSON.stringify(toCreateRequisitionRequest(requisition)),
    }),
  startFinalInspection: (jobId: number) =>
    apiFetch<Record<string, unknown>>(`/final-inspections/jobs/${jobId}`, {
      method: "POST",
      body: JSON.stringify(toStartInspectionRequest()),
    }),
};
