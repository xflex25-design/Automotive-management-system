import { createFileRoute } from "@tanstack/react-router";
import { RecordsPage } from "@/components/workshop/record-pages";
import { workshopHead } from "@/lib/route-head";
export const Route = createFileRoute("/quotations")({
  head: () =>
    workshopHead(
      "Quotation Management",
      "Prepare additional repair quotations; the customer authorizes requested work once on the vehicle intake.",
    ),
  component: () => <RecordsPage kind="quotations" />,
});
