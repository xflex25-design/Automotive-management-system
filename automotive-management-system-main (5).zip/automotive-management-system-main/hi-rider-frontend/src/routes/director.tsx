import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/workshop/dashboard";
import { workshopHead } from "@/lib/route-head";
export const Route = createFileRoute("/director")({
  head: () =>
    workshopHead(
      "Management Dashboard",
      "Hi Rider 4x4 World workshop operations and manager oversight.",
    ),
  component: Dashboard,
});
