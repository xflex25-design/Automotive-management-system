import { createFileRoute } from "@tanstack/react-router";
import { RecordsPage } from "@/components/workshop/record-pages";
import { workshopHead } from "@/lib/route-head";
export const Route = createFileRoute("/requisitions")({
  head: () =>
    workshopHead(
      "Parts Requisitions",
      "Parts shortages identified from job-card requirements and current store availability.",
    ),
  component: () => <RecordsPage kind="requisitions" />,
});
