import { createFileRoute } from "@tanstack/react-router";
import { ApprovalPage } from "@/components/workshop/monitor-pages";
import { workshopHead } from "@/lib/route-head";
export const Route = createFileRoute("/approvals")({
  head: () =>
    workshopHead(
      "Dispatch Order Approvals",
      "Manager and Boss approval or rejection of workshop dispatch orders before parts are issued.",
    ),
  component: ApprovalPage,
});
