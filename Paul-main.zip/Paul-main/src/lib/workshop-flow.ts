import type {
  DepartmentProgressItem,
  DepartmentWorkStatus,
  Inspection,
  IntakeAccessoryRecord,
  JobCard,
  JobCardPartsSheetRow,
  PartsCheckDetails,
  PartsCheckItem,
  Quotation,
  Requisition,
  Vehicle,
} from "./workshop";

export type StageMeta = {
  stageNumber: 1 | 2 | 3 | 4 | 5 | 6 | 7;
  index: 0 | 1 | 2 | 3 | 4 | 5 | 6;
  key: "intake" | "quotation" | "authorization" | "job_card" | "parts" | "dispatch" | "monitor";
  shortLabel: string;
  title: string;
  subtitle: string;
  owner: string;
};

export const WORKSHOP_FLOW_STAGES: readonly StageMeta[] = [
  {
    stageNumber: 1,
    index: 0,
    key: "intake",
    shortLabel: "Intake & Inspection",
    title: "Stage 1: Intake & Inspection",
    subtitle: "Capture customer, vehicle and initial inspection details",
    owner: "Receptionist / Intake Officer",
  },
  {
    stageNumber: 2,
    index: 1,
    key: "quotation",
    shortLabel: "Quotation",
    title: "Stage 2: Itemized Quotation Builder",
    subtitle: "Build itemized parts & labour costs with automatic VAT calculations",
    owner: "Salesperson / Quotation Officer",
  },
  {
    stageNumber: 3,
    index: 2,
    key: "authorization",
    shortLabel: "Authorization",
    title: "Stage 3: Customer Authorization Gate",
    subtitle: "Confirm quotation acceptance, workshop conditions and 50% deposit",
    owner: "Customer & Intake / Sales",
  },
  {
    stageNumber: 4,
    index: 3,
    key: "job_card",
    shortLabel: "Job Card",
    title: "Stage 4: Job Card & Department Routing",
    subtitle: "Define repair scope, parts sheet, departments and mechanic assignment",
    owner: "Foreman / Workshop Supervisor",
  },
  {
    stageNumber: 5,
    index: 4,
    key: "parts",
    shortLabel: "Parts",
    title: "Stage 5: Parts Availability & Requisition",
    subtitle: "Verify stock levels, raise purchase requisitions and receive parts",
    owner: "Stores Officer",
  },
  {
    stageNumber: 6,
    index: 5,
    key: "dispatch",
    shortLabel: "Dispatch",
    title: "Stage 6: Dispatch Order & Manager Approval",
    subtitle: "Approve release of parts from stores to the workshop floor",
    owner: "Manager & Stores",
  },
  {
    stageNumber: 7,
    index: 6,
    key: "monitor",
    shortLabel: "Workshop",
    title: "Stage 7: Department Work State & Live Stagnation Monitor",
    subtitle: "Monitor bay progress, stagnation alerts and submit for Final Inspection",
    owner: "Foreman / Workshop Supervisor",
  },
] as const;

export const DEFAULT_ACCESSORIES = [
  "Spare Wheel",
  "Jack",
  "Jack Handle",
  "Triangles",
  "Wheel Spanner",
  "Fire Extinguisher",
  "Tool Kit",
  "Wheel Covers",
  "Car Mats",
] as const;

export function createDefaultAccessoriesChecklist(): IntakeAccessoryRecord[] {
  return DEFAULT_ACCESSORIES.map((name) => ({
    name,
    available: true,
    condition: "Good",
    remarks: "",
  }));
}

export const ROUTABLE_DEPARTMENTS = [
  "Mechanical",
  "Electrical",
  "Suspension",
  "Brakes",
  "Diagnostics",
] as const;

export const DEFAULT_QUOTATION_STARTER_ITEMS = [
  {
    itemType: "PART" as const,
    item: "Air filter",
    description: "OEM engine air filter element",
    quantity: 1,
    unitPrice: 450,
  },
  {
    itemType: "PART" as const,
    item: "Oil filter",
    description: "Spin-on engine oil filter",
    quantity: 1,
    unitPrice: 250,
  },
  {
    itemType: "PART" as const,
    item: "Fuel filter",
    description: "Inline diesel/petrol fuel filter",
    quantity: 1,
    unitPrice: 250,
  },
  {
    itemType: "LABOUR" as const,
    item: "Labour",
    description: "Standard service & diagnostic labour",
    quantity: 1,
    unitPrice: 2000,
  },
];

export const DEFAULT_PARTS_SHEET_ITEMS = [
  "Air filter",
  "Oil filter",
  "Fuel filter",
  "Cabin filter",
] as const;

export const QUOTATION_SERVICE_PRESETS = [
  {
    id: "minor_service",
    label: "Minor 4x4 Service",
    items: [
      {
        itemType: "PART" as const,
        item: "Oil filter",
        description: "Spin-on engine oil filter",
        quantity: 1,
        unitPrice: 250,
      },
      {
        itemType: "PART" as const,
        item: "Engine oil (7L)",
        description: "Synthetic diesel/petrol engine oil",
        quantity: 1,
        unitPrice: 1200,
      },
      {
        itemType: "LABOUR" as const,
        item: "Minor service labour",
        description: "Oil change & 24-point safety check",
        quantity: 1,
        unitPrice: 1500,
      },
    ],
  },
  {
    id: "major_service",
    label: "Major 4x4 Service",
    items: DEFAULT_QUOTATION_STARTER_ITEMS,
  },
  {
    id: "brake_overhaul",
    label: "Brake Overhaul",
    items: [
      {
        itemType: "PART" as const,
        item: "Front brake pads",
        description: "Heavy-duty 4x4 front brake pad set",
        quantity: 1,
        unitPrice: 850,
      },
      {
        itemType: "PART" as const,
        item: "Brake booster",
        description: "Vacuum brake booster assembly",
        quantity: 1,
        unitPrice: 2400,
      },
      {
        itemType: "PART" as const,
        item: "Brake fluid (DOT 4)",
        description: "Hydraulic brake bleed & flush fluid",
        quantity: 1,
        unitPrice: 180,
      },
      {
        itemType: "LABOUR" as const,
        item: "Brake overhaul labour",
        description: "Strip, fit, bleed and road-test brakes",
        quantity: 1,
        unitPrice: 1800,
      },
    ],
  },
] as const;

export function buildPartsSheetFromQuotation(
  quotation: Quotation | undefined,
): JobCardPartsSheetRow[] {
  const partLines = (quotation?.items ?? []).filter(
    (line) => line.itemType === "PART" && (line.item?.trim() || line.description?.trim()),
  );
  if (partLines.length === 0) {
    return DEFAULT_PARTS_SHEET_ITEMS.map((name, idx) => ({
      id: `ps-${idx}`,
      partName: name,
      quoted: Boolean(
        quotation?.items?.some((item) =>
          item.item.toLowerCase().includes(name.split(" ")[0]?.toLowerCase() ?? ""),
        ),
      ),
      requiredFor: "Routine service / repair",
      additionalPart: "",
      quantity: 1,
    }));
  }
  return partLines.map((line, idx) => ({
    id: `ps-q-${idx}`,
    partName: line.item.trim() || line.description.trim(),
    quoted: true,
    requiredFor: line.description.trim() || "Quoted repair scope",
    additionalPart: "",
    quantity: Math.max(1, Number(line.quantity || 1)),
  }));
}

export const WORK_STATUS_OPTIONS: readonly DepartmentWorkStatus[] = [
  "Not Started",
  "In Progress",
  "Waiting for Parts",
  "On Hold",
  "Completed",
] as const;

export const APPROVED_DISPATCH_STATUSES = new Set([
  "APPROVED",
  "COMPLETED",
  "ISSUED",
  "APPROVED_AND_DISPATCHED",
]);

export function roundCurrency(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.round(value * 100) / 100;
}

export function calculateQuotationTotals(
  items: ReadonlyArray<{ quantity: number; unitPrice: number }>,
  vatRate = 0.16,
): { subtotal: number; vat: number; total: number; requiredDeposit: number } {
  const subtotal = roundCurrency(
    items.reduce((sum, line) => {
      const qty = Number.isFinite(line.quantity) && line.quantity > 0 ? line.quantity : 0;
      const price = Number.isFinite(line.unitPrice) && line.unitPrice > 0 ? line.unitPrice : 0;
      return sum + qty * price;
    }, 0),
  );
  const vat = roundCurrency(subtotal * vatRate);
  const total = roundCurrency(subtotal + vat);
  const requiredDeposit = roundCurrency(total * 0.5);
  return { subtotal, vat, total, requiredDeposit };
}

export function derivePartStockStatus(
  requiredQty: number,
  availableQty: number,
): "Available" | "Partially available" | "Out of stock" {
  const req = Number.isFinite(requiredQty) ? Math.max(0, requiredQty) : 0;
  const avail = Number.isFinite(availableQty) ? Math.max(0, availableQty) : 0;
  if (req === 0 || avail >= req) return "Available";
  if (avail <= 0) return "Out of stock";
  return "Partially available";
}

export function deriveOverallStockStatus(
  items: readonly Pick<PartsCheckItem, "requiredQty" | "availableQty">[],
): "Available" | "Partially available" | "Out of stock" {
  if (items.length === 0) return "Out of stock";
  const statuses = items.map((item) => derivePartStockStatus(item.requiredQty, item.availableQty));
  if (statuses.some((status) => status === "Out of stock")) return "Out of stock";
  if (statuses.some((status) => status === "Partially available")) return "Partially available";
  return "Available";
}

export function canCreateDispatchFromParts(
  items: readonly PartsCheckItem[],
  receiving?: PartsCheckDetails["receiving"],
): { allowed: boolean; blockers: string[] } {
  const blockers: string[] = [];
  if (items.length === 0) {
    blockers.push("At least one required part line must be verified.");
    return { allowed: false, blockers };
  }

  for (const item of items) {
    const status = derivePartStockStatus(item.requiredQty, item.availableQty);
    if (status !== "Available") {
      const receivedCovers =
        Boolean(receiving?.stockUpdated) &&
        (receiving?.quantityReceived ?? 0) >= Math.max(1, item.requiredQty - item.availableQty);
      if (!receivedCovers) {
        blockers.push(
          `${item.partName || "Part"} is ${status.toLowerCase()} (${item.availableQty}/${item.requiredQty} available).`,
        );
      }
    }
  }

  return {
    allowed: blockers.length === 0,
    blockers,
  };
}

export function isStage1IntakeComplete(vehicle: Vehicle | undefined): boolean {
  if (!vehicle) return false;
  if (
    !vehicle.customer?.trim() ||
    !vehicle.phone?.trim() ||
    !vehicle.plate?.trim() ||
    !vehicle.make?.trim() ||
    !vehicle.complaints?.trim()
  ) {
    return false;
  }

  const details = vehicle.intakeDetails;
  if (!details) return true;

  return (
    details.status === "completed" &&
    details.termsAccepted === true &&
    details.customerSignature.trim().length > 0 &&
    details.authorizationDate.trim().length > 0 &&
    Number.isFinite(details.mileageIn) &&
    details.mileageIn >= 0
  );
}

export function isStage2QuotationComplete(quotation: Quotation | undefined): boolean {
  if (!quotation) return false;
  if (quotation.status === "Draft") return false;
  if (!Number.isFinite(quotation.amount) || quotation.amount <= 0) return false;
  if (quotation.items && quotation.items.length === 0) return false;
  if (quotation.items) {
    const validLines = quotation.items.every(
      (line) =>
        (line.item?.trim() || line.description?.trim()) &&
        Number.isFinite(line.quantity) &&
        line.quantity > 0 &&
        Number.isFinite(line.unitPrice) &&
        line.unitPrice >= 0,
    );
    if (!validLines) return false;
  }
  return true;
}

export function isStage3AuthorizationComplete(quotation: Quotation | undefined): boolean {
  if (!quotation) return false;
  if (quotation.status !== "Approved") return false;

  const auth = quotation.authorization;
  if (!auth) {
    return true;
  }

  const allTermsAccepted =
    auth.terms.permissionRepairs &&
    auth.terms.permissionMaterials &&
    auth.terms.vehicleSecurity &&
    auth.terms.additionalWork &&
    auth.terms.paymentCollection;

  const minimumDeposit = roundCurrency(quotation.amount * 0.5);
  const depositSatisfied =
    (auth.paymentStatus === "Deposit Paid" || auth.paymentStatus === "Paid in Full") &&
    Number.isFinite(auth.depositAmount) &&
    auth.depositAmount >= minimumDeposit &&
    auth.paymentReference.trim().length > 0;

  return (
    auth.customerAcceptance === "Accepted" &&
    allTermsAccepted &&
    depositSatisfied &&
    auth.customerName.trim().length > 0 &&
    auth.customerSignature.trim().length > 0 &&
    auth.authorizationDate.trim().length > 0
  );
}

export function isStage4JobCardComplete(job: JobCard | undefined): boolean {
  if (!job) return false;
  if (!job.work?.trim()) return false;
  if (!job.department?.trim() || job.department === "Unassigned") return false;
  if (!job.due?.trim()) return false;
  if (job.routedDepartments && job.routedDepartments.length === 0) return false;
  if (job.assignedEmployee !== undefined && !job.assignedEmployee.trim()) return false;
  return true;
}

export function isStage5PartsComplete(
  requisitions: readonly Requisition[],
  vehicleId: string,
): boolean {
  const matching = requisitions.filter((r) => r.vehicleId === vehicleId);
  if (matching.length === 0) return false;

  return matching.some((req) => {
    if (req.status === "Rejected" || req.status === "Pending") return false;
    if (req.partsCheck) {
      if (req.partsCheck.status !== "completed" || !req.partsCheck.verifiedForDispatch) {
        return false;
      }
      return canCreateDispatchFromParts(req.partsCheck.items, req.partsCheck.receiving).allowed;
    }
    return req.status === "Approved" || req.status === "Dispatched" || req.status === "Ordered";
  });
}

export function findMatchingDispatch(
  dispatches: readonly Record<string, unknown>[],
  context: { vehicleId: string; job?: JobCard },
): Record<string, unknown> | undefined {
  return dispatches.find((dispatch) => {
    const dispatchVehicleId = String(dispatch["vehicleId"] ?? "");
    const dispatchJobNumber = String(dispatch["jobNumber"] ?? "");
    const dispatchJobId = Number(dispatch["jobId"]);
    if (dispatchVehicleId && dispatchVehicleId === context.vehicleId) return true;
    if (context.job) {
      if (dispatchJobNumber && dispatchJobNumber === context.job.id) return true;
      if (
        context.job.backendJobId !== undefined &&
        Number.isFinite(dispatchJobId) &&
        dispatchJobId === Number(context.job.backendJobId)
      ) {
        return true;
      }
    }
    return false;
  });
}

export function isStage6DispatchComplete(
  dispatches: readonly Record<string, unknown>[],
  context: { vehicleId: string; job?: JobCard },
): boolean {
  const dispatch = findMatchingDispatch(dispatches, context);
  if (!dispatch) return false;

  const status = String(dispatch["status"] ?? "").toUpperCase();
  if (!APPROVED_DISPATCH_STATUSES.has(status)) return false;

  const storesConfirmation = dispatch["storesConfirmation"] as
    { issuedBy?: string; dateIssued?: string; storesSignature?: string } | undefined;
  if (storesConfirmation) {
    if (
      !storesConfirmation.issuedBy?.trim() ||
      !storesConfirmation.dateIssued?.trim() ||
      !storesConfirmation.storesSignature?.trim()
    ) {
      return false;
    }
  }

  const acknowledgements = dispatch["acknowledgements"] as
    { authorizedPersonSignature?: string; accountsAcknowledgement?: string } | undefined;
  if (acknowledgements) {
    if (
      !acknowledgements.authorizedPersonSignature?.trim() ||
      !acknowledgements.accountsAcknowledgement?.trim()
    ) {
      return false;
    }
  }

  return true;
}

export function areStage7DepartmentsComplete(job: JobCard | undefined): boolean {
  if (!job) return false;
  if (job.departmentProgress && job.departmentProgress.length > 0) {
    return job.departmentProgress.every((item) => item.status === "Completed");
  }
  const normalized = job.status.trim().toLowerCase();
  return normalized === "completed" || normalized === "complete";
}

export type StagnationSummary = {
  hoursInDepartment: number;
  isOverdue: boolean;
  isWaitingForParts: boolean;
  awaitingSupervisorAttention: boolean;
  alerts: string[];
};

export function calculateStagnationSummary(
  job: JobCard | undefined,
  nowMs = Date.now(),
): StagnationSummary {
  if (!job) {
    return {
      hoursInDepartment: 0,
      isOverdue: false,
      isWaitingForParts: false,
      awaitingSupervisorAttention: false,
      alerts: [],
    };
  }

  const enteredAt =
    job.stagnationMeta?.departmentEnteredAtMs ??
    job.departmentProgress?.reduce(
      (min, item) => (item.updatedAtMs && item.updatedAtMs < min ? item.updatedAtMs : min),
      nowMs,
    ) ??
    nowMs;

  const hoursInDepartment = Math.max(0, Math.round(((nowMs - enteredAt) / 3_600_000) * 10) / 10);
  const allCompleted = areStage7DepartmentsComplete(job);

  let isOverdue = false;
  if (!allCompleted && job.due?.trim()) {
    const dueMs = Date.parse(
      job.due.trim().length === 10 ? `${job.due.trim()}T23:59:59` : job.due.trim(),
    );
    if (!Number.isNaN(dueMs) && nowMs > dueMs) {
      isOverdue = true;
    }
  }

  const progressList: readonly DepartmentProgressItem[] = job.departmentProgress ?? [];
  const isWaitingForParts =
    progressList.some((p) => p.status === "Waiting for Parts") ||
    job.status.trim().toLowerCase() === "awaiting parts";

  const hasOnHold = progressList.some((p) => p.status === "On Hold");
  const awaitingSupervisorAttention =
    Boolean(job.stagnationMeta?.awaitingSupervisorAttention) ||
    hasOnHold ||
    (!allCompleted && hoursInDepartment >= 24);

  const alerts: string[] = [];
  if (isOverdue) alerts.push("Exceeded expected completion date");
  if (isWaitingForParts) alerts.push("Department work waiting for parts");
  if (awaitingSupervisorAttention) alerts.push("Awaiting supervisor attention");
  if (!allCompleted && hoursInDepartment >= 24) {
    alerts.push(`In department for ${hoursInDepartment}h`);
  }

  return {
    hoursInDepartment,
    isOverdue,
    isWaitingForParts,
    awaitingSupervisorAttention,
    alerts,
  };
}

export type StageReadinessEntry = {
  stageNumber: 1 | 2 | 3 | 4 | 5 | 6 | 7;
  label: string;
  complete: boolean;
  status: "completed" | "in_progress" | "locked";
  missing: string[];
};

export type JobStageReadinessReport = {
  stages: Record<1 | 2 | 3 | 4 | 5 | 6 | 7, StageReadinessEntry>;
  stages1To6Complete: boolean;
  maxUnlockedStageIndex: 0 | 1 | 2 | 3 | 4 | 5 | 6;
  canSubmitFinalInspection: boolean;
  blockingReasons: string[];
};

export function evaluateJobStageReadiness(input: {
  vehicle: Vehicle | undefined;
  quotation: Quotation | undefined;
  job: JobCard | undefined;
  requisitions: readonly Requisition[];
  dispatches: readonly Record<string, unknown>[];
  foremanVerified?: boolean;
  workCompletedSummary?: string;
  completionDate?: string;
  nowMs?: number;
}): JobStageReadinessReport {
  const { vehicle, quotation, job, requisitions, dispatches } = input;
  const vehicleId = vehicle?.id ?? job?.vehicleId ?? quotation?.vehicleId ?? "";

  const s1Complete = isStage1IntakeComplete(vehicle);
  const s1Missing: string[] = [];
  if (!vehicle) s1Missing.push("Stage 1 Intake vehicle record is missing");
  else if (!s1Complete)
    s1Missing.push("Stage 1 Intake mandatory fields & customer authorization incomplete");

  const s2Complete = s1Complete && isStage2QuotationComplete(quotation);
  const s2Missing: string[] = [];
  if (!quotation) s2Missing.push("Stage 2 Quotation record is missing");
  else if (!isStage2QuotationComplete(quotation)) {
    s2Missing.push("Stage 2 Quotation must be generated & issued with valid items");
  }

  const s3Complete = s2Complete && isStage3AuthorizationComplete(quotation);
  const s3Missing: string[] = [];
  if (!quotation || quotation.status !== "Approved") {
    s3Missing.push("Stage 3 Customer Authorization & Approved status required");
  } else if (!isStage3AuthorizationComplete(quotation)) {
    s3Missing.push("Stage 3 Workshop terms, 50% deposit & customer signature required");
  }

  const s4Complete = s3Complete && isStage4JobCardComplete(job);
  const s4Missing: string[] = [];
  if (!job) s4Missing.push("Stage 4 Job Card record is missing");
  else if (!isStage4JobCardComplete(job)) {
    s4Missing.push("Stage 4 Job Card instructions, department routing & due date required");
  }

  const s5Complete =
    s4Complete && Boolean(vehicleId) && isStage5PartsComplete(requisitions, vehicleId);
  const s5Missing: string[] = [];
  const matchingReqs = vehicleId ? requisitions.filter((r) => r.vehicleId === vehicleId) : [];
  if (matchingReqs.length === 0) {
    s5Missing.push("Stage 5 Parts Availability & Requisition record is missing");
  } else if (!isStage5PartsComplete(requisitions, vehicleId)) {
    s5Missing.push("Stage 5 Parts availability must be verified & resolved before dispatch");
  }

  const s6Complete =
    s5Complete && Boolean(vehicleId) && isStage6DispatchComplete(dispatches, { vehicleId, job });
  const s6Missing: string[] = [];
  const dispatch = vehicleId ? findMatchingDispatch(dispatches, { vehicleId, job }) : undefined;
  if (!dispatch) {
    s6Missing.push("Stage 6 Dispatch Order record is missing");
  } else if (!isStage6DispatchComplete(dispatches, { vehicleId, job })) {
    s6Missing.push("Stage 6 Dispatch Order must be Manager Approved & confirmed by Stores");
  }

  const stages1To6Complete =
    s1Complete && s2Complete && s3Complete && s4Complete && s5Complete && s6Complete;

  const deptDone = areStage7DepartmentsComplete(job);
  const foremanVerified = input.foremanVerified ?? Boolean(job?.stagnationMeta?.foremanVerified);
  const workSummary = (
    input.workCompletedSummary ??
    job?.stagnationMeta?.workCompletedSummary ??
    ""
  ).trim();
  const completionDate = (input.completionDate ?? job?.stagnationMeta?.completionDate ?? "").trim();

  const s7Missing: string[] = [];
  if (!deptDone) s7Missing.push("All routed department statuses must be Completed");
  if (!workSummary) s7Missing.push("Work completed summary is required");
  if (!completionDate) s7Missing.push("Completion date is required");
  if (!foremanVerified) s7Missing.push("Foreman verification sign-off is required");

  const s7Complete = stages1To6Complete && s7Missing.length === 0;

  let maxUnlockedStageIndex: 0 | 1 | 2 | 3 | 4 | 5 | 6 = 0;
  if (s1Complete) maxUnlockedStageIndex = 1;
  if (s1Complete && s2Complete) maxUnlockedStageIndex = 2;
  if (s1Complete && s2Complete && s3Complete) maxUnlockedStageIndex = 3;
  if (s1Complete && s2Complete && s3Complete && s4Complete) maxUnlockedStageIndex = 4;
  if (s1Complete && s2Complete && s3Complete && s4Complete && s5Complete) maxUnlockedStageIndex = 5;
  if (stages1To6Complete) maxUnlockedStageIndex = 6;

  const statusFor = (
    stageNum: number,
    complete: boolean,
    prevComplete: boolean,
  ): "completed" | "in_progress" | "locked" => {
    if (complete) return "completed";
    if (stageNum === 1 || prevComplete) return "in_progress";
    return "locked";
  };

  const stages: Record<1 | 2 | 3 | 4 | 5 | 6 | 7, StageReadinessEntry> = {
    1: {
      stageNumber: 1,
      label: "Intake & Inspection",
      complete: s1Complete,
      status: statusFor(1, s1Complete, true),
      missing: s1Missing,
    },
    2: {
      stageNumber: 2,
      label: "Itemized Quotation",
      complete: s2Complete,
      status: statusFor(2, s2Complete, s1Complete),
      missing: s2Missing,
    },
    3: {
      stageNumber: 3,
      label: "Customer Authorization",
      complete: s3Complete,
      status: statusFor(3, s3Complete, s2Complete),
      missing: s3Missing,
    },
    4: {
      stageNumber: 4,
      label: "Job Card & Routing",
      complete: s4Complete,
      status: statusFor(4, s4Complete, s3Complete),
      missing: s4Missing,
    },
    5: {
      stageNumber: 5,
      label: "Parts Availability",
      complete: s5Complete,
      status: statusFor(5, s5Complete, s4Complete),
      missing: s5Missing,
    },
    6: {
      stageNumber: 6,
      label: "Dispatch & Approval",
      complete: s6Complete,
      status: statusFor(6, s6Complete, s5Complete),
      missing: s6Missing,
    },
    7: {
      stageNumber: 7,
      label: "Department Work & Final Sign-off",
      complete: s7Complete,
      status: statusFor(7, s7Complete, stages1To6Complete),
      missing: s7Missing,
    },
  };

  const blockingReasons = [
    ...s1Missing,
    ...s2Missing,
    ...s3Missing,
    ...s4Missing,
    ...s5Missing,
    ...s6Missing,
    ...s7Missing,
  ];

  return {
    stages,
    stages1To6Complete,
    maxUnlockedStageIndex,
    canSubmitFinalInspection: stages1To6Complete && s7Complete,
    blockingReasons,
  };
}

export function calculateJobCompletionPercentage(input: {
  vehicle?: Vehicle;
  quotation?: Quotation;
  job?: JobCard;
  requisitions?: readonly Requisition[];
  dispatches?: readonly Record<string, unknown>[];
  inspection?: Inspection;
  readiness?: JobStageReadinessReport;
}): number {
  const { vehicle, quotation, job, requisitions = [], dispatches = [], inspection } = input;
  const readiness =
    input.readiness ??
    evaluateJobStageReadiness({
      vehicle,
      quotation,
      job,
      requisitions,
      dispatches,
    });

  const completedStageCount =
    Object.values(readiness.stages).filter((s) => s.complete).length +
    (isFinalInspectionAndReleaseComplete({ vehicle, inspection }) ? 1 : 0);

  return Math.min(100, Math.max(0, Math.round((completedStageCount / 8) * 100)));
}

export type WorkshopQueueFilter = "all" | "quote_auth" | "in_bay" | "stagnated" | "final_release";

export function isFinalInspectionAndReleaseComplete(input: {
  vehicle?: Vehicle;
  inspection?: Inspection;
}): boolean {
  const { vehicle, inspection } = input;
  if (!vehicle || !inspection) return false;
  if (inspection.result !== "Passed") return false;
  if (!vehicle.released) return false;
  const details = vehicle.intakeDetails;
  if (!details) return true;
  return (
    Number.isFinite(details.mileageOut) &&
    Number(details.mileageOut) >= 0 &&
    Boolean(details.fuelLevelOut) &&
    Boolean(details.collectedBy?.trim()) &&
    Boolean(details.releasedBy?.trim())
  );
}

export type QueueDepartmentBadge = {
  label: string;
  department: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
};

export function deriveQueueDepartmentBadge(input: {
  vehicle: Vehicle;
  readiness: JobStageReadinessReport;
  job?: JobCard;
  inspection?: Inspection;
  nowMs?: number;
}): QueueDepartmentBadge {
  const { vehicle, readiness, job, inspection, nowMs } = input;
  const isReleased = isFinalInspectionAndReleaseComplete({ vehicle, inspection });
  if (isReleased) {
    return {
      label: "Released",
      department: "Completed",
      bgClass: "bg-emerald-50",
      textClass: "text-emerald-700",
      borderClass: "border-emerald-200",
    };
  }

  if (Boolean(inspection) || readiness.canSubmitFinalInspection) {
    return {
      label: "In Inspection",
      department: "Final Inspection",
      bgClass: "bg-purple-50",
      textClass: "text-purple-700",
      borderClass: "border-purple-200",
    };
  }

  const stagnation = calculateStagnationSummary(job, nowMs);
  if (
    stagnation.isWaitingForParts ||
    (readiness.maxUnlockedStageIndex === 4 && !readiness.stages[5].complete)
  ) {
    return {
      label: "Parts Awaiting",
      department: "Stores",
      bgClass: "bg-amber-50",
      textClass: "text-amber-800",
      borderClass: "border-amber-200",
    };
  }

  if (readiness.maxUnlockedStageIndex === 5 && !readiness.stages[6].complete) {
    return {
      label: "Dispatch",
      department: "Stores / Dispatch",
      bgClass: "bg-sky-50",
      textClass: "text-sky-700",
      borderClass: "border-sky-200",
    };
  }

  if (readiness.maxUnlockedStageIndex >= 3) {
    const rawDept =
      job?.routedDepartments?.[0] ||
      (job?.department && job.department !== "Unassigned" ? job.department : null) ||
      (vehicle.department && vehicle.department !== "Unassigned"
        ? vehicle.department
        : "Mechanical");

    const deptLower = rawDept.toLowerCase();
    if (deptLower.includes("panel")) {
      return {
        label: "Panel Beating",
        department: "Panel Beating",
        bgClass: "bg-orange-50",
        textClass: "text-orange-700",
        borderClass: "border-orange-200",
      };
    }
    if (deptLower.includes("paint")) {
      return {
        label: "Painting",
        department: "Painting",
        bgClass: "bg-teal-50",
        textClass: "text-teal-700",
        borderClass: "border-teal-200",
      };
    }
    if (deptLower.includes("fit")) {
      return {
        label: "Fitting",
        department: "Fitting",
        bgClass: "bg-violet-50",
        textClass: "text-violet-700",
        borderClass: "border-violet-200",
      };
    }
    if (deptLower.includes("sand")) {
      return {
        label: "Sanding",
        department: "Sanding",
        bgClass: "bg-stone-50",
        textClass: "text-stone-700",
        borderClass: "border-stone-200",
      };
    }
    return {
      label: rawDept || "Mechanical",
      department: rawDept || "Mechanical",
      bgClass: "bg-blue-50",
      textClass: "text-blue-700",
      borderClass: "border-blue-200",
    };
  }

  if (readiness.maxUnlockedStageIndex === 2) {
    return {
      label: "Authorization",
      department: "Accounts / Sales",
      bgClass: "bg-amber-50",
      textClass: "text-amber-700",
      borderClass: "border-amber-200",
    };
  }

  if (readiness.maxUnlockedStageIndex === 1) {
    return {
      label: "Quotation",
      department: "Sales",
      bgClass: "bg-slate-100",
      textClass: "text-slate-700",
      borderClass: "border-slate-200",
    };
  }

  return {
    label: "Intake",
    department: "Reception",
    bgClass: "bg-slate-100",
    textClass: "text-slate-700",
    borderClass: "border-slate-200",
  };
}

export function classifyWorkshopQueueItem(input: {
  vehicle: Vehicle;
  readiness: JobStageReadinessReport;
  job?: JobCard;
  inspection?: Inspection;
  nowMs?: number;
}): {
  bucket: Exclude<WorkshopQueueFilter, "all">;
  badgeLabel: string;
  isStagnated: boolean;
  isReleased: boolean;
  departmentBadge: QueueDepartmentBadge;
} {
  const { vehicle, readiness, job, inspection, nowMs } = input;
  const departmentBadge = deriveQueueDepartmentBadge(input);
  const isReleased = isFinalInspectionAndReleaseComplete({ vehicle, inspection });
  if (isReleased || Boolean(inspection)) {
    return {
      bucket: "final_release",
      badgeLabel: isReleased ? "Released" : "Final Inspection",
      isStagnated: false,
      isReleased,
      departmentBadge,
    };
  }
  const stagnation = calculateStagnationSummary(job, nowMs);
  const isStagnated =
    stagnation.isOverdue || stagnation.isWaitingForParts || stagnation.awaitingSupervisorAttention;
  if (isStagnated) {
    return {
      bucket: "stagnated",
      badgeLabel: "Attention Needed",
      isStagnated: true,
      isReleased: false,
      departmentBadge,
    };
  }
  if (readiness.maxUnlockedStageIndex >= 3) {
    return {
      bucket: "in_bay",
      badgeLabel: `Stage ${readiness.maxUnlockedStageIndex + 1}`,
      isStagnated: false,
      isReleased: false,
      departmentBadge,
    };
  }
  return {
    bucket: "quote_auth",
    badgeLabel: `Stage ${readiness.maxUnlockedStageIndex + 1}`,
    isStagnated: false,
    isReleased: false,
    departmentBadge,
  };
}

export function matchesWorkshopQueueSearch(
  vehicle: Pick<Vehicle, "plate" | "make" | "model" | "customer" | "intakeDetails">,
  query: string,
): boolean {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return true;

  const compactQuery = normalized.replace(/\s+/g, "");
  const plateRaw = (vehicle.plate ?? "").toLowerCase();
  const plateCompact = plateRaw.replace(/\s+/g, "");
  const make = (vehicle.make ?? "").toLowerCase();
  const model = (vehicle.model ?? vehicle.intakeDetails?.model ?? "").toLowerCase();
  const customer = (vehicle.customer ?? "").toLowerCase();

  return (
    plateRaw.includes(normalized) ||
    (compactQuery.length > 0 && plateCompact.includes(compactQuery)) ||
    make.includes(normalized) ||
    model.includes(normalized) ||
    customer.includes(normalized)
  );
}

export function filterWorkshopQueueItems<
  T extends { vehicle: Vehicle; bucket: Exclude<WorkshopQueueFilter, "all"> },
>(items: readonly T[], filter: WorkshopQueueFilter, searchQuery: string): T[] {
  return items.filter((item) => {
    const matchesBucket = filter === "all" || item.bucket === filter;
    if (!matchesBucket) return false;
    return matchesWorkshopQueueSearch(item.vehicle, searchQuery);
  });
}
