import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight, Car, RotateCcw, Search } from "./fa-icons";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useWorkspace } from "./workspace-context";
import {
  DataTable,
  EmptyState,
  SectionHeading,
  Status,
  TableFooter,
  ToolbarSearch,
  VehicleCell,
} from "./shared";
import { VehicleDetail } from "./vehicle-detail";
import { Stage1IntakeForm } from "./stages/stage-1-intake-form";
import {
  filterVehicles,
  getVehicleStatusCategory,
  nextSortState,
  sortRecords,
  vehicleRegistrationStatuses,
  workflowStages,
  type SortState,
  type VehicleRegistrationStatusFilter,
} from "@/lib/workshop";

export function IntakePage() {
  const { vehicles, loading } = useWorkspace();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<VehicleRegistrationStatusFilter>("All");
  const [sort, setSort] = useState<SortState>(null);
  const [detailId, setDetailId] = useState<string | null>(null);

  const filteredVehicles = sortRecords(
    filterVehicles(vehicles, { query, status: statusFilter }),
    sort,
    (v, key) => {
      switch (key) {
        case "vehicle":
          return `${v.make} ${v.id}`;
        case "vin":
          return v.vin ?? "";
        case "plate":
          return v.plate;
        case "customer":
          return v.customer;
        case "received":
          return v.received;
        case "status":
          return getVehicleStatusCategory(v);
        case "stage":
          return v.released ? 999 : v.stage;
        default:
          return "";
      }
    },
  );

  return (
    <>
      <div className="mb-8">
        <Stage1IntakeForm
          bannerExtra={
            <Button
              type="button"
              variant="secondary"
              size="sm"
              className="bg-white text-blue-900 hover:bg-blue-50 font-semibold"
              onClick={() => navigate({ to: "/vehicles" })}
            >
              Vehicle records
              <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          }
          onSaved={(_saved, advance) => {
            if (advance) {
              void navigate({ to: "/" });
            }
          }}
        />
      </div>

      <section className="table-section">
        <SectionHeading
          title="Registered Vehicles"
          subtitle="Filter registered vehicles by VIN, license plate, or owner name in real time"
        />
        <div className="toolbar">
          <ToolbarSearch
            ariaLabel="Search registered vehicles by VIN, license plate, or owner name"
            placeholder="Search by VIN, license plate, or owner name..."
            value={query}
            onChange={setQuery}
          />
          <Select
            value={statusFilter}
            onValueChange={(value) => setStatusFilter(value as VehicleRegistrationStatusFilter)}
          >
            <SelectTrigger
              className="w-[200px] h-[38px] rounded-[6px] border-[#d1d5db] bg-background text-sm font-normal shadow-none"
              aria-label="Filter vehicle status"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {vehicleRegistrationStatuses.map((status) => (
                <SelectItem key={status} value={status}>
                  {status === "All" ? "All statuses" : status}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <DataTable
          headers={[
            { label: "Vehicle", sortKey: "vehicle" },
            { label: "VIN", sortKey: "vin" },
            { label: "License plate", sortKey: "plate" },
            { label: "Owner", sortKey: "customer" },
            { label: "Received", sortKey: "received" },
            { label: "Status", sortKey: "status" },
            { label: "Current stage", sortKey: "stage" },
            "Actions",
          ]}
          loading={loading}
          sort={sort}
          onSort={(key) => setSort((current) => nextSortState(current, key))}
          empty={filteredVehicles.length === 0}
          emptyState={
            query.trim() || statusFilter !== "All" ? (
              <EmptyState
                icon={Search}
                tone="muted"
                title="No matching registered vehicles"
                description="No registered vehicles match the selected status or search criteria."
                action={
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setQuery("");
                      setStatusFilter("All");
                    }}
                  >
                    <RotateCcw />
                    Clear filters
                  </Button>
                }
              />
            ) : (
              <EmptyState
                icon={Car}
                tone="muted"
                title="No vehicles registered yet"
                description="Submit the vehicle registration form above to add a vehicle to the workshop listing."
              />
            )
          }
        >
          {filteredVehicles.map((v) => (
            <tr key={v.id}>
              <td>
                <VehicleCell vehicle={v} />
              </td>
              <td>
                <span className="font-mono text-xs">{v.vin || "—"}</span>
              </td>
              <td>{v.plate}</td>
              <td>{v.customer}</td>
              <td>{v.received}</td>
              <td>
                <Status>{getVehicleStatusCategory(v)}</Status>
              </td>
              <td>
                <Status>{v.released ? "Released" : (workflowStages[v.stage] ?? "Intake")}</Status>
              </td>
              <td>
                <Button
                  variant="ghost"
                  size="icon"
                  title={`View ${v.plate}`}
                  aria-label={`View ${v.plate}`}
                  onClick={() => setDetailId(v.id)}
                >
                  <ArrowUpRight />
                </Button>
              </td>
            </tr>
          ))}
        </DataTable>
        <TableFooter count={filteredVehicles.length} label="vehicles" />
      </section>

      <VehicleDetail id={detailId} onClose={() => setDetailId(null)} />
    </>
  );
}
