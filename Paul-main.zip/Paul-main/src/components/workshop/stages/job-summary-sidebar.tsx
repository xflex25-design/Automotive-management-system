import { CheckCircle2, ClipboardCheck, Clock, Lock, ShieldCheck } from "../fa-icons";
import {
  money,
  type Inspection,
  type JobCard,
  type Quotation,
  type Requisition,
  type Vehicle,
} from "@/lib/workshop";
import {
  calculateQuotationTotals,
  calculateStagnationSummary,
  isFinalInspectionAndReleaseComplete,
  WORKSHOP_FLOW_STAGES,
  type JobStageReadinessReport,
} from "@/lib/workshop-flow";

type JobSummarySidebarProps = {
  creatingNew: boolean;
  activeStageIndex: number;
  vehicle?: Vehicle;
  quotation?: Quotation;
  job?: JobCard;
  requisition?: Requisition;
  inspection?: Inspection;
  readiness: JobStageReadinessReport;
  onJumpToStage?: (stageIndex: number) => void;
};

export function JobSummarySidebar({
  creatingNew,
  activeStageIndex,
  vehicle,
  quotation,
  job,
  requisition,
  inspection,
  readiness,
  onJumpToStage,
}: JobSummarySidebarProps) {
  const currentStageMeta =
    activeStageIndex === 7
      ? {
          stageNumber: 8,
          shortLabel: "Final Release",
          title: "Final Inspection & Release",
        }
      : (WORKSHOP_FLOW_STAGES[activeStageIndex] ?? WORKSHOP_FLOW_STAGES[0]!);

  const completedCount =
    Object.values(readiness.stages).filter((s) => s.complete).length +
    (isFinalInspectionAndReleaseComplete({ vehicle, inspection }) ? 1 : 0);

  const quoteTotals = quotation?.items?.length
    ? calculateQuotationTotals(quotation.items)
    : quotation
      ? {
          subtotal: quotation.subtotal ?? Math.round((quotation.amount / 1.16) * 100) / 100,
          vat:
            quotation.taxAmount ??
            Math.round((quotation.amount - quotation.amount / 1.16) * 100) / 100,
          total: quotation.amount,
          requiredDeposit: Math.round(quotation.amount * 0.5 * 100) / 100,
        }
      : null;

  const depositPaid = quotation?.authorization?.depositAmount ?? 0;
  const isPaidApproved = quotation?.status === "Approved";
  const stagnation = calculateStagnationSummary(job);

  const nextMissingReasons = readiness.blockingReasons.slice(0, 3);

  return (
    <aside className="workshop-summary-card" aria-label="Live Job Summary">
      <div className="workshop-summary-header">
        <h3>Job Summary</h3>
        <span className="text-xs font-medium text-muted-foreground tabular-nums">
          Step {currentStageMeta.stageNumber} of 8
        </span>
      </div>

      {/* Vehicle & Customer Snapshot */}
      <div className="py-3.5 border-b border-border space-y-1.5 text-sm">
        <div className="flex items-center justify-between gap-2">
          <span className="font-semibold text-foreground">
            {creatingNew || !vehicle ? "New Vehicle Intake" : `${vehicle.plate} · ${vehicle.make}`}
          </span>
          {vehicle && !creatingNew && (
            <span className="text-xs font-mono text-muted-foreground">{vehicle.id}</span>
          )}
        </div>
        <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>
            {creatingNew || !vehicle
              ? "Fill customer & vehicle fields to open job"
              : `${vehicle.customer}${vehicle.phone ? ` · ${vehicle.phone}` : ""}`}
          </span>
        </div>
      </div>

      {/* Financial & Operational Breakdown */}
      <div className="py-3.5 border-b border-border space-y-2.5 text-xs">
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Current Stage</span>
          <span className="font-semibold text-foreground">{currentStageMeta.shortLabel}</span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Stages Completed</span>
          <span className="font-semibold tabular-nums text-foreground">{completedCount} of 8</span>
        </div>

        {job && (
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Assigned Bay / Lead</span>
            <span className="font-medium text-foreground">
              {job.routedDepartments?.join(", ") || job.department}
            </span>
          </div>
        )}

        {requisition?.partsCheck && (
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Parts Readiness</span>
            <span
              className={`font-semibold ${
                requisition.partsCheck.stockSummaryStatus === "Available"
                  ? "text-emerald-700"
                  : "text-amber-700"
              }`}
            >
              {requisition.partsCheck.stockSummaryStatus}
            </span>
          </div>
        )}
      </div>

      {/* Financial Summary when Quote exists */}
      {quoteTotals ? (
        <div className="py-3.5 border-b border-border space-y-2 text-xs tabular-nums">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">
              Quoted Items ({quotation?.items?.length ?? 1})
            </span>
            <span className="font-medium text-foreground">{money(quoteTotals.subtotal)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">VAT (16%)</span>
            <span className="font-medium text-foreground">{money(quoteTotals.vat)}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Required 50% Deposit</span>
            <span
              className={`font-semibold ${isPaidApproved ? "text-emerald-700" : "text-amber-700"}`}
            >
              {isPaidApproved && depositPaid > 0
                ? `${money(depositPaid)} Paid`
                : money(quoteTotals.requiredDeposit)}
            </span>
          </div>
          <div className="pt-2 border-t border-border flex items-center justify-between text-sm font-bold text-foreground">
            <span>Quotation Total</span>
            <span>{money(quoteTotals.total)}</span>
          </div>
        </div>
      ) : (
        <div className="py-3.5 border-b border-border text-xs text-muted-foreground">
          Quotation subtotal, VAT (16%), and 50% deposit appear here automatically at Stage 2.
        </div>
      )}

      {/* Stage 1-6 Gate Progress Checklist */}
      <div className="py-3.5 space-y-2">
        <div className="text-xs font-semibold text-foreground flex items-center justify-between">
          <span>Workflow Gate Progress</span>
          <span className="text-[11px] font-medium text-muted-foreground">
            {readiness.stages1To6Complete ? "Stages 1–6 Ready" : "Linear Gate"}
          </span>
        </div>
        <div className="space-y-1.5">
          {WORKSHOP_FLOW_STAGES.map((stage) => {
            const entry = readiness.stages[stage.stageNumber];
            const isUnlocked = creatingNew
              ? stage.index === 0
              : stage.index <= readiness.maxUnlockedStageIndex;
            const isCurrent = activeStageIndex === stage.index;
            return (
              <button
                key={stage.key}
                type="button"
                disabled={!isUnlocked || !onJumpToStage}
                onClick={() => isUnlocked && onJumpToStage?.(stage.index)}
                className={`w-full flex items-center justify-between rounded-md px-2.5 py-1.5 text-xs transition-colors text-left ${
                  isCurrent
                    ? "bg-accent text-primary font-semibold"
                    : entry.complete
                      ? "text-foreground hover:bg-muted/50"
                      : isUnlocked
                        ? "text-foreground hover:bg-muted/50"
                        : "text-muted-foreground opacity-60 cursor-not-allowed"
                }`}
              >
                <span className="flex items-center gap-2 min-w-0 truncate">
                  {entry.complete ? (
                    <CheckCircle2 size={13} className="text-emerald-600 shrink-0" />
                  ) : isUnlocked ? (
                    <Clock size={13} className="text-primary shrink-0" />
                  ) : (
                    <Lock size={12} className="text-muted-foreground shrink-0" />
                  )}
                  <span className="truncate">
                    {stage.stageNumber}. {stage.shortLabel}
                  </span>
                </span>
                <span className="text-[11px] shrink-0 ml-2">
                  {entry.complete ? "Done" : isCurrent ? "Active" : isUnlocked ? "Open" : "Locked"}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Attention / Next Action Hint */}
      {!creatingNew && (stagnation.alerts.length > 0 || nextMissingReasons.length > 0) && (
        <div className="mt-1 pt-3 border-t border-border space-y-1.5 text-xs">
          <div className="flex items-center gap-1.5 font-semibold text-foreground">
            <ShieldCheck size={14} className="text-primary shrink-0" />
            <span>Next Required Action</span>
          </div>
          {stagnation.alerts.map((alert) => (
            <p key={alert} className="text-amber-700 leading-snug">
              · {alert}
            </p>
          ))}
          {nextMissingReasons.slice(0, 2).map((reason) => (
            <p key={reason} className="text-muted-foreground leading-snug">
              · {reason}
            </p>
          ))}
        </div>
      )}

      {vehicle?.released && inspection?.result === "Passed" && (
        <div className="mt-3 pt-3 border-t border-border flex items-center gap-2 text-xs font-semibold text-emerald-700">
          <ClipboardCheck size={15} className="shrink-0" />
          <span>Vehicle passed QA and was released.</span>
        </div>
      )}
    </aside>
  );
}
