import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, CheckCircle2, Lock } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import type { Inspection, IntakeDetails, JobCard, Vehicle } from "@/lib/workshop";
import type { JobStageReadinessReport } from "@/lib/workshop-flow";

type Stage8FinalReleaseFormProps = {
  vehicle: Vehicle;
  job?: JobCard;
  inspection?: Inspection;
  readiness: JobStageReadinessReport;
  bannerExtra?: ReactNode;
  onBack?: () => void;
  onSendToRework?: () => void;
};

const FUEL_LEVELS = ["Empty", "1/4", "1/2", "3/4", "Full"] as const;

export function Stage8FinalReleaseForm({
  vehicle,
  job,
  inspection,
  readiness,
  onBack,
  onSendToRework,
}: Stage8FinalReleaseFormProps) {
  const { setInspections, setVehicles, setJobs, setHandovers, foreman, addActivity } =
    useWorkspace();

  const todayIso = new Date().toISOString().slice(0, 10);
  const nowTime = new Date().toTimeString().slice(0, 5);

  const [qaResult, setQaResult] = useState<Inspection["result"]>(
    inspection?.result === "Passed" || inspection?.result === "Rework required"
      ? inspection.result
      : "Passed",
  );
  const [qaNotes, setQaNotes] = useState(
    inspection?.notes ??
      job?.stagnationMeta?.workCompletedSummary ??
      "Road test & final quality check completed.",
  );
  const [inspectorName, setInspectorName] = useState(inspection?.foreman ?? foreman);
  const [inspectionDate, setInspectionDate] = useState(inspection?.date ?? todayIso);

  const [fuelLevelOut, setFuelLevelOut] = useState<IntakeDetails["fuelLevelOut"]>(
    vehicle.intakeDetails?.fuelLevelOut || vehicle.intakeDetails?.fuelLevelIn || "Full",
  );
  const [mileageOut, setMileageOut] = useState(
    vehicle.intakeDetails?.mileageOut !== undefined
      ? String(vehicle.intakeDetails.mileageOut)
      : vehicle.intakeDetails?.mileageIn !== undefined
        ? String(vehicle.intakeDetails.mileageIn)
        : vehicle.odometer !== undefined
          ? String(vehicle.odometer)
          : "",
  );

  const [collectedBy, setCollectedBy] = useState(
    vehicle.intakeDetails?.collectedBy || vehicle.customer || "",
  );
  const [collectedCustomerName, setCollectedCustomerName] = useState(
    vehicle.intakeDetails?.collectedCustomerName || vehicle.customer || "",
  );
  const [collectedPhone, setCollectedPhone] = useState(
    vehicle.intakeDetails?.collectedPhone || vehicle.phone || "",
  );
  const [timeOut, setTimeOut] = useState(vehicle.intakeDetails?.timeOut || nowTime);
  const [releasedBy, setReleasedBy] = useState(vehicle.intakeDetails?.releasedBy || foreman);
  const [releaseSignature, setReleaseSignature] = useState(
    vehicle.intakeDetails?.releaseSignature || vehicle.customer || "",
  );

  useEffect(() => {
    setQaResult(
      inspection?.result === "Passed" || inspection?.result === "Rework required"
        ? inspection.result
        : "Passed",
    );
    setQaNotes(
      inspection?.notes ??
        job?.stagnationMeta?.workCompletedSummary ??
        "Road test & final quality check completed.",
    );
    setInspectorName(inspection?.foreman ?? foreman);
    setInspectionDate(inspection?.date ?? todayIso);
    setFuelLevelOut(
      vehicle.intakeDetails?.fuelLevelOut || vehicle.intakeDetails?.fuelLevelIn || "Full",
    );
    setMileageOut(
      vehicle.intakeDetails?.mileageOut !== undefined
        ? String(vehicle.intakeDetails.mileageOut)
        : vehicle.intakeDetails?.mileageIn !== undefined
          ? String(vehicle.intakeDetails.mileageIn)
          : vehicle.odometer !== undefined
            ? String(vehicle.odometer)
            : "",
    );
    setCollectedBy(vehicle.intakeDetails?.collectedBy || vehicle.customer || "");
    setCollectedCustomerName(
      vehicle.intakeDetails?.collectedCustomerName || vehicle.customer || "",
    );
    setCollectedPhone(vehicle.intakeDetails?.collectedPhone || vehicle.phone || "");
    setTimeOut(vehicle.intakeDetails?.timeOut || nowTime);
    setReleasedBy(vehicle.intakeDetails?.releasedBy || foreman);
    setReleaseSignature(vehicle.intakeDetails?.releaseSignature || vehicle.customer || "");
  }, [vehicle, job, inspection, foreman, todayIso, nowTime]);

  const mileageIn = vehicle.intakeDetails?.mileageIn ?? vehicle.odometer ?? 0;
  const parsedMileageOut = Number(mileageOut || 0);
  const mileageTooLow = mileageOut.trim() !== "" && parsedMileageOut < mileageIn;

  const blockers: string[] = [];
  if (!readiness.stages1To6Complete) {
    blockers.push("Stages 1–6 must remain complete.");
  }
  if (!inspection) {
    blockers.push("Submit Stage 7 for Final Inspection first.");
  }
  if (qaResult === "Rework required") {
    blockers.push("Vehicle flagged for rework — return to Stage 7 before releasing.");
  }
  if (!mileageOut.trim() || Number.isNaN(parsedMileageOut) || mileageTooLow) {
    blockers.push(`Outgoing mileage must be >= incoming mileage (${mileageIn} km).`);
  }
  if (!fuelLevelOut) blockers.push("Select outgoing Fuel Level (OUT).");
  if (!collectedBy.trim()) blockers.push("Enter Collected By name.");
  if (!releasedBy.trim() || !releaseSignature.trim()) {
    blockers.push("Released By and Release Signature are required.");
  }

  const canRelease = blockers.length === 0 && qaResult === "Passed";

  function handleFlagRework() {
    if (!inspection) return;
    setInspections((prev) =>
      prev.map((ins) =>
        ins.id === inspection.id
          ? {
              ...ins,
              result: "Rework required",
              notes: qaNotes.trim() || "Returned from Final Inspection for rework",
              foreman: inspectorName.trim() || foreman,
              date: inspectionDate,
            }
          : ins,
      ),
    );
    if (job) {
      setJobs((prev) =>
        prev.map((item) =>
          item.id === job.id
            ? {
                ...item,
                status: "Rework required",
                stagnationMeta: {
                  ...item.stagnationMeta,
                  awaitingSupervisorAttention: true,
                },
              }
            : item,
        ),
      );
    }
    addActivity(
      `Final Inspection flagged rework (${inspection.id})`,
      `${vehicle.plate} returned to Stage 7`,
    );
    toast.error(`${vehicle.plate} flagged for rework. Returning to Stage 7.`);
    onSendToRework?.();
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (qaResult === "Rework required") {
      handleFlagRework();
      return;
    }
    if (!canRelease || !inspection) {
      toast.error(blockers[0] ?? "Complete final inspection & release details.");
      return;
    }

    setInspections((prev) =>
      prev.map((ins) =>
        ins.id === inspection.id
          ? {
              ...ins,
              result: "Passed",
              foreman: inspectorName.trim() || foreman,
              date: inspectionDate,
              notes: qaNotes.trim(),
            }
          : ins,
      ),
    );

    setVehicles((prev) =>
      prev.map((v) =>
        v.id === vehicle.id
          ? {
              ...v,
              released: true,
              progress: 100,
              stage: 6,
              intakeDetails: {
                ...(v.intakeDetails ?? {
                  customerType: "Individual",
                  customerAddress: "",
                  driverName: v.customer,
                  model: "",
                  year: "",
                  engineNumber: "",
                  mileageIn: v.odometer ?? 0,
                  fuelLevelIn: "Full",
                  accessories: [],
                  damageTypes: [],
                  additionalRemarks: "",
                  requestedRepairs: "",
                  additionalInstructions: "",
                  termsAccepted: true,
                  customerSignature: v.customer,
                  intakeOfficer: foreman,
                  authorizationDate: todayIso,
                  status: "completed",
                }),
                mileageOut: parsedMileageOut,
                fuelLevelOut,
                collectedBy: collectedBy.trim(),
                collectedCustomerName: collectedCustomerName.trim() || vehicle.customer,
                collectedPhone: collectedPhone.trim() || vehicle.phone,
                timeOut,
                releasedBy: releasedBy.trim(),
                releaseSignature: releaseSignature.trim(),
              },
            }
          : v,
      ),
    );

    setHandovers((prev) => {
      const nextEntry = {
        id: `HO-${vehicle.id}`,
        vehicleId: vehicle.id,
        jobId: job?.backendJobId ?? job?.id ?? vehicle.id,
        plate: vehicle.plate,
        customerName: collectedCustomerName.trim() || vehicle.customer,
        collectedBy: collectedBy.trim(),
        releasedBy: releasedBy.trim(),
        mileageOut: parsedMileageOut,
        fuelLevelOut,
        date: inspectionDate,
        timeOut,
      };
      const exists = prev.some((item) => String(item["vehicleId"] ?? "") === vehicle.id);
      return exists
        ? prev.map((item) => (String(item["vehicleId"] ?? "") === vehicle.id ? nextEntry : item))
        : [nextEntry, ...prev];
    });

    addActivity(
      `Final Inspection passed & vehicle released (${vehicle.plate})`,
      `${releasedBy.trim()} → Collected by ${collectedBy.trim()} (${parsedMileageOut} km)`,
    );
    toast.success(`${vehicle.plate} passed Final Inspection and has been released.`);
  }

  return (
    <form onSubmit={handleSubmit} className="stage-form-stack">
      {/* Card 1: Final Quality Inspection */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Final Quality Inspection</h3>
            <p className="stage-card-subtitle">
              Inspection {inspection?.id ?? "Pending Stage 7"} · {vehicle.plate}
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s8-qa-result">
                <span className="text-red-600">*</span> Inspection Decision
              </label>
              <Select
                value={qaResult}
                onValueChange={(value) => setQaResult(value as Inspection["result"])}
              >
                <SelectTrigger id="s8-qa-result" className="stage-select-trigger">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Passed">Passed — Ready for Release</SelectItem>
                  <SelectItem value="Rework required">
                    Rework Required — Return to Stage 7
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s8-inspector">
                Inspector / Foreman
              </label>
              <Input
                id="s8-inspector"
                className="stage-input"
                value={inspectorName}
                onChange={(e) => setInspectorName(e.target.value)}
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s8-date">
                Inspection Date
              </label>
              <Input
                id="s8-date"
                type="date"
                className="stage-input"
                value={inspectionDate}
                onChange={(e) => setInspectionDate(e.target.value)}
              />
            </div>
          </div>

          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s8-notes">
              Road-Test &amp; QA Notes
            </label>
            <Textarea
              id="s8-notes"
              className="stage-textarea"
              value={qaNotes}
              onChange={(e) => setQaNotes(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Card 2: Outgoing Fuel & Mileage */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Outgoing Fuel &amp; Mileage Check</h3>
            <p className="stage-card-subtitle">
              Incoming Fuel Level: <strong>{vehicle.intakeDetails?.fuelLevelIn ?? "Full"}</strong> ·
              Incoming Odometer: <strong className="tabular-nums">{mileageIn} km</strong>
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-end">
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s8-mileage-out">
              <span className="text-red-600">*</span> Mileage (OUT) km
            </label>
            <Input
              id="s8-mileage-out"
              type="number"
              min={mileageIn}
              className="stage-input tabular-nums"
              value={mileageOut}
              onChange={(e) => setMileageOut(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <span className="stage-field-label">
              <span className="text-red-600">*</span> Fuel Level (OUT)
            </span>
            <div className="flex flex-wrap items-center gap-3 min-h-[42px] px-3 rounded-md border border-slate-300 bg-white text-xs">
              {FUEL_LEVELS.map((lvl) => (
                <label key={lvl} className="flex items-center gap-1.5 cursor-pointer">
                  <input
                    type="radio"
                    name="s8_fuel_out"
                    checked={fuelLevelOut === lvl}
                    onChange={() => setFuelLevelOut(lvl)}
                    className="accent-primary"
                  />
                  <span className="font-medium text-slate-700">{lvl}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Card 3: Collection & Release Sign-Off */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Vehicle Collection &amp; Release Sign-Off</h3>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s8-collected-by">
              <span className="text-red-600">*</span> Collected By
            </label>
            <Input
              id="s8-collected-by"
              className="stage-input"
              value={collectedBy}
              onChange={(e) => setCollectedBy(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s8-collected-name">
              Customer Name
            </label>
            <Input
              id="s8-collected-name"
              className="stage-input"
              value={collectedCustomerName}
              onChange={(e) => setCollectedCustomerName(e.target.value)}
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s8-collected-phone">
              Phone Number
            </label>
            <Input
              id="s8-collected-phone"
              className="stage-input"
              value={collectedPhone}
              onChange={(e) => setCollectedPhone(e.target.value)}
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s8-time-out">
              Time Out
            </label>
            <Input
              id="s8-time-out"
              type="time"
              className="stage-input"
              value={timeOut}
              onChange={(e) => setTimeOut(e.target.value)}
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s8-released-by">
              <span className="text-red-600">*</span> Released By
            </label>
            <Input
              id="s8-released-by"
              className="stage-input"
              value={releasedBy}
              onChange={(e) => setReleasedBy(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s8-release-sig">
              <span className="text-red-600">*</span> Customer / Collector Signature
            </label>
            <Input
              id="s8-release-sig"
              className="stage-input"
              value={releaseSignature}
              onChange={(e) => setReleaseSignature(e.target.value)}
              required
            />
          </div>
        </div>

        <div className="flex items-start gap-2.5 text-xs text-slate-500 mt-4">
          <Lock size={14} className="text-slate-400 shrink-0 mt-0.5" />
          <p>
            Completing vehicle release creates a permanent handover record and marks the repair
            order complete.
          </p>
        </div>

        {vehicle.released && inspection?.result === "Passed" && (
          <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-900 flex items-center gap-2">
            <CheckCircle2 size={15} />
            <span>
              Vehicle <strong>{vehicle.plate}</strong> passed Final Inspection and has been released
              to <strong>{collectedBy}</strong>.
            </span>
          </div>
        )}

        {!canRelease && qaResult !== "Rework required" && blockers.length > 0 && (
          <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900 flex items-start gap-2">
            <AlertCircle size={15} className="shrink-0 mt-0.5" />
            <div>Remaining before release: {blockers.join(" · ")}</div>
          </div>
        )}
      </div>

      <div className="stage-cta-bar">
        <div>
          {onBack && (
            <Button type="button" variant="outline" onClick={onBack}>
              &larr; Back to Stage 7
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2.5 flex-wrap">
          {qaResult === "Rework required" ? (
            <Button type="button" variant="destructive" onClick={handleFlagRework}>
              Flag Rework &amp; Return to Stage 7
            </Button>
          ) : (
            <Button type="submit" disabled={!canRelease} className="stage-primary-cta">
              {vehicle.released ? "Update Release Sign-Off" : "Pass Inspection & Release Vehicle"}
            </Button>
          )}
        </div>
      </div>
    </form>
  );
}
