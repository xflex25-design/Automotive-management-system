import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertCircle,
  ArrowUpRight,
  Car,
  Check,
  CheckCircle2,
  ChevronDown,
  Copy,
  Lock,
  Mail,
  MoreVertical,
  Phone,
  Plus,
  Search,
  User,
  UserCheck,
  X,
} from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import type { Inspection, JobCard, Vehicle } from "@/lib/workshop";
import {
  classifyWorkshopQueueItem,
  evaluateJobStageReadiness,
  filterWorkshopQueueItems,
  isFinalInspectionAndReleaseComplete,
  matchesWorkshopQueueSearch,
  calculateJobCompletionPercentage,
  WORKSHOP_FLOW_STAGES,
  type WorkshopQueueFilter,
} from "@/lib/workshop-flow";
import { JobSummarySidebar } from "./job-summary-sidebar";
import { CircularProgressRing } from "./circular-progress-ring";
import { Stage1IntakeForm } from "./stage-1-intake-form";
import { Stage2QuotationForm } from "./stage-2-quotation-form";
import { Stage3AuthorizationForm } from "./stage-3-authorization-form";
import { Stage4JobCardForm } from "./stage-4-job-card-form";
import { Stage5PartsForm } from "./stage-5-parts-form";
import { Stage6DispatchForm } from "./stage-6-dispatch-form";
import { Stage7MonitorForm } from "./stage-7-monitor-form";
import { Stage8FinalReleaseForm } from "./stage-8-final-release-form";

const QUICK_TECHNICIANS = [
  "Lead Mechanic",
  "Peter Zulu",
  "Mechanic A",
  "Mechanic B",
  "Mechanic C",
  "John Banda",
] as const;

const QUEUE_FILTERS: Array<{ id: WorkshopQueueFilter; label: string }> = [
  { id: "all", label: "All Active" },
  { id: "quote_auth", label: "Intake / Quote" },
  { id: "in_bay", label: "In Workshop" },
  { id: "stagnated", label: "Attention Needed" },
  { id: "final_release", label: "Final Release" },
];

export function WorkshopStagesFlow() {
  const {
    vehicles,
    setVehicles,
    quotations,
    jobs,
    setJobs,
    requisitions,
    dispatches,
    inspections,
    setInspections,
    updateVehicleStage,
    addActivity,
    foreman,
  } = useWorkspace();

  const [creatingNew, setCreatingNew] = useState(vehicles.length === 0);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>(vehicles[0]?.id ?? "");
  const [activeStageIndex, setActiveStageIndex] = useState<number>(0);
  const [queueFilter, setQueueFilter] = useState<WorkshopQueueFilter>("all");
  const [queueSearch, setQueueSearch] = useState<string>("");
  const [queueExpanded, setQueueExpanded] = useState<boolean>(false);
  const [contactTarget, setContactTarget] = useState<Vehicle | null>(null);
  const [contactNote, setContactNote] = useState<string>("");
  const [assignTarget, setAssignTarget] = useState<(typeof queueItems)[number] | null>(null);
  const [customTechName, setCustomTechName] = useState<string>("");

  useEffect(() => {
    if (!creatingNew && !vehicles.some((v) => v.id === selectedVehicleId)) {
      if (vehicles.length > 0) {
        setSelectedVehicleId(vehicles[0]!.id);
      } else {
        setCreatingNew(true);
        setActiveStageIndex(0);
      }
    }
  }, [vehicles, selectedVehicleId, creatingNew]);

  const activeVehicle = creatingNew
    ? undefined
    : (vehicles.find((v) => v.id === selectedVehicleId) ?? vehicles[0]);

  const activeQuotation = activeVehicle
    ? quotations.find((q) => q.vehicleId === activeVehicle.id)
    : undefined;
  const activeJob = activeVehicle ? jobs.find((j) => j.vehicleId === activeVehicle.id) : undefined;
  const activeRequisition = activeVehicle
    ? requisitions.find((r) => r.vehicleId === activeVehicle.id)
    : undefined;
  const activeInspection = activeVehicle
    ? inspections.find((ins) => ins.vehicleId === activeVehicle.id)
    : undefined;

  const readiness = useMemo(
    () =>
      evaluateJobStageReadiness({
        vehicle: activeVehicle,
        quotation: activeQuotation,
        job: activeJob,
        requisitions,
        dispatches,
      }),
    [activeVehicle, activeQuotation, activeJob, requisitions, dispatches],
  );

  const stage8Unlocked = !creatingNew && readiness.stages1To6Complete && Boolean(activeInspection);
  const stage8Completed = isFinalInspectionAndReleaseComplete({
    vehicle: activeVehicle,
    inspection: activeInspection,
  });
  const maxAllowedStageIndex = stage8Unlocked ? 7 : readiness.maxUnlockedStageIndex;

  // Clamp activeStageIndex to the strict linear unlocked stage
  useEffect(() => {
    if (creatingNew) {
      if (activeStageIndex !== 0) setActiveStageIndex(0);
      return;
    }
    if (activeStageIndex > maxAllowedStageIndex) {
      setActiveStageIndex(maxAllowedStageIndex);
    }
  }, [creatingNew, activeStageIndex, maxAllowedStageIndex]);

  const queueItems = useMemo(() => {
    return vehicles.map((v) => {
      const q = quotations.find((item) => item.vehicleId === v.id);
      const j = jobs.find((item) => item.vehicleId === v.id);
      const ins = inspections.find((item) => item.vehicleId === v.id);
      const r = evaluateJobStageReadiness({
        vehicle: v,
        quotation: q,
        job: j,
        requisitions,
        dispatches,
      });
      const classification = classifyWorkshopQueueItem({
        vehicle: v,
        readiness: r,
        job: j,
        inspection: ins,
      });
      return {
        vehicle: v,
        job: j,
        inspection: ins,
        readiness: r,
        ...classification,
      };
    });
  }, [vehicles, quotations, jobs, inspections, requisitions, dispatches]);

  const searchMatchedQueueItems = useMemo(
    () => queueItems.filter((item) => matchesWorkshopQueueSearch(item.vehicle, queueSearch)),
    [queueItems, queueSearch],
  );

  const filteredQueueItems = useMemo(
    () => filterWorkshopQueueItems(queueItems, queueFilter, queueSearch),
    [queueItems, queueFilter, queueSearch],
  );

  function handleSelectVehicle(vehicleId: string) {
    setCreatingNew(false);
    setSelectedVehicleId(vehicleId);
    const v = vehicles.find((item) => item.id === vehicleId);
    if (v) {
      const q = quotations.find((item) => item.vehicleId === v.id);
      const j = jobs.find((item) => item.vehicleId === v.id);
      const ins = inspections.find((item) => item.vehicleId === v.id);
      const nextReadiness = evaluateJobStageReadiness({
        vehicle: v,
        quotation: q,
        job: j,
        requisitions,
        dispatches,
      });
      const nextMax =
        nextReadiness.stages1To6Complete && Boolean(ins) ? 7 : nextReadiness.maxUnlockedStageIndex;
      setActiveStageIndex(nextMax);
    }
  }

  function startNewIntake() {
    setCreatingNew(true);
    setSelectedVehicleId("");
    setActiveStageIndex(0);
  }

  function handleQuickMarkComplete(item: (typeof queueItems)[number]) {
    if (item.isReleased) {
      toast.info(`${item.vehicle.plate} is already marked complete and released.`);
      return;
    }
    if (!item.readiness.stages1To6Complete) {
      toast.error(
        `Complete Stages 1–6 before marking ${item.vehicle.plate} complete for Final Inspection.`,
      );
      return;
    }

    const todayIso = new Date().toISOString().slice(0, 10);
    if (!item.inspection && item.job) {
      const updatedProgress = (item.job.departmentProgress ?? []).map((entry) => ({
        ...entry,
        status: "Completed" as const,
        updatedAt: new Date().toISOString(),
        notes: entry.notes || "Completed via Quick Action",
      }));
      const summary =
        item.job.stagnationMeta?.workCompletedSummary?.trim() ||
        `All repairs completed for ${item.vehicle.plate}`;

      setJobs((prev) =>
        prev.map((j) =>
          j.id === item.job!.id
            ? {
                ...j,
                departmentProgress: updatedProgress,
                stagnationMeta: {
                  ...j.stagnationMeta,
                  awaitingSupervisorAttention: false,
                  foremanVerified: true,
                  workCompletedSummary: summary,
                  completionDate: j.stagnationMeta?.completionDate || todayIso,
                },
              }
            : j,
        ),
      );

      const nextInspection: Inspection = {
        id: `INS-${300 + inspections.length + 1}`,
        vehicleId: item.vehicle.id,
        jobId: item.job.id,
        plate: item.vehicle.plate,
        inspector: foreman,
        result: "Passed",
        notes: summary,
        date: todayIso,
      };
      setInspections((prev) => [...prev, nextInspection]);
      updateVehicleStage(item.vehicle.id, 7);
      addActivity(
        `Quick-completed Stage 7 & submitted for Final Inspection (${nextInspection.id})`,
        `${item.vehicle.plate} · Verified by ${foreman}`,
      );
      toast.success(
        `${item.vehicle.plate} marked complete and submitted for Final Inspection (${nextInspection.id}).`,
      );
      return;
    }

    const details = item.vehicle.intakeDetails;
    if (
      item.inspection &&
      details &&
      Number.isFinite(details.mileageOut) &&
      Number(details.mileageOut) >= 0 &&
      details.fuelLevelOut &&
      details.collectedBy?.trim() &&
      details.releasedBy?.trim()
    ) {
      setVehicles((prev) =>
        prev.map((v) =>
          v.id === item.vehicle.id ? { ...v, released: true, stage: Math.max(v.stage, 7) } : v,
        ),
      );
      addActivity(
        `Quick-released vehicle ${item.vehicle.plate}`,
        `Collected by ${details.collectedBy} (${details.mileageOut} km)`,
      );
      toast.success(`${item.vehicle.plate} marked complete and released.`);
      return;
    }

    handleSelectVehicle(item.vehicle.id);
    toast.info(
      `Opened Stage 8 for ${item.vehicle.plate} — enter outgoing odometer & release signature to finish handover.`,
    );
  }

  function handleToggleAttention(item: (typeof queueItems)[number]) {
    if (!item.job) {
      toast.info(
        `Create Stage 4 Job Card for ${item.vehicle.plate} before flagging bay attention.`,
      );
      return;
    }
    const nextFlag = !item.job.stagnationMeta?.awaitingSupervisorAttention;
    setJobs((prev) =>
      prev.map((j) =>
        j.id === item.job!.id
          ? {
              ...j,
              stagnationMeta: {
                ...j.stagnationMeta,
                awaitingSupervisorAttention: nextFlag,
              },
            }
          : j,
      ),
    );
    addActivity(
      nextFlag
        ? `Flagged ${item.vehicle.plate} for supervisor attention`
        : `Cleared attention flag on ${item.vehicle.plate}`,
      `${item.job.id} · ${item.vehicle.customer}`,
    );
    toast.success(
      nextFlag
        ? `${item.vehicle.plate} flagged under Attention Needed.`
        : `Attention flag cleared on ${item.vehicle.plate}.`,
    );
  }

  function handleOpenContact(vehicle: Vehicle) {
    setContactTarget(vehicle);
    setContactNote("");
  }

  function handleCopyPhone(phone: string) {
    if (!phone.trim()) return;
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      void navigator.clipboard.writeText(phone);
      toast.success(`Copied ${phone} to clipboard.`);
    }
  }

  function handleLogContact() {
    if (!contactTarget) return;
    const summary =
      contactNote.trim() || `Called ${contactTarget.customer} (${contactTarget.phone})`;
    addActivity(`Customer contacted · ${contactTarget.plate}`, summary);
    toast.success(`Logged customer contact for ${contactTarget.plate}.`);
    setContactTarget(null);
    setContactNote("");
  }

  function handleOpenAssign(item: (typeof queueItems)[number]) {
    setAssignTarget(item);
    setCustomTechName(item.job?.assignedEmployee ?? "");
  }

  function handleAssignTechnician(
    item: (typeof queueItems)[number] | null,
    technicianName: string,
  ) {
    if (!item) return;
    const cleanName = technicianName.trim();
    if (!cleanName) {
      toast.error("Please select or enter a technician name.");
      return;
    }

    const vehicleId = item.vehicle.id;
    const targetPlate = item.vehicle.plate;

    setJobs((prev) => {
      const existingJob = prev.find((j) => j.vehicleId === vehicleId);
      if (existingJob) {
        const currentProgress = existingJob.departmentProgress ?? [];
        const updatedProgress =
          currentProgress.length > 0
            ? currentProgress.map((dp) => ({
                ...dp,
                assignedMechanic: cleanName,
              }))
            : [
                {
                  department: existingJob.department || "Mechanical",
                  assignedMechanic: cleanName,
                  status: "In Progress" as const,
                },
              ];

        return prev.map((j) =>
          j.vehicleId === vehicleId
            ? {
                ...j,
                assignedEmployee: cleanName,
                departmentProgress: updatedProgress,
              }
            : j,
        );
      } else {
        const todayIso = new Date().toISOString().slice(0, 10);
        const newJob: JobCard = {
          id: `JC-${vehicleId.replace("VR-", "")}`,
          vehicleId,
          department: item.vehicle.department || "Mechanical",
          work: item.vehicle.complaints || "Workshop maintenance & repair",
          status: "In progress",
          due: item.vehicle.due || new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10),
          preparedBy: foreman,
          assignedEmployee: cleanName,
          routedDepartments: [item.vehicle.department || "Mechanical"],
          startDate: todayIso,
          departmentProgress: [
            {
              department: item.vehicle.department || "Mechanical",
              assignedMechanic: cleanName,
              status: "In Progress",
            },
          ],
        };
        return [newJob, ...prev];
      }
    });

    addActivity(`Technician assigned: ${cleanName}`, `${targetPlate} · Assigned by ${foreman}`);
    toast.success(`Assigned ${cleanName} to ${targetPlate}.`);
    setAssignTarget(null);
    setCustomTechName("");
  }

  const activeStageTitle =
    activeStageIndex === 7
      ? "Stage 8: Final Inspection & Vehicle Release"
      : (WORKSHOP_FLOW_STAGES[activeStageIndex]?.title ?? "Stage 1: Intake & Inspection");

  const activeStageSubtitle =
    activeStageIndex === 7
      ? "Complete road-test sign-off, outgoing mileage & fuel, and customer release"
      : (WORKSHOP_FLOW_STAGES[activeStageIndex]?.subtitle ?? "");

  return (
    <div className="workshop-flow-shell" data-testid="foreman-7-stage-flow">
      {/* Active Workshop Queue Card */}
      <div className="workshop-queue-card">
        {/* Row 1: Header + Quick Switcher + Primary Action + Collapse Toggle */}
        <div
          className={`flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 ${
            queueExpanded ? "pb-3 workshop-queue-section-divider" : ""
          }`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="h-7 w-7 rounded-md bg-primary text-primary-foreground flex items-center justify-center shrink-0">
              <Car size={15} />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-sm font-bold text-slate-900 leading-none">
                  Active Workshop Queue ({vehicles.length})
                </h3>
                {!queueExpanded && activeVehicle && !creatingNew && (
                  <span className="text-xs text-muted-foreground truncate">
                    · Active: <strong className="text-primary">{activeVehicle.plate}</strong>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-600 mt-0.5 truncate">
                Select a vehicle job card to inspect or advance its workshop stage
              </p>
            </div>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 shrink-0">
            {vehicles.length > 0 && (
              <Select
                value={creatingNew ? "__new__" : (activeVehicle?.id ?? "")}
                onValueChange={(value) => {
                  if (value === "__new__") {
                    startNewIntake();
                  } else {
                    handleSelectVehicle(value);
                  }
                }}
              >
                <SelectTrigger
                  aria-label="Select active workshop vehicle"
                  className="h-8 w-[185px] bg-white/95 text-slate-900 border-slate-300 text-xs font-medium"
                >
                  <SelectValue placeholder="Switch vehicle..." />
                </SelectTrigger>
                <SelectContent>
                  {vehicles.map((v) => (
                    <SelectItem key={v.id} value={v.id}>
                      {v.plate} · {v.customer || v.make} ({v.id})
                    </SelectItem>
                  ))}
                  <SelectItem value="__new__">+ New Vehicle Intake</SelectItem>
                </SelectContent>
              </Select>
            )}
            <Button
              type="button"
              size="sm"
              onClick={startNewIntake}
              className="h-8 px-3 text-xs bg-primary hover:bg-[var(--sidebar-royal-deep)] text-primary-foreground whitespace-nowrap shrink-0"
            >
              <Plus size={13} />
              New Vehicle Intake
            </Button>
            {vehicles.length > 0 && (
              <button
                type="button"
                onClick={() => setQueueExpanded((prev) => !prev)}
                aria-expanded={queueExpanded}
                className="h-8 px-2.5 rounded-md border border-border bg-white/95 hover:bg-slate-50 text-xs font-medium text-slate-700 inline-flex items-center gap-1 cursor-pointer whitespace-nowrap shrink-0"
              >
                <span>{queueExpanded ? "Hide Queue" : "Show Queue"}</span>
                <ChevronDown
                  size={13}
                  className={`transition-transform duration-150 ${queueExpanded ? "rotate-180" : ""}`}
                />
              </button>
            )}
          </div>
        </div>

        {/* Top Search Bar: Filter Active Workshop Queue by plate, make, or owner */}
        {queueExpanded && vehicles.length > 0 && (
          <div className="py-2.5 workshop-queue-section-divider flex flex-col sm:flex-row sm:items-center gap-2">
            <div className="relative flex-1">
              <Search
                size={14}
                aria-hidden="true"
                className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
              />
              <Input
                type="text"
                role="searchbox"
                aria-label="Search Active Workshop Queue"
                placeholder="Search by plate number, vehicle make, or owner name..."
                value={queueSearch}
                onChange={(e) => setQueueSearch(e.target.value)}
                className="h-9 pl-9 pr-8 bg-white/95 border-slate-300 text-xs text-slate-900 placeholder:text-slate-400 focus-visible:border-primary"
              />
              {queueSearch.length > 0 && (
                <button
                  type="button"
                  aria-label="Clear queue search"
                  onClick={() => setQueueSearch("")}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
                >
                  <X size={13} />
                </button>
              )}
            </div>
            {queueSearch.trim().length > 0 && (
              <span className="text-xs font-medium text-slate-600 tabular-nums shrink-0">
                {filteredQueueItems.length} of {queueItems.length} matching
              </span>
            )}
          </div>
        )}

        {/* Row 2: Segmented Filter Bar */}
        {queueExpanded && (
          <div className="py-2.5 workshop-queue-section-divider flex flex-wrap items-center gap-1.5">
            {QUEUE_FILTERS.map((filter) => {
              const count =
                filter.id === "all"
                  ? searchMatchedQueueItems.length
                  : searchMatchedQueueItems.filter((item) => item.bucket === filter.id).length;
              const active = queueFilter === filter.id;
              return (
                <button
                  key={filter.id}
                  type="button"
                  onClick={() => setQueueFilter(filter.id)}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold border whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                    active
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-white/90 text-slate-700 border-slate-200 hover:border-primary/40 hover:text-slate-900"
                  }`}
                >
                  {filter.label} ({count})
                </button>
              );
            })}
          </div>
        )}

        {/* Row 3: Clean Grouped Queue Rows with subtle navy-border bottom separators */}
        {queueExpanded && filteredQueueItems.length > 0 && (
          <div className="workshop-queue-rows" role="list" aria-label="Workshop vehicle queue rows">
            {filteredQueueItems.map((item) => {
              const isSelected = !creatingNew && activeVehicle?.id === item.vehicle.id;
              const currentStepNumber = item.isReleased
                ? 8
                : item.readiness.stages1To6Complete && Boolean(item.inspection)
                  ? 8
                  : item.readiness.maxUnlockedStageIndex + 1;
              const progressPct = Math.min(100, Math.round((currentStepNumber / 8) * 100));

              return (
                <div
                  key={item.vehicle.id}
                  role="listitem"
                  data-selected={isSelected}
                  className="workshop-queue-row"
                >
                  <button
                    type="button"
                    onClick={() => handleSelectVehicle(item.vehicle.id)}
                    className="workshop-queue-row-main"
                  >
                    <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 min-w-0">
                      <span
                        className={`font-mono text-xs font-bold tracking-tight shrink-0 ${
                          isSelected ? "text-primary" : "text-slate-900"
                        }`}
                      >
                        {item.vehicle.plate}
                      </span>
                      <span className="text-slate-300" aria-hidden="true">
                        ·
                      </span>
                      <span className="text-xs font-medium text-slate-800 truncate">
                        {item.vehicle.customer}
                      </span>
                      <span className="text-slate-300" aria-hidden="true">
                        ·
                      </span>
                      <span className="text-xs text-slate-600 truncate">
                        {[item.vehicle.make, item.vehicle.model].filter(Boolean).join(" ")}
                      </span>
                      <span className="text-[11px] font-mono text-slate-400 shrink-0">
                        ({item.vehicle.id})
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleOpenAssign(item)}
                    title={`Assigned technician: ${item.job?.assignedEmployee || "Unassigned"}. Click to assign or reassign.`}
                    className="inline-flex items-center gap-1 px-2 py-1 rounded text-[11px] font-medium bg-slate-100/90 hover:bg-primary/10 hover:text-primary text-slate-700 border border-slate-200/80 transition-colors cursor-pointer shrink-0"
                  >
                    <User size={11} className="text-slate-500" />
                    <span>{item.job?.assignedEmployee || "Assign Tech"}</span>
                  </button>

                  <div className="flex items-center gap-2.5 shrink-0 ml-auto mr-1">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold border shrink-0 transition-colors ${item.departmentBadge.bgClass} ${item.departmentBadge.textClass} ${item.departmentBadge.borderClass}`}
                      title={`Department: ${item.departmentBadge.department}`}
                    >
                      {item.departmentBadge.label}
                    </span>
                    <CircularProgressRing
                      percentage={calculateJobCompletionPercentage({
                        vehicle: item.vehicle,
                        quotation: quotations.find((q) => q.vehicleId === item.vehicle.id),
                        job: item.job,
                        requisitions,
                        dispatches,
                        inspection: item.inspection,
                        readiness: item.readiness,
                      })}
                      size={32}
                      strokeWidth={3}
                    />
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button
                        type="button"
                        aria-label={`Quick actions for ${item.vehicle.plate}`}
                        className="h-7 px-2 rounded-md border border-slate-200 bg-white/95 hover:border-primary/50 hover:text-primary text-xs font-medium text-slate-600 inline-flex items-center gap-1 cursor-pointer shrink-0 transition-colors"
                      >
                        <MoreVertical size={13} />
                        <span className="hidden sm:inline">Actions</span>
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                      align="end"
                      className="w-56 bg-white border-slate-200 shadow-lg z-50"
                    >
                      <DropdownMenuLabel className="text-xs">
                        {item.vehicle.plate} · {item.vehicle.customer}
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        disabled={item.isReleased || !item.readiness.stages1To6Complete}
                        onSelect={() => handleQuickMarkComplete(item)}
                      >
                        <CheckCircle2 size={14} className="text-emerald-600" />
                        <div className="flex flex-col">
                          <span>
                            {item.isReleased
                              ? "Already Released"
                              : item.inspection
                                ? "Complete Final Release"
                                : "Mark as Complete"}
                          </span>
                          {!item.readiness.stages1To6Complete && !item.isReleased && (
                            <span className="text-[10px] text-muted-foreground">
                              Requires Stages 1–6 complete
                            </span>
                          )}
                        </div>
                      </DropdownMenuItem>
                      <DropdownMenuItem onSelect={() => handleOpenAssign(item)}>
                        <UserCheck size={14} className="text-primary" />
                        <span>
                          {item.job?.assignedEmployee
                            ? `Reassign Tech (${item.job.assignedEmployee})`
                            : "Assign Technician"}
                        </span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onSelect={() => handleOpenContact(item.vehicle)}>
                        <Phone size={14} className="text-primary" />
                        <span>Contact Customer</span>
                      </DropdownMenuItem>
                      {item.job && !item.isReleased && (
                        <DropdownMenuItem onSelect={() => handleToggleAttention(item)}>
                          <AlertCircle size={14} className="text-amber-600" />
                          <span>
                            {item.job.stagnationMeta?.awaitingSupervisorAttention
                              ? "Clear Attention Flag"
                              : "Flag Attention Needed"}
                          </span>
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onSelect={() => handleSelectVehicle(item.vehicle.id)}>
                        <ArrowUpRight size={14} className="text-slate-500" />
                        <span>Open Current Stage</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              );
            })}
          </div>
        )}

        {queueExpanded && vehicles.length > 0 && filteredQueueItems.length === 0 && (
          <div className="workshop-queue-rows px-4 py-5 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
            <span>
              {queueSearch.trim()
                ? `No vehicles match "${queueSearch.trim()}"${queueFilter !== "all" ? " in this status filter" : ""}.`
                : "No vehicles in this queue status filter."}
            </span>
            <button
              type="button"
              onClick={() => {
                setQueueSearch("");
                setQueueFilter("all");
              }}
              className="font-semibold text-primary hover:underline cursor-pointer"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>

      {/* Clean Checkout-Inspired Header & 8-Step Horizontal Stepper */}
      <div className="workshop-stepper-card">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-4 mb-4 border-b border-border">
          <div className="min-w-0">
            {activeStageIndex > 0 ? (
              <button
                type="button"
                className="text-xs font-semibold text-slate-700 hover:text-primary cursor-pointer mb-1 inline-flex items-center gap-1"
                onClick={() => setActiveStageIndex(activeStageIndex - 1)}
              >
                &lt; Back to Stage {activeStageIndex}
              </button>
            ) : (
              <div className="text-xs font-medium text-muted-foreground mb-1">
                Workshop Job Workflow
              </div>
            )}
            <h2 className="text-lg font-bold text-slate-900 leading-tight">{activeStageTitle}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{activeStageSubtitle}</p>
          </div>
          {!creatingNew && activeVehicle && (
            <div className="text-right text-xs text-slate-600 tabular-nums">
              <div className="font-semibold text-slate-900">
                {activeVehicle.plate} · {activeVehicle.make}
              </div>
              <div>
                {activeVehicle.customer} · Ref {activeJob?.id ?? activeVehicle.id}
              </div>
            </div>
          )}
        </div>

        <div className="workshop-stepper-track" role="tablist" aria-label="7-Stage Workshop Flow">
          {WORKSHOP_FLOW_STAGES.map((stage) => {
            const stageReadiness = readiness.stages[stage.stageNumber];
            const isUnlocked = creatingNew
              ? stage.index === 0
              : stage.index <= readiness.maxUnlockedStageIndex;
            const isActive = activeStageIndex === stage.index;
            const isCompleted = !creatingNew && stageReadiness.complete;
            const state = isActive ? "active" : isCompleted ? "completed" : "locked";

            return (
              <button
                key={stage.key}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-label={`Stage ${stage.stageNumber}: ${stage.shortLabel}`}
                disabled={!isUnlocked}
                data-state={state}
                title={
                  !isUnlocked
                    ? `Complete Stage ${stage.stageNumber - 1} first to unlock ${stage.shortLabel}`
                    : stage.title
                }
                className="workshop-step-btn"
                onClick={() => isUnlocked && setActiveStageIndex(stage.index)}
              >
                <div className="workshop-step-line">
                  <span className="workshop-step-circle">
                    {isCompleted && !isActive ? (
                      <Check size={14} />
                    ) : !isUnlocked ? (
                      <Lock size={12} />
                    ) : (
                      stage.stageNumber
                    )}
                  </span>
                </div>
                <span className="workshop-step-label">{stage.shortLabel}</span>
              </button>
            );
          })}

          {/* Step 8: Final Inspection & Release */}
          <button
            type="button"
            role="tab"
            aria-selected={activeStageIndex === 7}
            aria-label="Stage 8: Final Release"
            disabled={!stage8Unlocked}
            data-state={
              activeStageIndex === 7 ? "active" : stage8Completed ? "completed" : "locked"
            }
            title={
              !stage8Unlocked
                ? "Submit Stage 7 for Final Inspection first to unlock Final Release"
                : "Stage 8: Final Inspection & Vehicle Release"
            }
            className="workshop-step-btn"
            onClick={() => stage8Unlocked && setActiveStageIndex(7)}
          >
            <div className="workshop-step-line">
              <span className="workshop-step-circle">
                {stage8Completed && activeStageIndex !== 7 ? (
                  <Check size={14} />
                ) : !stage8Unlocked ? (
                  <Lock size={12} />
                ) : (
                  8
                )}
              </span>
            </div>
            <span className="workshop-step-label">Final Release</span>
          </button>
        </div>
      </div>

      {/* Reference-Inspired 2-Column Split: Form Stack (Left) + Sticky Job Summary (Right) */}
      <div className="workshop-stage-split">
        <div className="min-w-0">
          {(activeStageIndex === 0 || !activeVehicle) && (
            <Stage1IntakeForm
              vehicle={creatingNew ? undefined : activeVehicle}
              onSaved={(savedVehicle, advance) => {
                setCreatingNew(false);
                setSelectedVehicleId(savedVehicle.id);
                if (advance) {
                  setActiveStageIndex(1);
                }
              }}
            />
          )}

          {activeStageIndex === 1 && activeVehicle && (
            <Stage2QuotationForm
              vehicle={activeVehicle}
              quotation={activeQuotation}
              job={activeJob}
              onBack={() => setActiveStageIndex(0)}
              onSaved={(_savedQuote, advance) => {
                if (advance) {
                  setActiveStageIndex(2);
                }
              }}
            />
          )}

          {activeStageIndex === 2 && activeVehicle && (
            <Stage3AuthorizationForm
              vehicle={activeVehicle}
              quotation={activeQuotation}
              onBack={() => setActiveStageIndex(1)}
              onAuthorized={() => {
                setActiveStageIndex(3);
              }}
            />
          )}

          {activeStageIndex === 3 && activeVehicle && (
            <Stage4JobCardForm
              vehicle={activeVehicle}
              quotation={activeQuotation}
              job={activeJob}
              onBack={() => setActiveStageIndex(2)}
              onSaved={() => {
                setActiveStageIndex(4);
              }}
            />
          )}

          {activeStageIndex === 4 && activeVehicle && (
            <Stage5PartsForm
              vehicle={activeVehicle}
              job={activeJob}
              quotation={activeQuotation}
              requisitions={requisitions}
              onBack={() => setActiveStageIndex(3)}
              onVerified={() => {
                setActiveStageIndex(5);
              }}
            />
          )}

          {activeStageIndex === 5 && activeVehicle && (
            <Stage6DispatchForm
              vehicle={activeVehicle}
              job={activeJob}
              requisition={activeRequisition}
              dispatches={dispatches}
              onBack={() => setActiveStageIndex(4)}
              onDispatched={() => {
                setActiveStageIndex(6);
              }}
            />
          )}

          {activeStageIndex === 6 && activeVehicle && (
            <Stage7MonitorForm
              vehicle={activeVehicle}
              job={activeJob}
              readiness={readiness}
              onBack={() => setActiveStageIndex(5)}
              onSubmitted={() => {
                setActiveStageIndex(7);
              }}
            />
          )}

          {activeStageIndex === 7 && activeVehicle && (
            <Stage8FinalReleaseForm
              vehicle={activeVehicle}
              job={activeJob}
              inspection={activeInspection}
              readiness={readiness}
              onBack={() => setActiveStageIndex(6)}
              onSendToRework={() => {
                setActiveStageIndex(6);
              }}
            />
          )}
        </div>

        <JobSummarySidebar
          creatingNew={creatingNew}
          activeStageIndex={activeStageIndex}
          vehicle={activeVehicle}
          quotation={activeQuotation}
          job={activeJob}
          requisition={activeRequisition}
          inspection={activeInspection}
          readiness={readiness}
          onJumpToStage={(idx) => setActiveStageIndex(idx)}
        />
      </div>

      {/* Quick Action: Contact Customer Modal */}
      <Dialog
        open={Boolean(contactTarget)}
        onOpenChange={(open) => {
          if (!open) setContactTarget(null);
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Contact Customer</DialogTitle>
            <DialogDescription>
              {contactTarget
                ? `${contactTarget.customer} · ${contactTarget.plate} (${[contactTarget.make, contactTarget.model].filter(Boolean).join(" ")})`
                : ""}
            </DialogDescription>
          </DialogHeader>

          {contactTarget && (
            <div className="space-y-4">
              <div className="rounded-lg border border-border bg-slate-50/70 p-3.5 space-y-2.5 text-sm">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-slate-800 font-medium">
                    <Phone size={15} className="text-primary shrink-0" />
                    <span>{contactTarget.phone || "No phone on file"}</span>
                  </div>
                  {contactTarget.phone && (
                    <div className="flex items-center gap-1.5">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="h-7 px-2 text-xs"
                        onClick={() => handleCopyPhone(contactTarget.phone)}
                      >
                        <Copy size={12} />
                        Copy
                      </Button>
                      <a
                        href={`tel:${contactTarget.phone.replace(/\s+/g, "")}`}
                        className="inline-flex items-center justify-center h-7 px-2.5 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:bg-[var(--sidebar-royal-deep)]"
                      >
                        Call
                      </a>
                    </div>
                  )}
                </div>

                {contactTarget.intakeDetails?.emailAddress && (
                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-border">
                    <div className="flex items-center gap-2 text-slate-700 text-xs">
                      <Mail size={14} className="text-primary shrink-0" />
                      <span>{contactTarget.intakeDetails.emailAddress}</span>
                    </div>
                    <a
                      href={`mailto:${contactTarget.intakeDetails.emailAddress}`}
                      className="text-xs font-semibold text-primary hover:underline"
                    >
                      Email
                    </a>
                  </div>
                )}
              </div>

              <div className="space-y-1.5">
                <label
                  className="text-xs font-semibold text-slate-700"
                  htmlFor="quick-contact-note"
                >
                  Contact Note (Optional)
                </label>
                <Textarea
                  id="quick-contact-note"
                  rows={3}
                  placeholder="e.g. Updated customer on parts ETA or confirmed pickup readiness..."
                  value={contactNote}
                  onChange={(e) => setContactNote(e.target.value)}
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setContactTarget(null)}>
              Close
            </Button>
            <Button
              type="button"
              onClick={handleLogContact}
              className="bg-primary hover:bg-[var(--sidebar-royal-deep)] text-primary-foreground"
            >
              Log Customer Contact
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Quick Action: Assign / Reassign Technician Floating Menu Dialog */}
      <Dialog
        open={Boolean(assignTarget)}
        onOpenChange={(open) => {
          if (!open) setAssignTarget(null);
        }}
      >
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserCheck size={18} className="text-primary" />
              <span>
                {assignTarget?.job?.assignedEmployee ? "Reassign Technician" : "Assign Technician"}
              </span>
            </DialogTitle>
            <DialogDescription>
              {assignTarget
                ? `${assignTarget.vehicle.plate} · ${assignTarget.vehicle.customer} (${[assignTarget.vehicle.make, assignTarget.vehicle.model].filter(Boolean).join(" ")})`
                : ""}
            </DialogDescription>
          </DialogHeader>

          {assignTarget && (
            <div className="space-y-4">
              <div className="rounded-lg border border-border bg-slate-50/70 p-3 space-y-1.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Current Lead Technician:</span>
                  <span className="font-semibold text-slate-800">
                    {assignTarget.job?.assignedEmployee || "Unassigned"}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Active Department:</span>
                  <span
                    className={`font-semibold px-2 py-0.5 rounded-full text-[10px] border ${assignTarget.departmentBadge.bgClass} ${assignTarget.departmentBadge.textClass} ${assignTarget.departmentBadge.borderClass}`}
                  >
                    {assignTarget.departmentBadge.label}
                  </span>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 mb-2 block">
                  Quick Select Workshop Technician
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {QUICK_TECHNICIANS.map((tech) => {
                    const isCurrent = assignTarget.job?.assignedEmployee === tech;
                    return (
                      <button
                        key={tech}
                        type="button"
                        onClick={() => handleAssignTechnician(assignTarget, tech)}
                        className={`flex items-center justify-between px-3 py-2 rounded-lg border text-xs font-medium transition-all text-left cursor-pointer ${
                          isCurrent
                            ? "border-primary bg-primary/10 text-primary font-semibold ring-1 ring-primary"
                            : "border-slate-200 bg-white hover:border-primary/40 hover:bg-slate-50 text-slate-800"
                        }`}
                      >
                        <span className="truncate">{tech}</span>
                        {isCurrent && <Check size={13} className="text-primary shrink-0 ml-1" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                <label className="text-xs font-semibold text-slate-700" htmlFor="custom-tech-input">
                  Or Enter Custom Technician Name
                </label>
                <div className="flex items-center gap-2">
                  <Input
                    id="custom-tech-input"
                    className="h-8 text-xs bg-white"
                    placeholder="e.g. Samuel Banda / Specialist Tech..."
                    value={customTechName}
                    onChange={(e) => setCustomTechName(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleAssignTechnician(assignTarget, customTechName);
                      }
                    }}
                  />
                  <Button
                    type="button"
                    size="sm"
                    className="h-8 text-xs px-3 bg-primary hover:bg-[var(--sidebar-royal-deep)] text-primary-foreground shrink-0"
                    onClick={() => handleAssignTechnician(assignTarget, customTechName)}
                  >
                    Assign
                  </Button>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setAssignTarget(null)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
