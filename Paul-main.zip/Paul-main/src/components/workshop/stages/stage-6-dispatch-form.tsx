import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Check, Plus, Trash2 } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import { money, type JobCard, type Requisition, type Vehicle } from "@/lib/workshop";
import { APPROVED_DISPATCH_STATUSES, findMatchingDispatch } from "@/lib/workshop-flow";

type DispatchItemDraft = {
  id: string;
  item: string;
  quantity: number;
  amount: number;
};

type Stage6DispatchFormProps = {
  vehicle: Vehicle;
  job?: JobCard;
  requisition?: Requisition;
  dispatches: Record<string, unknown>[];
  bannerExtra?: ReactNode;
  onDispatched?: () => void;
  onBack?: () => void;
};

export function Stage6DispatchForm({
  vehicle,
  job,
  requisition,
  dispatches,
  onDispatched,
  onBack,
}: Stage6DispatchFormProps) {
  const { setDispatches, setRequisitions, updateVehicleStage, addActivity, foreman } =
    useWorkspace();

  const existingDispatch = useMemo(
    () => findMatchingDispatch(dispatches, { vehicleId: vehicle.id, job }),
    [dispatches, vehicle.id, job],
  );
  const todayIso = new Date().toISOString().slice(0, 10);

  const defaultDispatchNo = useMemo(() => {
    if (existingDispatch?.["dispatchNumber"]) return String(existingDispatch["dispatchNumber"]);
    return `DO-${100 + dispatches.length + 1}`;
  }, [existingDispatch, dispatches.length]);

  const [dispatchNumber, setDispatchNumber] = useState(defaultDispatchNo);
  const [dispatchDate, setDispatchDate] = useState(String(existingDispatch?.["date"] ?? todayIso));

  const initialItems = useMemo<DispatchItemDraft[]>(() => {
    const rawItems = existingDispatch?.["items"];
    if (Array.isArray(rawItems) && rawItems.length > 0) {
      return rawItems.map((entry, idx) => {
        const rec = entry as Record<string, unknown>;
        return {
          id: String(rec["id"] ?? `di-${idx}`),
          item: String(rec["item"] ?? ""),
          quantity: Number(rec["quantity"] ?? 1),
          amount: Number(rec["amount"] ?? 0),
        };
      });
    }
    if (requisition?.partsCheck?.items && requisition.partsCheck.items.length > 0) {
      return requisition.partsCheck.items.map((row, idx) => ({
        id: `di-${idx}`,
        item: row.partName,
        quantity: row.requiredQty,
        amount: row.requiredQty * (row.unitPrice ?? 0),
      }));
    }
    return [
      { id: "di-1", item: "Air filter", quantity: 1, amount: 450 },
      { id: "di-2", item: "Oil filter", quantity: 1, amount: 250 },
    ];
  }, [existingDispatch, requisition]);

  const [items, setItems] = useState<DispatchItemDraft[]>(initialItems);

  const existingStatus = String(existingDispatch?.["status"] ?? "PENDING_APPROVAL").toUpperCase();
  const [managerDecision, setManagerDecision] = useState<
    "Approve" | "Reject" | "Request Corrections" | "Pending"
  >(() => {
    if (APPROVED_DISPATCH_STATUSES.has(existingStatus)) return "Approve";
    if (existingStatus === "REJECTED") return "Reject";
    if (existingStatus === "CORRECTIONS_REQUESTED") return "Request Corrections";
    return "Pending";
  });
  const [managerRemarks, setManagerRemarks] = useState(
    String(existingDispatch?.["managerRemarks"] ?? ""),
  );

  const existingStores = (existingDispatch?.["storesConfirmation"] ?? {}) as Record<
    string,
    unknown
  >;
  const [issuedBy, setIssuedBy] = useState(String(existingStores["issuedBy"] ?? "Stores Officer"));
  const [dateIssued, setDateIssued] = useState(String(existingStores["dateIssued"] ?? todayIso));
  const [quantityIssued, setQuantityIssued] = useState(
    String(
      existingStores["quantityIssued"] ?? initialItems.reduce((sum, row) => sum + row.quantity, 0),
    ),
  );
  const [storesSignature, setStoresSignature] = useState(
    String(existingStores["storesSignature"] ?? "Stores Officer"),
  );

  const existingAck = (existingDispatch?.["acknowledgements"] ?? {}) as Record<string, unknown>;
  const [customerSig, setCustomerSig] = useState(
    String(existingAck["customerSignature"] ?? vehicle.customer ?? ""),
  );
  const [authorizedSig, setAuthorizedSig] = useState(
    String(existingAck["authorizedPersonSignature"] ?? "Workshop Manager"),
  );
  const [accountsAck, setAccountsAck] = useState(
    String(existingAck["accountsAcknowledgement"] ?? "Accounts Cleared"),
  );

  useEffect(() => {
    setDispatchNumber(defaultDispatchNo);
    setDispatchDate(String(existingDispatch?.["date"] ?? todayIso));
    setItems(initialItems);
    const st = String(existingDispatch?.["status"] ?? "PENDING_APPROVAL").toUpperCase();
    setManagerDecision(
      APPROVED_DISPATCH_STATUSES.has(st)
        ? "Approve"
        : st === "REJECTED"
          ? "Reject"
          : st === "CORRECTIONS_REQUESTED"
            ? "Request Corrections"
            : "Pending",
    );
    setManagerRemarks(String(existingDispatch?.["managerRemarks"] ?? ""));
  }, [defaultDispatchNo, existingDispatch, initialItems, todayIso]);

  function addRow() {
    setItems((prev) => [
      ...prev,
      { id: `di-${Date.now()}-${prev.length}`, item: "", quantity: 1, amount: 0 },
    ]);
  }

  function removeRow(id: string) {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((row) => row.id !== id));
  }

  function updateRow(id: string, patch: Partial<DispatchItemDraft>) {
    setItems((prev) => prev.map((row) => (row.id === id ? { ...row, ...patch } : row)));
  }

  const canReleaseDispatch =
    managerDecision === "Approve" &&
    items.some((i) => i.item.trim() && i.quantity > 0) &&
    issuedBy.trim().length > 0 &&
    dateIssued.trim().length > 0 &&
    storesSignature.trim().length > 0 &&
    authorizedSig.trim().length > 0 &&
    accountsAck.trim().length > 0;

  function persistDispatch(nextStatus: string, decision: typeof managerDecision) {
    const cleanItems = items.filter((i) => i.item.trim() && i.quantity > 0);
    const record: Record<string, unknown> = {
      ...(existingDispatch ?? {}),
      id: existingDispatch?.["id"] ?? dispatchNumber,
      dispatchOrderId: existingDispatch?.["dispatchOrderId"] ?? Date.now(),
      dispatchNumber: dispatchNumber.trim() || defaultDispatchNo,
      vehicleId: vehicle.id,
      jobNumber: job?.id ?? vehicle.id,
      ...(job?.backendJobId !== undefined ? { jobId: job.backendJobId } : {}),
      customerName: vehicle.customer,
      vehicleRegistration: vehicle.plate,
      departmentName: job?.department ?? "Mechanical",
      date: dispatchDate,
      items: cleanItems,
      status: nextStatus,
      managerDecision: decision,
      managerRemarks: managerRemarks.trim(),
      storesConfirmation: {
        issuedBy: issuedBy.trim(),
        dateIssued,
        quantityIssued: Number(quantityIssued || 0),
        storesSignature: storesSignature.trim(),
      },
      acknowledgements: {
        customerSignature: customerSig.trim(),
        authorizedPersonSignature: authorizedSig.trim(),
        accountsAcknowledgement: accountsAck.trim(),
      },
    };

    setDispatches((prev) => {
      const idx = prev.findIndex(
        (d) =>
          String(d["vehicleId"] ?? "") === vehicle.id ||
          (job && String(d["jobNumber"] ?? "") === job.id),
      );
      if (idx >= 0) {
        return prev.map((d, i) => (i === idx ? record : d));
      }
      return [record, ...prev];
    });
  }

  function handleDecisionClick(decision: "Approve" | "Reject" | "Request Corrections") {
    setManagerDecision(decision);
    const statusMap = {
      Approve: "APPROVED",
      Reject: "REJECTED",
      "Request Corrections": "CORRECTIONS_REQUESTED",
    } as const;
    persistDispatch(statusMap[decision], decision);
    if (decision === "Approve") {
      toast.success("Manager approval recorded. Ready to release parts to workshop floor.");
    } else if (decision === "Reject") {
      toast.error("Dispatch rejected. Parts remain locked in stores.");
    } else {
      toast.info("Corrections requested on dispatch order.");
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!canReleaseDispatch) {
      toast.error(
        "Manager approval, Stores confirmation signatures, and Acknowledgements are required before dispatch.",
      );
      return;
    }

    persistDispatch("APPROVED_AND_DISPATCHED", "Approve");

    if (requisition) {
      setRequisitions((prev) =>
        prev.map((r) => (r.id === requisition.id ? { ...r, status: "Dispatched" } : r)),
      );
    }

    updateVehicleStage(vehicle.id, 6);
    addActivity(
      `Stage 6 Dispatch ${dispatchNumber} released`,
      `${foreman} · ${vehicle.plate} · Approved & issued to ${job?.department || "Workshop"}`,
    );
    toast.success(`Dispatch ${dispatchNumber} approved & released to workshop floor.`);
    onDispatched?.();
  }

  return (
    <form onSubmit={handleSubmit} className="stage-form-stack">
      {/* Card 1: Dispatch Header & Manager Decision */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Dispatch Authorization</h3>
            <p className="stage-card-subtitle">
              Job {job?.id ?? vehicle.id} · {vehicle.plate} · Decision:{" "}
              <strong className="text-slate-900">{managerDecision}</strong>
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              size="sm"
              variant={managerDecision === "Approve" ? "default" : "outline"}
              onClick={() => handleDecisionClick("Approve")}
            >
              <Check size={13} />
              Approve Dispatch
            </Button>
            <Button
              type="button"
              size="sm"
              variant={managerDecision === "Request Corrections" ? "default" : "outline"}
              onClick={() => handleDecisionClick("Request Corrections")}
            >
              Request Corrections
            </Button>
            <Button
              type="button"
              size="sm"
              variant={managerDecision === "Reject" ? "destructive" : "outline"}
              onClick={() => handleDecisionClick("Reject")}
            >
              Reject Dispatch
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s6-dispatch-no">
              <span className="text-red-600">*</span> Dispatch Order No.
            </label>
            <Input
              id="s6-dispatch-no"
              className="stage-input font-mono"
              value={dispatchNumber}
              onChange={(e) => setDispatchNumber(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s6-date">
              Dispatch Date
            </label>
            <Input
              id="s6-date"
              type="date"
              className="stage-input"
              value={dispatchDate}
              onChange={(e) => setDispatchDate(e.target.value)}
            />
          </div>
          <div className="stage-field sm:col-span-2">
            <label className="stage-field-label" htmlFor="s6-manager-remarks">
              Manager Remarks
            </label>
            <Textarea
              id="s6-manager-remarks"
              className="stage-textarea"
              placeholder="Approval notes or correction instructions"
              value={managerRemarks}
              onChange={(e) => setManagerRemarks(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Card 2: Dispatched Parts */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Items Being Dispatched</h3>
          </div>
          <Button type="button" size="sm" variant="outline" onClick={addRow}>
            <Plus size={14} />
            Add Dispatch Item
          </Button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b bg-slate-50 text-slate-600">
                <th className="py-2.5 px-2 font-semibold">Item</th>
                <th className="py-2.5 px-2 font-semibold w-28 text-right">Quantity</th>
                <th className="py-2.5 px-2 font-semibold w-36 text-right">Amount</th>
                <th className="py-2.5 px-2 font-semibold w-12 text-center">Del</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {items.map((row, idx) => (
                <tr key={row.id}>
                  <td className="py-1.5 px-2">
                    <Input
                      className="h-9 text-xs border-slate-300"
                      aria-label={`Dispatch item ${idx + 1} name`}
                      value={row.item}
                      onChange={(e) => updateRow(row.id, { item: e.target.value })}
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <Input
                      type="number"
                      min={1}
                      className="h-9 text-xs text-right border-slate-300 tabular-nums"
                      aria-label={`Dispatch item ${idx + 1} quantity`}
                      value={row.quantity}
                      onChange={(e) => updateRow(row.id, { quantity: Number(e.target.value || 1) })}
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <Input
                      type="number"
                      min={0}
                      step="0.01"
                      className="h-9 text-xs text-right border-slate-300 tabular-nums"
                      aria-label={`Dispatch item ${idx + 1} amount`}
                      value={row.amount}
                      onChange={(e) => updateRow(row.id, { amount: Number(e.target.value || 0) })}
                    />
                  </td>
                  <td className="py-1.5 px-2 text-center">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label={`Remove dispatch item ${row.item || idx + 1}`}
                      onClick={() => removeRow(row.id)}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="mt-3 text-right text-xs font-semibold text-slate-600 tabular-nums">
            Total Dispatch Value:{" "}
            <span className="text-slate-900">
              {money(items.reduce((sum, i) => sum + Number(i.amount || 0), 0))}
            </span>
          </div>
        </div>
      </div>

      {/* Card 3: Stores & Release Sign-Offs */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Stores Confirmation &amp; Sign-Offs</h3>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s6-issued-by">
              <span className="text-red-600">*</span> Issued By
            </label>
            <Input
              id="s6-issued-by"
              className="stage-input"
              value={issuedBy}
              onChange={(e) => setIssuedBy(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s6-date-issued">
              <span className="text-red-600">*</span> Date Issued
            </label>
            <Input
              id="s6-date-issued"
              type="date"
              className="stage-input"
              value={dateIssued}
              onChange={(e) => setDateIssued(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s6-qty-issued">
              <span className="text-red-600">*</span> Quantity Issued
            </label>
            <Input
              id="s6-qty-issued"
              type="number"
              min={1}
              className="stage-input tabular-nums"
              value={quantityIssued}
              onChange={(e) => setQuantityIssued(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s6-stores-sig">
              <span className="text-red-600">*</span> Stores Signature
            </label>
            <Input
              id="s6-stores-sig"
              className="stage-input"
              value={storesSignature}
              onChange={(e) => setStoresSignature(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s6-auth-sig">
              <span className="text-red-600">*</span> Authorized Person Signature
            </label>
            <Input
              id="s6-auth-sig"
              className="stage-input"
              value={authorizedSig}
              onChange={(e) => setAuthorizedSig(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s6-accounts-ack">
              <span className="text-red-600">*</span> Accounts Acknowledgement
            </label>
            <Input
              id="s6-accounts-ack"
              className="stage-input"
              value={accountsAck}
              onChange={(e) => setAccountsAck(e.target.value)}
              required
            />
          </div>
          <div className="stage-field sm:col-span-2 lg:col-span-3">
            <label className="stage-field-label" htmlFor="s6-cust-sig">
              Customer Signature (Optional)
            </label>
            <Input
              id="s6-cust-sig"
              className="stage-input"
              value={customerSig}
              onChange={(e) => setCustomerSig(e.target.value)}
            />
          </div>
        </div>
      </div>

      {!canReleaseDispatch && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900">
          <strong>Required before release:</strong>{" "}
          {[
            managerDecision !== "Approve" ? "Click Approve Dispatch (Manager approval)" : "",
            !issuedBy.trim() || !storesSignature.trim() ? "Complete Stores confirmation" : "",
            !authorizedSig.trim() || !accountsAck.trim() ? "Complete Acknowledgements" : "",
          ]
            .filter(Boolean)
            .join(" · ")}
        </div>
      )}

      <div className="stage-cta-bar">
        <div>
          {onBack && (
            <Button type="button" variant="outline" onClick={onBack}>
              &larr; Back to Stage 5
            </Button>
          )}
        </div>
        <Button type="submit" disabled={!canReleaseDispatch} className="stage-primary-cta">
          Approve &amp; Dispatch to Workshop Floor
        </Button>
      </div>
    </form>
  );
}
