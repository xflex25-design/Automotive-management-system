import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertCircle, Check, Plus, Trash2 } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import type {
  JobCard,
  PartsCheckDetails,
  PartsCheckItem,
  Quotation,
  Requisition,
  Vehicle,
} from "@/lib/workshop";
import {
  canCreateDispatchFromParts,
  deriveOverallStockStatus,
  derivePartStockStatus,
} from "@/lib/workshop-flow";

type Stage5PartsFormProps = {
  vehicle: Vehicle;
  job?: JobCard;
  quotation?: Quotation;
  requisitions: Requisition[];
  bannerExtra?: ReactNode;
  onVerified?: (req: Requisition) => void;
  onBack?: () => void;
};

export function Stage5PartsForm({
  vehicle,
  job,
  quotation,
  requisitions,
  onVerified,
  onBack,
}: Stage5PartsFormProps) {
  const {
    requisitions: allRequisitions,
    setRequisitions,
    dispatches,
    setDispatches,
    updateVehicleStage,
    foreman,
    addActivity,
  } = useWorkspace();

  const existingReq = requisitions.find((r) => r.vehicleId === vehicle.id);
  const todayIso = new Date().toISOString().slice(0, 10);

  const initialItems = useMemo<PartsCheckItem[]>(() => {
    if (existingReq?.partsCheck?.items && existingReq.partsCheck.items.length > 0) {
      return existingReq.partsCheck.items;
    }
    if (job?.partsSheet && job.partsSheet.length > 0) {
      return job.partsSheet
        .filter((row) => row.partName.trim() || row.additionalPart.trim())
        .map((row, idx) => {
          const name = row.additionalPart.trim() || row.partName.trim();
          const reqQty = Math.max(1, Number(row.quantity || 1));
          const quotedItem = quotation?.items?.find((q) =>
            q.item.toLowerCase().includes(name.toLowerCase()),
          );
          return {
            id: `chk-${idx}`,
            partName: name,
            requiredQty: reqQty,
            availableQty: reqQty,
            status: derivePartStockStatus(reqQty, reqQty),
            unitPrice: quotedItem?.unitPrice ?? 250,
          };
        });
    }
    return [
      {
        id: "chk-1",
        partName: "Air filter",
        requiredQty: 1,
        availableQty: 1,
        status: "Available",
        unitPrice: 450,
      },
      {
        id: "chk-2",
        partName: "Oil filter",
        requiredQty: 1,
        availableQty: 1,
        status: "Available",
        unitPrice: 250,
      },
    ];
  }, [existingReq, job, quotation]);

  const [items, setItems] = useState<PartsCheckItem[]>(initialItems);
  const [reqPartName, setReqPartName] = useState(
    existingReq?.partsCheck?.requisitionDetails.partName ?? "",
  );
  const [reqQty, setReqQty] = useState(
    String(existingReq?.partsCheck?.requisitionDetails.quantityRequired ?? 0),
  );
  const [supplier, setSupplier] = useState(
    existingReq?.partsCheck?.requisitionDetails.supplier ?? "Hi-Rider Spares & 4x4 Supply",
  );
  const [purchaseReqRef, setPurchaseReqRef] = useState(
    existingReq?.partsCheck?.requisitionDetails.purchaseRequisitionRef ?? "",
  );
  const [expectedDeliveryDate, setExpectedDeliveryDate] = useState(
    existingReq?.partsCheck?.requisitionDetails.expectedDeliveryDate ?? todayIso,
  );

  const [qtyReceived, setQtyReceived] = useState(
    String(existingReq?.partsCheck?.receiving.quantityReceived ?? 0),
  );
  const [dateReceived, setDateReceived] = useState(
    existingReq?.partsCheck?.receiving.dateReceived ?? todayIso,
  );
  const [receivedBy, setReceivedBy] = useState(
    existingReq?.partsCheck?.receiving.receivedBy ?? "Stores Officer",
  );
  const [stockUpdated, setStockUpdated] = useState(
    existingReq?.partsCheck?.receiving.stockUpdated ?? false,
  );

  const [showProcurement, setShowProcurement] = useState(
    Boolean(existingReq?.partsCheck?.requisitionDetails.partName),
  );

  useEffect(() => {
    setItems(initialItems);
    setReqPartName(existingReq?.partsCheck?.requisitionDetails.partName ?? "");
    setReqQty(String(existingReq?.partsCheck?.requisitionDetails.quantityRequired ?? 0));
    setSupplier(
      existingReq?.partsCheck?.requisitionDetails.supplier ?? "Hi-Rider Spares & 4x4 Supply",
    );
    setPurchaseReqRef(existingReq?.partsCheck?.requisitionDetails.purchaseRequisitionRef ?? "");
    setExpectedDeliveryDate(
      existingReq?.partsCheck?.requisitionDetails.expectedDeliveryDate ?? todayIso,
    );
    setQtyReceived(String(existingReq?.partsCheck?.receiving.quantityReceived ?? 0));
    setDateReceived(existingReq?.partsCheck?.receiving.dateReceived ?? todayIso);
    setReceivedBy(existingReq?.partsCheck?.receiving.receivedBy ?? "Stores Officer");
    setStockUpdated(existingReq?.partsCheck?.receiving.stockUpdated ?? false);
  }, [initialItems, existingReq, todayIso]);

  const normalizedItems = useMemo(
    () =>
      items.map((item) => ({
        ...item,
        status: derivePartStockStatus(item.requiredQty, item.availableQty),
      })),
    [items],
  );

  const overallStatus = useMemo(() => deriveOverallStockStatus(normalizedItems), [normalizedItems]);

  const receiving = useMemo<PartsCheckDetails["receiving"]>(
    () => ({
      quantityReceived: Number(qtyReceived || 0),
      dateReceived,
      receivedBy: receivedBy.trim(),
      stockUpdated,
    }),
    [qtyReceived, dateReceived, receivedBy, stockUpdated],
  );

  const dispatchGate = useMemo(
    () => canCreateDispatchFromParts(normalizedItems, receiving),
    [normalizedItems, receiving],
  );

  const availableCount = normalizedItems.filter((i) => i.status === "Available").length;
  const partialCount = normalizedItems.filter((i) => i.status === "Partially available").length;
  const outCount = normalizedItems.filter((i) => i.status === "Out of stock").length;
  const procurementOpen = showProcurement || outCount > 0 || partialCount > 0;

  function addItemRow() {
    setItems((prev) => [
      ...prev,
      {
        id: `chk-${Date.now()}-${prev.length}`,
        partName: "",
        requiredQty: 1,
        availableQty: 0,
        status: "Out of stock",
        unitPrice: 0,
      },
    ]);
  }

  function removeItemRow(id: string) {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((item) => item.id !== id));
  }

  function updateItemRow(id: string, patch: Partial<PartsCheckItem>) {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const merged = { ...item, ...patch };
        return {
          ...merged,
          status: derivePartStockStatus(merged.requiredQty, merged.availableQty),
        };
      }),
    );
  }

  function confirmAllInStock() {
    setItems((prev) =>
      prev.map((item) => ({
        ...item,
        availableQty: item.requiredQty,
        status: derivePartStockStatus(item.requiredQty, item.requiredQty),
      })),
    );
    toast.success("All required parts matched to in-stock quantities.");
  }

  function applyReceivedStock() {
    const receivedNum = Number(qtyReceived || 0);
    if (receivedNum <= 0) {
      toast.error("Enter a received quantity greater than 0 before updating stock.");
      return;
    }
    setItems((prev) =>
      prev.map((item) => {
        if (item.availableQty >= item.requiredQty) return item;
        const deficit = item.requiredQty - item.availableQty;
        const nextAvail = item.availableQty + Math.min(deficit, receivedNum);
        return {
          ...item,
          availableQty: nextAvail,
          status: derivePartStockStatus(item.requiredQty, nextAvail),
        };
      }),
    );
    setStockUpdated(true);
    toast.success("Received parts applied and stock levels updated.");
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!dispatchGate.allowed) {
      toast.error(dispatchGate.blockers[0] ?? "Cannot dispatch unavailable parts.");
      return;
    }

    const maxReqNum = allRequisitions.reduce((max, r) => {
      const m = r.id.match(/^REQ-(\d+)$/);
      return m ? Math.max(max, Number(m[1])) : max;
    }, 500);
    const reqId = existingReq?.id ?? `REQ-${maxReqNum + 1}`;
    const totalQty = normalizedItems.reduce((sum, i) => sum + i.requiredQty, 0);
    const totalAmount = normalizedItems.reduce(
      (sum, i) => sum + i.requiredQty * (i.unitPrice ?? 0),
      0,
    );

    const partsCheck: PartsCheckDetails = {
      items: normalizedItems,
      stockSummaryStatus: overallStatus,
      requisitionDetails: {
        partName: reqPartName.trim(),
        quantityRequired: Number(reqQty || 0),
        supplier: supplier.trim(),
        purchaseRequisitionRef: purchaseReqRef.trim(),
        expectedDeliveryDate,
      },
      receiving: {
        ...receiving,
        stockUpdated: true,
      },
      verifiedForDispatch: true,
      status: "completed",
    };

    const savedReq: Requisition = {
      ...(existingReq ?? {
        id: reqId,
        vehicleId: vehicle.id,
        department: job?.department || "Mechanical",
        reason: job?.work || vehicle.complaints || "Workshop parts verification",
        foreman,
        date: todayIso,
      }),
      id: reqId,
      vehicleId: vehicle.id,
      part: normalizedItems.map((i) => i.partName).join(", "),
      quantity: totalQty,
      amount: totalAmount,
      status: "Approved",
      partsCheck,
    };

    setRequisitions((prev) => {
      const exists = prev.some((r) => r.id === savedReq.id || r.vehicleId === vehicle.id);
      if (exists) {
        return prev.map((r) => (r.id === savedReq.id || r.vehicleId === vehicle.id ? savedReq : r));
      }
      return [savedReq, ...prev];
    });

    const hasDispatch = dispatches.some(
      (d) =>
        String(d["vehicleId"] ?? "") === vehicle.id ||
        (job && String(d["jobNumber"] ?? "") === job.id),
    );
    if (!hasDispatch) {
      const dispatchNumber = `DO-${100 + dispatches.length + 1}`;
      setDispatches((prev) => [
        {
          id: dispatchNumber,
          dispatchOrderId: Date.now(),
          dispatchNumber,
          vehicleId: vehicle.id,
          jobNumber: job?.id ?? vehicle.id,
          customerName: vehicle.customer,
          vehicleRegistration: vehicle.plate,
          departmentName: job?.department || "Mechanical",
          date: todayIso,
          status: "PENDING_APPROVAL",
          items: normalizedItems.map((item) => ({
            id: item.id,
            item: item.partName,
            quantity: item.requiredQty,
            amount: item.requiredQty * (item.unitPrice ?? 0),
          })),
        },
        ...prev,
      ]);
    }

    updateVehicleStage(vehicle.id, 5);
    addActivity(
      `Stage 5 Parts verified (${reqId})`,
      `${vehicle.plate} · ${normalizedItems.length} part line(s) verified → Dispatch Order created`,
    );
    toast.success(`Parts verified and dispatch order prepared for ${vehicle.plate}.`);
    onVerified?.(savedReq);
  }

  return (
    <form onSubmit={handleSubmit} className="stage-form-stack">
      {/* Stock Overview Strip */}
      <div className="stage-card">
        <div className="stage-card-head !mb-3">
          <div>
            <h3 className="stage-card-title">Stock Verification Overview</h3>
            <p className="stage-card-subtitle">
              Job {job?.id ?? vehicle.id} · {vehicle.plate} · Overall status:{" "}
              <strong className="text-slate-900">{overallStatus}</strong>
            </p>
          </div>
          <div className="flex items-center gap-4 text-xs tabular-nums">
            <span className="text-emerald-700 font-semibold">{availableCount} Available</span>
            <span className="text-amber-700 font-semibold">{partialCount} Partial</span>
            <span className="text-red-700 font-semibold">{outCount} Out of stock</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <span className="text-xs text-slate-500">
            Verify available store counts below. Dispatch stays blocked while any required part is
            out of stock.
          </span>
          <div className="flex items-center gap-2">
            <Button type="button" size="sm" variant="outline" onClick={confirmAllInStock}>
              <Check size={13} />
              Confirm All In Stock
            </Button>
            <Button type="button" size="sm" variant="outline" onClick={addItemRow}>
              <Plus size={14} />
              Add Part Check
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto mt-3">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b bg-slate-50 text-slate-600">
                <th className="py-2.5 px-2 font-semibold">Part</th>
                <th className="py-2.5 px-2 font-semibold w-28 text-right">Required Qty</th>
                <th className="py-2.5 px-2 font-semibold w-28 text-right">Available Qty</th>
                <th className="py-2.5 px-2 font-semibold w-40">Status</th>
                <th className="py-2.5 px-2 font-semibold w-12 text-center">Del</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {normalizedItems.map((row, idx) => (
                <tr key={row.id}>
                  <td className="py-1.5 px-2">
                    <Input
                      className="h-9 text-xs border-slate-300"
                      aria-label={`Part line ${idx + 1} name`}
                      value={row.partName}
                      onChange={(e) => updateItemRow(row.id, { partName: e.target.value })}
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <Input
                      type="number"
                      min={1}
                      className="h-9 text-xs text-right border-slate-300 tabular-nums"
                      aria-label={`Part line ${idx + 1} required quantity`}
                      value={row.requiredQty}
                      onChange={(e) =>
                        updateItemRow(row.id, { requiredQty: Number(e.target.value || 1) })
                      }
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <Input
                      type="number"
                      min={0}
                      className="h-9 text-xs text-right border-slate-300 tabular-nums"
                      aria-label={`Part line ${idx + 1} available quantity`}
                      value={row.availableQty}
                      onChange={(e) =>
                        updateItemRow(row.id, { availableQty: Number(e.target.value || 0) })
                      }
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <span
                      className={`text-xs font-semibold ${
                        row.status === "Available"
                          ? "text-emerald-700"
                          : row.status === "Partially available"
                            ? "text-amber-700"
                            : "text-red-700"
                      }`}
                    >
                      {row.status}
                    </span>
                  </td>
                  <td className="py-1.5 px-2 text-center">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label={`Remove part check ${row.partName || idx + 1}`}
                      onClick={() => removeItemRow(row.id)}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100">
          <button
            type="button"
            className="stage-link-toggle"
            onClick={() => setShowProcurement((prev) => !prev)}
          >
            {procurementOpen
              ? "− Hide Purchase Requisition & Goods Receiving"
              : "+ Raise Purchase Requisition / Receive Stock (if parts ordered)"}
          </button>
        </div>
      </div>

      {procurementOpen && (
        <div className="stage-card">
          <div className="stage-card-head">
            <div>
              <h3 className="stage-card-title">Purchase Requisition &amp; Stock Receiving</h3>
              <p className="stage-card-subtitle">
                Record supplier order and apply received parts into workshop stock
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="stage-field sm:col-span-2">
              <label className="stage-field-label" htmlFor="s5-req-part">
                Out-of-Stock Part Name
              </label>
              <Input
                id="s5-req-part"
                className="stage-input"
                placeholder="Part name to order"
                value={reqPartName}
                onChange={(e) => setReqPartName(e.target.value)}
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s5-req-qty">
                Quantity Required
              </label>
              <Input
                id="s5-req-qty"
                type="number"
                min={0}
                className="stage-input tabular-nums"
                value={reqQty}
                onChange={(e) => setReqQty(e.target.value)}
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s5-pr-ref">
                Purchase Requisition Ref
              </label>
              <Input
                id="s5-pr-ref"
                className="stage-input font-mono"
                placeholder="PR-2026-01"
                value={purchaseReqRef}
                onChange={(e) => setPurchaseReqRef(e.target.value)}
              />
            </div>
            <div className="stage-field sm:col-span-2">
              <label className="stage-field-label" htmlFor="s5-supplier">
                Supplier
              </label>
              <Input
                id="s5-supplier"
                className="stage-input"
                value={supplier}
                onChange={(e) => setSupplier(e.target.value)}
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s5-delivery">
                Expected Delivery Date
              </label>
              <Input
                id="s5-delivery"
                type="date"
                className="stage-input"
                value={expectedDeliveryDate}
                onChange={(e) => setExpectedDeliveryDate(e.target.value)}
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s5-qty-received">
                Quantity Received
              </label>
              <Input
                id="s5-qty-received"
                type="number"
                min={0}
                className="stage-input tabular-nums"
                value={qtyReceived}
                onChange={(e) => setQtyReceived(e.target.value)}
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s5-date-received">
                Date Received
              </label>
              <Input
                id="s5-date-received"
                type="date"
                className="stage-input"
                value={dateReceived}
                onChange={(e) => setDateReceived(e.target.value)}
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s5-received-by">
                Received By
              </label>
              <Input
                id="s5-received-by"
                className="stage-input"
                value={receivedBy}
                onChange={(e) => setReceivedBy(e.target.value)}
              />
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
            <label className="flex items-center gap-2 text-xs font-medium cursor-pointer text-slate-700">
              <input
                type="checkbox"
                checked={stockUpdated}
                onChange={(e) => setStockUpdated(e.target.checked)}
                className="accent-primary h-4 w-4"
              />
              <span>Stock levels updated in stores</span>
            </label>
            <Button type="button" size="sm" variant="outline" onClick={applyReceivedStock}>
              <Check size={13} />
              Receive &amp; Update Stock
            </Button>
          </div>
        </div>
      )}

      {!dispatchGate.allowed && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-800 flex items-start gap-2">
          <AlertCircle size={15} className="shrink-0 mt-0.5" />
          <span>{dispatchGate.blockers.join(" ")}</span>
        </div>
      )}

      <div className="stage-cta-bar">
        <div>
          {onBack && (
            <Button type="button" variant="outline" onClick={onBack}>
              &larr; Back to Stage 4
            </Button>
          )}
        </div>
        <Button type="submit" disabled={!dispatchGate.allowed} className="stage-primary-cta">
          Verify Parts &amp; Create Dispatch Order
        </Button>
      </div>
    </form>
  );
}
