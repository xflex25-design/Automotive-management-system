import { useEffect, useState, type ChangeEvent, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Check, CheckCircle2, Lock, Save, Upload } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import type { IntakeAccessoryRecord, IntakeDetails, Vehicle } from "@/lib/workshop";
import { createDefaultAccessoriesChecklist } from "@/lib/workshop-flow";

type Stage1IntakeFormProps = {
  vehicle?: Vehicle;
  bannerExtra?: ReactNode;
  onSaved?: (vehicle: Vehicle, advanceToQuotation: boolean) => void;
};

type IntakeSubTab = "customer_vehicle" | "accessories_condition" | "scope_authorization";

const FUEL_LEVELS = ["Empty", "1/4", "1/2", "3/4", "Full"] as const;

export function Stage1IntakeForm({ vehicle, onSaved }: Stage1IntakeFormProps) {
  const { vehicles, setVehicles, setInventory, foreman, addActivity } = useWorkspace();

  const todayIso = new Date().toISOString().slice(0, 10);
  const [activeSubTab, setActiveSubTab] = useState<IntakeSubTab>("customer_vehicle");

  const [customerName, setCustomerName] = useState(vehicle?.customer ?? "");
  const [phone, setPhone] = useState(vehicle?.phone ?? "");
  const [dateReceived, setDateReceived] = useState(todayIso);
  const [email, setEmail] = useState(vehicle?.email ?? "");
  const [customerType, setCustomerType] = useState<"Individual" | "Corporate">(
    vehicle?.intakeDetails?.customerType ?? "Individual",
  );
  const [customerAddress, setCustomerAddress] = useState(
    vehicle?.intakeDetails?.customerAddress ?? "",
  );

  const [plate, setPlate] = useState(vehicle?.plate ?? "");
  const [make, setMake] = useState(() => {
    if (!vehicle?.make) return "";
    const parts = vehicle.make.split(" ");
    return parts[0] ?? vehicle.make;
  });
  const [model, setModel] = useState(() => {
    if (vehicle?.intakeDetails?.model) return vehicle.intakeDetails.model;
    if (!vehicle?.make) return "";
    const parts = vehicle.make.split(" ");
    return parts.slice(1).join(" ");
  });
  const [year, setYear] = useState(vehicle?.intakeDetails?.year ?? "");
  const [vin, setVin] = useState(vehicle?.vin ?? "");
  const [engineNumber, setEngineNumber] = useState(vehicle?.intakeDetails?.engineNumber ?? "");
  const [driverName, setDriverName] = useState(vehicle?.intakeDetails?.driverName ?? "");

  const [mileageIn, setMileageIn] = useState(
    vehicle?.intakeDetails?.mileageIn !== undefined
      ? String(vehicle.intakeDetails.mileageIn)
      : vehicle?.odometer !== undefined
        ? String(vehicle.odometer)
        : "",
  );
  const [fuelLevelIn, setFuelLevelIn] = useState<IntakeDetails["fuelLevelIn"]>(
    vehicle?.intakeDetails?.fuelLevelIn ?? "Full",
  );

  const [accessories, setAccessories] = useState<IntakeAccessoryRecord[]>(
    vehicle?.intakeDetails?.accessories ?? createDefaultAccessoriesChecklist(),
  );

  const [damageTypes, setDamageTypes] = useState<Array<"Chip" | "Dent" | "Scratch">>(
    vehicle?.intakeDetails?.damageTypes ?? [],
  );
  const [damageDescription, setDamageDescription] = useState(vehicle?.damage ?? "");
  const [additionalRemarks, setAdditionalRemarks] = useState(
    vehicle?.intakeDetails?.additionalRemarks ?? "",
  );
  const [photos, setPhotos] = useState<string[]>(vehicle?.photos ?? []);

  const [complaints, setComplaints] = useState(vehicle?.complaints ?? "");
  const [requestedRepairs, setRequestedRepairs] = useState(
    vehicle?.intakeDetails?.requestedRepairs ?? "",
  );
  const [additionalInstructions, setAdditionalInstructions] = useState(
    vehicle?.intakeDetails?.additionalInstructions ?? "",
  );

  const [termsAccepted, setTermsAccepted] = useState(vehicle?.intakeDetails?.termsAccepted ?? true);
  const [customerSignature, setCustomerSignature] = useState(
    vehicle?.intakeDetails?.customerSignature ?? "",
  );
  const [intakeOfficer, setIntakeOfficer] = useState(
    vehicle?.intakeDetails?.intakeOfficer ?? foreman,
  );
  const [authorizationDate, setAuthorizationDate] = useState(
    vehicle?.intakeDetails?.authorizationDate ?? todayIso,
  );

  const [deliveredBy, setDeliveredBy] = useState(vehicle?.intakeDetails?.deliveredBy ?? "Self");
  const [deliveredPhone, setDeliveredPhone] = useState(
    vehicle?.intakeDetails?.deliveredPhone ?? "",
  );
  const [receivedBy, setReceivedBy] = useState(vehicle?.intakeDetails?.receivedBy ?? foreman);
  const [receivedSignature, setReceivedSignature] = useState(
    vehicle?.intakeDetails?.receivedSignature ?? foreman,
  );

  // Progressive disclosure toggles inspired by "+ Add Your Company Name"
  const [showOptionalCustomer, setShowOptionalCustomer] = useState(
    Boolean(
      vehicle?.email ||
      vehicle?.intakeDetails?.customerAddress ||
      vehicle?.intakeDetails?.customerType === "Corporate",
    ),
  );
  const [showOptionalVehicle, setShowOptionalVehicle] = useState(
    Boolean(
      vehicle?.vin ||
      vehicle?.intakeDetails?.year ||
      vehicle?.intakeDetails?.engineNumber ||
      vehicle?.intakeDetails?.driverName,
    ),
  );
  const [showOptionalScope, setShowOptionalScope] = useState(
    Boolean(
      vehicle?.intakeDetails?.requestedRepairs || vehicle?.intakeDetails?.additionalInstructions,
    ),
  );
  const [showOfficerDetails, setShowOfficerDetails] = useState(false);

  const selfDelivered = deliveredBy.trim().toLowerCase() === "self";

  useEffect(() => {
    if (!vehicle) return;
    setCustomerName(vehicle.customer ?? "");
    setPhone(vehicle.phone ?? "");
    setEmail(vehicle.email ?? "");
    setCustomerType(vehicle.intakeDetails?.customerType ?? "Individual");
    setCustomerAddress(vehicle.intakeDetails?.customerAddress ?? "");
    setPlate(vehicle.plate ?? "");
    const parts = (vehicle.make ?? "").split(" ");
    setMake(parts[0] ?? "");
    setModel(vehicle.intakeDetails?.model ?? parts.slice(1).join(" "));
    setYear(vehicle.intakeDetails?.year ?? "");
    setVin(vehicle.vin ?? "");
    setEngineNumber(vehicle.intakeDetails?.engineNumber ?? "");
    setDriverName(vehicle.intakeDetails?.driverName ?? "");
    setMileageIn(
      vehicle.intakeDetails?.mileageIn !== undefined
        ? String(vehicle.intakeDetails.mileageIn)
        : vehicle.odometer !== undefined
          ? String(vehicle.odometer)
          : "",
    );
    setFuelLevelIn(vehicle.intakeDetails?.fuelLevelIn ?? "Full");
    setAccessories(vehicle.intakeDetails?.accessories ?? createDefaultAccessoriesChecklist());
    setDamageTypes(vehicle.intakeDetails?.damageTypes ?? []);
    setDamageDescription(vehicle.damage ?? "");
    setAdditionalRemarks(vehicle.intakeDetails?.additionalRemarks ?? "");
    setPhotos(vehicle.photos ?? []);
    setComplaints(vehicle.complaints ?? "");
    setRequestedRepairs(vehicle.intakeDetails?.requestedRepairs ?? "");
    setAdditionalInstructions(vehicle.intakeDetails?.additionalInstructions ?? "");
    setTermsAccepted(vehicle.intakeDetails?.termsAccepted ?? true);
    setCustomerSignature(vehicle.intakeDetails?.customerSignature ?? "");
    setIntakeOfficer(vehicle.intakeDetails?.intakeOfficer ?? foreman);
    setAuthorizationDate(vehicle.intakeDetails?.authorizationDate ?? todayIso);
    setDeliveredBy(vehicle.intakeDetails?.deliveredBy ?? "Self");
    setDeliveredPhone(vehicle.intakeDetails?.deliveredPhone ?? vehicle.phone ?? "");
    setReceivedBy(vehicle.intakeDetails?.receivedBy ?? foreman);
    setReceivedSignature(vehicle.intakeDetails?.receivedSignature ?? foreman);
    setShowOptionalCustomer(
      Boolean(
        vehicle.email ||
        vehicle.intakeDetails?.customerAddress ||
        vehicle.intakeDetails?.customerType === "Corporate",
      ),
    );
    setShowOptionalVehicle(
      Boolean(
        vehicle.vin ||
        vehicle.intakeDetails?.year ||
        vehicle.intakeDetails?.engineNumber ||
        vehicle.intakeDetails?.driverName,
      ),
    );
    setShowOptionalScope(
      Boolean(
        vehicle.intakeDetails?.requestedRepairs || vehicle.intakeDetails?.additionalInstructions,
      ),
    );
  }, [vehicle, foreman, todayIso]);

  function handleAccessoryChange(index: number, patch: Partial<IntakeAccessoryRecord>) {
    setAccessories((prev) => prev.map((row, idx) => (idx === index ? { ...row, ...patch } : row)));
  }

  function markAllAccessoriesAvailable() {
    setAccessories((prev) =>
      prev.map((row) => ({ ...row, available: true, condition: "Good" as const })),
    );
    toast.success("All accessories marked available in good condition.");
  }

  function toggleDamageType(type: "Chip" | "Dent" | "Scratch") {
    setDamageTypes((prev) =>
      prev.includes(type) ? prev.filter((item) => item !== type) : [...prev, type],
    );
  }

  function handlePhotoUpload(event: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.target.files ?? []);
    if (files.length === 0) return;
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === "string") {
          const dataUrl = reader.result;
          setPhotos((prev) => [...prev, dataUrl]);
        }
      };
      reader.readAsDataURL(file);
    });
  }

  const tab1Done =
    Boolean(customerName.trim()) &&
    Boolean(phone.trim()) &&
    Boolean(plate.trim()) &&
    Boolean(make.trim());
  const tab2Done =
    Boolean(mileageIn.trim()) && !Number.isNaN(Number(mileageIn)) && Number(mileageIn) >= 0;
  const tab3Done =
    Boolean(complaints.trim()) &&
    termsAccepted &&
    Boolean(customerSignature.trim()) &&
    Boolean(authorizationDate.trim());

  const missingSummary: string[] = [];
  if (!customerName.trim()) missingSummary.push("Customer Name");
  if (!phone.trim()) missingSummary.push("Phone Number");
  if (!plate.trim()) missingSummary.push("Registration No.");
  if (!make.trim()) missingSummary.push("Vehicle Make");
  if (!tab2Done) missingSummary.push("Mileage / KM In");
  if (!complaints.trim()) missingSummary.push("Customer's Reported Problem");
  if (!termsAccepted) missingSummary.push("Accept Intake Conditions");
  if (!customerSignature.trim()) missingSummary.push("Customer Signature");

  function persistIntake(mode: "draft" | "inspection" | "proceed") {
    const cleanPlate = plate.trim().toUpperCase();
    const cleanCustomer = customerName.trim();
    const cleanPhone = phone.trim();
    const cleanMake = make.trim();
    const cleanComplaints = complaints.trim();

    if (mode !== "draft") {
      if (!tab1Done) {
        setActiveSubTab("customer_vehicle");
        toast.error("Please fill Customer Name, Phone, Registration No., and Vehicle Make.");
        return;
      }
      if (!tab2Done) {
        setActiveSubTab("accessories_condition");
        toast.error("Please enter a valid incoming Mileage (km).");
        return;
      }
      if (!tab3Done) {
        setActiveSubTab("scope_authorization");
        toast.error("Reported problem, terms acceptance, and customer signature are required.");
        return;
      }
    }

    const existingConflict = vehicles.find(
      (v) => v.plate === cleanPlate && !v.released && v.id !== vehicle?.id,
    );
    if (existingConflict && cleanPlate) {
      toast.error("This registration already has an active workshop record.");
      return;
    }

    const maxId = vehicles.reduce((max, item) => {
      const match = item.id.match(/^VR-(\d+)$/);
      return match ? Math.max(max, Number(match[1])) : max;
    }, 1060);
    const id = vehicle?.id ?? `VR-${maxId + 1}`;
    const receivedLabel =
      vehicle?.received ||
      new Date(dateReceived || todayIso).toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });

    const intakeDetails: IntakeDetails = {
      ...vehicle?.intakeDetails,
      customerType,
      customerAddress: customerAddress.trim(),
      driverName: driverName.trim() || cleanCustomer,
      model: model.trim(),
      year: year.trim(),
      engineNumber: engineNumber.trim(),
      mileageIn: Number(mileageIn || 0),
      fuelLevelIn,
      accessories,
      damageTypes,
      additionalRemarks: additionalRemarks.trim(),
      requestedRepairs: requestedRepairs.trim(),
      additionalInstructions: additionalInstructions.trim(),
      termsAccepted,
      customerSignature: customerSignature.trim(),
      intakeOfficer: intakeOfficer.trim() || foreman,
      authorizationDate,
      deliveredBy: deliveredBy.trim() || "Self",
      deliveredPhone: deliveredPhone.trim() || cleanPhone,
      receivedBy: receivedBy.trim() || foreman,
      receivedSignature: receivedSignature.trim() || foreman,
      status: mode === "draft" ? "draft" : "completed",
    };

    const fullMake = [cleanMake, model.trim()].filter(Boolean).join(" ") || cleanMake || "Vehicle";
    const nextStage = mode === "proceed" ? Math.max(vehicle?.stage ?? 0, 1) : (vehicle?.stage ?? 0);

    const savedVehicle: Vehicle = {
      ...(vehicle ?? {
        id,
        department: "Unassigned",
        foreman,
        due: "",
        progress: 0,
      }),
      id,
      plate: cleanPlate || "DRAFT",
      make: fullMake,
      customer: cleanCustomer || "Draft Customer",
      phone: cleanPhone,
      email: email.trim(),
      received: receivedLabel,
      stage: nextStage,
      complaints: cleanComplaints,
      damage: damageDescription.trim() || additionalRemarks.trim() || "No visible external damage",
      ...(vin.trim() ? { vin: vin.trim().toUpperCase() } : {}),
      ...(mileageIn.trim() ? { odometer: Number(mileageIn) } : {}),
      ...(photos.length > 0 ? { photos } : {}),
      intakeDetails,
    };

    setVehicles((prev) => {
      const exists = prev.some((item) => item.id === savedVehicle.id);
      return exists
        ? prev.map((item) => (item.id === savedVehicle.id ? savedVehicle : item))
        : [savedVehicle, ...prev];
    });

    const availableAccessoryNames = accessories
      .filter((a) => a.available)
      .map((a) => `${a.name} (${a.condition})`)
      .join(", ");

    setInventory((prev) => {
      const existingCard = prev.find((card) => card.vehicleId === savedVehicle.id);
      const nextCard = {
        id: existingCard?.id ?? `INV-${savedVehicle.id.replace("VR-", "")}`,
        vehicleId: savedVehicle.id,
        items: availableAccessoryNames || "No accessories listed",
        condition: savedVehicle.damage,
        date: receivedLabel,
      };
      return existingCard
        ? prev.map((c) => (c.vehicleId === savedVehicle.id ? nextCard : c))
        : [nextCard, ...prev];
    });

    if (mode === "draft") {
      toast.success(`Intake draft saved for ${savedVehicle.plate}.`);
    } else if (mode === "inspection") {
      addActivity(
        `Intake inspection recorded: ${savedVehicle.make}`,
        `${intakeOfficer || foreman} · ${savedVehicle.id}`,
      );
      toast.success(`Vehicle inspection saved for ${savedVehicle.plate}.`);
    } else {
      addActivity(
        `Stage 1 Intake completed: ${savedVehicle.make}`,
        `${intakeOfficer || foreman} · ${savedVehicle.id} → Stage 2 Quotation`,
      );
      toast.success(`${savedVehicle.plate} intake completed. Proceeding to Stage 2 Quotation.`);
    }

    onSaved?.(savedVehicle, mode === "proceed");
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    persistIntake("proceed");
  }

  const subTabs: Array<{ id: IntakeSubTab; label: string; done: boolean }> = [
    { id: "customer_vehicle", label: "1. Customer & Vehicle", done: tab1Done },
    { id: "accessories_condition", label: "2. Accessories & Condition", done: tab2Done },
    { id: "scope_authorization", label: "3. Job Scope & Sign-Off", done: tab3Done },
  ];

  return (
    <form onSubmit={handleSubmit} noValidate className="stage-form-stack">
      {/* Guided Section Switcher */}
      <div className="stage-subtabs-bar" role="tablist" aria-label="Stage 1 Intake Sections">
        {subTabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            role="tab"
            aria-selected={activeSubTab === tab.id}
            data-active={activeSubTab === tab.id}
            className="stage-subtab-btn"
            onClick={() => setActiveSubTab(tab.id)}
          >
            {tab.done && <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {activeSubTab === "customer_vehicle" && (
        <>
          {/* Quick Check-In Option Card */}
          <div className="stage-card">
            <div className="stage-card-head !mb-2">
              <h3 className="stage-card-title">Check-In Options</h3>
            </div>
            <label className="flex items-start gap-3 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={selfDelivered}
                onChange={(e) => {
                  if (e.target.checked) {
                    setDeliveredBy("Self");
                    setDriverName(customerName.trim());
                  } else {
                    setDeliveredBy("Driver");
                    setShowOptionalVehicle(true);
                  }
                }}
                className="accent-primary mt-1 h-4 w-4"
              />
              <span>
                Customer dropped off the vehicle in person. Driver and contact details match the
                customer record below.
              </span>
            </label>
          </div>

          {/* Customer Information Card */}
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Customer Information</h3>
                <p className="stage-card-subtitle">
                  Primary owner or fleet contact for this repair
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s1-customer-name">
                    <span className="text-red-600">*</span> Customer Name
                  </label>
                  <Input
                    id="s1-customer-name"
                    className="stage-input"
                    placeholder="John Mwale"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                  />
                </div>
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s1-phone">
                    <span className="text-red-600">*</span> Phone Number
                  </label>
                  <Input
                    id="s1-phone"
                    className="stage-input"
                    placeholder="0977 123 456"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>
              </div>

              <button
                type="button"
                className="stage-link-toggle"
                onClick={() => setShowOptionalCustomer((prev) => !prev)}
              >
                {showOptionalCustomer
                  ? "− Hide Email, Customer Type & Address"
                  : "+ Add Email, Customer Type & Address (Optional)"}
              </button>

              {showOptionalCustomer && (
                <div className="pt-2 space-y-4 border-t border-slate-100">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="stage-field">
                      <label className="stage-field-label" htmlFor="s1-email">
                        Email Address
                      </label>
                      <Input
                        id="s1-email"
                        type="email"
                        className="stage-input"
                        placeholder="john@example.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                      />
                    </div>
                    <div className="stage-field">
                      <label className="stage-field-label" htmlFor="s1-customer-type">
                        Customer Type
                      </label>
                      <Select
                        value={customerType}
                        onValueChange={(value) =>
                          setCustomerType(value as "Individual" | "Corporate")
                        }
                      >
                        <SelectTrigger id="s1-customer-type" className="stage-select-trigger">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Individual">Individual</SelectItem>
                          <SelectItem value="Corporate">Corporate</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="stage-field">
                      <label className="stage-field-label" htmlFor="s1-date-received">
                        Date Received
                      </label>
                      <Input
                        id="s1-date-received"
                        type="date"
                        className="stage-input"
                        value={dateReceived}
                        onChange={(e) => setDateReceived(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-address">
                      Customer Address
                    </label>
                    <Input
                      id="s1-address"
                      className="stage-input"
                      placeholder="Plot 123, Lusaka"
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Vehicle Information Card */}
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Vehicle Details</h3>
                <p className="stage-card-subtitle">Registration plate and model identification</p>
              </div>
              {customerName.trim() && (
                <button
                  type="button"
                  className="stage-link-toggle"
                  onClick={() => {
                    setDriverName(customerName.trim());
                    setShowOptionalVehicle(true);
                  }}
                >
                  Driver = Customer
                </button>
              )}
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s1-plate">
                    <span className="text-red-600">*</span> Registration No.
                  </label>
                  <Input
                    id="s1-plate"
                    className="stage-input uppercase font-mono"
                    placeholder="BAK 6213"
                    value={plate}
                    onChange={(e) => setPlate(e.target.value.toUpperCase())}
                  />
                </div>
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s1-make">
                    <span className="text-red-600">*</span> Vehicle Make
                  </label>
                  <Input
                    id="s1-make"
                    className="stage-input"
                    placeholder="Toyota"
                    value={make}
                    onChange={(e) => setMake(e.target.value)}
                  />
                </div>
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s1-model">
                    Vehicle Model
                  </label>
                  <Input
                    id="s1-model"
                    className="stage-input"
                    placeholder="Hilux"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                  />
                </div>
              </div>

              <button
                type="button"
                className="stage-link-toggle"
                onClick={() => setShowOptionalVehicle((prev) => !prev)}
              >
                {showOptionalVehicle
                  ? "− Hide VIN, Year, Engine No. & Driver"
                  : "+ Add VIN / Chassis No., Year, Engine No. & Driver (Optional)"}
              </button>

              {showOptionalVehicle && (
                <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-slate-100">
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-vin">
                      VIN / Chassis No.
                    </label>
                    <Input
                      id="s1-vin"
                      className="stage-input uppercase font-mono"
                      placeholder="JTDFX23G700012345"
                      value={vin}
                      onChange={(e) => setVin(e.target.value.toUpperCase())}
                    />
                  </div>
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-driver">
                      Driver&apos;s Name
                    </label>
                    <Input
                      id="s1-driver"
                      className="stage-input"
                      placeholder="Driver name (or Self)"
                      value={driverName}
                      onChange={(e) => setDriverName(e.target.value)}
                    />
                  </div>
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-year">
                      Year
                    </label>
                    <Input
                      id="s1-year"
                      className="stage-input"
                      placeholder="2016"
                      value={year}
                      onChange={(e) => setYear(e.target.value)}
                    />
                  </div>
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-engine">
                      Engine No.
                    </label>
                    <Input
                      id="s1-engine"
                      className="stage-input font-mono"
                      placeholder="1KD-456789"
                      value={engineNumber}
                      onChange={(e) => setEngineNumber(e.target.value)}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {activeSubTab === "accessories_condition" && (
        <>
          {/* Incoming Fuel & Mileage */}
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Incoming Fuel &amp; Odometer</h3>
                <p className="stage-card-subtitle">
                  Outgoing fuel and mileage are recorded at Stage 8 Final Release
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-end">
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s1-mileage-in">
                  <span className="text-red-600">*</span> Mileage / KM In
                </label>
                <div className="flex items-center gap-2">
                  <Input
                    id="s1-mileage-in"
                    type="number"
                    min={0}
                    className="stage-input tabular-nums"
                    placeholder="120000"
                    value={mileageIn}
                    onChange={(e) => setMileageIn(e.target.value)}
                  />
                  <span className="text-xs font-medium text-muted-foreground shrink-0">km</span>
                </div>
              </div>
              <div className="stage-field">
                <span className="stage-field-label">
                  <span className="text-red-600">*</span> Fuel Level (IN)
                </span>
                <div className="flex flex-wrap items-center gap-3 min-h-[42px] px-3 rounded-md border border-slate-300 bg-white text-xs">
                  {FUEL_LEVELS.map((lvl) => (
                    <label key={lvl} className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="s1_fuel_in"
                        checked={fuelLevelIn === lvl}
                        onChange={() => setFuelLevelIn(lvl)}
                        className="accent-primary"
                      />
                      <span className="font-medium text-slate-700">{lvl}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Accessories Checklist */}
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Vehicle Accessories Checklist</h3>
                <p className="stage-card-subtitle">
                  Verify loose items present at vehicle check-in
                </p>
              </div>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={markAllAccessoriesAvailable}
              >
                <Check size={13} />
                Mark All Available &amp; Good
              </Button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b bg-slate-50 text-slate-600">
                    <th className="py-2.5 px-2.5 font-semibold">Accessory</th>
                    <th className="py-2.5 px-2.5 font-semibold text-center">Available</th>
                    <th className="py-2.5 px-2.5 font-semibold text-center">Missing</th>
                    <th className="py-2.5 px-2.5 font-semibold">Condition</th>
                    <th className="py-2.5 px-2.5 font-semibold">Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {accessories.map((row, idx) => (
                    <tr key={row.name}>
                      <td className="py-2 px-2.5 font-medium whitespace-nowrap text-slate-800">
                        {row.name}
                      </td>
                      <td className="py-2 px-2.5 text-center">
                        <input
                          type="radio"
                          name={`s1_acc_${idx}`}
                          aria-label={`${row.name} available`}
                          checked={row.available}
                          onChange={() => handleAccessoryChange(idx, { available: true })}
                          className="accent-primary"
                        />
                      </td>
                      <td className="py-2 px-2.5 text-center">
                        <input
                          type="radio"
                          name={`s1_acc_${idx}`}
                          aria-label={`${row.name} missing`}
                          checked={!row.available}
                          onChange={() => handleAccessoryChange(idx, { available: false })}
                          className="accent-primary"
                        />
                      </td>
                      <td className="py-1.5 px-2.5">
                        <Select
                          value={row.condition}
                          onValueChange={(value) =>
                            handleAccessoryChange(idx, {
                              condition: value as IntakeAccessoryRecord["condition"],
                            })
                          }
                        >
                          <SelectTrigger
                            className="h-8 text-xs w-28 border-slate-300"
                            aria-label={`${row.name} condition`}
                          >
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Good">Good</SelectItem>
                            <SelectItem value="Fair">Fair</SelectItem>
                            <SelectItem value="Damaged">Damaged</SelectItem>
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="py-1.5 px-2.5">
                        <Input
                          className="h-8 text-xs border-slate-300"
                          aria-label={`${row.name} remarks`}
                          placeholder="Remarks"
                          value={row.remarks}
                          onChange={(e) => handleAccessoryChange(idx, { remarks: e.target.value })}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Condition & Damage Inspection */}
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Condition &amp; Damage Inspection</h3>
                <p className="stage-card-subtitle">
                  Note pre-existing body marks or upload check-in photos
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-5 text-xs">
                <span className="font-semibold text-slate-700">Existing Damages:</span>
                {(["Chip", "Dent", "Scratch"] as const).map((type) => (
                  <label key={type} className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={damageTypes.includes(type)}
                      onChange={() => toggleDamageType(type)}
                      className="accent-primary"
                    />
                    <span>
                      {type} ({type[0]})
                    </span>
                  </label>
                ))}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s1-damage-desc">
                    Damage Description
                  </label>
                  <Textarea
                    id="s1-damage-desc"
                    className="stage-textarea"
                    placeholder="Small scratch on rear bumper"
                    value={damageDescription}
                    onChange={(e) => setDamageDescription(e.target.value)}
                  />
                </div>
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s1-additional-remarks">
                    Additional Remarks
                  </label>
                  <Textarea
                    id="s1-additional-remarks"
                    className="stage-textarea"
                    placeholder="No major damage"
                    value={additionalRemarks}
                    onChange={(e) => setAdditionalRemarks(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3 pt-1">
                <label
                  htmlFor="s1-photo-upload"
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-md border border-primary/40 bg-accent text-primary text-xs font-semibold cursor-pointer hover:bg-accent/80"
                >
                  <Upload size={14} />
                  Upload Inspection Photos
                </label>
                <input
                  id="s1-photo-upload"
                  type="file"
                  accept="image/*"
                  multiple
                  className="sr-only"
                  onChange={handlePhotoUpload}
                />
                <span className="text-xs text-muted-foreground">
                  {photos.length > 0 ? `${photos.length} photo(s) attached` : "No photos chosen"}
                </span>
              </div>
            </div>
          </div>
        </>
      )}

      {activeSubTab === "scope_authorization" && (
        <>
          {/* Job to Be Done Card */}
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Job Scope &amp; Reported Problem</h3>
                <p className="stage-card-subtitle">
                  Capture what the customer needs inspected or repaired
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s1-complaints">
                  <span className="text-red-600">*</span> Customer&apos;s Reported Problem
                </label>
                <Textarea
                  id="s1-complaints"
                  className="stage-textarea"
                  placeholder="Service and brake check"
                  value={complaints}
                  onChange={(e) => setComplaints(e.target.value)}
                />
              </div>

              <button
                type="button"
                className="stage-link-toggle"
                onClick={() => setShowOptionalScope((prev) => !prev)}
              >
                {showOptionalScope
                  ? "− Hide Requested Repairs & Additional Instructions"
                  : "+ Add Requested Repairs & Special Instructions (Optional)"}
              </button>

              {showOptionalScope && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-requested-repairs">
                      Requested Repairs
                    </label>
                    <Textarea
                      id="s1-requested-repairs"
                      className="stage-textarea"
                      placeholder="Full service, replace filters & inspect brakes"
                      value={requestedRepairs}
                      onChange={(e) => setRequestedRepairs(e.target.value)}
                    />
                  </div>
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-additional-instructions">
                      Additional Instructions
                    </label>
                    <Textarea
                      id="s1-additional-instructions"
                      className="stage-textarea"
                      placeholder="Contact customer before extra work"
                      value={additionalInstructions}
                      onChange={(e) => setAdditionalInstructions(e.target.value)}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Intake Authorization & Check-In Sign-Off Card */}
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Intake Authorization Sign-Off</h3>
                <p className="stage-card-subtitle">
                  Customer acknowledgement before generating Stage 2 Quotation
                </p>
              </div>
              {customerName.trim() && (
                <button
                  type="button"
                  className="stage-link-toggle"
                  onClick={() => setCustomerSignature(customerName.trim())}
                >
                  Copy Customer Name
                </button>
              )}
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s1-customer-sig">
                    <span className="text-red-600">*</span> Customer Signature
                  </label>
                  <Input
                    id="s1-customer-sig"
                    className="stage-input"
                    placeholder="Type customer full name to sign"
                    value={customerSignature}
                    onChange={(e) => setCustomerSignature(e.target.value)}
                  />
                </div>
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s1-auth-date">
                    <span className="text-red-600">*</span> Authorization Date
                  </label>
                  <Input
                    id="s1-auth-date"
                    type="date"
                    className="stage-input"
                    value={authorizationDate}
                    onChange={(e) => setAuthorizationDate(e.target.value)}
                  />
                </div>
              </div>

              <label className="flex items-start gap-2.5 text-xs font-medium text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={termsAccepted}
                  onChange={(e) => setTermsAccepted(e.target.checked)}
                  className="accent-primary mt-0.5 h-4 w-4"
                />
                <span>
                  I agree to the workshop inspection and vehicle inventory conditions.{" "}
                  <span className="text-red-600">*</span>
                </span>
              </label>

              <div className="flex items-start gap-2.5 text-xs text-slate-500 pt-1">
                <Lock size={14} className="text-slate-400 shrink-0 mt-0.5" />
                <p>
                  Your inspection record is locked to this vehicle check-in. We compare incoming
                  fuel, odometer, and accessories against final handover at Stage 8.
                </p>
              </div>

              <button
                type="button"
                className="stage-link-toggle"
                onClick={() => setShowOfficerDetails((prev) => !prev)}
              >
                {showOfficerDetails
                  ? "− Hide Check-In Officer & Delivery Details"
                  : "+ Edit Check-In Officer & Delivery Details"}
              </button>

              {showOfficerDetails && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-intake-officer">
                      Intake Officer
                    </label>
                    <Input
                      id="s1-intake-officer"
                      className="stage-input"
                      value={intakeOfficer}
                      onChange={(e) => setIntakeOfficer(e.target.value)}
                    />
                  </div>
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-delivered-by">
                      Delivered By
                    </label>
                    <Input
                      id="s1-delivered-by"
                      className="stage-input"
                      value={deliveredBy}
                      onChange={(e) => setDeliveredBy(e.target.value)}
                    />
                  </div>
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-delivered-phone">
                      Delivery Contact Phone
                    </label>
                    <Input
                      id="s1-delivered-phone"
                      className="stage-input"
                      placeholder={phone || "0977 123 456"}
                      value={deliveredPhone}
                      onChange={(e) => setDeliveredPhone(e.target.value)}
                    />
                  </div>
                  <div className="stage-field">
                    <label className="stage-field-label" htmlFor="s1-received-by">
                      Received &amp; Checked By
                    </label>
                    <Input
                      id="s1-received-by"
                      className="stage-input"
                      value={receivedBy}
                      onChange={(e) => setReceivedBy(e.target.value)}
                    />
                  </div>
                  <div className="stage-field sm:col-span-2">
                    <label className="stage-field-label" htmlFor="s1-received-sig">
                      Officer Signature
                    </label>
                    <Input
                      id="s1-received-sig"
                      className="stage-input"
                      value={receivedSignature}
                      onChange={(e) => setReceivedSignature(e.target.value)}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </>
      )}

      {missingSummary.length > 0 && (
        <div className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-2.5 text-xs text-amber-900">
          <strong>Remaining to complete Intake:</strong> {missingSummary.join(", ")}
        </div>
      )}

      {/* Clean Checkout-Style Action Footer */}
      <div className="stage-cta-bar">
        <div className="flex items-center gap-2">
          {activeSubTab !== "customer_vehicle" && (
            <Button
              type="button"
              variant="outline"
              onClick={() =>
                setActiveSubTab(
                  activeSubTab === "scope_authorization"
                    ? "accessories_condition"
                    : "customer_vehicle",
                )
              }
            >
              &larr; Previous Section
            </Button>
          )}
          {activeSubTab !== "scope_authorization" && (
            <Button
              type="button"
              variant="outline"
              onClick={() =>
                setActiveSubTab(
                  activeSubTab === "customer_vehicle"
                    ? "accessories_condition"
                    : "scope_authorization",
                )
              }
            >
              Next Section &rarr;
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2.5 flex-wrap">
          <Button type="button" variant="outline" onClick={() => persistIntake("draft")}>
            <Save size={14} />
            Save Draft
          </Button>
          <Button type="button" variant="outline" onClick={() => persistIntake("inspection")}>
            <Check size={14} />
            Save Inspection
          </Button>
          <Button type="submit" className="stage-primary-cta">
            Save Intake &amp; Proceed to Quotation
          </Button>
        </div>
      </div>
    </form>
  );
}
