import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Save, Trash2 } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import { money, type JobCard, type Quotation, type Vehicle } from "@/lib/workshop";
import {
  calculateQuotationTotals,
  DEFAULT_QUOTATION_STARTER_ITEMS,
  QUOTATION_SERVICE_PRESETS,
} from "@/lib/workshop-flow";

type QuotationLineDraft = {
  id: string;
  itemType: "PART" | "LABOUR" | "SERVICE" | "OTHER";
  item: string;
  description: string;
  quantity: number;
  unitPrice: number;
};

type Stage2QuotationFormProps = {
  vehicle: Vehicle;
  quotation?: Quotation;
  job?: JobCard;
  bannerExtra?: ReactNode;
  onSaved?: (quotation: Quotation, advanceToAuthorization: boolean) => void;
  onBack?: () => void;
};

export function Stage2QuotationForm({
  vehicle,
  quotation,
  job,
  onSaved,
  onBack,
}: Stage2QuotationFormProps) {
  const { quotations, setQuotations, updateVehicleStage, foreman, addActivity } = useWorkspace();

  const todayIso = new Date().toISOString().slice(0, 10);
  const nextQuotationNumber = useMemo(() => {
    if (quotation?.id) return quotation.id;
    const maxNum = quotations.reduce((max, item) => {
      const m = item.id.match(/^QT-(\d+)$/);
      return m ? Math.max(max, Number(m[1])) : max;
    }, 1020);
    return `QT-${maxNum + 1}`;
  }, [quotation?.id, quotations]);

  const [quotationNumber, setQuotationNumber] = useState(nextQuotationNumber);
  const [quotationDate, setQuotationDate] = useState(quotation?.quotationDate ?? todayIso);
  const [salesperson, setSalesperson] = useState(
    quotation?.paperFields?.["salesperson"] ?? "Workshop Sales Officer",
  );
  const [preparedBy, setPreparedBy] = useState(quotation?.preparedByName ?? foreman);
  const [signature, setSignature] = useState(quotation?.paperFields?.["signature"] ?? foreman);

  const [items, setItems] = useState<QuotationLineDraft[]>(() => {
    if (quotation?.items && quotation.items.length > 0) {
      return quotation.items.map((line, index) => ({
        id: `qline-${index}`,
        itemType: line.itemType,
        item: line.item,
        description: line.description,
        quantity: line.quantity,
        unitPrice: line.unitPrice,
      }));
    }
    return DEFAULT_QUOTATION_STARTER_ITEMS.map((line, index) => ({
      ...line,
      id: `qline-${index}`,
    }));
  });

  useEffect(() => {
    setQuotationNumber(nextQuotationNumber);
    setQuotationDate(quotation?.quotationDate ?? todayIso);
    setSalesperson(quotation?.paperFields?.["salesperson"] ?? "Workshop Sales Officer");
    setPreparedBy(quotation?.preparedByName ?? foreman);
    setSignature(quotation?.paperFields?.["signature"] ?? foreman);
    if (quotation?.items && quotation.items.length > 0) {
      setItems(
        quotation.items.map((line, index) => ({
          id: `qline-${index}`,
          itemType: line.itemType,
          item: line.item,
          description: line.description,
          quantity: line.quantity,
          unitPrice: line.unitPrice,
        })),
      );
    }
  }, [quotation, nextQuotationNumber, foreman, todayIso]);

  const totals = useMemo(() => calculateQuotationTotals(items), [items]);

  function addRow() {
    setItems((prev) => [
      ...prev,
      {
        id: `qline-${Date.now()}-${prev.length}`,
        itemType: "PART",
        item: "",
        description: "",
        quantity: 1,
        unitPrice: 0,
      },
    ]);
  }

  function removeRow(id: string) {
    if (items.length <= 1) {
      toast.error("At least one quotation line item is required.");
      return;
    }
    setItems((prev) => prev.filter((row) => row.id !== id));
  }

  function updateRow(id: string, patch: Partial<QuotationLineDraft>) {
    setItems((prev) => prev.map((row) => (row.id === id ? { ...row, ...patch } : row)));
  }

  function applyPreset(presetId: string) {
    const preset = QUOTATION_SERVICE_PRESETS.find((item) => item.id === presetId);
    if (!preset) return;
    setItems(
      preset.items.map((line, index) => ({
        ...line,
        id: `qline-preset-${Date.now()}-${index}`,
      })),
    );
    toast.success(`Applied "${preset.label}" quotation template.`);
  }

  function saveQuotation(issueAndProceed: boolean) {
    const validItems = items.filter(
      (line) => (line.item.trim() || line.description.trim()) && line.quantity > 0,
    );
    if (validItems.length === 0) {
      toast.error("Add at least one quotation item with quantity greater than 0.");
      return;
    }
    if (issueAndProceed && totals.total <= 0) {
      toast.error("Quotation total amount must be greater than zero before issuing.");
      return;
    }
    if (issueAndProceed && (!preparedBy.trim() || !signature.trim())) {
      toast.error("Prepared by and signature are required to issue the quotation.");
      return;
    }

    const mappedItems = validItems.map((line) => ({
      itemType: line.itemType,
      item: line.item.trim() || line.description.trim(),
      description: line.description.trim() || line.item.trim(),
      quantity: Number(line.quantity),
      unitPrice: Number(line.unitPrice),
      lineTotal: Number(line.quantity) * Number(line.unitPrice),
    }));

    const nextStatus: Quotation["status"] =
      quotation?.status === "Approved"
        ? "Approved"
        : issueAndProceed
          ? "Awaiting approval"
          : "Draft";

    const savedQuotation: Quotation = {
      ...(quotation ?? {
        id: quotationNumber.trim() || nextQuotationNumber,
        vehicleId: vehicle.id,
        description: vehicle.complaints || "Workshop repair quotation",
        amount: totals.total,
        status: nextStatus,
      }),
      id: quotationNumber.trim() || nextQuotationNumber,
      vehicleId: vehicle.id,
      amount: totals.total,
      subtotal: totals.subtotal,
      taxAmount: totals.vat,
      quotationDate,
      preparedByName: preparedBy.trim(),
      description:
        mappedItems.map((i) => `${i.item} (${i.quantity})`).join(", ") || vehicle.complaints,
      status: nextStatus,
      items: mappedItems,
      paperFields: {
        salesperson: salesperson.trim(),
        signature: signature.trim(),
        jobNumber: job?.id ?? vehicle.id,
      },
    };

    setQuotations((prev) => {
      const exists = prev.some(
        (q) => q.id === savedQuotation.id || q.vehicleId === savedQuotation.vehicleId,
      );
      if (exists) {
        return prev.map((q) =>
          q.id === savedQuotation.id || q.vehicleId === savedQuotation.vehicleId
            ? savedQuotation
            : q,
        );
      }
      return [savedQuotation, ...prev];
    });

    if (issueAndProceed) {
      updateVehicleStage(vehicle.id, 2);
      addActivity(
        `Quotation ${savedQuotation.id} issued (${money(totals.total)})`,
        `${vehicle.plate} · Sent to Stage 3 Customer Authorization`,
      );
      toast.success(`Quotation ${savedQuotation.id} issued. Proceeding to Customer Authorization.`);
    } else {
      toast.success(`Quotation draft ${savedQuotation.id} saved.`);
    }

    onSaved?.(savedQuotation, issueAndProceed);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    saveQuotation(true);
  }

  return (
    <form onSubmit={handleSubmit} className="stage-form-stack">
      {/* Quotation Metadata Card */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Quotation Details</h3>
            <p className="stage-card-subtitle">
              Reference details for {vehicle.customer} · {vehicle.plate} ({vehicle.make})
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s2-quote-no">
              <span className="text-red-600">*</span> Quotation Number
            </label>
            <Input
              id="s2-quote-no"
              className="stage-input font-mono"
              value={quotationNumber}
              onChange={(e) => setQuotationNumber(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s2-quote-date">
              <span className="text-red-600">*</span> Date
            </label>
            <Input
              id="s2-quote-date"
              type="date"
              className="stage-input"
              value={quotationDate}
              onChange={(e) => setQuotationDate(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s2-salesperson">
              Salesperson
            </label>
            <Input
              id="s2-salesperson"
              className="stage-input"
              value={salesperson}
              onChange={(e) => setSalesperson(e.target.value)}
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s2-prepared-by">
              <span className="text-red-600">*</span> Prepared By
            </label>
            <Input
              id="s2-prepared-by"
              className="stage-input"
              value={preparedBy}
              onChange={(e) => setPreparedBy(e.target.value)}
              required
            />
          </div>
          <div className="stage-field sm:col-span-2">
            <label className="stage-field-label" htmlFor="s2-signature">
              <span className="text-red-600">*</span> Officer Signature
            </label>
            <Input
              id="s2-signature"
              className="stage-input"
              value={signature}
              onChange={(e) => setSignature(e.target.value)}
              required
            />
          </div>
        </div>
      </div>

      {/* Itemized Quotation Lines */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Parts &amp; Labour Items</h3>
            <p className="stage-card-subtitle">
              Choose a quick template or add custom parts and labour rows
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {QUOTATION_SERVICE_PRESETS.map((preset) => (
              <Button
                key={preset.id}
                type="button"
                size="sm"
                variant="outline"
                onClick={() => applyPreset(preset.id)}
              >
                {preset.label}
              </Button>
            ))}
            <Button type="button" size="sm" variant="outline" onClick={addRow}>
              <Plus size={14} />
              Add Item
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b bg-slate-50 text-slate-600">
                <th className="py-2.5 px-1.5 font-semibold w-7">#</th>
                <th className="py-2.5 px-1.5 font-semibold w-24">Type</th>
                <th className="py-2.5 px-1.5 font-semibold min-w-[130px]">Item</th>
                <th className="py-2.5 px-1.5 font-semibold min-w-[150px]">Description</th>
                <th className="py-2.5 px-1.5 font-semibold w-16 text-right">Qty</th>
                <th className="py-2.5 px-1.5 font-semibold w-24 text-right">Unit Price</th>
                <th className="py-2.5 px-1.5 font-semibold w-24 text-right">Total</th>
                <th className="py-2.5 px-1.5 font-semibold w-10 text-center">Del</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {items.map((row, idx) => {
                const lineTotal =
                  (Number.isFinite(row.quantity) ? row.quantity : 0) *
                  (Number.isFinite(row.unitPrice) ? row.unitPrice : 0);
                return (
                  <tr key={row.id}>
                    <td className="py-2 px-2 font-medium text-muted-foreground">{idx + 1}</td>
                    <td className="py-1.5 px-2">
                      <Select
                        value={row.itemType}
                        onValueChange={(value) =>
                          updateRow(row.id, {
                            itemType: value as QuotationLineDraft["itemType"],
                          })
                        }
                      >
                        <SelectTrigger
                          className="h-9 text-xs border-slate-300"
                          aria-label={`Line ${idx + 1} type`}
                        >
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="PART">Part</SelectItem>
                          <SelectItem value="LABOUR">Labour</SelectItem>
                          <SelectItem value="SERVICE">Service</SelectItem>
                          <SelectItem value="OTHER">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="py-1.5 px-2">
                      <Input
                        className="h-9 text-xs border-slate-300"
                        aria-label={`Line ${idx + 1} item`}
                        placeholder="Air filter"
                        value={row.item}
                        onChange={(e) => updateRow(row.id, { item: e.target.value })}
                      />
                    </td>
                    <td className="py-1.5 px-2">
                      <Input
                        className="h-9 text-xs border-slate-300"
                        aria-label={`Line ${idx + 1} description`}
                        placeholder="Part or labour description"
                        value={row.description}
                        onChange={(e) => updateRow(row.id, { description: e.target.value })}
                      />
                    </td>
                    <td className="py-1.5 px-2">
                      <Input
                        type="number"
                        min={1}
                        step={1}
                        className="h-9 text-xs text-right border-slate-300"
                        aria-label={`Line ${idx + 1} quantity`}
                        value={row.quantity}
                        onChange={(e) =>
                          updateRow(row.id, { quantity: Number(e.target.value || 0) })
                        }
                      />
                    </td>
                    <td className="py-1.5 px-2">
                      <Input
                        type="number"
                        min={0}
                        step="0.01"
                        className="h-9 text-xs text-right border-slate-300"
                        aria-label={`Line ${idx + 1} unit price`}
                        value={row.unitPrice}
                        onChange={(e) =>
                          updateRow(row.id, { unitPrice: Number(e.target.value || 0) })
                        }
                      />
                    </td>
                    <td className="py-2 px-2 text-right font-semibold tabular-nums whitespace-nowrap">
                      {money(lineTotal)}
                    </td>
                    <td className="py-1.5 px-2 text-center">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        aria-label={`Remove quotation item ${row.item || idx + 1}`}
                        onClick={() => removeRow(row.id)}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4 text-xs tabular-nums">
          <div className="flex flex-wrap items-center gap-6 text-slate-600">
            <span>
              Subtotal: <strong className="text-slate-900">{money(totals.subtotal)}</strong>
            </span>
            <span>
              VAT (16%): <strong className="text-slate-900">{money(totals.vat)}</strong>
            </span>
            <span>
              50% Deposit:{" "}
              <strong className="text-slate-900">{money(totals.requiredDeposit)}</strong>
            </span>
          </div>
          <div className="text-sm font-bold text-slate-900">Total: {money(totals.total)}</div>
        </div>
      </div>

      {/* Footer CTA */}
      <div className="stage-cta-bar">
        <div>
          {onBack && (
            <Button type="button" variant="outline" onClick={onBack}>
              &larr; Back to Stage 1
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2.5 flex-wrap">
          <Button type="button" variant="outline" onClick={() => saveQuotation(false)}>
            <Save size={14} />
            Save Draft
          </Button>
          <Button type="submit" className="stage-primary-cta">
            Generate &amp; Issue Quotation
          </Button>
        </div>
      </div>
    </form>
  );
}
