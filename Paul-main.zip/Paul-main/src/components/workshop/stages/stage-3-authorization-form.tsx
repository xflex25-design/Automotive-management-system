import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AlertCircle, Check, Lock } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import {
  money,
  type CustomerAuthorizationDetails,
  type Quotation,
  type Vehicle,
} from "@/lib/workshop";
import { roundCurrency } from "@/lib/workshop-flow";

type Stage3AuthorizationFormProps = {
  vehicle: Vehicle;
  quotation?: Quotation;
  bannerExtra?: ReactNode;
  onAuthorized?: (quotation: Quotation) => void;
  onBack?: () => void;
};

export function Stage3AuthorizationForm({
  vehicle,
  quotation,
  onAuthorized,
  onBack,
}: Stage3AuthorizationFormProps) {
  const { setQuotations, updateVehicleStage, addActivity, foreman } = useWorkspace();

  const todayIso = new Date().toISOString().slice(0, 10);
  const totalAmount = quotation?.amount ?? 0;
  const requiredDeposit = roundCurrency(totalAmount * 0.5);

  const [customerAcceptance, setCustomerAcceptance] = useState<
    CustomerAuthorizationDetails["customerAcceptance"]
  >(
    quotation?.authorization?.customerAcceptance ??
      (quotation?.status === "Approved" ? "Accepted" : "Pending"),
  );

  const [terms, setTerms] = useState<CustomerAuthorizationDetails["terms"]>(
    quotation?.authorization?.terms ?? {
      permissionRepairs: quotation?.status === "Approved",
      permissionMaterials: quotation?.status === "Approved",
      vehicleSecurity: quotation?.status === "Approved",
      additionalWork: quotation?.status === "Approved",
      paymentCollection: quotation?.status === "Approved",
    },
  );

  const [paymentStatus, setPaymentStatus] = useState<CustomerAuthorizationDetails["paymentStatus"]>(
    quotation?.authorization?.paymentStatus ??
      (quotation?.status === "Approved" ? "Deposit Paid" : "Unpaid"),
  );
  const [depositAmount, setDepositAmount] = useState<string>(
    quotation?.authorization?.depositAmount !== undefined
      ? String(quotation.authorization.depositAmount)
      : String(requiredDeposit),
  );
  const [paymentReference, setPaymentReference] = useState(
    quotation?.authorization?.paymentReference ?? "",
  );

  const [customerName, setCustomerName] = useState(
    quotation?.authorization?.customerName ?? vehicle.customer ?? "",
  );
  const [customerSignature, setCustomerSignature] = useState(
    quotation?.authorization?.customerSignature ?? vehicle.intakeDetails?.customerSignature ?? "",
  );
  const [authorizationDate, setAuthorizationDate] = useState(
    quotation?.authorization?.authorizationDate ?? todayIso,
  );

  useEffect(() => {
    const reqDep = roundCurrency((quotation?.amount ?? 0) * 0.5);
    setCustomerAcceptance(
      quotation?.authorization?.customerAcceptance ??
        (quotation?.status === "Approved" ? "Accepted" : "Pending"),
    );
    setTerms(
      quotation?.authorization?.terms ?? {
        permissionRepairs: quotation?.status === "Approved",
        permissionMaterials: quotation?.status === "Approved",
        vehicleSecurity: quotation?.status === "Approved",
        additionalWork: quotation?.status === "Approved",
        paymentCollection: quotation?.status === "Approved",
      },
    );
    setPaymentStatus(
      quotation?.authorization?.paymentStatus ??
        (quotation?.status === "Approved" ? "Deposit Paid" : "Unpaid"),
    );
    setDepositAmount(
      quotation?.authorization?.depositAmount !== undefined
        ? String(quotation.authorization.depositAmount)
        : String(reqDep),
    );
    setPaymentReference(quotation?.authorization?.paymentReference ?? "");
    setCustomerName(quotation?.authorization?.customerName ?? vehicle.customer ?? "");
    setCustomerSignature(
      quotation?.authorization?.customerSignature ?? vehicle.intakeDetails?.customerSignature ?? "",
    );
    setAuthorizationDate(quotation?.authorization?.authorizationDate ?? todayIso);
  }, [quotation, vehicle, todayIso]);

  const allTermsChecked =
    terms.permissionRepairs &&
    terms.permissionMaterials &&
    terms.vehicleSecurity &&
    terms.additionalWork &&
    terms.paymentCollection;

  const parsedDeposit = Number(depositAmount || 0);
  const depositValid =
    (paymentStatus === "Deposit Paid" || paymentStatus === "Paid in Full") &&
    Number.isFinite(parsedDeposit) &&
    parsedDeposit >= requiredDeposit &&
    paymentReference.trim().length > 0;

  const canAuthorize =
    Boolean(quotation) &&
    customerAcceptance === "Accepted" &&
    allTermsChecked &&
    depositValid &&
    customerName.trim().length > 0 &&
    customerSignature.trim().length > 0 &&
    authorizationDate.trim().length > 0;

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!quotation) {
      toast.error("Complete Stage 2 Quotation before Customer Authorization.");
      return;
    }
    if (!canAuthorize) {
      toast.error(
        "All customer terms, acceptance, 50% deposit payment reference, and signature are required.",
      );
      return;
    }

    const authorization: CustomerAuthorizationDetails = {
      customerAcceptance,
      terms,
      requiredDepositPercent: 50,
      depositAmount: parsedDeposit,
      paymentStatus,
      paymentReference: paymentReference.trim(),
      customerName: customerName.trim(),
      customerSignature: customerSignature.trim(),
      authorizationDate,
    };

    const updatedQuotation: Quotation = {
      ...quotation,
      status: "Approved",
      approvalReference: `${paymentStatus} · ${paymentReference.trim()} · ${authorizationDate}`,
      authorization,
    };

    setQuotations((prev) => prev.map((q) => (q.id === updatedQuotation.id ? updatedQuotation : q)));
    updateVehicleStage(vehicle.id, 3);
    addActivity(
      `Stage 3 Customer Authorization approved (${updatedQuotation.id})`,
      `${foreman} · ${vehicle.plate} · Deposit ${money(parsedDeposit)} (${paymentReference.trim()})`,
    );
    toast.success(`Authorization confirmed for ${vehicle.plate}. Proceeding to Job Card.`);
    onAuthorized?.(updatedQuotation);
  }

  if (!quotation) {
    return (
      <div className="stage-card flex items-center gap-2.5 text-sm text-muted-foreground">
        <AlertCircle size={16} className="text-amber-600 shrink-0" />
        <span>No issued quotation found for this vehicle. Complete Stage 2 first.</span>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="stage-form-stack">
      {/* Card 1: Quotation Decision & Deposit Payment */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Quotation Decision &amp; 50% Deposit</h3>
            <p className="stage-card-subtitle">
              Quotation {quotation.id} · Total {money(totalAmount)} · Minimum Deposit{" "}
              {money(requiredDeposit)}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s3-acceptance">
              <span className="text-red-600">*</span> Customer Acceptance
            </label>
            <Select
              value={customerAcceptance}
              onValueChange={(value) =>
                setCustomerAcceptance(value as CustomerAuthorizationDetails["customerAcceptance"])
              }
            >
              <SelectTrigger id="s3-acceptance" className="stage-select-trigger">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Pending">Pending</SelectItem>
                <SelectItem value="Accepted">Accepted</SelectItem>
                <SelectItem value="Declined">Declined</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s3-payment-status">
              <span className="text-red-600">*</span> Payment Status
            </label>
            <Select
              value={paymentStatus}
              onValueChange={(value) =>
                setPaymentStatus(value as CustomerAuthorizationDetails["paymentStatus"])
              }
            >
              <SelectTrigger id="s3-payment-status" className="stage-select-trigger">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Unpaid">Unpaid</SelectItem>
                <SelectItem value="Deposit Paid">Deposit Paid (50%)</SelectItem>
                <SelectItem value="Paid in Full">Paid in Full</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s3-deposit-amount">
              <span className="text-red-600">*</span> Deposit Amount Paid
            </label>
            <Input
              id="s3-deposit-amount"
              type="number"
              min={0}
              step="0.01"
              className="stage-input tabular-nums"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              required
            />
          </div>

          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s3-payment-ref">
              <span className="text-red-600">*</span> Payment Reference
            </label>
            <Input
              id="s3-payment-ref"
              className="stage-input font-mono"
              placeholder="e.g. REC-88412 / EFT-2026"
              value={paymentReference}
              onChange={(e) => setPaymentReference(e.target.value)}
              required
            />
          </div>
        </div>
      </div>

      {/* Card 2: Service Management Conditions */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Customer Terms &amp; Service Conditions</h3>
            <p className="stage-card-subtitle">All five repair authorizations are required</p>
          </div>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() =>
              setTerms({
                permissionRepairs: true,
                permissionMaterials: true,
                vehicleSecurity: true,
                additionalWork: true,
                paymentCollection: true,
              })
            }
          >
            <Check size={13} />
            Accept All Terms
          </Button>
        </div>

        <div className="space-y-2.5 text-xs">
          {[
            {
              key: "permissionRepairs" as const,
              label: "Permission to carry out the quoted repairs and road-testing.",
            },
            {
              key: "permissionMaterials" as const,
              label: "Permission to procure and fit all necessary replacement materials and parts.",
            },
            {
              key: "vehicleSecurity" as const,
              label:
                "Vehicle security and workshop responsibility conditions understood and accepted.",
            },
            {
              key: "additionalWork" as const,
              label:
                "Additional work discovered during disassembly requires prior customer approval.",
            },
            {
              key: "paymentCollection" as const,
              label:
                "50% deposit prior to commencement of work; balance payable before vehicle collection.",
            },
          ].map((item) => (
            <label
              key={item.key}
              className="flex items-start gap-2.5 py-2 border-b border-slate-100 last:border-b-0 cursor-pointer text-slate-700"
            >
              <input
                type="checkbox"
                checked={terms[item.key]}
                onChange={(e) => setTerms((prev) => ({ ...prev, [item.key]: e.target.checked }))}
                className="accent-primary mt-0.5 h-4 w-4"
              />
              <span className="leading-snug">{item.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Card 3: Customer Sign-Off */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Customer Approval Sign-Off</h3>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s3-customer-name">
              <span className="text-red-600">*</span> Customer Name
            </label>
            <Input
              id="s3-customer-name"
              className="stage-input"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s3-customer-sig">
              <span className="text-red-600">*</span> Customer Signature
            </label>
            <Input
              id="s3-customer-sig"
              className="stage-input"
              placeholder="Type customer signature"
              value={customerSignature}
              onChange={(e) => setCustomerSignature(e.target.value)}
              required
            />
          </div>
          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s3-auth-date">
              <span className="text-red-600">*</span> Authorization Date
            </label>
            <Input
              id="s3-auth-date"
              type="date"
              className="stage-input"
              value={authorizationDate}
              onChange={(e) => setAuthorizationDate(e.target.value)}
              required
            />
          </div>
        </div>

        <div className="flex items-start gap-2.5 text-xs text-slate-500 mt-4">
          <Lock size={14} className="text-slate-400 shrink-0 mt-0.5" />
          <p>
            Authorization locks the approved quotation scope and opens Stage 4 Job Card creation.
          </p>
        </div>

        {!canAuthorize && (
          <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900 space-y-1">
            <div className="font-semibold">
              Remaining before generating Job Card (Required deposit: {money(requiredDeposit)}):
            </div>
            <div>
              {[
                customerAcceptance !== "Accepted" ? "Set Customer Acceptance = Accepted" : "",
                !allTermsChecked ? "Check all 5 workshop terms" : "",
                !depositValid
                  ? "Set Payment Status (Deposit Paid / Paid in Full) + Payment Reference"
                  : "",
                !customerSignature.trim() ? "Customer Signature" : "",
              ]
                .filter(Boolean)
                .join(" · ")}
            </div>
          </div>
        )}
      </div>

      <div className="stage-cta-bar">
        <div>
          {onBack && (
            <Button type="button" variant="outline" onClick={onBack}>
              &larr; Back to Stage 2
            </Button>
          )}
        </div>
        <Button type="submit" disabled={!canAuthorize} className="stage-primary-cta">
          Confirm Authorization &amp; Generate Job Card
        </Button>
      </div>
    </form>
  );
}
