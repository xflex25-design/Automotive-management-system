import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2 } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import {
  createJobCardAuditEntry,
  type DepartmentProgressItem,
  type JobCard,
  type JobCardPartsSheetRow,
  type Quotation,
  type Vehicle,
} from "@/lib/workshop";
import { buildPartsSheetFromQuotation, ROUTABLE_DEPARTMENTS } from "@/lib/workshop-flow";

type Stage4JobCardFormProps = {
  vehicle: Vehicle;
  quotation?: Quotation;
  job?: JobCard;
  bannerExtra?: ReactNode;
  onSaved?: (job: JobCard) => void;
  onBack?: () => void;
};

export function Stage4JobCardForm({
  vehicle,
  quotation,
  job,
  onSaved,
  onBack,
}: Stage4JobCardFormProps) {
  const { jobs, setJobs, setVehicles, updateVehicleStage, foreman, addActivity } = useWorkspace();

  const todayIso = new Date().toISOString().slice(0, 10);
  const nextJobNumber = useMemo(() => {
    if (job?.id) return job.id;
    const maxNum = jobs.reduce((max, item) => {
      const m = item.id.match(/^JC-(\d+)$/);
      return m ? Math.max(max, Number(m[1])) : max;
    }, 880);
    return `JC-${maxNum + 1}`;
  }, [job?.id, jobs]);

  const [jobNumber, setJobNumber] = useState(nextJobNumber);
  const [dateCreated, setDateCreated] = useState(job?.startDate ?? todayIso);
  const [approvedQuoteRef, setApprovedQuoteRef] = useState(
    job?.approvedQuotationRef ?? quotation?.id ?? "",
  );
  const [workToPerform, setWorkToPerform] = useState(
    job?.work || vehicle.intakeDetails?.requestedRepairs || vehicle.complaints || "",
  );
  const [repairsRequired, setRepairsRequired] = useState(
    job?.repairsRequired ?? quotation?.description ?? "",
  );
  const [inspectionFindings, setInspectionFindings] = useState(
    job?.inspectionFindings ?? vehicle.damage ?? "",
  );
  const [specialInstructions, setSpecialInstructions] = useState(
    job?.specialInstructions ?? vehicle.intakeDetails?.additionalInstructions ?? "",
  );

  const [partsSheet, setPartsSheet] = useState<JobCardPartsSheetRow[]>(() => {
    if (job?.partsSheet && job.partsSheet.length > 0) return job.partsSheet;
    return buildPartsSheetFromQuotation(quotation);
  });

  const [routedDepartments, setRoutedDepartments] = useState<string[]>(
    job?.routedDepartments && job.routedDepartments.length > 0
      ? job.routedDepartments
      : [job?.department && job.department !== "Unassigned" ? job.department : "Mechanical"],
  );
  const [primaryDepartment, setPrimaryDepartment] = useState(
    job?.department && job.department !== "Unassigned" ? job.department : "Mechanical",
  );
  const [foremanName, setForemanName] = useState(job?.preparedBy ?? foreman);
  const [assignedMechanic, setAssignedMechanic] = useState(job?.assignedEmployee ?? "Mechanic A");
  const [expectedCompletionDate, setExpectedCompletionDate] = useState(job?.due || todayIso);

  const [showDetailedFindings, setShowDetailedFindings] = useState(
    Boolean(job?.repairsRequired || job?.inspectionFindings || job?.specialInstructions),
  );

  useEffect(() => {
    setJobNumber(nextJobNumber);
    setDateCreated(job?.startDate ?? todayIso);
    setApprovedQuoteRef(job?.approvedQuotationRef ?? quotation?.id ?? "");
    setWorkToPerform(
      job?.work || vehicle.intakeDetails?.requestedRepairs || vehicle.complaints || "",
    );
    setRepairsRequired(job?.repairsRequired ?? quotation?.description ?? "");
    setInspectionFindings(job?.inspectionFindings ?? vehicle.damage ?? "");
    setSpecialInstructions(
      job?.specialInstructions ?? vehicle.intakeDetails?.additionalInstructions ?? "",
    );
    if (job?.partsSheet && job.partsSheet.length > 0) {
      setPartsSheet(job.partsSheet);
    }
    const depts =
      job?.routedDepartments && job.routedDepartments.length > 0
        ? job.routedDepartments
        : [job?.department && job.department !== "Unassigned" ? job.department : "Mechanical"];
    setRoutedDepartments(depts);
    setPrimaryDepartment(depts[0] ?? "Mechanical");
    setForemanName(job?.preparedBy ?? foreman);
    setAssignedMechanic(job?.assignedEmployee ?? "Mechanic A");
    setExpectedCompletionDate(job?.due || todayIso);
  }, [job, quotation, vehicle, nextJobNumber, foreman, todayIso]);

  function toggleDepartment(dept: string) {
    setRoutedDepartments((prev) => {
      const exists = prev.includes(dept);
      const next = exists ? prev.filter((item) => item !== dept) : [...prev, dept];
      if (!exists && next.length === 1) {
        setPrimaryDepartment(dept);
      } else if (exists && primaryDepartment === dept && next.length > 0) {
        setPrimaryDepartment(next[0]!);
      }
      return next;
    });
  }

  function addPartsRow() {
    setPartsSheet((prev) => [
      ...prev,
      {
        id: `ps-${Date.now()}-${prev.length}`,
        partName: "",
        quoted: false,
        requiredFor: "",
        additionalPart: "",
        quantity: 1,
      },
    ]);
  }

  function removePartsRow(id: string) {
    if (partsSheet.length <= 1) return;
    setPartsSheet((prev) => prev.filter((row) => row.id !== id));
  }

  function updatePartsRow(id: string, patch: Partial<JobCardPartsSheetRow>) {
    setPartsSheet((prev) => prev.map((row) => (row.id === id ? { ...row, ...patch } : row)));
  }

  function syncQuotedParts() {
    setPartsSheet(buildPartsSheetFromQuotation(quotation));
    toast.success("Parts sheet synced from approved quotation.");
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!workToPerform.trim()) {
      toast.error("Please specify work to be performed.");
      return;
    }
    if (routedDepartments.length === 0) {
      toast.error("Select at least one workshop department for routing.");
      return;
    }
    if (!assignedMechanic.trim() || !expectedCompletionDate.trim()) {
      toast.error("Assigned mechanic and expected completion date are required.");
      return;
    }

    const existingProgressMap = new Map(
      (job?.departmentProgress ?? []).map((item) => [item.department, item]),
    );
    const nowMs = Date.now();
    const departmentProgress: DepartmentProgressItem[] = routedDepartments.map((dept) => {
      const prev = existingProgressMap.get(dept);
      return (
        prev ?? {
          department: dept,
          assignedMechanic: assignedMechanic.trim(),
          status: "Not Started",
          updatedAtMs: nowMs,
        }
      );
    });

    const resolvedPrimary = routedDepartments.includes(primaryDepartment)
      ? primaryDepartment
      : routedDepartments[0]!;

    const cleanedParts = partsSheet.filter(
      (row) => row.partName.trim() || row.additionalPart.trim(),
    );

    const savedJob: JobCard = {
      ...(job ?? {
        id: jobNumber.trim() || nextJobNumber,
        vehicleId: vehicle.id,
        status: "Pending",
      }),
      id: jobNumber.trim() || nextJobNumber,
      vehicleId: vehicle.id,
      department: resolvedPrimary,
      work: workToPerform.trim(),
      status: job?.status ?? "Pending",
      due: expectedCompletionDate,
      startDate: dateCreated,
      preparedBy: foremanName.trim() || foreman,
      assignedEmployee: assignedMechanic.trim(),
      approvedQuotationRef: approvedQuoteRef.trim(),
      repairsRequired: repairsRequired.trim(),
      inspectionFindings: inspectionFindings.trim(),
      specialInstructions: specialInstructions.trim(),
      routedDepartments,
      partsSheet: cleanedParts,
      parts: cleanedParts.map((row, index) => ({
        id: index + 1,
        name: row.additionalPart.trim() || row.partName.trim(),
        quantity: Math.max(1, Number(row.quantity || 1)),
      })),
      departmentProgress,
      stagnationMeta: {
        ...job?.stagnationMeta,
        departmentEnteredAtMs: job?.stagnationMeta?.departmentEnteredAtMs ?? nowMs,
      },
      auditTrail: job?.auditTrail?.length
        ? job.auditTrail
        : [
            createJobCardAuditEntry({
              type: "created",
              actor: foremanName.trim() || foreman,
              actorRole: "Foreman",
              department: resolvedPrimary,
              newStatus: "Pending",
              summary: `Job card ${jobNumber.trim() || nextJobNumber} routed to ${routedDepartments.join(", ")}`,
              note: specialInstructions.trim() || undefined,
            }),
          ],
    };

    setJobs((prev) => {
      const exists = prev.some((j) => j.id === savedJob.id || j.vehicleId === savedJob.vehicleId);
      if (exists) {
        return prev.map((j) =>
          j.id === savedJob.id || j.vehicleId === savedJob.vehicleId ? savedJob : j,
        );
      }
      return [savedJob, ...prev];
    });

    setVehicles((prev) =>
      prev.map((v) =>
        v.id === vehicle.id
          ? {
              ...v,
              department: resolvedPrimary,
              foreman: foremanName.trim() || foreman,
              due: expectedCompletionDate,
              stage: Math.max(v.stage, 4),
            }
          : v,
      ),
    );
    updateVehicleStage(vehicle.id, 4);
    addActivity(
      `Stage 4 Job Card ${savedJob.id} created`,
      `${vehicle.plate} · Routed to ${routedDepartments.join(", ")} · ${assignedMechanic.trim()}`,
    );
    toast.success(`Job card ${savedJob.id} saved. Checking parts availability.`);
    onSaved?.(savedJob);
  }

  return (
    <form onSubmit={handleSubmit} className="stage-form-stack">
      {/* Card 1: Job Card Metadata & Instructions */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Job Card &amp; Repair Scope</h3>
            <p className="stage-card-subtitle">
              {vehicle.customer} · {vehicle.plate} ({vehicle.make})
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s4-job-no">
                <span className="text-red-600">*</span> Job Number
              </label>
              <Input
                id="s4-job-no"
                className="stage-input font-mono"
                value={jobNumber}
                onChange={(e) => setJobNumber(e.target.value)}
                required
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s4-date">
                Start Date
              </label>
              <Input
                id="s4-date"
                type="date"
                className="stage-input"
                value={dateCreated}
                onChange={(e) => setDateCreated(e.target.value)}
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s4-quote-ref">
                Approved Quotation Ref
              </label>
              <Input
                id="s4-quote-ref"
                className="stage-input font-mono"
                value={approvedQuoteRef}
                onChange={(e) => setApprovedQuoteRef(e.target.value)}
              />
            </div>
          </div>

          <div className="stage-field">
            <label className="stage-field-label" htmlFor="s4-work">
              <span className="text-red-600">*</span> Work to Be Performed
            </label>
            <Textarea
              id="s4-work"
              className="stage-textarea"
              placeholder="Describe repair work to be carried out"
              value={workToPerform}
              onChange={(e) => setWorkToPerform(e.target.value)}
              required
            />
          </div>

          <button
            type="button"
            className="stage-link-toggle"
            onClick={() => setShowDetailedFindings((prev) => !prev)}
          >
            {showDetailedFindings
              ? "− Hide Repairs List, Findings & Special Instructions"
              : "+ Add Repairs List, Findings & Special Instructions"}
          </button>

          {showDetailedFindings && (
            <div className="pt-2 space-y-4 border-t border-slate-100">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s4-repairs">
                    Repairs Required
                  </label>
                  <Textarea
                    id="s4-repairs"
                    className="stage-textarea"
                    placeholder="Repairs list"
                    value={repairsRequired}
                    onChange={(e) => setRepairsRequired(e.target.value)}
                  />
                </div>
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s4-findings">
                    Inspection Findings
                  </label>
                  <Textarea
                    id="s4-findings"
                    className="stage-textarea"
                    placeholder="Intake inspection notes"
                    value={inspectionFindings}
                    onChange={(e) => setInspectionFindings(e.target.value)}
                  />
                </div>
              </div>
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s4-special">
                  Special Instructions
                </label>
                <Input
                  id="s4-special"
                  className="stage-input"
                  placeholder="Any torque/road-test notes"
                  value={specialInstructions}
                  onChange={(e) => setSpecialInstructions(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Card 2: Department Routing & Assignment */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Department Routing &amp; Mechanic Assignment</h3>
            <p className="stage-card-subtitle">
              Select all workshop bays involved and assign the lead mechanic
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex flex-wrap gap-2.5 text-xs">
            {ROUTABLE_DEPARTMENTS.map((dept) => (
              <label
                key={dept}
                className={`flex items-center gap-2 rounded-md border px-3.5 py-2 cursor-pointer font-medium transition-colors ${
                  routedDepartments.includes(dept)
                    ? "border-primary bg-accent/70 text-primary font-semibold"
                    : "border-slate-300 bg-white text-slate-700 hover:border-slate-400"
                }`}
              >
                <input
                  type="checkbox"
                  checked={routedDepartments.includes(dept)}
                  onChange={() => toggleDepartment(dept)}
                  className="accent-primary"
                />
                <span>{dept}</span>
              </label>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s4-primary-dept">
                <span className="text-red-600">*</span> Lead Department
              </label>
              <Select value={primaryDepartment} onValueChange={setPrimaryDepartment}>
                <SelectTrigger id="s4-primary-dept" className="stage-select-trigger">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {(routedDepartments.length > 0
                    ? routedDepartments
                    : [...ROUTABLE_DEPARTMENTS]
                  ).map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s4-foreman">
                Foreman Name
              </label>
              <Input
                id="s4-foreman"
                className="stage-input"
                value={foremanName}
                onChange={(e) => setForemanName(e.target.value)}
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s4-mechanic">
                <span className="text-red-600">*</span> Assigned Mechanic
              </label>
              <Input
                id="s4-mechanic"
                className="stage-input"
                placeholder="e.g. Mechanic A / Peter Zulu"
                value={assignedMechanic}
                onChange={(e) => setAssignedMechanic(e.target.value)}
                required
              />
            </div>
            <div className="stage-field">
              <label className="stage-field-label" htmlFor="s4-due">
                <span className="text-red-600">*</span> Expected Completion
              </label>
              <Input
                id="s4-due"
                type="date"
                className="stage-input"
                value={expectedCompletionDate}
                onChange={(e) => setExpectedCompletionDate(e.target.value)}
                required
              />
            </div>
          </div>
        </div>
      </div>

      {/* Card 3: Parts Information Sheet */}
      <div className="stage-card">
        <div className="stage-card-head">
          <div>
            <h3 className="stage-card-title">Parts Information Sheet</h3>
            <p className="stage-card-subtitle">
              Pre-filled from approved quotation parts; adjust or add extra parts if required
            </p>
          </div>
          <div className="flex items-center gap-2">
            {quotation?.items && quotation.items.length > 0 && (
              <Button type="button" size="sm" variant="outline" onClick={syncQuotedParts}>
                Sync Quoted Parts
              </Button>
            )}
            <Button type="button" size="sm" variant="outline" onClick={addPartsRow}>
              <Plus size={14} />
              Add Part Row
            </Button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b bg-slate-50 text-slate-600">
                <th className="py-2.5 px-2 font-semibold">Part Name</th>
                <th className="py-2.5 px-2 font-semibold text-center">Quoted</th>
                <th className="py-2.5 px-2 font-semibold">Required For</th>
                <th className="py-2.5 px-2 font-semibold">Additional Parts</th>
                <th className="py-2.5 px-2 font-semibold w-20 text-right">Qty</th>
                <th className="py-2.5 px-2 font-semibold w-12 text-center">Del</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {partsSheet.map((row, idx) => (
                <tr key={row.id}>
                  <td className="py-1.5 px-2">
                    <Input
                      className="h-9 text-xs border-slate-300"
                      aria-label={`Parts sheet row ${idx + 1} part`}
                      value={row.partName}
                      onChange={(e) => updatePartsRow(row.id, { partName: e.target.value })}
                    />
                  </td>
                  <td className="py-1.5 px-2 text-center">
                    <input
                      type="checkbox"
                      aria-label={`${row.partName || `Row ${idx + 1}`} quoted`}
                      checked={row.quoted}
                      onChange={(e) => updatePartsRow(row.id, { quoted: e.target.checked })}
                      className="accent-primary"
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <Input
                      className="h-9 text-xs border-slate-300"
                      aria-label={`Parts sheet row ${idx + 1} required for`}
                      placeholder="e.g. Service / Braking"
                      value={row.requiredFor}
                      onChange={(e) => updatePartsRow(row.id, { requiredFor: e.target.value })}
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <Input
                      className="h-9 text-xs border-slate-300"
                      aria-label={`Parts sheet row ${idx + 1} additional part`}
                      placeholder="Optional extra part"
                      value={row.additionalPart}
                      onChange={(e) => updatePartsRow(row.id, { additionalPart: e.target.value })}
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <Input
                      type="number"
                      min={1}
                      className="h-9 text-xs text-right border-slate-300"
                      aria-label={`Parts sheet row ${idx + 1} quantity`}
                      value={row.quantity}
                      onChange={(e) =>
                        updatePartsRow(row.id, { quantity: Number(e.target.value || 1) })
                      }
                    />
                  </td>
                  <td className="py-1.5 px-2 text-center">
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      aria-label={`Remove part row ${row.partName || idx + 1}`}
                      onClick={() => removePartsRow(row.id)}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="stage-cta-bar">
        <div>
          {onBack && (
            <Button type="button" variant="outline" onClick={onBack}>
              &larr; Back to Stage 3
            </Button>
          )}
        </div>
        <Button type="submit" className="stage-primary-cta">
          Save Job Card &amp; Check Parts
        </Button>
      </div>
    </form>
  );
}
