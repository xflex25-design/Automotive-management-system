import { r as DepartmentsPage } from "./monitor-pages-B-tlhenF.js";
//#region src/routes/departments.tsx?tsr-split=component
var SplitComponent = DepartmentsPage;
//#endregion
export { SplitComponent as component };
