import { a as ReportsPage } from "./monitor-pages-B-tlhenF.js";
//#region src/routes/reports.tsx?tsr-split=component
var SplitComponent = ReportsPage;
//#endregion
export { SplitComponent as component };
