import { B as Plus, Ct as toast, E as FileText, Gt as require_react, H as RotateCcw, J as ShieldCheck, O as GitBranch, Ut as require_jsx_runtime, Y as SlidersHorizontal, _t as nextSortState, b as ClipboardList, c as ArrowUpRight, ct as useWorkspace, et as Truck, g as CheckCircle2, it as Wrench, p as Car, qt as __toESM, s as ArrowRight, t as Button, vt as sortRecords, x as Clock, xt as workflowStages, z as Package } from "./button-ByH67M_G.js";
import { t as Link } from "./index-DDvlJ1GD.js";
import { t as VehicleDetail } from "./vehicle-detail-DCFpkq95.js";
import { _ as metricIcons, a as LineChart, c as ProgressBar, d as TableFooter, i as ExportButton, l as SectionHeading, m as ViewAllVehicles, n as DateFilter, o as Metrics, p as VehicleCell, r as EmptyState, s as PageHeading, t as DataTable, u as Status } from "./shared-D1FqIhYl.js";
//#region src/components/workshop/dashboard.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function DepartmentCards() {
	const { workflows, loading } = useWorkspace();
	const departments = (0, import_react.useMemo)(() => {
		const orders = workflows.flatMap((plan) => Array.isArray(plan["workOrders"]) ? plan["workOrders"] : []);
		const grouped = /* @__PURE__ */ new Map();
		for (const order of orders) {
			const name = String(order["departmentName"] ?? "Unassigned");
			grouped.set(name, [...grouped.get(name) ?? [], order]);
		}
		return Array.from(grouped, ([name, rows]) => {
			const completed = rows.filter((row) => ["COMPLETED", "CONFIRMED"].includes(String(row["status"]).toUpperCase())).length;
			return {
				name,
				active: rows.length - completed,
				completed,
				pending: rows.filter((row) => ["READY", "BLOCKED"].includes(String(row["status"]).toUpperCase())).length,
				efficiency: rows.length ? Math.round(completed / rows.length * 100) : 0
			};
		});
	}, [workflows]);
	if (!departments.length) return loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "table-wrap",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			compact: true,
			icon: Wrench,
			tone: "muted",
			title: "Loading department workload…",
			description: "Fetching active work orders across workshop bays."
		})
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "table-wrap",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			compact: true,
			icon: Wrench,
			title: "No department work orders yet",
			description: "Work orders appear here once job cards and repair plans are created.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				size: "sm",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/departments",
					children: ["View departments", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
				})
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "department-grid",
		children: departments.map((dept) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "department-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, {
						size: 14,
						className: "text-primary"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: dept.name })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "dept-count",
					children: [dept.active, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium text-muted-foreground ml-2",
						children: "active jobs"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					dept.completed,
					" completed · ",
					dept.pending,
					" pending"
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: dept.efficiency }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between mt-2 text-xs font-medium text-muted-foreground tabular-nums",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Completion rate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [dept.efficiency, "%"] })]
				})
			]
		}, dept.name))
	});
}
function Dashboard({ role }) {
	const { vehicles, jobs, requisitions, inspections, activities, foreman, setRole, dispatches, invoices, handovers, loading, error, workflowOptions, api, refresh } = useWorkspace();
	(0, import_react.useEffect)(() => setRole(role), [role, setRole]);
	const [period, setPeriod] = (0, import_react.useState)("This week");
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [stageFilter, setStageFilter] = (0, import_react.useState)(false);
	const [approvingDispatch, setApprovingDispatch] = (0, import_react.useState)(null);
	const [vehicleSort, setVehicleSort] = (0, import_react.useState)(null);
	const [authSort, setAuthSort] = (0, import_react.useState)(null);
	const [dispatchSort, setDispatchSort] = (0, import_react.useState)(null);
	const pending = requisitions.filter((r) => r.status === "Pending").length;
	const isForeman = role === "Foreman";
	const isDirector = role === "Director";
	const isManagement = role === "Management";
	const employees = workflowOptions["employees"] ?? [];
	const employeeId = Number({
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": false,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/"
	}["VITE_EMPLOYEE_ID"]);
	const employeeName = String(employees.find((employee) => Number(employee["id"]) === employeeId)?.["name"] ?? "");
	const filteredVehicles = vehicles.filter((vehicle) => {
		if (stageFilter) return jobs.some((job) => job.vehicleId === vehicle.id && !["COMPLETED", "CANCELLED"].includes(job.status.toUpperCase()));
		return true;
	});
	const shownVehicles = sortRecords(filteredVehicles, vehicleSort, (vehicle, key) => {
		switch (key) {
			case "vehicle": return `${vehicle.make} ${vehicle.plate}`;
			case "customer": return vehicle.customer;
			case "received": return vehicle.received;
			case "stage": return vehicle.stage;
			case "department": return vehicle.department;
			default: return "";
		}
	}).slice(0, 5);
	const pendingAuthRequisitions = sortRecords(requisitions.filter((r) => r.status === "Pending"), authSort, (r, key) => {
		switch (key) {
			case "id": return r.id;
			case "part": return r.part;
			case "quantity": return r.quantity;
			case "department": return r.department;
			case "status": return r.status;
			default: return "";
		}
	});
	const activeJobs = jobs.filter((job) => ![
		"COMPLETED",
		"CANCELLED",
		"CLOSED"
	].includes(job.status.toUpperCase())).length;
	const pendingDispatches = sortRecords(dispatches.filter((dispatch) => String(dispatch["status"]).toUpperCase() === "PENDING_APPROVAL"), dispatchSort, (dispatch, key) => {
		const dispatchId = Number(dispatch["dispatchOrderId"] ?? dispatch["id"]);
		const jobId = Number(dispatch["jobId"]);
		const job = jobs.find((candidate) => candidate.backendJobId === jobId);
		const vehicle = job ? vehicles.find((candidate) => candidate.id === job.vehicleId) : void 0;
		switch (key) {
			case "dispatch": return String(dispatch["dispatchNumber"] ?? dispatchId);
			case "job": return vehicle ? `${vehicle.plate} ${vehicle.customer}` : String(dispatch["jobNumber"] ?? jobId);
			case "department": return String(dispatch["departmentName"] ?? "");
			case "status": return String(dispatch["status"] ?? "Pending");
			default: return "";
		}
	});
	const awaitingRelease = invoices.filter((invoice) => Number(invoice["balanceDue"] ?? 0) <= 0 && !handovers.some((handover) => Number(handover["jobId"]) === Number(invoice["jobId"]))).length;
	const trend = (0, import_react.useMemo)(() => {
		const now = /* @__PURE__ */ new Date();
		const parsed = (value) => {
			const numeric = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
			if (numeric) return new Date(Number(numeric[3]), Number(numeric[2]) - 1, Number(numeric[1]));
			const date = new Date(value);
			return Number.isNaN(date.getTime()) ? null : date;
		};
		return Array.from({ length: 6 }, (_, index) => {
			const date = new Date(now);
			if (period === "This week") date.setDate(now.getDate() - (5 - index));
			else date.setDate(now.getDate() - (5 - index) * 7);
			date.setHours(0, 0, 0, 0);
			const next = new Date(date);
			if (period !== "This week") next.setDate(next.getDate() + 7);
			else next.setDate(next.getDate() + 1);
			const count = vehicles.filter((vehicle) => {
				const received = parsed(vehicle.received);
				return received && received >= date && received < next;
			}).length;
			return {
				label: period === "This week" ? new Intl.DateTimeFormat(void 0, { weekday: "short" }).format(date) : new Intl.DateTimeFormat(void 0, {
					month: "short",
					day: "numeric"
				}).format(date),
				count
			};
		});
	}, [period, vehicles]);
	const stageCounts = workflowStages.map((name, stage) => ({
		name,
		value: vehicles.filter((vehicle) => vehicle.stage === stage).length
	})).filter((item) => item.value > 0);
	const intakeDiff = trend.slice(3).reduce((total, point) => total + point.count, 0) - trend.slice(0, 3).reduce((total, point) => total + point.count, 0);
	const intakeDelta = vehicles.length > 0 ? {
		text: `${intakeDiff > 0 ? `+${intakeDiff}` : intakeDiff} vs prior`,
		direction: intakeDiff > 0 ? "up" : intakeDiff < 0 ? "down" : "flat"
	} : void 0;
	const activePartsCount = requisitions.filter((request) => [
		"Pending",
		"Approved",
		"Ordered"
	].includes(request.status)).length;
	const pendingInspectionsCount = inspections.filter((inspection) => inspection.result === "Pending").length;
	const passedInspectionsCount = inspections.filter((inspection) => inspection.result === "Passed").length;
	const inRepairVehiclesCount = vehicles.filter((vehicle) => !vehicle.released).length;
	const heading = isForeman ? "Foreman Dashboard" : isDirector ? "Director Dashboard" : "Management Dashboard";
	const subtitle = isForeman ? `Intake & workshop control · ${foreman}` : isDirector ? "Business overview & parts authorization" : "Workshop operations & performance oversight";
	const metrics = isForeman ? [
		{
			label: "Vehicles received",
			value: vehicles.length,
			note: `${inRepairVehiclesCount} active in workshop`,
			icon: metricIcons.Car,
			delta: intakeDelta
		},
		{
			label: "Active job cards",
			value: activeJobs,
			note: jobs.length ? `${jobs.length - activeJobs} of ${jobs.length} completed` : "Open job cards",
			icon: metricIcons.Wrench
		},
		{
			label: "Awaiting parts",
			value: activePartsCount,
			note: `${pending} pending director approval`,
			icon: metricIcons.Package,
			tone: pending > 0 ? "warning" : "default"
		},
		{
			label: "Ready for inspection",
			value: pendingInspectionsCount,
			note: inspections.length ? `${passedInspectionsCount} of ${inspections.length} passed` : "Inspections in progress",
			icon: metricIcons.ClipboardCheck,
			tone: passedInspectionsCount > 0 && pendingInspectionsCount === 0 ? "success" : "default"
		}
	] : [
		{
			label: "Total vehicles",
			value: vehicles.length,
			note: `${vehicles.filter((v) => v.released).length} released to customers`,
			icon: metricIcons.Car,
			delta: intakeDelta
		},
		{
			label: "Currently in repair",
			value: activeJobs,
			note: jobs.length ? `${Math.round(activeJobs / jobs.length * 100)}% of total jobs active` : "Open job cards",
			icon: metricIcons.Wrench
		},
		{
			label: isDirector ? "Pending parts approvals" : "Awaiting parts",
			value: isDirector ? pending : requisitions.filter((request) => request.status === "Pending").length,
			note: isDirector ? "Your authorization required" : `${requisitions.length} total requisitions`,
			icon: metricIcons.Package,
			tone: pending > 0 ? "warning" : "default"
		},
		{
			label: isDirector ? "Completed vehicles" : "Awaiting release",
			value: isDirector ? handovers.length : awaitingRelease,
			note: isDirector ? "Recorded vehicle handovers" : "Paid invoices awaiting handover",
			icon: metricIcons.ClipboardCheck,
			tone: isDirector && handovers.length > 0 ? "success" : awaitingRelease > 0 ? "warning" : "default"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeading, {
			title: heading,
			subtitle,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/departments",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, {}), "Department workload"]
				})
			}), isForeman && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/registration",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Register vehicle"]
				})
			})]
		}),
		error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "attention-band",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Workshop records could not be loaded" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => void refresh(),
				children: "Retry"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metrics, { items: metrics }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `attention-band ${isDirector && pending > 0 || isManagement && pendingDispatches.length > 0 ? "attention-band-warning" : ""}`.trim(),
			children: [
				isDirector ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { size: 18 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: isDirector ? `${pending} parts requests are awaiting your authorization` : "Keep the workshop moving" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: isDirector ? "Review requested parts, quantities and reasons before authorizing procurement." : isManagement ? `${pendingDispatches.length} parts dispatches are waiting for management approval.` : "Review workshop records and pending requisitions." })] }),
				isManagement ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "link",
					size: "sm",
					className: "band-action",
					onClick: () => document.getElementById("dispatch-approvals")?.scrollIntoView({ behavior: "smooth" }),
					children: ["Approve dispatches ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 13 })]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "link",
					size: "sm",
					className: "band-action",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: isDirector ? "/approvals" : "/requisitions",
						children: [isDirector ? "Approve requests" : "View requisitions", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 13 })]
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overview-grid",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overview-section",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						title: "Vehicle intake",
						subtitle: period === "This week" ? "Last 6 days" : "Last 6 weeks",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateFilter, {
							value: period,
							onChange: setPeriod
						})
					}),
					loading && vehicles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						compact: true,
						icon: Car,
						tone: "muted",
						title: "Loading intake records…",
						description: "Retrieving recent vehicle intake activity."
					}) : vehicles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						compact: true,
						icon: Car,
						title: "No vehicle intake records yet",
						description: "Intake volume will plot automatically as vehicles are registered.",
						action: isForeman ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/registration",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Register vehicle"]
							})
						}) : void 0
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineChart, {
						values: trend.map((point) => point.count),
						labels: trend.map((point) => point.label)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between items-center mt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "chart-key",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), "Vehicles received"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-medium text-muted-foreground tabular-nums",
							children: [trend.reduce((total, point) => total + point.count, 0), " in this period"]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overview-section",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					title: "Workshop at a glance",
					subtitle: "Current vehicle distribution",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "link",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/workflow",
							children: ["View workflow", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 13 })]
						})
					})
				}), stageCounts.length ? stageCounts.map((item) => {
					const share = vehicles.length ? Math.round(item.value / vehicles.length * 100) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "stage-row",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: item.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: share }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
								item.value,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground font-normal",
									children: [
										"(",
										share,
										"%)"
									]
								})
							] })
						]
					}, item.name);
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					compact: true,
					icon: GitBranch,
					tone: "muted",
					title: "No vehicle workflow records yet",
					description: "Stage distribution across the 12 workshop steps updates as vehicles progress."
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "table-section",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
					title: "Recent vehicles",
					subtitle: "Latest intake and workshop activity",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5 flex-wrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => setStageFilter((v) => !v),
								"aria-pressed": stageFilter,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {}), stageFilter ? "All vehicles" : "In repair"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
								filename: "workshop-overview",
								rows: vehicles
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ViewAllVehicles, {})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					headers: [
						{
							label: "Vehicle",
							sortKey: "vehicle"
						},
						{
							label: "Customer",
							sortKey: "customer"
						},
						{
							label: "Received",
							sortKey: "received"
						},
						{
							label: "Current stage",
							sortKey: "stage"
						},
						{
							label: "Department",
							sortKey: "department"
						},
						""
					],
					loading,
					sort: vehicleSort,
					onSort: (key) => setVehicleSort((current) => nextSortState(current, key)),
					empty: shownVehicles.length === 0,
					emptyState: stageFilter ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						icon: SlidersHorizontal,
						tone: "muted",
						title: "No vehicles currently in repair",
						description: "No vehicles match the active in-repair filter right now.",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setStageFilter(false),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Show all vehicles"]
						}), isForeman && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/registration",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Register vehicle"]
							})
						})] })
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						icon: Car,
						title: "No vehicles registered yet",
						description: "Register an incoming vehicle to track its progress from intake through inspection and handover.",
						action: isForeman ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/registration",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Register vehicle"]
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/vehicles",
								children: ["View vehicle records", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
							})
						})
					}),
					children: shownVehicles.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: vehicle.customer }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-muted-foreground",
							children: vehicle.received.replace(" 2026", "")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: [
							"Intake",
							"Quotation",
							"Awaiting approval",
							"Inventory card",
							"Job card",
							"Parts requisition",
							"Awaiting parts",
							"Procurement",
							"Parts dispatch",
							"In repair",
							"Inspection",
							"Awaiting release"
						][vehicle.stage] }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: vehicle.department }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							title: `View ${vehicle.plate}`,
							"aria-label": `View ${vehicle.plate}`,
							onClick: () => setDetail(vehicle.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
						}) })
					] }, vehicle.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableFooter, {
					count: shownVehicles.length,
					label: "recent vehicles"
				})
			]
		}),
		isDirector && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "table-section",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				title: "Parts authorization",
				subtitle: "Requests requiring a director decision",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "link",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/approvals",
						children: ["Review all requests", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 13 })]
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				headers: [
					{
						label: "Request",
						sortKey: "id"
					},
					{
						label: "Part",
						sortKey: "part"
					},
					{
						label: "Quantity",
						sortKey: "quantity",
						align: "right"
					},
					{
						label: "Department",
						sortKey: "department"
					},
					{
						label: "Status",
						sortKey: "status"
					},
					""
				],
				loading,
				sort: authSort,
				onSort: (key) => setAuthSort((current) => nextSortState(current, key)),
				empty: pending === 0,
				emptyState: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: ShieldCheck,
					title: "No parts awaiting authorization",
					description: "All submitted parts requisitions have been reviewed. New requests from foremen will appear here.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/approvals",
							children: ["View all requisitions", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})
				}),
				children: pendingAuthRequisitions.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: r.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.part }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "text-right tabular-nums",
						children: r.quantity
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.department }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: r.status }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/approvals",
							children: ["Approve", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 12 })]
						})
					}) })
				] }, r.id))
			})]
		}),
		isManagement && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "table-section",
			id: "dispatch-approvals",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				title: "Parts dispatch approvals",
				subtitle: "Approve dispatch orders before issue",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void refresh(),
					children: "Refresh"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				headers: [
					{
						label: "Dispatch",
						sortKey: "dispatch"
					},
					{
						label: "Job",
						sortKey: "job"
					},
					{
						label: "Department",
						sortKey: "department"
					},
					{
						label: "Status",
						sortKey: "status"
					},
					"Action"
				],
				loading,
				sort: dispatchSort,
				onSort: (key) => setDispatchSort((current) => nextSortState(current, key)),
				empty: !pendingDispatches.length,
				emptyState: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: Truck,
					title: "No pending dispatch approvals",
					description: "There are no workshop parts dispatches waiting for management sign-off.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => void refresh(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Refresh queue"]
					})
				}),
				children: pendingDispatches.map((dispatch) => {
					const dispatchId = Number(dispatch["dispatchOrderId"] ?? dispatch["id"]);
					const jobId = Number(dispatch["jobId"]);
					const job = jobs.find((candidate) => candidate.backendJobId === jobId);
					const vehicle = job ? vehicles.find((candidate) => candidate.id === job.vehicleId) : void 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "cell-title",
							children: String(dispatch["dispatchNumber"] ?? dispatchId)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: vehicle ? `${vehicle.plate} · ${vehicle.customer}` : String(dispatch["jobNumber"] ?? jobId) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: String(dispatch["departmentName"] ?? "—") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: String(dispatch["status"] ?? "Pending") }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							disabled: approvingDispatch === dispatchId,
							onClick: async () => {
								if (!Number.isSafeInteger(employeeId) || employeeId <= 0 || !employeeName) {
									toast.error("Set VITE_EMPLOYEE_ID to an active workshop employee before approving dispatches.");
									return;
								}
								setApprovingDispatch(dispatchId);
								try {
									await api.dispatchAction(dispatchId, "approve", {
										approvedByEmployeeId: employeeId,
										signerName: employeeName,
										remarks: "Approved from Management dashboard"
									});
									await refresh();
									toast.success("Dispatch approved.");
								} catch (approvalError) {
									toast.error(approvalError instanceof Error ? approvalError.message : "Could not approve dispatch.");
								} finally {
									setApprovingDispatch(null);
								}
							},
							children: "Approve"
						}) })
					] }, dispatchId);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
			title: "Department workload",
			subtitle: "Work coordinated by foremen, across the workshop",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "link",
				size: "sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/departments",
					children: ["View performance", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 13 })]
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DepartmentCards, {})] }),
		!isForeman && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overview-grid mt-7",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, { title: "Recent activity" }), activities.length > 0 ? activities.slice(0, 3).map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "activity-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: a.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: a.detail })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: a.time })
				]
			}, i)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				compact: true,
				icon: ClipboardList,
				tone: "muted",
				title: "No recent workshop activity",
				description: "Vehicle registrations, quotations, job cards, and approvals will appear here.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/vehicles",
						children: ["View vehicle records", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
					})
				})
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, { title: "Operational priorities" }),
				[
					{
						icon: Clock,
						count: pending,
						label: "pending requisitions",
						detail: "Awaiting director decision"
					},
					{
						icon: Package,
						count: pendingDispatches.length,
						label: "dispatches pending approval",
						detail: "Awaiting management decision"
					},
					{
						icon: FileText,
						count: awaitingRelease,
						label: "vehicles awaiting handover",
						detail: "Paid invoices without a recorded handover"
					}
				].filter((priority) => priority.count > 0).map((priority) => {
					const Icon = priority.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "activity-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							priority.count,
							" ",
							priority.label
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: priority.detail })] })]
					}, priority.label);
				}),
				!pending && !pendingDispatches.length && !awaitingRelease && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					compact: true,
					icon: CheckCircle2,
					tone: "muted",
					title: "No outstanding priorities",
					description: "No pending requisitions, dispatch approvals, or unpaid handovers require attention.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/alerts",
							children: ["View operational alerts", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
						})
					})
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleDetail, {
			id: detail,
			onClose: () => setDetail(null)
		})
	] });
}
//#endregion
export { DepartmentCards as n, Dashboard as t };
