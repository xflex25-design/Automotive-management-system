import { Ut as require_jsx_runtime } from "./button-ByH67M_G.js";
import { t as RecordsPage } from "./record-pages-Zto0897Q.js";
//#region src/routes/job-cards.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordsPage, { kind: "jobs" });
//#endregion
export { SplitComponent as component };
