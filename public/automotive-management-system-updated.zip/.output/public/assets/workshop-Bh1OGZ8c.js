import { c as WorkshopPage } from "./monitor-pages-B-tlhenF.js";
//#region src/routes/workshop.tsx?tsr-split=component
var SplitComponent = WorkshopPage;
//#endregion
export { SplitComponent as component };
