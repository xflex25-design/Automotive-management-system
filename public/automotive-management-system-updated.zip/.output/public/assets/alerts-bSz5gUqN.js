import { t as AlertsPage } from "./monitor-pages-B-tlhenF.js";
//#region src/routes/alerts.tsx?tsr-split=component
var SplitComponent = AlertsPage;
//#endregion
export { SplitComponent as component };
