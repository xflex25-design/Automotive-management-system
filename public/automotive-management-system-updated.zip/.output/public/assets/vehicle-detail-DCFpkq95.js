import { Gt as require_react, Ut as require_jsx_runtime, ct as useWorkspace, ot as cn, qt as __toESM, yt as stageName } from "./button-ByH67M_G.js";
import { a as DialogOverlay$1, i as DialogDescription$1, l as X, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "./dist-pmrAdYzb.js";
import { h as Workflow, u as Status } from "./shared-D1FqIhYl.js";
//#region src/components/ui/dialog.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-overlay data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-[calc(100%_-_32px)] max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 rounded-md border bg-background p-6", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-[var(--type-heading-leading)] tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm font-normal text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
//#endregion
//#region src/components/workshop/vehicle-detail.tsx
function VehicleDetail({ id, onClose }) {
	const { vehicleFor, quotations, jobs, requisitions } = useWorkspace();
	const vehicle = id ? vehicleFor(id) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!vehicle,
		onOpenChange: (open) => {
			if (!open) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-3xl modal-scroll",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: [
				vehicle?.make,
				" · ",
				vehicle?.plate
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				vehicle?.id,
				" · Received ",
				vehicle?.received
			] })] }), vehicle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "detail-grid",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Customer" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: vehicle.customer })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Contact number" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: vehicle.phone })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Current stage" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: vehicle.released ? "Released" : stageName(vehicle.stage) }) })] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "detail-notes",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Customer complaints" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: vehicle.complaints }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "block mt-4",
							children: "Existing damage"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: vehicle.damage })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "detail-notes",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Workshop records" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-3 mt-3",
						children: [
							quotations.filter((q) => q.vehicleId === id).map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								q.id,
								" · ",
								q.status
							] }, q.id)),
							jobs.filter((j) => j.vehicleId === id).map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								j.id,
								" · ",
								j.status
							] }, j.id)),
							requisitions.filter((r) => r.vehicleId === id).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								r.id,
								" · ",
								r.status
							] }, r.id))
						]
					})]
				}),
				vehicle.photos && vehicle.photos.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "uploaded-photos",
					children: vehicle.photos.map((url, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: url,
						alt: `Vehicle intake photograph ${i + 1}`
					}, url))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold text-base mt-3",
					children: "Vehicle workflow"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Workflow, { stage: vehicle.stage })
			] })]
		})
	});
}
//#endregion
export { DialogHeader as a, DialogDescription as i, Dialog as n, DialogTitle as o, DialogContent as r, VehicleDetail as t };
