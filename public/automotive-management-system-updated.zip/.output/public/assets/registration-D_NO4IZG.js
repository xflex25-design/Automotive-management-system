import { Ct as toast, Gt as require_react, Ut as require_jsx_runtime, ct as useWorkspace, qt as __toESM, s as ArrowRight, t as Button } from "./button-ByH67M_G.js";
import { n as useNavigate } from "./index-DDvlJ1GD.js";
import { n as Input, t as Textarea } from "./textarea-CehZkQXX.js";
//#region src/components/workshop/intake.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function IntakePage() {
	const { vehicles, setVehicles, foreman, addActivity } = useWorkspace();
	const navigate = useNavigate();
	const [saving, setSaving] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		const form = new FormData(event.currentTarget);
		const plate = String(form.get("plate") ?? "").trim().toUpperCase();
		if (vehicles.some((v) => v.plate === plate && !v.released)) {
			toast.error("This registration already has an active workshop record.");
			return;
		}
		setSaving(true);
		try {
			const id = `VR-${1069 + vehicles.length - 8}`;
			setVehicles((prev) => [{
				id,
				plate,
				make: String(form.get("make")),
				customer: String(form.get("customer")),
				phone: String(form.get("phone")),
				email: String(form.get("email")),
				received: "11 Nov 2026",
				stage: 0,
				department: "Unassigned",
				foreman,
				complaints: String(form.get("complaints")),
				damage: String(form.get("damage")),
				due: "",
				progress: 0,
				...String(form.get("vin") ?? "") ? { vin: String(form.get("vin")) } : {},
				...String(form.get("odometer") ?? "") ? { odometer: Number(form.get("odometer")) } : {},
				...String(form.get("colour") ?? "") ? { color: String(form.get("colour")) } : {}
			}, ...prev]);
			addActivity(`Vehicle registered: ${String(form.get("make"))}`, `${foreman} · ${id}`);
			toast.success(`${plate} registered. Ready for quotation.`);
			navigate({ to: "/vehicles" });
		} catch (cause) {
			toast.error(cause instanceof Error ? cause.message : "Vehicle registration failed.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "registration-panel",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "registration-header",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "Vehicle Registration" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: () => navigate({ to: "/vehicles" }),
				children: ["Vehicle records", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "registration-grid",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "reg-customer",
							className: "registration-label",
							children: ["Full Name ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-required",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "reg-customer",
							name: "customer",
							placeholder: "Customer full name",
							className: "registration-input",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "reg-plate",
							className: "registration-label",
							children: ["Registration Number ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-required",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "reg-plate",
							name: "plate",
							placeholder: "e.g. BCA 4821",
							className: "registration-input",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "reg-phone",
							className: "registration-label",
							children: ["Phone Number ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-required",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "reg-phone",
							type: "tel",
							name: "phone",
							placeholder: "+260",
							className: "registration-input",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "reg-make",
							className: "registration-label",
							children: ["Make & Model ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-required",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "reg-make",
							name: "make",
							placeholder: "e.g. Toyota Hilux",
							className: "registration-input",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "reg-email",
							className: "registration-label",
							children: "Email Address"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "reg-email",
							type: "email",
							name: "email",
							placeholder: "customer@example.com",
							className: "registration-input"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "reg-vin",
							className: "registration-label",
							children: "Chassis / VIN Number"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "reg-vin",
							name: "vin",
							placeholder: "Vehicle identification number",
							className: "registration-input"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "reg-colour",
							className: "registration-label",
							children: "Vehicle Colour"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "reg-colour",
							name: "colour",
							placeholder: "e.g. White",
							className: "registration-input"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "reg-odometer",
							className: "registration-label",
							children: "Odometer Reading (km)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "reg-odometer",
							name: "odometer",
							type: "number",
							min: "0",
							placeholder: "e.g. 124500",
							className: "registration-input"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row registration-row-top",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "reg-complaints",
							className: "registration-label",
							children: ["Customer Complaints ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-required",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "reg-complaints",
							name: "complaints",
							rows: 3,
							placeholder: "Record the customer's concerns and requested repairs",
							className: "registration-textarea",
							required: true
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row registration-row-top",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "reg-damage",
							className: "registration-label",
							children: ["Existing Damage ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-required",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "reg-damage",
							name: "damage",
							rows: 3,
							placeholder: "Record dents, scratches, or state no visible damage",
							className: "registration-textarea",
							required: true
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "registration-actions",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: saving,
					className: "registration-submit-btn",
					children: saving ? "Submitting…" : "Submit"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "reset",
					variant: "outline",
					className: "registration-reset-btn",
					children: "Reset"
				})]
			})]
		})]
	});
}
//#endregion
//#region src/routes/registration.tsx?tsr-split=component
var SplitComponent = IntakePage;
//#endregion
export { SplitComponent as component };
