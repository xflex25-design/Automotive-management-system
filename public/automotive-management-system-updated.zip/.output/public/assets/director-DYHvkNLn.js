import { Ut as require_jsx_runtime } from "./button-ByH67M_G.js";
import { t as Dashboard } from "./dashboard-BjlMLzjf.js";
//#region src/routes/director.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, { role: "Director" });
//#endregion
export { SplitComponent as component };
