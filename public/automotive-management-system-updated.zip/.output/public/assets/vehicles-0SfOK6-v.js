import { o as VehiclesPage } from "./monitor-pages-B-tlhenF.js";
//#region src/routes/vehicles.tsx?tsr-split=component
var SplitComponent = VehiclesPage;
//#endregion
export { SplitComponent as component };
