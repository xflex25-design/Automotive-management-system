import { n as ApprovalPage } from "./monitor-pages-B-tlhenF.js";
//#region src/routes/approvals.tsx?tsr-split=component
var SplitComponent = ApprovalPage;
//#endregion
export { SplitComponent as component };
