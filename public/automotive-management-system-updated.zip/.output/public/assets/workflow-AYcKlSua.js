import { s as WorkflowPage } from "./monitor-pages-B-tlhenF.js";
//#region src/routes/workflow.tsx?tsr-split=component
var SplitComponent = WorkflowPage;
//#endregion
export { SplitComponent as component };
