import { Ut as require_jsx_runtime, ct as useWorkspace } from "./button-ByH67M_G.js";
import { s as PageHeading } from "./shared-D1FqIhYl.js";
//#region src/routes/settings.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const w = useWorkspace();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
		title: "Account Settings",
		subtitle: "Your current workspace view"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-lg border bg-card p-5 text-sm space-y-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "Current view:"
			}),
			" ",
			w.role
		] })
	})] });
}
//#endregion
export { SettingsPage as component };
