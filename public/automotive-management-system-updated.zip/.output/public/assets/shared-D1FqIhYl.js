import { C as Download, E as FileText, Gt as require_react, Ut as require_jsx_runtime, W as Search, at as X, bt as stageOwners, c as ArrowUpRight, d as CalendarDays, h as Check, ht as formatCompactNumber, it as Wrench, ot as cn, p as Car, qt as __toESM, t as Button, v as ChevronRight, x as Clock, xt as workflowStages, y as ClipboardCheck, z as Package } from "./button-ByH67M_G.js";
import { t as Link } from "./index-DDvlJ1GD.js";
//#region src/components/ui/skeleton.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function Skeleton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-primary/10", className),
		...props
	});
}
//#endregion
//#region src/components/ui/table.tsx
function getAriaSort(direction) {
	if (direction === "asc") return "ascending";
	if (direction === "desc") return "descending";
	return "none";
}
function getSortButtonAriaLabel(label, direction) {
	const clean = label.trim() || "column";
	if (direction === "asc") return `Sort by ${clean}, currently sorted ascending. Activate to sort descending.`;
	if (direction === "desc") return `Sort by ${clean}, currently sorted descending. Activate to clear sorting.`;
	return `Sort by ${clean}, currently unsorted. Activate to sort ascending.`;
}
function SortIndicator({ direction, className }) {
	const state = direction ?? "none";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("table-sort-indicator", state !== "none" && "table-sort-indicator-active", className),
		"data-sort-direction": state,
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: "10",
			height: "14",
			viewBox: "0 0 10 14",
			fill: "none",
			xmlns: "http://www.w3.org/2000/svg",
			className: "table-sort-svg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M5 1L8.5 5.25H1.5L5 1Z",
				className: cn("table-sort-arrow table-sort-arrow-up", direction === "asc" && "is-active"),
				fill: "currentColor"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M5 13L1.5 8.75H8.5L5 13Z",
				className: cn("table-sort-arrow table-sort-arrow-down", direction === "desc" && "is-active"),
				fill: "currentColor"
			})]
		})
	});
}
var Table = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "relative w-full overflow-auto",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
		ref,
		className: cn("w-full caption-bottom text-sm tabular-nums", className),
		...props
	})
}));
Table.displayName = "Table";
var TableHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
	ref,
	className: cn("[&_tr]:border-b", className),
	...props
}));
TableHeader.displayName = "TableHeader";
var TableBody = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
	ref,
	className: cn("[&_tr:last-child]:border-0", className),
	...props
}));
TableBody.displayName = "TableBody";
var TableFooter$1 = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
	ref,
	className: cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className),
	...props
}));
TableFooter$1.displayName = "TableFooter";
var TableRow = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
	ref,
	className: cn("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className),
	...props
}));
TableRow.displayName = "TableRow";
var TableHead = import_react.forwardRef(({ className, children, sortDirection, onSort, sortLabel, align = "left", scope, ...props }, ref) => {
	const isRight = align === "right";
	const isSorted = sortDirection === "asc" || sortDirection === "desc";
	const resolvedLabel = sortLabel ?? (typeof children === "string" || typeof children === "number" ? String(children) : "");
	if (onSort) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
		ref,
		scope: scope ?? "col",
		"aria-sort": getAriaSort(sortDirection),
		className: cn("h-10 p-0 align-middle text-xs font-semibold tracking-label tabular-nums text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", isRight ? "text-right" : "text-left", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onSort,
			"aria-label": getSortButtonAriaLabel(resolvedLabel, sortDirection),
			className: cn("table-sort-btn table-sort-btn-ui", isSorted && "table-sort-btn-active", isRight && "table-sort-btn-right"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortIndicator, { direction: sortDirection })]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
		ref,
		scope: scope ?? "col",
		className: cn("h-10 px-2 align-middle text-xs font-semibold tracking-label tabular-nums text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", isRight ? "text-right" : "text-left", className),
		...props,
		children
	});
});
TableHead.displayName = "TableHead";
var TableCell = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
	ref,
	className: cn("p-2 align-middle text-[length:var(--type-table-cell-size)] font-normal tabular-nums [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
	...props
}));
TableCell.displayName = "TableCell";
var TableCaption = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
	ref,
	className: cn("mt-4 text-xs font-medium text-muted-foreground", className),
	...props
}));
TableCaption.displayName = "TableCaption";
//#endregion
//#region src/components/workshop/shared.tsx
function PageHeading({ title, subtitle, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "breadcrumb",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Workspace" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 12 }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: title })
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "page-heading",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: subtitle })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "heading-actions",
			children
		})]
	})] });
}
function SectionHeading({ title, subtitle, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "section-heading",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: title }), subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: subtitle })] }), children]
	});
}
function Status({ children: value }) {
	const children = value ?? "Intake";
	const normalized = children.toLowerCase();
	const isApproved = [
		"approved",
		"complete",
		"completed",
		"passed",
		"released",
		"confirmed"
	].includes(normalized);
	const isFlagged = [
		"flagged",
		"rejected",
		"rework required",
		"cancelled",
		"on hold"
	].includes(normalized);
	const isPending = [
		"pending",
		"awaiting approval",
		"awaiting parts",
		"draft",
		"customer authorization"
	].includes(normalized);
	let badgeColor = "status-blue";
	if (isApproved) badgeColor = "status-approved";
	else if (isFlagged) badgeColor = "status-flagged";
	else if (isPending) badgeColor = "status-pending";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: `status ${badgeColor}`,
		children: [isApproved && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 11 }), children]
	});
}
function Metrics({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "metric-grid",
		children: items.map((item) => {
			const displayValue = typeof item.value === "number" ? formatCompactNumber(item.value) : item.value;
			const iconToneClass = item.tone === "success" ? "metric-icon-success" : item.tone === "warning" ? "metric-icon-warning" : item.tone === "danger" ? "metric-icon-danger" : "";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "metric-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `metric-icon ${iconToneClass}`.trim(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "metric-label",
						children: item.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "metric-value-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "metric-value",
							title: typeof item.value === "number" ? item.value.toLocaleString() : void 0,
							children: displayValue
						}), item.delta && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `metric-delta metric-delta-${item.delta.direction}`,
							children: item.delta.text
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "metric-note",
						children: item.note ?? item.hint
					})] })
				]
			}, item.label);
		})
	});
}
var metricIcons = {
	Car,
	FileText,
	Wrench,
	Package,
	ClipboardCheck,
	Clock
};
function ProgressBar({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "progress-track",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("progress", {
			max: 100,
			value,
			"aria-label": `${value}% complete`
		})
	});
}
function EmptyState({ icon: Icon = FileText, title, description, action, actionLabel, onAction, tone = "default", compact = false, className }) {
	const toneClass = tone === "muted" ? "empty-state-tone-muted" : tone === "warning" ? "empty-state-tone-warning" : "empty-state-tone-default";
	const resolvedAction = action ?? (actionLabel && onAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "outline",
		size: "sm",
		onClick: onAction,
		children: actionLabel
	}) : null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-empty-state": "true",
		className: `empty-state ${compact ? "empty-state-compact" : ""} ${className ?? ""}`.trim(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `empty-state-illustration ${toneClass}`,
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "empty-state-icon",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: compact ? 17 : 21 })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "empty-state-title",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "empty-state-description",
				children: description
			}),
			resolvedAction && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "empty-state-actions",
				children: resolvedAction
			})
		]
	});
}
function isColumnConfig(header) {
	return typeof header === "object" && header !== null && !(0, import_react.isValidElement)(header) && "label" in header;
}
var SKELETON_CELL_WIDTHS = [
	"w-28",
	"w-36",
	"w-24",
	"w-20",
	"w-32",
	"w-16"
];
function DataTable({ headers, children, empty = false, emptyState, loading = false, loadingRows = 5, sort = null, onSort }) {
	const safeRows = Math.max(1, loadingRows);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "table-wrap",
		"aria-busy": loading || void 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "data-table",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: headers.map((h, i) => {
					if (isColumnConfig(h)) {
						const isRight = h.align === "right";
						if (h.sortKey && onSort) {
							const sortKey = h.sortKey;
							const isSorted = sort?.key === sortKey;
							const direction = isSorted ? sort.direction : null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								scope: "col",
								"aria-sort": getAriaSort(direction),
								className: `table-th-sortable ${isRight ? "text-right" : ""}`.trim(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => onSort(sortKey),
									"aria-label": getSortButtonAriaLabel(h.label, direction),
									className: `table-sort-btn ${isSorted ? "table-sort-btn-active" : ""} ${isRight ? "table-sort-btn-right" : ""}`.trim(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: h.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortIndicator, { direction })]
								})
							}, sortKey);
						}
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							scope: "col",
							className: isRight ? "text-right" : void 0,
							children: h.label
						}, h.label || `col-${i}`);
					}
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						scope: "col",
						children: h
					}, typeof h === "string" ? h || `col-${i}` : i);
				}) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: loading ? Array.from({ length: safeRows }, (_, rowIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
					className: "table-skeleton-row",
					"aria-hidden": "true",
					children: headers.map((h, colIndex) => {
						const isRight = isColumnConfig(h) && h.align === "right";
						const widthClass = SKELETON_CELL_WIDTHS[(rowIndex + colIndex) % SKELETON_CELL_WIDTHS.length];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `flex flex-col gap-1.5 ${isRight ? "items-end" : ""}`.trim(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: `h-3.5 ${widthClass}` }), colIndex === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-2.5 w-16 opacity-70" })]
						}) }, `skeleton-${rowIndex}-${colIndex}`);
					})
				}, `skeleton-${rowIndex}`)) : children })]
			}),
			loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				role: "status",
				"aria-live": "polite",
				children: "Loading table records..."
			}),
			!loading && empty && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "empty-state-wrap",
				children: emptyState ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: Search,
					tone: "muted",
					title: "No matching records",
					description: "No records match your current search or filter selection."
				})
			})
		]
	});
}
function VehicleCell({ vehicle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "cell-title",
		children: vehicle?.make ?? "Vehicle"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "cell-subtitle",
		children: [
			vehicle?.plate ?? "—",
			" · ",
			vehicle?.id ?? "—"
		]
	})] });
}
function TableFooter({ count, label = "records" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "table-footer",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			"Showing ",
			count,
			" ",
			label
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Updated 11 Nov 2026" })]
	});
}
function LineChart({ values, labels }) {
	const chartValues = values.length === 6 ? values : [
		0,
		0,
		0,
		0,
		0,
		0
	];
	const chartLabels = labels.length === 6 ? labels : [
		"",
		"",
		"",
		"",
		"",
		""
	];
	const max = Math.max(1, ...chartValues);
	const points = chartValues.map((value, index) => ({
		x: 35 + index * 94,
		y: 134 - value / max * 112
	}));
	const line = `M${points.map(({ x, y }) => `${x},${y}`).join("L")}`;
	const area = `${line}L505 134H35Z`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "chart",
		viewBox: "0 0 520 170",
		role: "img",
		"aria-label": `Vehicles received: ${chartValues.join(", ")}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				className: "chart-grid",
				d: "M35 20H505 M35 58H505 M35 96H505 M35 134H505"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "5",
				y: "23",
				children: max
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "5",
				y: "61",
				children: Math.round(max * (2 / 3))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "10",
				y: "99",
				children: Math.round(max / 3)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "10",
				y: "137",
				children: "0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				className: "chart-area",
				d: area
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				className: "chart-line",
				d: line
			}),
			points.map(({ x, y }, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				className: "chart-point",
				cx: x,
				cy: y,
				r: "3.6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", { children: `${chartLabels[i]}: ${chartValues[i]} vehicles` })
			}, i)),
			chartLabels.map((day, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: 35 + i * 94,
				y: "159",
				textAnchor: "middle",
				children: day
			}, `${day}-${i}`))
		]
	});
}
function Workflow({ stage }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "workflow-list",
		children: workflowStages.map((name, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `workflow-step ${index < stage ? "step-done" : index === stage ? "step-current" : ""}`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "step-number",
				children: index < stage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 13 }) : String(index + 1).padStart(2, "0")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: stageOwners[index] })] })]
		}, name))
	});
}
function ExportButton({ filename, rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		onClick: () => exportCsv(filename, rows),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Export report"]
	});
}
function exportCsv(filename, rows) {
	if (rows.length === 0) return;
	const first = rows[0];
	if (!first) return;
	const keys = Object.keys(first);
	const escape = (value) => {
		const text = String(value ?? "");
		return `"${(/^[=+@-]/.test(text) ? "'" : "") + text.replaceAll("\"", "\"\"")}"`;
	};
	const data = [keys.map(escape).join(","), ...rows.map((row) => keys.map((key) => escape(row[key])).join(","))].join("\r\n");
	const url = URL.createObjectURL(new Blob([data], { type: "text/csv;charset=utf-8;" }));
	const a = document.createElement("a");
	a.href = url;
	a.download = `${filename}.csv`;
	a.click();
	URL.revokeObjectURL(url);
}
function ViewAllVehicles() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		asChild: true,
		variant: "link",
		size: "sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/vehicles",
			children: ["View all vehicles", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 13 })]
		})
	});
}
function DateFilter({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		size: "sm",
		onClick: () => onChange(value === "This week" ? "This month" : "This week"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, {}), value]
	});
}
function ToolbarSearch({ value, onChange, placeholder, ariaLabel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "filter-search",
		role: "search",
		onSubmit: (e) => {
			e.preventDefault();
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "filter-search-field",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
					size: 14,
					className: "filter-search-icon",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "text",
					"aria-label": ariaLabel,
					placeholder,
					value,
					onChange: (e) => onChange(e.target.value)
				}),
				value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "filter-search-clear",
					"aria-label": "Clear filter",
					title: "Clear filter",
					onClick: () => onChange(""),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 12 })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "submit",
			className: "filter-search-btn",
			"aria-label": "Search records",
			title: "Search",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 13 })
		})]
	});
}
//#endregion
export { TableRow as C, TableHeader as S, metricIcons as _, LineChart as a, TableCell as b, ProgressBar as c, TableFooter as d, ToolbarSearch as f, exportCsv as g, Workflow as h, ExportButton as i, SectionHeading as l, ViewAllVehicles as m, DateFilter as n, Metrics as o, VehicleCell as p, EmptyState as r, PageHeading as s, DataTable as t, Status as u, Table as v, TableHead as x, TableBody as y };
