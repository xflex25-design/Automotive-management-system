import { B as Plus, Ct as toast, E as FileText, G as Send, Gt as require_react, H as RotateCcw, J as ShieldCheck, U as Save, Ut as require_jsx_runtime, V as Printer, W as Search, Wt as require_react_dom, _t as nextSortState, at as X, b as ClipboardList, c as ArrowUpRight, ct as useWorkspace, dt as canCreateInventory, f as Camera, ft as canDecideParts, gt as money, h as Check$1, i as useComposedRefs, lt as backendApi, mt as departments, o as Archive, ot as cn, qt as __toESM, r as createSlot, t as Button, vt as sortRecords, y as ClipboardCheck, z as Package } from "./button-ByH67M_G.js";
import { n as Input, t as Textarea } from "./textarea-CehZkQXX.js";
import { C as createContextScope, S as useLayoutEffect2, _ as FocusScope, b as useCallbackRef, d as ReactRemoveScroll, f as hideOthers, g as useId, h as Portal, m as Presence, p as useControllableState, u as createLucideIcon, v as useFocusGuards, w as composeEventHandlers, x as Primitive, y as DismissableLayer } from "./dist-pmrAdYzb.js";
import { a as DialogHeader, i as DialogDescription, n as Dialog, o as DialogTitle, r as DialogContent, t as VehicleDetail } from "./vehicle-detail-DCFpkq95.js";
import { C as TableRow, S as TableHeader, b as TableCell, d as TableFooter, f as ToolbarSearch, i as ExportButton, p as VehicleCell, r as EmptyState, s as PageHeading, t as DataTable, u as Status, v as Table, x as TableHead, y as TableBody } from "./shared-D1FqIhYl.js";
//#region node_modules/@radix-ui/number/dist/index.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var __defProp$5 = Object.defineProperty;
var __name$5 = (target, value) => __defProp$5(target, "name", {
	value,
	configurable: true
});
function clamp$1(value, [min, max]) {
	return Math.min(max, Math.max(min, value));
}
__name$5(clamp$1, "clamp");
//#endregion
//#region node_modules/@radix-ui/react-collection/dist/index.mjs
var import_jsx_runtime = require_jsx_runtime();
var __defProp$4 = Object.defineProperty;
var __name$4 = (target, value) => __defProp$4(target, "name", {
	value,
	configurable: true
});
// @__NO_SIDE_EFFECTS__
function createCollection(name) {
	const PROVIDER_NAME = name + "CollectionProvider";
	const [createCollectionContext, createCollectionScope] = createContextScope(PROVIDER_NAME);
	const [CollectionProviderImpl, useCollectionContext] = createCollectionContext(PROVIDER_NAME, {
		collectionRef: { current: null },
		itemMap: /* @__PURE__ */ new Map()
	});
	const CollectionProvider = /* @__PURE__ */ __name$4((props) => {
		const { scope, children } = props;
		const ref = import_react.useRef(null);
		const itemMap = import_react.useRef(/* @__PURE__ */ new Map()).current;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			scope,
			itemMap,
			collectionRef: ref,
			children
		});
	}, "CollectionProvider");
	CollectionProvider.displayName = PROVIDER_NAME;
	const COLLECTION_SLOT_NAME = name + "CollectionSlot";
	const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
	const CollectionSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children } = props;
		const context = useCollectionContext(COLLECTION_SLOT_NAME, scope);
		const composedRefs = useComposedRefs(forwardedRef, context.collectionRef);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionSlotImpl, {
			ref: composedRefs,
			children
		});
	});
	CollectionSlot.displayName = COLLECTION_SLOT_NAME;
	const ITEM_SLOT_NAME = name + "CollectionItemSlot";
	const ITEM_DATA_ATTR = "data-radix-collection-item";
	const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
	const CollectionItemSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children, ...itemData } = props;
		const ref = import_react.useRef(null);
		const composedRefs = useComposedRefs(forwardedRef, ref);
		const context = useCollectionContext(ITEM_SLOT_NAME, scope);
		import_react.useEffect(() => {
			context.itemMap.set(ref, {
				ref,
				...itemData
			});
			return () => void context.itemMap.delete(ref);
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionItemSlotImpl, {
			[ITEM_DATA_ATTR]: "",
			ref: composedRefs,
			children
		});
	});
	CollectionItemSlot.displayName = ITEM_SLOT_NAME;
	function useCollection(scope) {
		const context = useCollectionContext(name + "CollectionConsumer", scope);
		return import_react.useCallback(() => {
			const collectionNode = context.collectionRef.current;
			if (!collectionNode) return [];
			const orderedNodes = Array.from(collectionNode.querySelectorAll(`[${ITEM_DATA_ATTR}]`));
			return Array.from(context.itemMap.values()).sort((a, b) => orderedNodes.indexOf(a.ref.current) - orderedNodes.indexOf(b.ref.current));
		}, [context.collectionRef, context.itemMap]);
	}
	__name$4(useCollection, "useCollection");
	return [
		{
			Provider: CollectionProvider,
			Slot: CollectionSlot,
			ItemSlot: CollectionItemSlot
		},
		useCollection,
		createCollectionScope
	];
}
__name$4(createCollection, "createCollection");
var __instanciated = /* @__PURE__ */ new WeakMap();
var OrderedDict = class _OrderedDict extends Map {
	static {
		__name$4(this, "OrderedDict");
	}
	#keys;
	constructor(entries) {
		super(entries);
		this.#keys = [...super.keys()];
		__instanciated.set(this, true);
	}
	set(key, value) {
		if (__instanciated.get(this) && !this.has(key)) this.#keys.push(key);
		super.set(key, value);
		return this;
	}
	/**
	* Sets a key-value pair so that it ends up at the given index.
	* - Existing keys are moved
	* - Negative indices count from the end of the resulting dictionary, so
	*   inserting at -1 makes the item the last one, -2 the second to last, etc.
	* - Out-of-range indices are clamped
	*/
	insert(index, key, value) {
		const has = this.has(key);
		const finalSize = has ? this.size : this.size + 1;
		const relativeIndex = toSafeInteger(index);
		const targetIndex = relativeIndex >= 0 ? Math.min(relativeIndex, finalSize - 1) : Math.max(finalSize + relativeIndex, 0);
		if (has ? this.#keys.indexOf(key) === targetIndex : targetIndex === this.size) {
			this.set(key, value);
			return this;
		}
		const keys = this.#keys.filter((existingKey) => existingKey !== key);
		keys.splice(targetIndex, 0, key);
		const entries = keys.map((entryKey) => [entryKey, entryKey === key ? value : this.get(entryKey)]);
		this.clear();
		for (const [entryKey, entryValue] of entries) this.set(entryKey, entryValue);
		return this;
	}
	with(index, key, value) {
		const copy = new _OrderedDict(this);
		copy.insert(index, key, value);
		return copy;
	}
	before(key) {
		const index = this.#keys.indexOf(key) - 1;
		if (index < 0) return;
		return this.entryAt(index);
	}
	/**
	* Sets a new key-value pair at the position before the given key.
	*/
	setBefore(key, newKey, value) {
		const index = this.#keys.indexOf(key);
		if (index === -1) return this;
		const currentIndex = this.#keys.indexOf(newKey);
		const targetIndex = currentIndex !== -1 && currentIndex < index ? index - 1 : index;
		return this.insert(targetIndex, newKey, value);
	}
	after(key) {
		let index = this.#keys.indexOf(key);
		index = index === -1 || index === this.size - 1 ? -1 : index + 1;
		if (index === -1) return;
		return this.entryAt(index);
	}
	/**
	* Sets a new key-value pair at the position after the given key.
	*/
	setAfter(key, newKey, value) {
		const index = this.#keys.indexOf(key);
		if (index === -1) return this;
		const currentIndex = this.#keys.indexOf(newKey);
		const targetIndex = currentIndex !== -1 && currentIndex <= index ? index : index + 1;
		return this.insert(targetIndex, newKey, value);
	}
	first() {
		return this.entryAt(0);
	}
	last() {
		return this.entryAt(-1);
	}
	clear() {
		this.#keys = [];
		return super.clear();
	}
	delete(key) {
		const deleted = super.delete(key);
		if (deleted) this.#keys.splice(this.#keys.indexOf(key), 1);
		return deleted;
	}
	deleteAt(index) {
		const key = this.keyAt(index);
		if (key !== void 0) return this.delete(key);
		return false;
	}
	at(index) {
		const key = at(this.#keys, index);
		if (key !== void 0) return this.get(key);
	}
	entryAt(index) {
		const key = at(this.#keys, index);
		if (key !== void 0) return [key, this.get(key)];
	}
	indexOf(key) {
		return this.#keys.indexOf(key);
	}
	keyAt(index) {
		return at(this.#keys, index);
	}
	from(key, offset) {
		const index = this.indexOf(key);
		if (index === -1) return;
		let dest = index + offset;
		if (dest < 0) dest = 0;
		if (dest >= this.size) dest = this.size - 1;
		return this.at(dest);
	}
	keyFrom(key, offset) {
		const index = this.indexOf(key);
		if (index === -1) return;
		let dest = index + offset;
		if (dest < 0) dest = 0;
		if (dest >= this.size) dest = this.size - 1;
		return this.keyAt(dest);
	}
	find(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return entry;
			index++;
		}
	}
	findIndex(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return index;
			index++;
		}
		return -1;
	}
	filter(predicate, thisArg) {
		const entries = [];
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) entries.push(entry);
			index++;
		}
		return new _OrderedDict(entries);
	}
	map(callbackfn, thisArg) {
		const entries = [];
		let index = 0;
		for (const entry of this) {
			entries.push([entry[0], Reflect.apply(callbackfn, thisArg, [
				entry,
				index,
				this
			])]);
			index++;
		}
		return new _OrderedDict(entries);
	}
	reduce(...args) {
		const [callbackfn, initialValue] = args;
		const hasInitialValue = args.length > 1;
		if (!hasInitialValue && this.size === 0) throw new TypeError("Reduce of empty OrderedDict with no initial value");
		let index = 0;
		let accumulator = initialValue;
		for (const entry of this) {
			if (index === 0 && !hasInitialValue) accumulator = entry;
			else accumulator = Reflect.apply(callbackfn, this, [
				accumulator,
				entry,
				index,
				this
			]);
			index++;
		}
		return accumulator;
	}
	reduceRight(...args) {
		const [callbackfn, initialValue] = args;
		const hasInitialValue = args.length > 1;
		if (!hasInitialValue && this.size === 0) throw new TypeError("Reduce of empty OrderedDict with no initial value");
		let accumulator = initialValue;
		for (let index = this.size - 1; index >= 0; index--) {
			const entry = this.entryAt(index);
			if (index === this.size - 1 && !hasInitialValue) accumulator = entry;
			else accumulator = Reflect.apply(callbackfn, this, [
				accumulator,
				entry,
				index,
				this
			]);
		}
		return accumulator;
	}
	/**
	* Sorts the dictionary in place. This method mutates the dictionary and
	* returns a reference to the same object
	*
	* @param compareFn Function used to determine the order of the elements. It
	* is expected to return a negative value if the first argument is less than
	* the second argument, zero if they're equal, and a positive value otherwise.
	*/
	sort(compareFn) {
		if (typeof compareFn !== "function") throw new TypeError(`OrderedDict.sort requires a compare function`);
		const entries = [...this.entries()].sort(compareFn);
		this.clear();
		for (const [key, value] of entries) this.set(key, value);
		return this;
	}
	/**
	* Returns a copy of the dictionary with its elements sorted.
	*
	* @param compareFn Function used to determine the order of the elements. It
	* is expected to return a negative value if the first argument is less than
	* the second argument, zero if they're equal, and a positive value otherwise.
	*/
	toSorted(compareFn) {
		if (typeof compareFn !== "function") throw new TypeError(`OrderedDict.toSorted requires a compare function`);
		const entries = [...this.entries()].sort(compareFn);
		return new _OrderedDict(entries);
	}
	toReversed() {
		const reversed = new _OrderedDict();
		for (let index = this.size - 1; index >= 0; index--) {
			const key = this.keyAt(index);
			const element = this.get(key);
			reversed.set(key, element);
		}
		return reversed;
	}
	toSpliced(...args) {
		const entries = [...this.entries()];
		entries.splice(...args);
		return new _OrderedDict(entries);
	}
	slice(start, end) {
		const result = new _OrderedDict();
		for (const key of this.#keys.slice(start, end)) result.set(key, this.get(key));
		return result;
	}
	every(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (!Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return false;
			index++;
		}
		return true;
	}
	some(predicate, thisArg) {
		let index = 0;
		for (const entry of this) {
			if (Reflect.apply(predicate, thisArg, [
				entry,
				index,
				this
			])) return true;
			index++;
		}
		return false;
	}
};
function at(array, index) {
	if ("at" in Array.prototype) return Array.prototype.at.call(array, index);
	const actualIndex = toSafeIndex(array, index);
	return actualIndex === -1 ? void 0 : array[actualIndex];
}
__name$4(at, "at");
function toSafeIndex(array, index) {
	const length = array.length;
	const relativeIndex = toSafeInteger(index);
	const actualIndex = relativeIndex >= 0 ? relativeIndex : length + relativeIndex;
	return actualIndex < 0 || actualIndex >= length ? -1 : actualIndex;
}
__name$4(toSafeIndex, "toSafeIndex");
function toSafeInteger(number) {
	return number !== number || number === 0 ? 0 : Math.trunc(number);
}
__name$4(toSafeInteger, "toSafeInteger");
// @__NO_SIDE_EFFECTS__
function createCollection2(name) {
	const PROVIDER_NAME = name + "CollectionProvider";
	const [createCollectionContext, createCollectionScope] = createContextScope(PROVIDER_NAME);
	const [CollectionStableContextProvider, useStableCollectionContext] = createCollectionContext(PROVIDER_NAME);
	CollectionStableContextProvider.displayName = name + "CollectionStableContextProvider";
	const [CollectionStatefulContextProvider, useStatefulCollectionContext] = createCollectionContext(PROVIDER_NAME);
	CollectionStatefulContextProvider.displayName = name + "CollectionStatefulContextProvider";
	const CollectionProvider = /* @__PURE__ */ __name$4(({ state, ...props }) => {
		return state ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			...props,
			state
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionInit, { ...props });
	}, "CollectionProvider");
	CollectionProvider.displayName = PROVIDER_NAME;
	const CollectionInit = /* @__PURE__ */ __name$4((props) => {
		const state = useInitCollection();
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionProviderImpl, {
			...props,
			state
		});
	}, "CollectionInit");
	CollectionInit.displayName = name + "CollectionInit";
	const CollectionProviderImpl = /* @__PURE__ */ __name$4((props) => {
		const { scope, children, state } = props;
		const ref = import_react.useRef(null);
		const [collectionElement, setCollectionElement] = import_react.useState(null);
		const composeRefs = useComposedRefs(ref, setCollectionElement);
		const [collection, setCollection] = state;
		const registryRef = import_react.useRef(new OrderedDict());
		const getCollection = import_react.useCallback(() => {
			const registry = registryRef.current;
			if (!isInDocumentOrder(registry)) registry.sort(sortByDocumentPosition);
			return registry;
		}, []);
		import_react.useEffect(() => {
			if (!collectionElement) return;
			const observer = getChildListObserver(() => {
				setCollection((map) => {
					const sorted = map.toSorted(sortByDocumentPosition);
					return sorted.some(([key], index) => map.keyAt(index) !== key) ? sorted : map;
				});
			});
			observer.observe(collectionElement, {
				childList: true,
				subtree: true
			});
			return () => {
				observer.disconnect();
			};
		}, [collectionElement, setCollection]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionStableContextProvider, {
			scope,
			collectionElementRef: composeRefs,
			collectionElementRefObject: ref,
			getCollection,
			setCollection,
			registryRef,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionStatefulContextProvider, {
				scope,
				collectionElement,
				collection,
				children
			})
		});
	}, "CollectionProviderImpl");
	CollectionProviderImpl.displayName = name + "CollectionProviderImpl";
	const COLLECTION_SLOT_NAME = name + "CollectionSlot";
	const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
	const CollectionSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children } = props;
		const context = useStableCollectionContext(COLLECTION_SLOT_NAME, scope);
		const composedRefs = useComposedRefs(forwardedRef, context.collectionElementRef);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionSlotImpl, {
			ref: composedRefs,
			children
		});
	});
	CollectionSlot.displayName = COLLECTION_SLOT_NAME;
	const ITEM_SLOT_NAME = name + "CollectionItemSlot";
	const ITEM_DATA_ATTR = "data-radix-collection-item";
	const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
	const CollectionItemSlot = import_react.forwardRef((props, forwardedRef) => {
		const { scope, children, ...itemData } = props;
		const ref = import_react.useRef(null);
		const { setCollection, registryRef } = useStableCollectionContext(ITEM_SLOT_NAME, scope);
		const itemDataRef = import_react.useRef(itemData);
		if (!shallowEqual(itemDataRef.current, itemData)) itemDataRef.current = itemData;
		const memoizedItemData = itemDataRef.current;
		const registerElement = import_react.useCallback((node) => {
			const registry = registryRef.current;
			if (node) registry.set(node, {
				...itemDataRef.current,
				element: node
			});
			else if (ref.current) registry.delete(ref.current);
		}, [registryRef]);
		const composedRefs = useComposedRefs(forwardedRef, registerElement, ref);
		useLayoutEffect2(() => {
			const node = ref.current;
			const registry = registryRef.current;
			if (node && registry.has(node)) registry.set(node, {
				...memoizedItemData,
				element: node
			});
		}, [memoizedItemData, registryRef]);
		const registeredRef = import_react.useRef(null);
		import_react.useEffect(() => {
			const element = ref.current;
			const registered = registeredRef.current;
			if ((registered?.element ?? null) === element && (!element || registered?.itemData === memoizedItemData)) return;
			registeredRef.current = element ? {
				element,
				itemData: memoizedItemData
			} : null;
			setCollection((map) => {
				const next = new OrderedDict(map);
				if (registered && registered.element !== element) next.delete(registered.element);
				if (element) next.set(element, {
					...memoizedItemData,
					element
				});
				return next.sort(sortByDocumentPosition);
			});
		});
		import_react.useEffect(() => {
			return () => {
				const registered = registeredRef.current;
				registeredRef.current = null;
				if (!registered) return;
				setCollection((map) => {
					if (!map.has(registered.element)) return map;
					const next = new OrderedDict(map);
					next.delete(registered.element);
					return next;
				});
			};
		}, [setCollection]);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionItemSlotImpl, {
			[ITEM_DATA_ATTR]: "",
			ref: composedRefs,
			children
		});
	});
	CollectionItemSlot.displayName = ITEM_SLOT_NAME;
	function useInitCollection() {
		return import_react.useState(new OrderedDict());
	}
	__name$4(useInitCollection, "useInitCollection");
	function useCollection(scope) {
		const { collection } = useStatefulCollectionContext(name + "CollectionConsumer", scope);
		return collection;
	}
	__name$4(useCollection, "useCollection");
	function useGetCollection(scope) {
		const { getCollection } = useStableCollectionContext(name + "CollectionConsumer", scope);
		return getCollection;
	}
	__name$4(useGetCollection, "useGetCollection");
	return [{
		Provider: CollectionProvider,
		Slot: CollectionSlot,
		ItemSlot: CollectionItemSlot
	}, {
		createCollectionScope,
		useCollection,
		useGetCollection,
		useInitCollection
	}];
}
__name$4(createCollection2, "createCollection");
function shallowEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== "object" || typeof b !== "object") return false;
	if (a == null || b == null) return false;
	const keysA = Object.keys(a);
	const keysB = Object.keys(b);
	if (keysA.length !== keysB.length) return false;
	for (const key of keysA) {
		if (!Object.prototype.hasOwnProperty.call(b, key)) return false;
		if (a[key] !== b[key]) return false;
	}
	return true;
}
__name$4(shallowEqual, "shallowEqual");
function isElementPreceding(a, b) {
	return !!(b.compareDocumentPosition(a) & Node.DOCUMENT_POSITION_PRECEDING);
}
__name$4(isElementPreceding, "isElementPreceding");
function isInDocumentOrder(dict) {
	let previous;
	for (const element of dict.keys()) {
		if (previous) {
			const position = previous.compareDocumentPosition(element);
			if (!(position & Node.DOCUMENT_POSITION_DISCONNECTED) && position & Node.DOCUMENT_POSITION_PRECEDING) return false;
		}
		previous = element;
	}
	return true;
}
__name$4(isInDocumentOrder, "isInDocumentOrder");
function sortByDocumentPosition(a, b) {
	return !a[1].element || !b[1].element ? 0 : isElementPreceding(a[1].element, b[1].element) ? -1 : 1;
}
__name$4(sortByDocumentPosition, "sortByDocumentPosition");
function getChildListObserver(callback) {
	return new MutationObserver((mutationsList) => {
		for (const mutation of mutationsList) if (mutation.type === "childList") {
			callback();
			return;
		}
	});
}
__name$4(getChildListObserver, "getChildListObserver");
//#endregion
//#region node_modules/@radix-ui/react-direction/dist/index.mjs
var __defProp$3 = Object.defineProperty;
var __name$3 = (target, value) => __defProp$3(target, "name", {
	value,
	configurable: true
});
var Direction$1 = {
	LTR: "ltr",
	RTL: "rtl"
};
var DirectionContext = import_react.createContext(void 0);
function useDirection(localDir) {
	const globalDir = import_react.useContext(DirectionContext);
	return localDir || globalDir || Direction$1.LTR;
}
__name$3(useDirection, "useDirection");
//#endregion
//#region node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
/**
* Custom positioning reference element.
* @see https://floating-ui.com/docs/virtual-elements
*/
var sides = [
	"top",
	"right",
	"bottom",
	"left"
];
var min = Math.min;
var max = Math.max;
var round = Math.round;
var floor = Math.floor;
var createCoords = (v) => ({
	x: v,
	y: v
});
var oppositeSideMap = {
	left: "right",
	right: "left",
	bottom: "top",
	top: "bottom"
};
function clamp(start, value, end) {
	return max(start, min(value, end));
}
function evaluate(value, param) {
	return typeof value === "function" ? value(param) : value;
}
function getSide(placement) {
	return placement.split("-")[0];
}
function getAlignment(placement) {
	return placement.split("-")[1];
}
function getOppositeAxis(axis) {
	return axis === "x" ? "y" : "x";
}
function getAxisLength(axis) {
	return axis === "y" ? "height" : "width";
}
function getSideAxis(placement) {
	const firstChar = placement[0];
	return firstChar === "t" || firstChar === "b" ? "y" : "x";
}
function getAlignmentAxis(placement) {
	return getOppositeAxis(getSideAxis(placement));
}
function getAlignmentSides(placement, rects, rtl) {
	if (rtl === void 0) rtl = false;
	const alignment = getAlignment(placement);
	const alignmentAxis = getAlignmentAxis(placement);
	const length = getAxisLength(alignmentAxis);
	let mainAlignmentSide = alignmentAxis === "x" ? alignment === (rtl ? "end" : "start") ? "right" : "left" : alignment === "start" ? "bottom" : "top";
	if (rects.reference[length] > rects.floating[length]) mainAlignmentSide = getOppositePlacement(mainAlignmentSide);
	return [mainAlignmentSide, getOppositePlacement(mainAlignmentSide)];
}
function getExpandedPlacements(placement) {
	const oppositePlacement = getOppositePlacement(placement);
	return [
		getOppositeAlignmentPlacement(placement),
		oppositePlacement,
		getOppositeAlignmentPlacement(oppositePlacement)
	];
}
function getOppositeAlignmentPlacement(placement) {
	return placement.includes("start") ? placement.replace("start", "end") : placement.replace("end", "start");
}
var lrPlacement = ["left", "right"];
var rlPlacement = ["right", "left"];
var tbPlacement = ["top", "bottom"];
var btPlacement = ["bottom", "top"];
function getSideList(side, isStart, rtl) {
	switch (side) {
		case "top":
		case "bottom":
			if (rtl) return isStart ? rlPlacement : lrPlacement;
			return isStart ? lrPlacement : rlPlacement;
		case "left":
		case "right": return isStart ? tbPlacement : btPlacement;
		default: return [];
	}
}
function getOppositeAxisPlacements(placement, flipAlignment, direction, rtl) {
	const alignment = getAlignment(placement);
	let list = getSideList(getSide(placement), direction === "start", rtl);
	if (alignment) {
		list = list.map((side) => side + "-" + alignment);
		if (flipAlignment) list = list.concat(list.map(getOppositeAlignmentPlacement));
	}
	return list;
}
function getOppositePlacement(placement) {
	const side = getSide(placement);
	return oppositeSideMap[side] + placement.slice(side.length);
}
function expandPaddingObject(padding) {
	var _padding$top, _padding$right, _padding$bottom, _padding$left;
	return {
		top: (_padding$top = padding.top) != null ? _padding$top : 0,
		right: (_padding$right = padding.right) != null ? _padding$right : 0,
		bottom: (_padding$bottom = padding.bottom) != null ? _padding$bottom : 0,
		left: (_padding$left = padding.left) != null ? _padding$left : 0
	};
}
function getPaddingObject(padding) {
	return typeof padding !== "number" ? expandPaddingObject(padding) : {
		top: padding,
		right: padding,
		bottom: padding,
		left: padding
	};
}
function rectToClientRect(rect) {
	const { x, y, width, height } = rect;
	return {
		width,
		height,
		top: y,
		left: x,
		right: x + width,
		bottom: y + height,
		x,
		y
	};
}
//#endregion
//#region node_modules/@floating-ui/core/dist/floating-ui.core.mjs
function computeCoordsFromPlacement(_ref, placement, rtl) {
	let { reference, floating } = _ref;
	const sideAxis = getSideAxis(placement);
	const alignmentAxis = getAlignmentAxis(placement);
	const alignLength = getAxisLength(alignmentAxis);
	const side = getSide(placement);
	const isVertical = sideAxis === "y";
	const commonX = reference.x + reference.width / 2 - floating.width / 2;
	const commonY = reference.y + reference.height / 2 - floating.height / 2;
	const commonAlign = reference[alignLength] / 2 - floating[alignLength] / 2;
	let coords;
	switch (side) {
		case "top":
			coords = {
				x: commonX,
				y: reference.y - floating.height
			};
			break;
		case "bottom":
			coords = {
				x: commonX,
				y: reference.y + reference.height
			};
			break;
		case "right":
			coords = {
				x: reference.x + reference.width,
				y: commonY
			};
			break;
		case "left":
			coords = {
				x: reference.x - floating.width,
				y: commonY
			};
			break;
		default: coords = {
			x: reference.x,
			y: reference.y
		};
	}
	const alignment = getAlignment(placement);
	if (alignment) coords[alignmentAxis] += commonAlign * (alignment === "end" ? 1 : -1) * (rtl && isVertical ? -1 : 1);
	return coords;
}
/**
* Resolves with an object of overflow side offsets that determine how much the
* element is overflowing a given clipping boundary on each side.
* - positive = overflowing the boundary by that number of pixels
* - negative = how many pixels left before it will overflow
* - 0 = lies flush with the boundary
* @see https://floating-ui.com/docs/detectOverflow
*/
async function detectOverflow(state, options) {
	var _await$platform$isEle;
	if (options === void 0) options = {};
	const { x, y, platform, rects, elements, strategy } = state;
	const { boundary = "clippingAncestors", rootBoundary = "viewport", elementContext = "floating", altBoundary = false, padding = 0 } = evaluate(options, state);
	const paddingObject = getPaddingObject(padding);
	const element = elements[altBoundary ? elementContext === "floating" ? "reference" : "floating" : elementContext];
	const clippingClientRect = rectToClientRect(await platform.getClippingRect({
		element: ((_await$platform$isEle = await (platform.isElement == null ? void 0 : platform.isElement(element))) != null ? _await$platform$isEle : true) ? element : element.contextElement || await (platform.getDocumentElement == null ? void 0 : platform.getDocumentElement(elements.floating)),
		boundary,
		rootBoundary,
		strategy
	}));
	const rect = elementContext === "floating" ? {
		x,
		y,
		width: rects.floating.width,
		height: rects.floating.height
	} : rects.reference;
	const offsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(elements.floating));
	const offsetScale = await (platform.isElement == null ? void 0 : platform.isElement(offsetParent)) && await (platform.getScale == null ? void 0 : platform.getScale(offsetParent)) || {
		x: 1,
		y: 1
	};
	const elementClientRect = rectToClientRect(platform.convertOffsetParentRelativeRectToViewportRelativeRect ? await platform.convertOffsetParentRelativeRectToViewportRelativeRect({
		elements,
		rect,
		offsetParent,
		strategy
	}) : rect);
	return {
		top: (clippingClientRect.top - elementClientRect.top + paddingObject.top) / offsetScale.y,
		bottom: (elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom) / offsetScale.y,
		left: (clippingClientRect.left - elementClientRect.left + paddingObject.left) / offsetScale.x,
		right: (elementClientRect.right - clippingClientRect.right + paddingObject.right) / offsetScale.x
	};
}
var MAX_RESET_COUNT = 50;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*
* This export does not have any `platform` interface logic. You will need to
* write one for the platform you are using Floating UI with.
*/
var computePosition$1 = async (reference, floating, config) => {
	const { placement = "bottom", strategy = "absolute", middleware = [], platform } = config;
	const platformWithDetectOverflow = platform.detectOverflow ? platform : {
		...platform,
		detectOverflow
	};
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(floating));
	let rects = await platform.getElementRects({
		reference,
		floating,
		strategy
	});
	let { x, y } = computeCoordsFromPlacement(rects, placement, rtl);
	let statefulPlacement = placement;
	let resetCount = 0;
	const middlewareData = {};
	for (let i = 0; i < middleware.length; i++) {
		const currentMiddleware = middleware[i];
		if (!currentMiddleware) continue;
		const { name, fn } = currentMiddleware;
		const { x: nextX, y: nextY, data, reset } = await fn({
			x,
			y,
			initialPlacement: placement,
			placement: statefulPlacement,
			strategy,
			middlewareData,
			rects,
			platform: platformWithDetectOverflow,
			elements: {
				reference,
				floating
			}
		});
		x = nextX != null ? nextX : x;
		y = nextY != null ? nextY : y;
		middlewareData[name] = {
			...middlewareData[name],
			...data
		};
		if (reset && resetCount < MAX_RESET_COUNT) {
			resetCount++;
			if (typeof reset === "object") {
				if (reset.placement) statefulPlacement = reset.placement;
				if (reset.rects) rects = reset.rects === true ? await platform.getElementRects({
					reference,
					floating,
					strategy
				}) : reset.rects;
				({x, y} = computeCoordsFromPlacement(rects, statefulPlacement, rtl));
			}
			i = -1;
		}
	}
	return {
		x,
		y,
		placement: statefulPlacement,
		strategy,
		middlewareData
	};
};
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$3 = (options) => ({
	name: "arrow",
	options,
	async fn(state) {
		const { x, y, placement, rects, platform, elements, middlewareData } = state;
		const { element, padding = 0 } = evaluate(options, state) || {};
		if (element == null) return {};
		const paddingObject = getPaddingObject(padding);
		const coords = {
			x,
			y
		};
		const axis = getAlignmentAxis(placement);
		const length = getAxisLength(axis);
		const arrowDimensions = await platform.getDimensions(element);
		const isYAxis = axis === "y";
		const minProp = isYAxis ? "top" : "left";
		const maxProp = isYAxis ? "bottom" : "right";
		const clientProp = isYAxis ? "clientHeight" : "clientWidth";
		const endDiff = rects.reference[length] + rects.reference[axis] - coords[axis] - rects.floating[length];
		const startDiff = coords[axis] - rects.reference[axis];
		const arrowOffsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(element));
		let clientSize = arrowOffsetParent ? arrowOffsetParent[clientProp] : 0;
		if (!clientSize || !await (platform.isElement == null ? void 0 : platform.isElement(arrowOffsetParent))) clientSize = elements.floating[clientProp] || rects.floating[length];
		const centerToReference = endDiff / 2 - startDiff / 2;
		const largestPossiblePadding = clientSize / 2 - arrowDimensions[length] / 2 - 1;
		const minPadding = min(paddingObject[minProp], largestPossiblePadding);
		const maxPadding = min(paddingObject[maxProp], largestPossiblePadding);
		const max = clientSize - arrowDimensions[length] - maxPadding;
		const center = clientSize / 2 - arrowDimensions[length] / 2 + centerToReference;
		const offset = clamp(minPadding, center, max);
		const shouldAddOffset = !middlewareData.arrow && getAlignment(placement) != null && center !== offset && rects.reference[length] / 2 - (center < minPadding ? minPadding : maxPadding) - arrowDimensions[length] / 2 < 0;
		const alignmentOffset = shouldAddOffset ? center < minPadding ? center - minPadding : center - max : 0;
		return {
			[axis]: coords[axis] + alignmentOffset,
			data: {
				[axis]: offset,
				centerOffset: center - offset - alignmentOffset,
				...shouldAddOffset && { alignmentOffset }
			},
			reset: shouldAddOffset
		};
	}
});
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "flip",
		options,
		async fn(state) {
			var _middlewareData$arrow, _middlewareData$flip;
			const { placement, middlewareData, rects, initialPlacement, platform, elements } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true, fallbackPlacements: specifiedFallbackPlacements, fallbackStrategy = "bestFit", fallbackAxisSideDirection = "none", flipAlignment = true, ...detectOverflowOptions } = evaluate(options, state);
			if ((_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			const side = getSide(placement);
			const initialSideAxis = getSideAxis(initialPlacement);
			const isBasePlacement = getSide(initialPlacement) === initialPlacement;
			const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
			const fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipAlignment ? [getOppositePlacement(initialPlacement)] : getExpandedPlacements(initialPlacement));
			const hasFallbackAxisSideDirection = fallbackAxisSideDirection !== "none";
			if (!specifiedFallbackPlacements && hasFallbackAxisSideDirection) fallbackPlacements.push(...getOppositeAxisPlacements(initialPlacement, flipAlignment, fallbackAxisSideDirection, rtl));
			const placements = [initialPlacement, ...fallbackPlacements];
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const overflows = [];
			let overflowsData = ((_middlewareData$flip = middlewareData.flip) == null ? void 0 : _middlewareData$flip.overflows) || [];
			if (checkMainAxis) overflows.push(overflow[side]);
			if (checkCrossAxis) {
				const sides = getAlignmentSides(placement, rects, rtl);
				overflows.push(overflow[sides[0]], overflow[sides[1]]);
			}
			overflowsData = [...overflowsData, {
				placement,
				overflows
			}];
			if (!overflows.every((side) => side <= 0)) {
				var _middlewareData$flip2, _overflowsData$filter;
				const nextIndex = (((_middlewareData$flip2 = middlewareData.flip) == null ? void 0 : _middlewareData$flip2.index) || 0) + 1;
				const nextPlacement = placements[nextIndex];
				if (nextPlacement) {
					if (!(checkCrossAxis === "alignment" ? initialSideAxis !== getSideAxis(nextPlacement) : false) || overflowsData.every((d) => getSideAxis(d.placement) === initialSideAxis ? d.overflows[0] > 0 : true)) return {
						data: {
							index: nextIndex,
							overflows: overflowsData
						},
						reset: { placement: nextPlacement }
					};
				}
				let resetPlacement = (_overflowsData$filter = overflowsData.filter((d) => d.overflows[0] <= 0).sort((a, b) => a.overflows[1] - b.overflows[1])[0]) == null ? void 0 : _overflowsData$filter.placement;
				if (!resetPlacement) switch (fallbackStrategy) {
					case "bestFit": {
						var _overflowsData$filter2;
						const placement = (_overflowsData$filter2 = overflowsData.filter((d) => {
							if (hasFallbackAxisSideDirection) {
								const currentSideAxis = getSideAxis(d.placement);
								return currentSideAxis === initialSideAxis || currentSideAxis === "y";
							}
							return true;
						}).map((d) => [d.placement, d.overflows.filter((overflow) => overflow > 0).reduce((acc, overflow) => acc + overflow, 0)]).sort((a, b) => a[1] - b[1])[0]) == null ? void 0 : _overflowsData$filter2[0];
						if (placement) resetPlacement = placement;
						break;
					}
					case "initialPlacement": resetPlacement = initialPlacement;
				}
				if (placement !== resetPlacement) return { reset: { placement: resetPlacement } };
			}
			return {};
		}
	};
};
function getSideOffsets(overflow, rect) {
	return {
		top: overflow.top - rect.height,
		right: overflow.right - rect.width,
		bottom: overflow.bottom - rect.height,
		left: overflow.left - rect.width
	};
}
function isAnySideFullyClipped(overflow) {
	return sides.some((side) => overflow[side] >= 0);
}
/**
* Provides data to hide the floating element in applicable situations, such as
* when it is not in the same clipping context as the reference element.
* @see https://floating-ui.com/docs/hide
*/
var hide$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "hide",
		options,
		async fn(state) {
			const { rects, platform } = state;
			const { strategy = "referenceHidden", ...detectOverflowOptions } = evaluate(options, state);
			switch (strategy) {
				case "referenceHidden": {
					const offsets = getSideOffsets(await platform.detectOverflow(state, {
						...detectOverflowOptions,
						elementContext: "reference"
					}), rects.reference);
					return { data: {
						referenceHiddenOffsets: offsets,
						referenceHidden: isAnySideFullyClipped(offsets)
					} };
				}
				case "escaped": {
					const offsets = getSideOffsets(await platform.detectOverflow(state, {
						...detectOverflowOptions,
						altBoundary: true
					}), rects.floating);
					return { data: {
						escapedOffsets: offsets,
						escaped: isAnySideFullyClipped(offsets)
					} };
				}
				default: return {};
			}
		}
	};
};
var originSides = /*#__PURE__*/ new Set(["left", "top"]);
async function convertValueToCoords(state, options) {
	const { placement, platform, elements } = state;
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
	const side = getSide(placement);
	const alignment = getAlignment(placement);
	const isVertical = getSideAxis(placement) === "y";
	const mainAxisMulti = originSides.has(side) ? -1 : 1;
	const crossAxisMulti = rtl && isVertical ? -1 : 1;
	const rawValue = evaluate(options, state);
	let { mainAxis, crossAxis, alignmentAxis } = typeof rawValue === "number" ? {
		mainAxis: rawValue,
		crossAxis: 0,
		alignmentAxis: null
	} : {
		mainAxis: rawValue.mainAxis || 0,
		crossAxis: rawValue.crossAxis || 0,
		alignmentAxis: rawValue.alignmentAxis
	};
	if (alignment && typeof alignmentAxis === "number") crossAxis = alignment === "end" ? alignmentAxis * -1 : alignmentAxis;
	return isVertical ? {
		x: crossAxis * crossAxisMulti,
		y: mainAxis * mainAxisMulti
	} : {
		x: mainAxis * mainAxisMulti,
		y: crossAxis * crossAxisMulti
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$2 = function(options) {
	if (options === void 0) options = 0;
	return {
		name: "offset",
		options,
		async fn(state) {
			var _middlewareData$offse, _middlewareData$arrow;
			const { x, y, placement, middlewareData } = state;
			const diffCoords = await convertValueToCoords(state, options);
			if (placement === ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse.placement) && (_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			return {
				x: x + diffCoords.x,
				y: y + diffCoords.y,
				data: {
					...diffCoords,
					placement
				}
			};
		}
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "shift",
		options,
		async fn(state) {
			const { x, y, placement, platform } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = false, limiter = { fn: (_ref) => {
				let { x, y } = _ref;
				return {
					x,
					y
				};
			} }, ...detectOverflowOptions } = evaluate(options, state);
			const coords = {
				x,
				y
			};
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const crossAxis = getSideAxis(placement);
			const mainAxis = getOppositeAxis(crossAxis);
			let mainAxisCoord = coords[mainAxis];
			let crossAxisCoord = coords[crossAxis];
			const clampCoord = (axis, coord) => clamp(coord + overflow[axis === "y" ? "top" : "left"], coord, coord - overflow[axis === "y" ? "bottom" : "right"]);
			if (checkMainAxis) mainAxisCoord = clampCoord(mainAxis, mainAxisCoord);
			if (checkCrossAxis) crossAxisCoord = clampCoord(crossAxis, crossAxisCoord);
			const limitedCoords = limiter.fn({
				...state,
				[mainAxis]: mainAxisCoord,
				[crossAxis]: crossAxisCoord
			});
			return {
				...limitedCoords,
				data: {
					x: limitedCoords.x - x,
					y: limitedCoords.y - y,
					enabled: {
						[mainAxis]: checkMainAxis,
						[crossAxis]: checkCrossAxis
					}
				}
			};
		}
	};
};
/**
* Built-in `limiter` that will stop `shift()` at a certain point.
*/
var limitShift$2 = function(options) {
	if (options === void 0) options = {};
	return {
		options,
		fn(state) {
			var _rawOffset$mainAxis, _rawOffset$crossAxis;
			const { x, y, placement, rects, middlewareData } = state;
			const { offset = 0, mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true } = evaluate(options, state);
			const coords = {
				x,
				y
			};
			const crossAxis = getSideAxis(placement);
			const mainAxis = getOppositeAxis(crossAxis);
			let mainAxisCoord = coords[mainAxis];
			let crossAxisCoord = coords[crossAxis];
			const rawOffset = evaluate(offset, state);
			const computedOffset = typeof rawOffset === "number" ? {
				mainAxis: rawOffset,
				crossAxis: 0
			} : {
				mainAxis: (_rawOffset$mainAxis = rawOffset.mainAxis) != null ? _rawOffset$mainAxis : 0,
				crossAxis: (_rawOffset$crossAxis = rawOffset.crossAxis) != null ? _rawOffset$crossAxis : 0
			};
			if (checkMainAxis) {
				const len = mainAxis === "y" ? "height" : "width";
				const limitMin = rects.reference[mainAxis] - rects.floating[len] + computedOffset.mainAxis;
				const limitMax = rects.reference[mainAxis] + rects.reference[len] - computedOffset.mainAxis;
				if (mainAxisCoord < limitMin) mainAxisCoord = limitMin;
				else if (mainAxisCoord > limitMax) mainAxisCoord = limitMax;
			}
			if (checkCrossAxis) {
				var _middlewareData$offse, _middlewareData$offse2;
				const len = mainAxis === "y" ? "width" : "height";
				const isOriginSide = originSides.has(getSide(placement));
				const limitMin = rects.reference[crossAxis] - rects.floating[len] + (isOriginSide ? ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse[crossAxis]) || 0 : 0) + (isOriginSide ? 0 : computedOffset.crossAxis);
				const limitMax = rects.reference[crossAxis] + rects.reference[len] + (isOriginSide ? 0 : ((_middlewareData$offse2 = middlewareData.offset) == null ? void 0 : _middlewareData$offse2[crossAxis]) || 0) - (isOriginSide ? computedOffset.crossAxis : 0);
				if (crossAxisCoord < limitMin) crossAxisCoord = limitMin;
				else if (crossAxisCoord > limitMax) crossAxisCoord = limitMax;
			}
			return {
				[mainAxis]: mainAxisCoord,
				[crossAxis]: crossAxisCoord
			};
		}
	};
};
/**
* Provides data that allows you to change the size of the floating element —
* for instance, prevent it from overflowing the clipping boundary or match the
* width of the reference element.
* @see https://floating-ui.com/docs/size
*/
var size$2 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "size",
		options,
		async fn(state) {
			const { placement, rects, platform, elements } = state;
			const { apply = () => {}, ...detectOverflowOptions } = evaluate(options, state);
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const side = getSide(placement);
			const alignment = getAlignment(placement);
			const isYAxis = getSideAxis(placement) === "y";
			const { width, height } = rects.floating;
			let heightSide;
			let widthSide;
			if (side === "top" || side === "bottom") {
				heightSide = side;
				widthSide = alignment === (await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating)) ? "start" : "end") ? "left" : "right";
			} else {
				widthSide = side;
				heightSide = alignment === "end" ? "top" : "bottom";
			}
			const maximumClippingHeight = height - overflow.top - overflow.bottom;
			const maximumClippingWidth = width - overflow.left - overflow.right;
			const overflowAvailableHeight = min(height - overflow[heightSide], maximumClippingHeight);
			const overflowAvailableWidth = min(width - overflow[widthSide], maximumClippingWidth);
			const shiftData = state.middlewareData.shift;
			const noShift = !shiftData;
			let availableHeight = overflowAvailableHeight;
			let availableWidth = overflowAvailableWidth;
			if (shiftData != null && shiftData.enabled.x) availableWidth = maximumClippingWidth;
			if (shiftData != null && shiftData.enabled.y) availableHeight = maximumClippingHeight;
			if (noShift && !alignment) if (isYAxis) availableWidth = width - 2 * max(overflow.left, overflow.right);
			else availableHeight = height - 2 * max(overflow.top, overflow.bottom);
			await apply({
				...state,
				availableWidth,
				availableHeight
			});
			const nextDimensions = await platform.getDimensions(elements.floating);
			if (width !== nextDimensions.width || height !== nextDimensions.height) return { reset: { rects: true } };
			return {};
		}
	};
};
//#endregion
//#region node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
function hasWindow() {
	return typeof window !== "undefined";
}
function getNodeName(node) {
	if (isNode(node)) return (node.nodeName || "").toLowerCase();
	return "#document";
}
function getWindow(node) {
	var _node$ownerDocument;
	return (node == null || (_node$ownerDocument = node.ownerDocument) == null ? void 0 : _node$ownerDocument.defaultView) || window;
}
function getDocumentElement(node) {
	var _ref;
	return (_ref = (isNode(node) ? node.ownerDocument : node.document) || window.document) == null ? void 0 : _ref.documentElement;
}
function isNode(value) {
	if (!hasWindow()) return false;
	return value instanceof Node || value instanceof getWindow(value).Node;
}
function isElement(value) {
	if (!hasWindow()) return false;
	return value instanceof Element || value instanceof getWindow(value).Element;
}
function isHTMLElement(value) {
	if (!hasWindow()) return false;
	return value instanceof HTMLElement || value instanceof getWindow(value).HTMLElement;
}
function isShadowRoot(value) {
	if (!hasWindow() || typeof ShadowRoot === "undefined") return false;
	return value instanceof ShadowRoot || value instanceof getWindow(value).ShadowRoot;
}
function isOverflowElement(element) {
	const { overflow, overflowX, overflowY, display } = getComputedStyle$1(element);
	return /auto|scroll|overlay|hidden|clip/.test(overflow + overflowY + overflowX) && display !== "inline" && display !== "contents";
}
function isTableElement(element) {
	return /^(table|td|th)$/.test(getNodeName(element));
}
function isTopLayer(element) {
	try {
		if (element.matches(":popover-open")) return true;
	} catch (_e) {}
	try {
		return element.matches(":modal");
	} catch (_e) {
		return false;
	}
}
var willChangeRe = /transform|translate|scale|rotate|perspective|filter/;
var containRe = /paint|layout|strict|content/;
var isNotNone = (value) => !!value && value !== "none";
var isWebKitValue;
function isContainingBlock(elementOrCss) {
	const css = isElement(elementOrCss) ? getComputedStyle$1(elementOrCss) : elementOrCss;
	return isNotNone(css.transform) || isNotNone(css.translate) || isNotNone(css.scale) || isNotNone(css.rotate) || isNotNone(css.perspective) || !isWebKit() && (isNotNone(css.backdropFilter) || isNotNone(css.filter)) || willChangeRe.test(css.willChange || "") || containRe.test(css.contain || "");
}
function getContainingBlock(element) {
	let currentNode = getParentNode(element);
	while (isHTMLElement(currentNode) && !isLastTraversableNode(currentNode)) {
		if (isContainingBlock(currentNode)) return currentNode;
		else if (isTopLayer(currentNode)) return null;
		currentNode = getParentNode(currentNode);
	}
	return null;
}
function isWebKit() {
	if (isWebKitValue == null) isWebKitValue = typeof CSS !== "undefined" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none");
	return isWebKitValue;
}
function isLastTraversableNode(node) {
	return /^(html|body|#document)$/.test(getNodeName(node));
}
function getComputedStyle$1(element) {
	return getWindow(element).getComputedStyle(element);
}
function getNodeScroll(element) {
	if (isElement(element)) return {
		scrollLeft: element.scrollLeft,
		scrollTop: element.scrollTop
	};
	return {
		scrollLeft: element.scrollX,
		scrollTop: element.scrollY
	};
}
function getParentNode(node) {
	if (getNodeName(node) === "html") return node;
	const result = node.assignedSlot || node.parentNode || isShadowRoot(node) && node.host || getDocumentElement(node);
	return isShadowRoot(result) ? result.host : result;
}
function getNearestOverflowAncestor(node) {
	const parentNode = getParentNode(node);
	if (isLastTraversableNode(parentNode)) return (node.ownerDocument || node).body;
	if (isHTMLElement(parentNode) && isOverflowElement(parentNode)) return parentNode;
	return getNearestOverflowAncestor(parentNode);
}
function getOverflowAncestors(node, list, traverseIframes) {
	var _node$ownerDocument2;
	if (list === void 0) list = [];
	if (traverseIframes === void 0) traverseIframes = true;
	const scrollableAncestor = getNearestOverflowAncestor(node);
	const isBody = scrollableAncestor === ((_node$ownerDocument2 = node.ownerDocument) == null ? void 0 : _node$ownerDocument2.body);
	const win = getWindow(scrollableAncestor);
	if (isBody) {
		const frameElement = getFrameElement(win);
		return list.concat(win, win.visualViewport || [], isOverflowElement(scrollableAncestor) ? scrollableAncestor : [], frameElement && traverseIframes ? getOverflowAncestors(frameElement) : []);
	} else return list.concat(scrollableAncestor, getOverflowAncestors(scrollableAncestor, [], traverseIframes));
}
function getFrameElement(win) {
	return win.parent && Object.getPrototypeOf(win.parent) ? win.frameElement : null;
}
//#endregion
//#region node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
function getCssDimensions(element) {
	const css = getComputedStyle$1(element);
	let width = parseFloat(css.width) || 0;
	let height = parseFloat(css.height) || 0;
	const hasOffset = isHTMLElement(element);
	const offsetWidth = hasOffset ? element.offsetWidth : width;
	const offsetHeight = hasOffset ? element.offsetHeight : height;
	const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
	if (shouldFallback) {
		width = offsetWidth;
		height = offsetHeight;
	}
	return {
		width,
		height,
		$: shouldFallback
	};
}
function unwrapElement(element) {
	return !isElement(element) ? element.contextElement : element;
}
function getScale(element) {
	const domElement = unwrapElement(element);
	if (!isHTMLElement(domElement)) return createCoords(1);
	const rect = domElement.getBoundingClientRect();
	const { width, height, $ } = getCssDimensions(domElement);
	let x = ($ ? round(rect.width) : rect.width) / width;
	let y = ($ ? round(rect.height) : rect.height) / height;
	if (!x || !Number.isFinite(x)) x = 1;
	if (!y || !Number.isFinite(y)) y = 1;
	return {
		x,
		y
	};
}
var noOffsets = /*#__PURE__*/ createCoords(0);
function getVisualOffsets(element) {
	const win = getWindow(element);
	if (!isWebKit() || !win.visualViewport) return noOffsets;
	return {
		x: win.visualViewport.offsetLeft,
		y: win.visualViewport.offsetTop
	};
}
function shouldAddVisualOffsets(element, isFixed, floatingOffsetParent) {
	if (isFixed === void 0) isFixed = false;
	return !!floatingOffsetParent && isFixed && floatingOffsetParent === getWindow(element);
}
function getBoundingClientRect(element, includeScale, isFixedStrategy, offsetParent) {
	if (includeScale === void 0) includeScale = false;
	if (isFixedStrategy === void 0) isFixedStrategy = false;
	const clientRect = element.getBoundingClientRect();
	const domElement = unwrapElement(element);
	let scale = createCoords(1);
	if (includeScale) if (offsetParent) {
		if (isElement(offsetParent)) scale = getScale(offsetParent);
	} else scale = getScale(element);
	const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : createCoords(0);
	let x = (clientRect.left + visualOffsets.x) / scale.x;
	let y = (clientRect.top + visualOffsets.y) / scale.y;
	let width = clientRect.width / scale.x;
	let height = clientRect.height / scale.y;
	if (domElement && offsetParent) {
		const win = getWindow(domElement);
		const offsetWin = isElement(offsetParent) ? getWindow(offsetParent) : offsetParent;
		let currentWin = win;
		let currentIFrame = getFrameElement(currentWin);
		while (currentIFrame && offsetWin !== currentWin) {
			const iframeScale = getScale(currentIFrame);
			const iframeRect = currentIFrame.getBoundingClientRect();
			const css = getComputedStyle$1(currentIFrame);
			const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
			const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
			x *= iframeScale.x;
			y *= iframeScale.y;
			width *= iframeScale.x;
			height *= iframeScale.y;
			x += left;
			y += top;
			currentWin = getWindow(currentIFrame);
			currentIFrame = getFrameElement(currentWin);
		}
	}
	return rectToClientRect({
		width,
		height,
		x,
		y
	});
}
function getWindowScrollBarX(element, rect) {
	const leftScroll = getNodeScroll(element).scrollLeft;
	if (!rect) return getBoundingClientRect(getDocumentElement(element)).left + leftScroll;
	return rect.left + leftScroll;
}
function getHTMLOffset(documentElement, scroll) {
	const htmlRect = documentElement.getBoundingClientRect();
	return {
		x: htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect),
		y: htmlRect.top + scroll.scrollTop
	};
}
function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
	let { elements, rect, offsetParent, strategy } = _ref;
	const isFixed = strategy === "fixed";
	const documentElement = getDocumentElement(offsetParent);
	const topLayer = elements ? isTopLayer(elements.floating) : false;
	if (offsetParent === documentElement || topLayer && isFixed) return rect;
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	let scale = createCoords(1);
	const offsets = createCoords(0);
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	if (isOffsetParentAnElement || !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent);
			scale = getScale(offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		}
	}
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		width: rect.width * scale.x,
		height: rect.height * scale.y,
		x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
		y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
	};
}
function getClientRects(element) {
	return element.getClientRects ? Array.from(element.getClientRects()) : [];
}
function getDocumentRect(html) {
	const scroll = getNodeScroll(html);
	const body = html.ownerDocument.body;
	const width = max(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
	const height = max(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
	let x = -scroll.scrollLeft + getWindowScrollBarX(html);
	const y = -scroll.scrollTop;
	if (getComputedStyle$1(body).direction === "rtl") x += max(html.clientWidth, body.clientWidth) - width;
	return {
		width,
		height,
		x,
		y
	};
}
var SCROLLBAR_MAX = 25;
function getViewportRect(element, strategy, rootBoundary) {
	if (rootBoundary === void 0) rootBoundary = "viewport";
	const isLayoutViewport = rootBoundary === "layoutViewport";
	const win = getWindow(element);
	const html = getDocumentElement(element);
	const visualViewport = win.visualViewport;
	let width = html.clientWidth;
	let height = html.clientHeight;
	let x = 0;
	let y = 0;
	if (visualViewport) {
		const layoutRelativeClientCoords = !isWebKit() || strategy === "fixed";
		if (isLayoutViewport) {
			if (!layoutRelativeClientCoords) {
				x = -visualViewport.offsetLeft;
				y = -visualViewport.offsetTop;
			}
		} else {
			width = visualViewport.width;
			height = visualViewport.height;
			if (layoutRelativeClientCoords) {
				x = visualViewport.offsetLeft;
				y = visualViewport.offsetTop;
			}
		}
	}
	if (getWindowScrollBarX(html) <= 0) {
		const doc = html.ownerDocument;
		const body = doc.body;
		const bodyStyles = getComputedStyle(body);
		const bodyMarginInline = doc.compatMode === "CSS1Compat" ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
		const reservedWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
		const gutter = getComputedStyle(html).scrollbarGutter === "stable both-edges" ? reservedWidth / 2 : reservedWidth;
		if (gutter <= SCROLLBAR_MAX) width -= gutter;
	}
	return {
		width,
		height,
		x,
		y
	};
}
function getInnerBoundingClientRect(element, strategy) {
	const clientRect = getBoundingClientRect(element, true, strategy === "fixed");
	const top = clientRect.top + element.clientTop;
	const left = clientRect.left + element.clientLeft;
	const scale = getScale(element);
	return {
		width: element.clientWidth * scale.x,
		height: element.clientHeight * scale.y,
		x: left * scale.x,
		y: top * scale.y
	};
}
function getClientRectFromClippingAncestor(element, clippingAncestor, strategy) {
	let rect;
	if (clippingAncestor === "viewport" || clippingAncestor === "layoutViewport") rect = getViewportRect(element, strategy, clippingAncestor);
	else if (clippingAncestor === "document") rect = getDocumentRect(getDocumentElement(element));
	else if (isElement(clippingAncestor)) rect = getInnerBoundingClientRect(clippingAncestor, strategy);
	else {
		const visualOffsets = getVisualOffsets(element);
		rect = {
			x: clippingAncestor.x - visualOffsets.x,
			y: clippingAncestor.y - visualOffsets.y,
			width: clippingAncestor.width,
			height: clippingAncestor.height
		};
	}
	return rectToClientRect(rect);
}
function getClippingElementAncestors(element, cache) {
	const cachedResult = cache.get(element);
	if (cachedResult) return cachedResult;
	let result = getOverflowAncestors(element, [], false).filter((el) => isElement(el) && getNodeName(el) !== "body");
	let lastKeptComputedStyle = null;
	const elementIsFixed = getComputedStyle$1(element).position === "fixed";
	let currentNode = elementIsFixed ? getParentNode(element) : element;
	while (isElement(currentNode) && !isLastTraversableNode(currentNode)) {
		const computedStyle = getComputedStyle$1(currentNode);
		const currentNodeIsContaining = isContainingBlock(currentNode);
		const lastPosition = lastKeptComputedStyle ? lastKeptComputedStyle.position : elementIsFixed ? "fixed" : "";
		if (!currentNodeIsContaining && (lastPosition === "fixed" || lastPosition === "absolute" && computedStyle.position === "static")) result = result.filter((ancestor) => ancestor !== currentNode);
		else lastKeptComputedStyle = computedStyle;
		currentNode = getParentNode(currentNode);
	}
	cache.set(element, result);
	return result;
}
function getClippingRect(_ref) {
	let { element, boundary, rootBoundary, strategy } = _ref;
	const clippingAncestors = [...boundary === "clippingAncestors" ? isTopLayer(element) ? [] : getClippingElementAncestors(element, this._c) : [].concat(boundary), rootBoundary];
	const firstRect = getClientRectFromClippingAncestor(element, clippingAncestors[0], strategy);
	let top = firstRect.top;
	let right = firstRect.right;
	let bottom = firstRect.bottom;
	let left = firstRect.left;
	for (let i = 1; i < clippingAncestors.length; i++) {
		const rect = getClientRectFromClippingAncestor(element, clippingAncestors[i], strategy);
		top = max(rect.top, top);
		right = min(rect.right, right);
		bottom = min(rect.bottom, bottom);
		left = max(rect.left, left);
	}
	return {
		width: right - left,
		height: bottom - top,
		x: left,
		y: top
	};
}
function getDimensions(element) {
	const { width, height } = getCssDimensions(element);
	return {
		width,
		height
	};
}
function getRectRelativeToOffsetParent(element, offsetParent, strategy) {
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	const documentElement = getDocumentElement(offsetParent);
	const isFixed = strategy === "fixed";
	const rect = getBoundingClientRect(element, true, isFixed, offsetParent);
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	const offsets = createCoords(0);
	if (isOffsetParentAnElement || !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		}
	}
	if (!isOffsetParentAnElement && documentElement) offsets.x = getWindowScrollBarX(documentElement);
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		x: rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x,
		y: rect.top + scroll.scrollTop - offsets.y - htmlOffset.y,
		width: rect.width,
		height: rect.height
	};
}
function isStaticPositioned(element) {
	return getComputedStyle$1(element).position === "static";
}
function getTrueOffsetParent(element, polyfill) {
	if (!isHTMLElement(element) || getComputedStyle$1(element).position === "fixed") return null;
	if (polyfill) return polyfill(element);
	let rawOffsetParent = element.offsetParent;
	if (getDocumentElement(element) === rawOffsetParent) rawOffsetParent = rawOffsetParent.ownerDocument.body;
	return rawOffsetParent;
}
function getOffsetParent(element, polyfill) {
	const win = getWindow(element);
	if (isTopLayer(element)) return win;
	if (!isHTMLElement(element)) {
		let svgOffsetParent = getParentNode(element);
		while (svgOffsetParent && !isLastTraversableNode(svgOffsetParent)) {
			if (isElement(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) return svgOffsetParent;
			svgOffsetParent = getParentNode(svgOffsetParent);
		}
		return win;
	}
	let offsetParent = getTrueOffsetParent(element, polyfill);
	while (offsetParent && isTableElement(offsetParent) && isStaticPositioned(offsetParent)) offsetParent = getTrueOffsetParent(offsetParent, polyfill);
	if (offsetParent && isLastTraversableNode(offsetParent) && isStaticPositioned(offsetParent) && !isContainingBlock(offsetParent)) return win;
	return offsetParent || getContainingBlock(element) || win;
}
var getElementRects = async function(data) {
	const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
	const getDimensionsFn = this.getDimensions;
	const floatingDimensions = await getDimensionsFn(data.floating);
	return {
		reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
		floating: {
			x: 0,
			y: 0,
			width: floatingDimensions.width,
			height: floatingDimensions.height
		}
	};
};
function isRTL(element) {
	return getComputedStyle$1(element).direction === "rtl";
}
var platform = {
	convertOffsetParentRelativeRectToViewportRelativeRect,
	getDocumentElement,
	getClippingRect,
	getOffsetParent,
	getElementRects,
	getClientRects,
	getDimensions,
	getScale,
	isElement,
	isRTL
};
function rectsAreEqual(a, b) {
	return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
}
function observeMove(element, onMove, ancestorResize) {
	let io = null;
	let timeoutId;
	const root = getDocumentElement(element);
	function cleanup() {
		var _io;
		clearTimeout(timeoutId);
		(_io = io) == null || _io.disconnect();
		io = null;
	}
	function refresh(skip, threshold) {
		if (skip === void 0) skip = false;
		if (threshold === void 0) threshold = 1;
		cleanup();
		const elementRectForRootMargin = element.getBoundingClientRect();
		const { left, top, width, height } = elementRectForRootMargin;
		if (!skip) onMove();
		if (!width || !height) return;
		const insetTop = floor(top);
		const insetRight = floor(root.clientWidth - (left + width));
		const insetBottom = floor(root.clientHeight - (top + height));
		const insetLeft = floor(left);
		const options = {
			rootMargin: -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px",
			threshold: max(0, min(1, threshold)) || 1
		};
		let isFirstUpdate = true;
		function handleObserve(entries) {
			const ratio = entries[0].intersectionRatio;
			if (!rectsAreEqual(elementRectForRootMargin, element.getBoundingClientRect())) return refresh();
			if (ratio !== threshold) {
				if (!isFirstUpdate) return refresh();
				if (!ratio) timeoutId = setTimeout(() => {
					refresh(false, 1e-7);
				}, 1e3);
				else refresh(false, ratio);
			}
			isFirstUpdate = false;
		}
		try {
			io = new IntersectionObserver(handleObserve, {
				...options,
				root: root.ownerDocument
			});
		} catch (_e) {
			io = new IntersectionObserver(handleObserve, options);
		}
		io.observe(element);
	}
	const win = getWindow(element);
	const handleResize = () => refresh(ancestorResize);
	win.addEventListener("resize", handleResize);
	refresh(true);
	return () => {
		win.removeEventListener("resize", handleResize);
		cleanup();
	};
}
/**
* Automatically updates the position of the floating element when necessary.
* Should only be called when the floating element is mounted on the DOM or
* visible on the screen.
* @returns cleanup function that should be invoked when the floating element is
* removed from the DOM or hidden from the screen.
* @see https://floating-ui.com/docs/autoUpdate
*/
function autoUpdate(reference, floating, update, options) {
	if (options === void 0) options = {};
	const { ancestorScroll = true, ancestorResize = true, elementResize = typeof ResizeObserver === "function", layoutShift = typeof IntersectionObserver === "function", animationFrame = false } = options;
	const referenceEl = unwrapElement(reference);
	const ancestors = ancestorScroll || ancestorResize ? [...referenceEl ? getOverflowAncestors(referenceEl) : [], ...floating ? getOverflowAncestors(floating) : []] : [];
	ancestors.forEach((ancestor) => {
		ancestorScroll && ancestor.addEventListener("scroll", update);
		ancestorResize && ancestor.addEventListener("resize", update);
	});
	const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update, ancestorResize) : null;
	let reobserveFrame = -1;
	let resizeObserver = null;
	if (elementResize) {
		resizeObserver = new ResizeObserver((_ref) => {
			let [firstEntry] = _ref;
			if (firstEntry && firstEntry.target === referenceEl && resizeObserver && floating) {
				resizeObserver.unobserve(floating);
				cancelAnimationFrame(reobserveFrame);
				reobserveFrame = requestAnimationFrame(() => {
					var _resizeObserver;
					(_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating);
				});
			}
			update();
		});
		if (referenceEl && !animationFrame) resizeObserver.observe(referenceEl);
		if (floating) resizeObserver.observe(floating);
	}
	let frameId;
	let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
	if (animationFrame) frameLoop();
	function frameLoop() {
		const nextRefRect = getBoundingClientRect(reference);
		if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) update();
		prevRefRect = nextRefRect;
		frameId = requestAnimationFrame(frameLoop);
	}
	update();
	return () => {
		var _resizeObserver2;
		ancestors.forEach((ancestor) => {
			ancestorScroll && ancestor.removeEventListener("scroll", update);
			ancestorResize && ancestor.removeEventListener("resize", update);
		});
		cleanupIo?.();
		(_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
		resizeObserver = null;
		if (animationFrame) cancelAnimationFrame(frameId);
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$1 = offset$2;
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$1 = shift$2;
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$1 = flip$2;
/**
* Provides data that allows you to change the size of the floating element —
* for instance, prevent it from overflowing the clipping boundary or match the
* width of the reference element.
* @see https://floating-ui.com/docs/size
*/
var size$1 = size$2;
/**
* Provides data to hide the floating element in applicable situations, such as
* when it is not in the same clipping context as the reference element.
* @see https://floating-ui.com/docs/hide
*/
var hide$1 = hide$2;
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$2 = arrow$3;
/**
* Built-in `limiter` that will stop `shift()` at a certain point.
*/
var limitShift$1 = limitShift$2;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*/
var computePosition = (reference, floating, options) => {
	const cache = /* @__PURE__ */ new Map();
	const mergedOptions = options != null ? options : {};
	const platformWithCache = {
		...platform,
		...mergedOptions.platform,
		_c: cache
	};
	return computePosition$1(reference, floating, {
		...mergedOptions,
		platform: platformWithCache
	});
};
//#endregion
//#region node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs
var index = typeof document !== "undefined" ? import_react.useLayoutEffect : function noop() {};
function deepEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (typeof a === "function" && a.toString() === b.toString()) return true;
	let length;
	let i;
	let keys;
	if (a && b && typeof a === "object") {
		if (Array.isArray(a)) {
			length = a.length;
			if (length !== b.length) return false;
			for (i = length; i-- !== 0;) if (!deepEqual(a[i], b[i])) return false;
			return true;
		}
		keys = Object.keys(a);
		length = keys.length;
		if (length !== Object.keys(b).length) return false;
		for (i = length; i-- !== 0;) if (!{}.hasOwnProperty.call(b, keys[i])) return false;
		for (i = length; i-- !== 0;) {
			const key = keys[i];
			if (key === "_owner" && a.$$typeof) continue;
			if (!deepEqual(a[key], b[key])) return false;
		}
		return true;
	}
	return a !== a && b !== b;
}
function getDPR(element) {
	if (typeof window === "undefined") return 1;
	return (element.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function roundByDPR(element, value) {
	const dpr = getDPR(element);
	return Math.round(value * dpr) / dpr;
}
function useLatestRef(value) {
	const ref = import_react.useRef(value);
	index(() => {
		ref.current = value;
	});
	return ref;
}
/**
* Provides data to position a floating element.
* @see https://floating-ui.com/docs/useFloating
*/
function useFloating(options) {
	if (options === void 0) options = {};
	const { placement = "bottom", strategy = "absolute", middleware = [], platform, elements: { reference: externalReference, floating: externalFloating } = {}, transform = true, whileElementsMounted, open } = options;
	const [data, setData] = import_react.useState({
		x: 0,
		y: 0,
		strategy,
		placement,
		middlewareData: {},
		isPositioned: false
	});
	const [latestMiddleware, setLatestMiddleware] = import_react.useState(middleware);
	if (!deepEqual(latestMiddleware, middleware)) setLatestMiddleware(middleware);
	const [_reference, _setReference] = import_react.useState(null);
	const [_floating, _setFloating] = import_react.useState(null);
	const setReference = import_react.useCallback((node) => {
		if (node !== referenceRef.current) {
			referenceRef.current = node;
			_setReference(node);
		}
	}, []);
	const setFloating = import_react.useCallback((node) => {
		if (node !== floatingRef.current) {
			floatingRef.current = node;
			_setFloating(node);
		}
	}, []);
	const referenceEl = externalReference || _reference;
	const floatingEl = externalFloating || _floating;
	const referenceRef = import_react.useRef(null);
	const floatingRef = import_react.useRef(null);
	const dataRef = import_react.useRef(data);
	const hasWhileElementsMounted = whileElementsMounted != null;
	const whileElementsMountedRef = useLatestRef(whileElementsMounted);
	const platformRef = useLatestRef(platform);
	const openRef = useLatestRef(open);
	const update = import_react.useCallback(() => {
		if (!referenceRef.current || !floatingRef.current) return;
		const config = {
			placement,
			strategy,
			middleware: latestMiddleware
		};
		if (platformRef.current) config.platform = platformRef.current;
		computePosition(referenceRef.current, floatingRef.current, config).then((data) => {
			const fullData = {
				...data,
				isPositioned: openRef.current !== false
			};
			if (isMountedRef.current && !deepEqual(dataRef.current, fullData)) {
				dataRef.current = fullData;
				import_react_dom.flushSync(() => {
					setData(fullData);
				});
			}
		});
	}, [
		latestMiddleware,
		placement,
		strategy,
		platformRef,
		openRef
	]);
	index(() => {
		if (open === false && dataRef.current.isPositioned) {
			dataRef.current.isPositioned = false;
			setData((data) => ({
				...data,
				isPositioned: false
			}));
		}
	}, [open]);
	const isMountedRef = import_react.useRef(false);
	index(() => {
		isMountedRef.current = true;
		return () => {
			isMountedRef.current = false;
		};
	}, []);
	index(() => {
		if (referenceEl) referenceRef.current = referenceEl;
		if (floatingEl) floatingRef.current = floatingEl;
		if (referenceEl && floatingEl) {
			if (whileElementsMountedRef.current) return whileElementsMountedRef.current(referenceEl, floatingEl, update);
			update();
		}
	}, [
		referenceEl,
		floatingEl,
		update,
		whileElementsMountedRef,
		hasWhileElementsMounted
	]);
	const refs = import_react.useMemo(() => ({
		reference: referenceRef,
		floating: floatingRef,
		setReference,
		setFloating
	}), [setReference, setFloating]);
	const elements = import_react.useMemo(() => ({
		reference: referenceEl,
		floating: floatingEl
	}), [referenceEl, floatingEl]);
	const floatingStyles = import_react.useMemo(() => {
		const initialStyles = {
			position: strategy,
			left: 0,
			top: 0
		};
		if (!elements.floating) return initialStyles;
		const x = roundByDPR(elements.floating, data.x);
		const y = roundByDPR(elements.floating, data.y);
		if (transform) return {
			...initialStyles,
			transform: "translate(" + x + "px, " + y + "px)",
			...getDPR(elements.floating) >= 1.5 && { willChange: "transform" }
		};
		return {
			position: strategy,
			left: x,
			top: y
		};
	}, [
		strategy,
		transform,
		elements.floating,
		data.x,
		data.y
	]);
	return import_react.useMemo(() => ({
		...data,
		update,
		refs,
		elements,
		floatingStyles
	}), [
		data,
		update,
		refs,
		elements,
		floatingStyles
	]);
}
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* This wraps the core `arrow` middleware to allow React refs as the element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow$1 = (options) => {
	function isRef(value) {
		return {}.hasOwnProperty.call(value, "current");
	}
	return {
		name: "arrow",
		options,
		fn(state) {
			const { element, padding } = typeof options === "function" ? options(state) : options;
			if (element && isRef(element)) {
				if (element.current != null) return arrow$2({
					element: element.current,
					padding
				}).fn(state);
				return {};
			}
			if (element) return arrow$2({
				element,
				padding
			}).fn(state);
			return {};
		}
	};
};
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset = (options, deps) => {
	const result = offset$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift = (options, deps) => {
	const result = shift$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Built-in `limiter` that will stop `shift()` at a certain point.
*/
var limitShift = (options, deps) => {
	return {
		fn: limitShift$1(options).fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip = (options, deps) => {
	const result = flip$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Provides data that allows you to change the size of the floating element —
* for instance, prevent it from overflowing the clipping boundary or match the
* width of the reference element.
* @see https://floating-ui.com/docs/size
*/
var size = (options, deps) => {
	const result = size$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Provides data to hide the floating element in applicable situations, such as
* when it is not in the same clipping context as the reference element.
* @see https://floating-ui.com/docs/hide
*/
var hide = (options, deps) => {
	const result = hide$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* This wraps the core `arrow` middleware to allow React refs as the element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow = (options, deps) => {
	const result = arrow$1(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
//#endregion
//#region node_modules/@radix-ui/react-use-size/dist/index.mjs
var __defProp$2 = Object.defineProperty;
var __name$2 = (target, value) => __defProp$2(target, "name", {
	value,
	configurable: true
});
function useSize(element) {
	const [size, setSize] = import_react.useState(void 0);
	useLayoutEffect2(() => {
		if (element) {
			setSize({
				width: element.offsetWidth,
				height: element.offsetHeight
			});
			let rAF = 0;
			const resizeObserver = new ResizeObserver((entries) => {
				if (!Array.isArray(entries)) return;
				if (!entries.length) return;
				const entry = entries[0];
				window.cancelAnimationFrame(rAF);
				rAF = window.requestAnimationFrame(() => {
					let width;
					let height;
					if ("borderBoxSize" in entry) {
						const borderSizeEntry = entry["borderBoxSize"];
						const borderSize = Array.isArray(borderSizeEntry) ? borderSizeEntry[0] : borderSizeEntry;
						width = borderSize["inlineSize"];
						height = borderSize["blockSize"];
					} else {
						width = element.offsetWidth;
						height = element.offsetHeight;
					}
					setSize({
						width,
						height
					});
				});
			});
			resizeObserver.observe(element, { box: "border-box" });
			return () => {
				window.cancelAnimationFrame(rAF);
				resizeObserver.unobserve(element);
			};
		} else setSize(void 0);
	}, [element]);
	return size;
}
__name$2(useSize, "useSize");
//#endregion
//#region node_modules/@radix-ui/react-popper/dist/index.mjs
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});
var Sticky = {
	Partial: "partial",
	Always: "always"
};
var UpdatePositionStrategy = {
	Optimized: "optimized",
	Always: "always"
};
var POPPER_NAME = "Popper";
var [createPopperContext, createPopperScope] = createContextScope(POPPER_NAME);
var [PopperProvider, usePopperContext] = createPopperContext(POPPER_NAME);
var Popper = /* @__PURE__ */ __name$1((props) => {
	const { __scopePopper, children } = props;
	const [anchor, setAnchor] = import_react.useState(null);
	const [placementState, setPlacementState] = import_react.useState(void 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopperProvider, {
		scope: __scopePopper,
		anchor,
		onAnchorChange: setAnchor,
		placementState,
		setPlacementState,
		children
	});
}, "Popper");
var ANCHOR_NAME = "PopperAnchor";
var PopperAnchor = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function PopperAnchor2(props, forwardedRef) {
	const { __scopePopper, virtualRef, ...anchorProps } = props;
	const context = usePopperContext(ANCHOR_NAME, __scopePopper);
	const ref = import_react.useRef(null);
	const onAnchorChange = context.onAnchorChange;
	const callbackRef = import_react.useCallback((node) => {
		ref.current = node;
		if (node) onAnchorChange(node);
	}, [onAnchorChange]);
	const composedRefs = useComposedRefs(forwardedRef, callbackRef);
	const anchorRef = import_react.useRef(null);
	import_react.useEffect(() => {
		if (!virtualRef) return;
		const previousAnchor = anchorRef.current;
		anchorRef.current = virtualRef.current;
		if (previousAnchor !== anchorRef.current) onAnchorChange(anchorRef.current);
	});
	const sideAndAlign = context.placementState && getSideAndAlignFromPlacement(context.placementState);
	const placedSide = sideAndAlign?.[0];
	const placedAlign = sideAndAlign?.[1];
	return virtualRef ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		"data-radix-popper-side": placedSide,
		"data-radix-popper-align": placedAlign,
		...anchorProps,
		ref: composedRefs
	});
}, "PopperAnchor"));
var CONTENT_NAME$1 = "PopperContent";
var [PopperContentProvider, useContentContext] = createPopperContext(CONTENT_NAME$1);
var PopperContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$1(function PopperContent2(props, forwardedRef) {
	const { __scopePopper, side = "bottom", sideOffset = 0, align = "center", alignOffset = 0, arrowPadding = 0, avoidCollisions = true, collisionBoundary = [], collisionPadding: collisionPaddingProp = 0, sticky = Sticky.Partial, hideWhenDetached = false, updatePositionStrategy = UpdatePositionStrategy.Optimized, onPlaced, ...contentProps } = props;
	const context = usePopperContext(CONTENT_NAME$1, __scopePopper);
	const [content, setContent] = import_react.useState(null);
	const composedRefs = useComposedRefs(forwardedRef, setContent);
	const [arrow$4, setArrow] = import_react.useState(null);
	const arrowSize = useSize(arrow$4);
	const arrowWidth = arrowSize?.width ?? 0;
	const arrowHeight = arrowSize?.height ?? 0;
	const desiredPlacement = side + (align !== "center" ? "-" + align : "");
	const collisionPadding = typeof collisionPaddingProp === "number" ? collisionPaddingProp : {
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
		...collisionPaddingProp
	};
	const boundary = Array.isArray(collisionBoundary) ? collisionBoundary : [collisionBoundary];
	const hasExplicitBoundaries = boundary.length > 0;
	const detectOverflowOptions = {
		padding: collisionPadding,
		boundary: boundary.filter(isNotNull),
		altBoundary: hasExplicitBoundaries
	};
	const { refs, floatingStyles, placement, isPositioned, middlewareData } = useFloating({
		strategy: "fixed",
		placement: desiredPlacement,
		whileElementsMounted: /* @__PURE__ */ __name$1((...args) => {
			return autoUpdate(...args, { animationFrame: updatePositionStrategy === UpdatePositionStrategy.Always });
		}, "whileElementsMounted"),
		elements: { reference: context.anchor },
		middleware: [
			offset({
				mainAxis: sideOffset + arrowHeight,
				alignmentAxis: alignOffset
			}),
			avoidCollisions && shift({
				mainAxis: true,
				crossAxis: false,
				...sticky === Sticky.Partial ? { limiter: limitShift() } : {},
				...detectOverflowOptions
			}),
			avoidCollisions && flip({ ...detectOverflowOptions }),
			size({
				...detectOverflowOptions,
				apply: /* @__PURE__ */ __name$1(({ elements, rects, availableWidth, availableHeight }) => {
					const { width: anchorWidth, height: anchorHeight } = rects.reference;
					const contentStyle = elements.floating.style;
					contentStyle.setProperty("--radix-popper-available-width", `${availableWidth}px`);
					contentStyle.setProperty("--radix-popper-available-height", `${availableHeight}px`);
					contentStyle.setProperty("--radix-popper-anchor-width", `${anchorWidth}px`);
					contentStyle.setProperty("--radix-popper-anchor-height", `${anchorHeight}px`);
				}, "apply")
			}),
			arrow$4 && arrow({
				element: arrow$4,
				padding: arrowPadding
			}),
			transformOrigin({
				arrowWidth,
				arrowHeight
			}),
			hideWhenDetached && hide(hasExplicitBoundaries ? {
				strategy: "referenceHidden",
				...detectOverflowOptions
			} : {
				strategy: "referenceHidden",
				padding: detectOverflowOptions.padding,
				altBoundary: detectOverflowOptions.altBoundary
			})
		]
	});
	const setPlacementState = context.setPlacementState;
	useLayoutEffect2(() => {
		setPlacementState(placement);
		return () => {
			setPlacementState(void 0);
		};
	}, [placement, setPlacementState]);
	const [placedSide, placedAlign] = getSideAndAlignFromPlacement(placement);
	const handlePlaced = useCallbackRef(onPlaced);
	useLayoutEffect2(() => {
		if (isPositioned) handlePlaced?.();
	}, [isPositioned, handlePlaced]);
	const arrowX = middlewareData.arrow?.x;
	const arrowY = middlewareData.arrow?.y;
	const cannotCenterArrow = middlewareData.arrow?.centerOffset !== 0;
	const [contentZIndex, setContentZIndex] = import_react.useState();
	useLayoutEffect2(() => {
		if (content) setContentZIndex(window.getComputedStyle(content).zIndex);
	}, [content]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: refs.setFloating,
		"data-radix-popper-content-wrapper": "",
		style: {
			...floatingStyles,
			transform: isPositioned ? floatingStyles.transform : "translate(0, -200%)",
			minWidth: "max-content",
			zIndex: contentZIndex,
			"--radix-popper-transform-origin": [middlewareData.transformOrigin?.x, middlewareData.transformOrigin?.y].join(" "),
			...middlewareData.hide?.referenceHidden && {
				visibility: "hidden",
				pointerEvents: "none"
			}
		},
		dir: props.dir,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopperContentProvider, {
			scope: __scopePopper,
			placedSide,
			placedAlign,
			onArrowChange: setArrow,
			arrowX,
			arrowY,
			shouldHideArrow: cannotCenterArrow,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
				"data-side": placedSide,
				"data-align": placedAlign,
				...contentProps,
				ref: composedRefs,
				style: {
					...contentProps.style,
					animation: !isPositioned ? "none" : contentProps.style?.animation
				}
			})
		})
	});
}, "PopperContent"));
function isNotNull(value) {
	return value !== null;
}
__name$1(isNotNull, "isNotNull");
var transformOrigin = /* @__PURE__ */ __name$1((options) => ({
	name: "transformOrigin",
	options,
	fn(data) {
		const { placement, rects, middlewareData } = data;
		const isArrowHidden = middlewareData.arrow?.centerOffset !== 0;
		const arrowWidth = isArrowHidden ? 0 : options.arrowWidth;
		const arrowHeight = isArrowHidden ? 0 : options.arrowHeight;
		const [placedSide, placedAlign] = getSideAndAlignFromPlacement(placement);
		const noArrowAlign = {
			start: "0%",
			center: "50%",
			end: "100%"
		}[placedAlign];
		const arrowXCenter = (middlewareData.arrow?.x ?? 0) + arrowWidth / 2;
		const arrowYCenter = (middlewareData.arrow?.y ?? 0) + arrowHeight / 2;
		let x = "";
		let y = "";
		if (placedSide === "bottom") {
			x = isArrowHidden ? noArrowAlign : `${arrowXCenter}px`;
			y = `${-arrowHeight}px`;
		} else if (placedSide === "top") {
			x = isArrowHidden ? noArrowAlign : `${arrowXCenter}px`;
			y = `${rects.floating.height + arrowHeight}px`;
		} else if (placedSide === "right") {
			x = `${-arrowHeight}px`;
			y = isArrowHidden ? noArrowAlign : `${arrowYCenter}px`;
		} else if (placedSide === "left") {
			x = `${rects.floating.width + arrowHeight}px`;
			y = isArrowHidden ? noArrowAlign : `${arrowYCenter}px`;
		}
		return { data: {
			x,
			y
		} };
	}
}), "transformOrigin");
function getSideAndAlignFromPlacement(placement) {
	const [side, align = "center"] = placement.split("-");
	return [side, align];
}
__name$1(getSideAndAlignFromPlacement, "getSideAndAlignFromPlacement");
//#endregion
//#region node_modules/@radix-ui/react-visually-hidden/dist/index.mjs
var VISUALLY_HIDDEN_STYLES = Object.freeze({
	position: "absolute",
	border: 0,
	width: 1,
	height: 1,
	padding: 0,
	margin: -1,
	overflow: "hidden",
	clip: "rect(0, 0, 0, 0)",
	whiteSpace: "nowrap",
	wordWrap: "normal"
});
//#endregion
//#region node_modules/@radix-ui/react-select/dist/index.mjs
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var Position = {
	ItemAligned: "item-aligned",
	Popper: "popper"
};
var Direction = {
	LTR: "ltr",
	RTL: "rtl"
};
var OPEN_KEYS = [
	" ",
	"Enter",
	"ArrowUp",
	"ArrowDown"
];
var SELECTION_KEYS = [" ", "Enter"];
var SELECT_NAME = "Select";
var [Collection, useCollection, createCollectionScope] = /* @__PURE__ */ createCollection(SELECT_NAME);
var [createSelectContext, createSelectScope] = createContextScope(SELECT_NAME, [createCollectionScope, createPopperScope]);
var usePopperScope = createPopperScope();
var [SelectProviderImpl, useSelectContext] = createSelectContext(SELECT_NAME);
var [SelectNativeOptionsProvider, useSelectNativeOptionsContext] = createSelectContext(SELECT_NAME);
function SelectProvider(props) {
	const { __scopeSelect, children, open: openProp, defaultOpen, onOpenChange, value: valueProp, defaultValue, onValueChange, dir, name, autoComplete, disabled, required, form, internal_do_not_use_render } = props;
	const popperScope = usePopperScope(__scopeSelect);
	const [trigger, setTrigger] = import_react.useState(null);
	const [valueNode, setValueNode] = import_react.useState(null);
	const [valueNodeHasChildren, setValueNodeHasChildren] = import_react.useState(false);
	const direction = useDirection(dir);
	const [open, setOpen] = useControllableState({
		prop: openProp,
		defaultProp: defaultOpen ?? false,
		onChange: onOpenChange,
		caller: SELECT_NAME
	});
	const [value, setValue] = useControllableState({
		prop: valueProp,
		defaultProp: defaultValue,
		onChange: onValueChange,
		caller: SELECT_NAME
	});
	const triggerPointerDownPosRef = import_react.useRef(null);
	const hasConsumerStoppedPropagationRef = import_react.useRef(false);
	const [userSelection, setUserSelection] = import_react.useState(null);
	const handleUserSelect = /* @__PURE__ */ __name((nextValue) => {
		setUserSelection({
			value: nextValue,
			hasConsumerStoppedPropagation: hasConsumerStoppedPropagationRef.current
		});
		setValue(nextValue);
	}, "handleUserSelect");
	const initialValueRef = import_react.useRef(value);
	import_react.useEffect(() => {
		const associatedForm = form ? trigger?.ownerDocument.getElementById(form) : trigger?.form;
		if (associatedForm instanceof HTMLFormElement) {
			const reset = /* @__PURE__ */ __name(() => setValue(initialValueRef.current), "reset");
			associatedForm.addEventListener("reset", reset);
			return () => associatedForm.removeEventListener("reset", reset);
		}
	}, [
		form,
		trigger,
		setValue
	]);
	const isFormControl = trigger ? !!form || !!trigger.closest("form") : true;
	const [nativeOptionsSet, setNativeOptionsSet] = import_react.useState(/* @__PURE__ */ new Set());
	const contentId = useId();
	const nativeSelectKey = Array.from(nativeOptionsSet).map((option) => option.props.value).join(";");
	const handleNativeOptionAdd = import_react.useCallback((option) => {
		setNativeOptionsSet((prev) => new Set(prev).add(option));
	}, []);
	const handleNativeOptionRemove = import_react.useCallback((option) => {
		setNativeOptionsSet((prev) => {
			const optionsSet = new Set(prev);
			optionsSet.delete(option);
			return optionsSet;
		});
	}, []);
	const context = {
		required,
		trigger,
		onTriggerChange: setTrigger,
		valueNode,
		onValueNodeChange: setValueNode,
		valueNodeHasChildren,
		onValueNodeHasChildrenChange: setValueNodeHasChildren,
		contentId,
		value,
		onValueChange: setValue,
		hasConsumerStoppedPropagationRef,
		userSelection,
		onUserSelect: handleUserSelect,
		open,
		onOpenChange: setOpen,
		dir: direction,
		triggerPointerDownPosRef,
		disabled,
		name,
		autoComplete,
		form,
		nativeOptions: nativeOptionsSet,
		nativeSelectKey,
		isFormControl
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Popper, {
		...popperScope,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectProviderImpl, {
			scope: __scopeSelect,
			...context,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Provider, {
				scope: __scopeSelect,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectNativeOptionsProvider, {
					scope: __scopeSelect,
					onNativeOptionAdd: handleNativeOptionAdd,
					onNativeOptionRemove: handleNativeOptionRemove,
					children: isFunction(internal_do_not_use_render) ? internal_do_not_use_render(context) : children
				})
			})
		})
	});
}
__name(SelectProvider, "SelectProvider");
var Select$1 = /* @__PURE__ */ __name((props) => {
	const { __scopeSelect, children, ...providerProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectProvider, {
		__scopeSelect,
		...providerProps,
		internal_do_not_use_render: ({ isFormControl }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [children, isFormControl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectBubbleInput, { __scopeSelect }) : null] })
	});
}, "Select");
var TRIGGER_NAME = "SelectTrigger";
var SelectTrigger$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectTrigger2(props, forwardedRef) {
	const { __scopeSelect, disabled = false, ...triggerProps } = props;
	const popperScope = usePopperScope(__scopeSelect);
	const context = useSelectContext(TRIGGER_NAME, __scopeSelect);
	const isDisabled = context.disabled || disabled;
	const composedRefs = useComposedRefs(forwardedRef, context.onTriggerChange);
	const getItems = useCollection(__scopeSelect);
	const pointerTypeRef = import_react.useRef("touch");
	const [searchRef, handleTypeaheadSearch, resetTypeahead] = useTypeaheadSearch((search) => {
		const enabledItems = getItems().filter((item) => !item.disabled);
		const nextItem = findNextItem(enabledItems, search, enabledItems.find((item) => item.value === context.value));
		if (nextItem !== void 0) context.onUserSelect(nextItem.value);
	});
	const handleOpen = /* @__PURE__ */ __name((pointerEvent) => {
		if (!isDisabled) {
			context.onOpenChange(true);
			resetTypeahead();
		}
		if (pointerEvent) context.triggerPointerDownPosRef.current = {
			x: Math.round(pointerEvent.pageX),
			y: Math.round(pointerEvent.pageY)
		};
	}, "handleOpen");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopperAnchor, {
		asChild: true,
		...popperScope,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.button, {
			type: "button",
			role: "combobox",
			"aria-controls": context.open ? context.contentId : void 0,
			"aria-expanded": context.open,
			"aria-required": context.required,
			"aria-autocomplete": "none",
			dir: context.dir,
			"data-state": context.open ? "open" : "closed",
			disabled: isDisabled,
			"data-disabled": isDisabled ? "" : void 0,
			"data-placeholder": shouldShowPlaceholder(context.value) ? "" : void 0,
			...triggerProps,
			ref: composedRefs,
			onClick: composeEventHandlers(triggerProps.onClick, (event) => {
				event.currentTarget.focus();
				if (pointerTypeRef.current !== "mouse") handleOpen(event);
			}),
			onPointerDown: composeEventHandlers(triggerProps.onPointerDown, (event) => {
				pointerTypeRef.current = event.pointerType;
				const target = event.target;
				if (target.hasPointerCapture(event.pointerId)) target.releasePointerCapture(event.pointerId);
				if (event.button === 0 && event.ctrlKey === false && event.pointerType === "mouse") {
					handleOpen(event);
					event.preventDefault();
				}
			}),
			onKeyDown: composeEventHandlers(triggerProps.onKeyDown, (event) => {
				const isTypingAhead = searchRef.current !== "";
				if (!(event.ctrlKey || event.altKey || event.metaKey) && event.key.length === 1) {
					context.hasConsumerStoppedPropagationRef.current = event.isPropagationStopped();
					handleTypeaheadSearch(event.key);
				}
				if (isTypingAhead && event.key === " ") return;
				if (OPEN_KEYS.includes(event.key)) {
					handleOpen();
					event.preventDefault();
				}
			})
		})
	});
}, "SelectTrigger"));
var VALUE_NAME = "SelectValue";
var SelectValue$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectValue2(props, forwardedRef) {
	const { __scopeSelect, className, style, children, placeholder = "", ...valueProps } = props;
	const context = useSelectContext(VALUE_NAME, __scopeSelect);
	const { onValueNodeHasChildrenChange } = context;
	const hasChildren = children !== void 0;
	const composedRefs = useComposedRefs(forwardedRef, context.onValueNodeChange);
	useLayoutEffect2(() => {
		onValueNodeHasChildrenChange(hasChildren);
	}, [onValueNodeHasChildrenChange, hasChildren]);
	const showPlaceholder = shouldShowPlaceholder(context.value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
		...valueProps,
		asChild: showPlaceholder ? false : valueProps.asChild,
		ref: composedRefs,
		style: { pointerEvents: "none" },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: showPlaceholder ? placeholder : children }, showPlaceholder ? "placeholder" : "value")
	});
}, "SelectValue"));
var SelectIcon = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectIcon2(props, forwardedRef) {
	const { __scopeSelect, children, ...iconProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
		"aria-hidden": true,
		...iconProps,
		ref: forwardedRef,
		children: children || "▼"
	});
}, "SelectIcon"));
var [PortalProvider, usePortalContext] = createSelectContext("SelectPortal", { forceMount: void 0 });
var SelectPortal = /* @__PURE__ */ __name((props) => {
	const { __scopeSelect, forceMount, ...portalProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalProvider, {
		scope: props.__scopeSelect,
		forceMount,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, {
			asChild: true,
			...portalProps
		})
	});
}, "SelectPortal");
var CONTENT_NAME = "SelectContent";
var SelectContent$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectContent2(props, forwardedRef) {
	const portalContext = usePortalContext(CONTENT_NAME, props.__scopeSelect);
	const { forceMount = portalContext.forceMount, ...contentProps } = props;
	const context = useSelectContext(CONTENT_NAME, props.__scopeSelect);
	const [fragment, setFragment] = import_react.useState();
	useLayoutEffect2(() => {
		setFragment(new DocumentFragment());
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
		present: forceMount || context.open,
		children: ({ present }) => present ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContentImpl, {
			...contentProps,
			ref: forwardedRef
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContentFragment, {
			...contentProps,
			fragment
		})
	});
}, "SelectContent"));
var SelectContentFragment = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectContentFragment2(props, forwardedRef) {
	const { __scopeSelect, children, fragment } = props;
	if (!fragment) return null;
	return import_react_dom.createPortal(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContentProvider, {
		scope: __scopeSelect,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Slot, {
			scope: __scopeSelect,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: forwardedRef,
				children
			})
		})
	}), fragment);
}, "SelectContentFragment"));
var CONTENT_MARGIN = 10;
var [SelectContentProvider, useSelectContentContext] = createSelectContext(CONTENT_NAME);
var Slot = createSlot("SelectContent.RemoveScroll");
var SelectContentImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectContentImpl2(props, forwardedRef) {
	const { __scopeSelect } = props;
	const { position = Position.ItemAligned, onCloseAutoFocus, onEscapeKeyDown, onPointerDownOutside, side, sideOffset, align, alignOffset, arrowPadding, collisionBoundary, collisionPadding, sticky, hideWhenDetached, avoidCollisions, ...contentProps } = props;
	const context = useSelectContext(CONTENT_NAME, __scopeSelect);
	const [content, setContent] = import_react.useState(null);
	const [viewport, setViewport] = import_react.useState(null);
	const composedRefs = useComposedRefs(forwardedRef, setContent);
	const [selectedItem, setSelectedItem] = import_react.useState(null);
	const [selectedItemText, setSelectedItemText] = import_react.useState(null);
	const getItems = useCollection(__scopeSelect);
	const [isPositioned, setIsPositioned] = import_react.useState(false);
	const firstValidItemFoundRef = import_react.useRef(false);
	const firstItemFoundRef = import_react.useRef(false);
	const firstItemTextFoundRef = import_react.useRef(false);
	import_react.useEffect(() => {
		if (content) return hideOthers(content);
	}, [content]);
	useFocusGuards();
	const focusFirst = import_react.useCallback((candidates) => {
		const [firstItem, ...restItems] = getItems().map((item) => item.ref.current);
		const [lastItem] = restItems.slice(-1);
		const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
		for (const candidate of candidates) {
			if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
			candidate?.scrollIntoView({ block: "nearest" });
			if (candidate === firstItem && viewport) viewport.scrollTop = 0;
			if (candidate === lastItem && viewport) viewport.scrollTop = viewport.scrollHeight;
			candidate?.focus();
			if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
		}
	}, [getItems, viewport]);
	const focusSelectedItem = import_react.useCallback(() => focusFirst([selectedItem, content]), [
		focusFirst,
		selectedItem,
		content
	]);
	import_react.useEffect(() => {
		if (isPositioned) focusSelectedItem();
	}, [isPositioned, focusSelectedItem]);
	const { onOpenChange, triggerPointerDownPosRef } = context;
	import_react.useEffect(() => {
		if (content) {
			let pointerMoveDelta = {
				x: 0,
				y: 0
			};
			const handlePointerMove = /* @__PURE__ */ __name((event) => {
				pointerMoveDelta = {
					x: Math.abs(Math.round(event.pageX) - (triggerPointerDownPosRef.current?.x ?? 0)),
					y: Math.abs(Math.round(event.pageY) - (triggerPointerDownPosRef.current?.y ?? 0))
				};
			}, "handlePointerMove");
			const handlePointerUp = /* @__PURE__ */ __name((event) => {
				if (pointerMoveDelta.x <= 10 && pointerMoveDelta.y <= 10) event.preventDefault();
				else if (!event.composedPath().includes(content)) onOpenChange(false);
				document.removeEventListener("pointermove", handlePointerMove);
				triggerPointerDownPosRef.current = null;
			}, "handlePointerUp");
			if (triggerPointerDownPosRef.current !== null) {
				document.addEventListener("pointermove", handlePointerMove);
				document.addEventListener("pointerup", handlePointerUp, {
					capture: true,
					once: true
				});
			}
			return () => {
				document.removeEventListener("pointermove", handlePointerMove);
				document.removeEventListener("pointerup", handlePointerUp, { capture: true });
			};
		}
	}, [
		content,
		onOpenChange,
		triggerPointerDownPosRef
	]);
	import_react.useEffect(() => {
		const close = /* @__PURE__ */ __name(() => onOpenChange(false), "close");
		window.addEventListener("blur", close);
		window.addEventListener("resize", close);
		return () => {
			window.removeEventListener("blur", close);
			window.removeEventListener("resize", close);
		};
	}, [onOpenChange]);
	const [searchRef, handleTypeaheadSearch] = useTypeaheadSearch((search) => {
		const enabledItems = getItems().filter((item) => !item.disabled);
		const nextItem = findNextItem(enabledItems, search, enabledItems.find((item) => item.ref.current === document.activeElement));
		if (nextItem) setTimeout(() => nextItem.ref.current?.focus());
	});
	const itemRefCallback = import_react.useCallback((node, value, disabled) => {
		const isFirstItem = !firstItemFoundRef.current;
		if (isFirstItem) firstItemFoundRef.current = true;
		const isFirstValidItem = !firstValidItemFoundRef.current && !disabled;
		if (context.value !== void 0 && context.value === value || isFirstValidItem) {
			setSelectedItem(node);
			if (isFirstValidItem) firstValidItemFoundRef.current = true;
		} else if (isFirstItem) setSelectedItem(node);
	}, [context.value]);
	const handleItemLeave = import_react.useCallback(() => content?.focus(), [content]);
	const itemTextRefCallback = import_react.useCallback((node, value, disabled) => {
		if (!node) return;
		const isFirstItem = !firstItemTextFoundRef.current;
		if (isFirstItem) firstItemTextFoundRef.current = true;
		const isFirstValidItem = !firstValidItemFoundRef.current && !disabled;
		if (context.value !== void 0 && context.value === value || isFirstValidItem) setSelectedItemText(node);
		else if (isFirstItem) setSelectedItemText(node);
	}, [context.value]);
	const SelectPosition = position === Position.Popper ? SelectPopperPosition : SelectItemAlignedPosition;
	const popperContentProps = SelectPosition === SelectPopperPosition ? {
		side,
		sideOffset,
		align,
		alignOffset,
		arrowPadding,
		collisionBoundary,
		collisionPadding,
		sticky,
		hideWhenDetached,
		avoidCollisions
	} : {};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContentProvider, {
		scope: __scopeSelect,
		content,
		viewport,
		onViewportChange: setViewport,
		itemRefCallback,
		selectedItem,
		onItemLeave: handleItemLeave,
		itemTextRefCallback,
		focusSelectedItem,
		selectedItemText,
		position,
		isPositioned,
		searchRef,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactRemoveScroll, {
			as: Slot,
			allowPinchZoom: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusScope, {
				asChild: true,
				trapped: context.open,
				onMountAutoFocus: (event) => {
					event.preventDefault();
				},
				onUnmountAutoFocus: composeEventHandlers(onCloseAutoFocus, (event) => {
					context.trigger?.focus({ preventScroll: true });
					event.preventDefault();
				}),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DismissableLayer, {
					asChild: true,
					disableOutsidePointerEvents: true,
					onEscapeKeyDown,
					onPointerDownOutside,
					onFocusOutside: (event) => event.preventDefault(),
					onDismiss: () => context.onOpenChange(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPosition, {
						role: "listbox",
						id: context.contentId,
						"data-state": context.open ? "open" : "closed",
						dir: context.dir,
						onContextMenu: (event) => event.preventDefault(),
						...contentProps,
						...popperContentProps,
						onPlaced: () => setIsPositioned(true),
						ref: composedRefs,
						style: {
							display: "flex",
							flexDirection: "column",
							outline: "none",
							...contentProps.style
						},
						onKeyDown: composeEventHandlers(contentProps.onKeyDown, (event) => {
							const isModifierKey = event.ctrlKey || event.altKey || event.metaKey;
							if (event.key === "Tab") event.preventDefault();
							if (!isModifierKey && event.key.length === 1) handleTypeaheadSearch(event.key);
							if ([
								"ArrowUp",
								"ArrowDown",
								"Home",
								"End"
							].includes(event.key)) {
								let candidateNodes = getItems().filter((item) => !item.disabled).map((item) => item.ref.current);
								if (["ArrowUp", "End"].includes(event.key)) candidateNodes = candidateNodes.slice().reverse();
								if (["ArrowUp", "ArrowDown"].includes(event.key)) {
									const currentElement = event.target;
									const currentIndex = candidateNodes.indexOf(currentElement);
									candidateNodes = candidateNodes.slice(currentIndex + 1);
								}
								setTimeout(() => focusFirst(candidateNodes));
								event.preventDefault();
							}
						})
					})
				})
			})
		})
	});
}, "SelectContentImpl"));
var SelectItemAlignedPosition = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectItemAlignedPosition2(props, forwardedRef) {
	const { __scopeSelect, onPlaced, ...popperProps } = props;
	const context = useSelectContext(CONTENT_NAME, __scopeSelect);
	const contentContext = useSelectContentContext(CONTENT_NAME, __scopeSelect);
	const [contentWrapper, setContentWrapper] = import_react.useState(null);
	const [content, setContent] = import_react.useState(null);
	const composedRefs = useComposedRefs(forwardedRef, setContent);
	const getItems = useCollection(__scopeSelect);
	const shouldExpandOnScrollRef = import_react.useRef(false);
	const shouldRepositionRef = import_react.useRef(true);
	const { viewport, selectedItem, selectedItemText, focusSelectedItem } = contentContext;
	const position = import_react.useCallback(() => {
		if (context.trigger && context.valueNode && contentWrapper && content && viewport && selectedItem && selectedItemText) {
			const triggerRect = context.trigger.getBoundingClientRect();
			const contentRect = content.getBoundingClientRect();
			const valueNodeRect = context.valueNode.getBoundingClientRect();
			const itemTextRect = selectedItemText.getBoundingClientRect();
			if (context.dir !== Direction.RTL) {
				const itemTextOffset = itemTextRect.left - contentRect.left;
				const left = valueNodeRect.left - itemTextOffset;
				const leftDelta = triggerRect.left - left;
				const minContentWidth = triggerRect.width + leftDelta;
				const contentWidth = Math.max(minContentWidth, contentRect.width);
				const rightEdge = window.innerWidth - CONTENT_MARGIN;
				const clampedLeft = clamp$1(left, [CONTENT_MARGIN, Math.max(CONTENT_MARGIN, rightEdge - contentWidth)]);
				contentWrapper.style.minWidth = minContentWidth + "px";
				contentWrapper.style.left = clampedLeft + "px";
			} else {
				const itemTextOffset = contentRect.right - itemTextRect.right;
				const right = window.innerWidth - valueNodeRect.right - itemTextOffset;
				const rightDelta = window.innerWidth - triggerRect.right - right;
				const minContentWidth = triggerRect.width + rightDelta;
				const contentWidth = Math.max(minContentWidth, contentRect.width);
				const leftEdge = window.innerWidth - CONTENT_MARGIN;
				const clampedRight = clamp$1(right, [CONTENT_MARGIN, Math.max(CONTENT_MARGIN, leftEdge - contentWidth)]);
				contentWrapper.style.minWidth = minContentWidth + "px";
				contentWrapper.style.right = clampedRight + "px";
			}
			const items = getItems();
			const availableHeight = window.innerHeight - CONTENT_MARGIN * 2;
			const itemsHeight = viewport.scrollHeight;
			const contentStyles = window.getComputedStyle(content);
			const contentBorderTopWidth = parseInt(contentStyles.borderTopWidth, 10);
			const contentPaddingTop = parseInt(contentStyles.paddingTop, 10);
			const contentBorderBottomWidth = parseInt(contentStyles.borderBottomWidth, 10);
			const contentPaddingBottom = parseInt(contentStyles.paddingBottom, 10);
			const fullContentHeight = contentBorderTopWidth + contentPaddingTop + itemsHeight + contentPaddingBottom + contentBorderBottomWidth;
			const minContentHeight = Math.min(selectedItem.offsetHeight * 5, fullContentHeight);
			const viewportStyles = window.getComputedStyle(viewport);
			const viewportPaddingTop = parseInt(viewportStyles.paddingTop, 10);
			const viewportPaddingBottom = parseInt(viewportStyles.paddingBottom, 10);
			const topEdgeToTriggerMiddle = triggerRect.top + triggerRect.height / 2 - CONTENT_MARGIN;
			const triggerMiddleToBottomEdge = availableHeight - topEdgeToTriggerMiddle;
			const selectedItemHalfHeight = selectedItem.offsetHeight / 2;
			const itemOffsetMiddle = selectedItem.offsetTop + selectedItemHalfHeight;
			const contentTopToItemMiddle = contentBorderTopWidth + contentPaddingTop + itemOffsetMiddle;
			const itemMiddleToContentBottom = fullContentHeight - contentTopToItemMiddle;
			if (contentTopToItemMiddle <= topEdgeToTriggerMiddle) {
				const isLastItem = items.length > 0 && selectedItem === items[items.length - 1].ref.current;
				contentWrapper.style.bottom = "0px";
				const viewportOffsetBottom = content.clientHeight - viewport.offsetTop - viewport.offsetHeight;
				const height = contentTopToItemMiddle + Math.max(triggerMiddleToBottomEdge, selectedItemHalfHeight + (isLastItem ? viewportPaddingBottom : 0) + viewportOffsetBottom + contentBorderBottomWidth);
				contentWrapper.style.height = height + "px";
			} else {
				const isFirstItem = items.length > 0 && selectedItem === items[0].ref.current;
				contentWrapper.style.top = "0px";
				const height = Math.max(topEdgeToTriggerMiddle, contentBorderTopWidth + viewport.offsetTop + (isFirstItem ? viewportPaddingTop : 0) + selectedItemHalfHeight) + itemMiddleToContentBottom;
				contentWrapper.style.height = height + "px";
				viewport.scrollTop = contentTopToItemMiddle - topEdgeToTriggerMiddle + viewport.offsetTop;
			}
			contentWrapper.style.margin = `${CONTENT_MARGIN}px 0`;
			contentWrapper.style.minHeight = minContentHeight + "px";
			contentWrapper.style.maxHeight = availableHeight + "px";
			onPlaced?.();
			requestAnimationFrame(() => shouldExpandOnScrollRef.current = true);
		}
	}, [
		getItems,
		context.trigger,
		context.valueNode,
		contentWrapper,
		content,
		viewport,
		selectedItem,
		selectedItemText,
		context.dir,
		onPlaced
	]);
	useLayoutEffect2(() => position(), [position]);
	const [contentZIndex, setContentZIndex] = import_react.useState();
	useLayoutEffect2(() => {
		if (content) setContentZIndex(window.getComputedStyle(content).zIndex);
	}, [content]);
	const handleScrollButtonChange = import_react.useCallback((node) => {
		if (node && shouldRepositionRef.current === true) {
			position();
			focusSelectedItem?.();
			shouldRepositionRef.current = false;
		}
	}, [position, focusSelectedItem]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewportProvider, {
		scope: __scopeSelect,
		contentWrapper,
		shouldExpandOnScrollRef,
		onScrollButtonChange: handleScrollButtonChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: setContentWrapper,
			style: {
				display: "flex",
				flexDirection: "column",
				position: "fixed",
				zIndex: contentZIndex
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
				...popperProps,
				ref: composedRefs,
				style: {
					boxSizing: "border-box",
					maxHeight: "100%",
					...popperProps.style
				}
			})
		})
	});
}, "SelectItemAlignedPosition"));
var SelectPopperPosition = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectPopperPosition2(props, forwardedRef) {
	const { __scopeSelect, align = "start", collisionPadding = CONTENT_MARGIN, ...popperProps } = props;
	const popperScope = usePopperScope(__scopeSelect);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopperContent, {
		...popperScope,
		...popperProps,
		ref: forwardedRef,
		align,
		collisionPadding,
		style: {
			boxSizing: "border-box",
			...popperProps.style,
			"--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-select-content-available-width": "var(--radix-popper-available-width)",
			"--radix-select-content-available-height": "var(--radix-popper-available-height)",
			"--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
}, "SelectPopperPosition"));
var [SelectViewportProvider, useSelectViewportContext] = createSelectContext(CONTENT_NAME, {});
var VIEWPORT_NAME = "SelectViewport";
var SelectViewport = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectViewport2(props, forwardedRef) {
	const { __scopeSelect, nonce, ...viewportProps } = props;
	const contentContext = useSelectContentContext(VIEWPORT_NAME, __scopeSelect);
	const viewportContext = useSelectViewportContext(VIEWPORT_NAME, __scopeSelect);
	const composedRefs = useComposedRefs(forwardedRef, contentContext.onViewportChange);
	const prevScrollTopRef = import_react.useRef(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", {
		dangerouslySetInnerHTML: { __html: `[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}` },
		nonce
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.Slot, {
		scope: __scopeSelect,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
			"data-radix-select-viewport": "",
			role: "presentation",
			...viewportProps,
			ref: composedRefs,
			style: {
				position: "relative",
				flex: 1,
				overflow: "hidden auto",
				...viewportProps.style
			},
			onScroll: composeEventHandlers(viewportProps.onScroll, (event) => {
				const viewport = event.currentTarget;
				const { contentWrapper, shouldExpandOnScrollRef } = viewportContext;
				if (shouldExpandOnScrollRef?.current && contentWrapper) {
					const scrolledBy = Math.abs(prevScrollTopRef.current - viewport.scrollTop);
					if (scrolledBy > 0) {
						const availableHeight = window.innerHeight - CONTENT_MARGIN * 2;
						const cssMinHeight = parseFloat(contentWrapper.style.minHeight);
						const cssHeight = parseFloat(contentWrapper.style.height);
						const prevHeight = Math.max(cssMinHeight, cssHeight);
						if (prevHeight < availableHeight) {
							const nextHeight = prevHeight + scrolledBy;
							const clampedNextHeight = Math.min(availableHeight, nextHeight);
							const heightDiff = nextHeight - clampedNextHeight;
							contentWrapper.style.height = clampedNextHeight + "px";
							if (contentWrapper.style.bottom === "0px") {
								viewport.scrollTop = heightDiff > 0 ? heightDiff : 0;
								contentWrapper.style.justifyContent = "flex-end";
							}
						}
					}
				}
				prevScrollTopRef.current = viewport.scrollTop;
			})
		})
	})] });
}, "SelectViewport"));
var [SelectGroupContextProvider, useSelectGroupContext] = createSelectContext("SelectGroup");
var LABEL_NAME = "SelectLabel";
var SelectLabel$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectLabel2(props, forwardedRef) {
	const { __scopeSelect, ...labelProps } = props;
	const groupContext = useSelectGroupContext(LABEL_NAME, __scopeSelect);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		id: groupContext.id,
		...labelProps,
		ref: forwardedRef
	});
}, "SelectLabel"));
var ITEM_NAME = "SelectItem";
var [SelectItemContextProvider, useSelectItemContext] = createSelectContext(ITEM_NAME);
var SelectItem$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectItem2(props, forwardedRef) {
	const { __scopeSelect, value, disabled = false, textValue: textValueProp, ...itemProps } = props;
	const context = useSelectContext(ITEM_NAME, __scopeSelect);
	const contentContext = useSelectContentContext(ITEM_NAME, __scopeSelect);
	const isSelected = context.value === value;
	const [textValue, setTextValue] = import_react.useState(textValueProp ?? "");
	const [isFocused, setIsFocused] = import_react.useState(false);
	const handleItemRefCallback = useCallbackRef((node) => contentContext.itemRefCallback?.(node, value, disabled));
	const composedRefs = useComposedRefs(forwardedRef, handleItemRefCallback);
	const textId = useId();
	const pointerTypeRef = import_react.useRef("touch");
	function handleSelect(event) {
		context.hasConsumerStoppedPropagationRef.current = event.isPropagationStopped();
		context.onUserSelect(value);
		context.onOpenChange(false);
	}
	__name(handleSelect, "handleSelect");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemContextProvider, {
		scope: __scopeSelect,
		value,
		disabled,
		textId,
		isSelected,
		onItemTextChange: import_react.useCallback((node) => {
			setTextValue((prevTextValue) => prevTextValue || (node?.textContent ?? "").trim());
		}, []),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collection.ItemSlot, {
			scope: __scopeSelect,
			value,
			disabled,
			textValue,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
				role: "option",
				"aria-labelledby": textId,
				"data-highlighted": isFocused ? "" : void 0,
				"aria-selected": isSelected && isFocused,
				"data-state": isSelected ? "checked" : "unchecked",
				"aria-disabled": disabled || void 0,
				"data-disabled": disabled ? "" : void 0,
				tabIndex: disabled ? void 0 : -1,
				...itemProps,
				ref: composedRefs,
				onFocus: composeEventHandlers(itemProps.onFocus, () => setIsFocused(true)),
				onBlur: composeEventHandlers(itemProps.onBlur, () => setIsFocused(false)),
				onClick: composeEventHandlers(itemProps.onClick, (event) => {
					if (disabled) return;
					if (pointerTypeRef.current !== "mouse") handleSelect(event);
				}),
				onPointerUp: composeEventHandlers(itemProps.onPointerUp, (event) => {
					if (disabled) return;
					if (pointerTypeRef.current === "mouse") handleSelect(event);
				}),
				onPointerDown: composeEventHandlers(itemProps.onPointerDown, (event) => {
					pointerTypeRef.current = event.pointerType;
				}),
				onPointerMove: composeEventHandlers(itemProps.onPointerMove, (event) => {
					pointerTypeRef.current = event.pointerType;
					if (disabled) contentContext.onItemLeave?.();
					else if (pointerTypeRef.current === "mouse") event.currentTarget.focus({ preventScroll: true });
				}),
				onPointerLeave: composeEventHandlers(itemProps.onPointerLeave, (event) => {
					if (event.currentTarget === document.activeElement) contentContext.onItemLeave?.();
				}),
				onKeyDown: composeEventHandlers(itemProps.onKeyDown, (event) => {
					if (disabled || event.target !== event.currentTarget) return;
					if (contentContext.searchRef?.current !== "" && event.key === " ") return;
					if (SELECTION_KEYS.includes(event.key)) handleSelect(event);
					if (event.key === " ") event.preventDefault();
				})
			})
		})
	});
}, "SelectItem"));
var ITEM_TEXT_NAME = "SelectItemText";
var SelectItemText = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectItemText2(props, forwardedRef) {
	const { __scopeSelect, className, style, ...itemTextProps } = props;
	const context = useSelectContext(ITEM_TEXT_NAME, __scopeSelect);
	const contentContext = useSelectContentContext(ITEM_TEXT_NAME, __scopeSelect);
	const itemContext = useSelectItemContext(ITEM_TEXT_NAME, __scopeSelect);
	const nativeOptionsContext = useSelectNativeOptionsContext(ITEM_TEXT_NAME, __scopeSelect);
	const [itemTextNode, setItemTextNode] = import_react.useState(null);
	const handleItemTextRefCallback = useCallbackRef((node) => contentContext.itemTextRefCallback?.(node, itemContext.value, itemContext.disabled));
	const composedRefs = useComposedRefs(forwardedRef, setItemTextNode, itemContext.onItemTextChange, handleItemTextRefCallback);
	const textContent = itemTextNode?.textContent;
	const nativeOption = import_react.useMemo(() => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
		value: itemContext.value,
		disabled: itemContext.disabled,
		children: textContent
	}, itemContext.value), [
		itemContext.disabled,
		itemContext.value,
		textContent
	]);
	const { onNativeOptionAdd, onNativeOptionRemove } = nativeOptionsContext;
	useLayoutEffect2(() => {
		onNativeOptionAdd(nativeOption);
		return () => onNativeOptionRemove(nativeOption);
	}, [
		onNativeOptionAdd,
		onNativeOptionRemove,
		nativeOption
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
		id: itemContext.textId,
		...itemTextProps,
		ref: composedRefs
	}), itemContext.isSelected && context.valueNode && !context.valueNodeHasChildren && !shouldShowPlaceholder(context.value) ? import_react_dom.createPortal(itemTextProps.children, context.valueNode) : null] });
}, "SelectItemText"));
var ITEM_INDICATOR_NAME = "SelectItemIndicator";
var SelectItemIndicator = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectItemIndicator2(props, forwardedRef) {
	const { __scopeSelect, ...itemIndicatorProps } = props;
	return useSelectItemContext(ITEM_INDICATOR_NAME, __scopeSelect).isSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.span, {
		"aria-hidden": true,
		...itemIndicatorProps,
		ref: forwardedRef
	}) : null;
}, "SelectItemIndicator"));
var SCROLL_UP_BUTTON_NAME = "SelectScrollUpButton";
var SelectScrollUpButton$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectScrollUpButton2(props, forwardedRef) {
	const contentContext = useSelectContentContext(SCROLL_UP_BUTTON_NAME, props.__scopeSelect);
	const viewportContext = useSelectViewportContext(SCROLL_UP_BUTTON_NAME, props.__scopeSelect);
	const [canScrollUp, setCanScrollUp] = import_react.useState(false);
	const composedRefs = useComposedRefs(forwardedRef, viewportContext.onScrollButtonChange);
	useLayoutEffect2(() => {
		if (contentContext.viewport && contentContext.isPositioned) {
			let handleScroll2 = function() {
				const canScrollUp2 = viewport.scrollTop > 0;
				setCanScrollUp(canScrollUp2);
			};
			__name(handleScroll2, "handleScroll");
			const viewport = contentContext.viewport;
			handleScroll2();
			viewport.addEventListener("scroll", handleScroll2);
			return () => viewport.removeEventListener("scroll", handleScroll2);
		}
	}, [contentContext.viewport, contentContext.isPositioned]);
	return canScrollUp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollButtonImpl, {
		...props,
		ref: composedRefs,
		onAutoScroll: () => {
			const { viewport, selectedItem } = contentContext;
			if (viewport && selectedItem) viewport.scrollTop = viewport.scrollTop - selectedItem.offsetHeight;
		}
	}) : null;
}, "SelectScrollUpButton"));
var SCROLL_DOWN_BUTTON_NAME = "SelectScrollDownButton";
var SelectScrollDownButton$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectScrollDownButton2(props, forwardedRef) {
	const contentContext = useSelectContentContext(SCROLL_DOWN_BUTTON_NAME, props.__scopeSelect);
	const viewportContext = useSelectViewportContext(SCROLL_DOWN_BUTTON_NAME, props.__scopeSelect);
	const [canScrollDown, setCanScrollDown] = import_react.useState(false);
	const composedRefs = useComposedRefs(forwardedRef, viewportContext.onScrollButtonChange);
	useLayoutEffect2(() => {
		if (contentContext.viewport && contentContext.isPositioned) {
			let handleScroll2 = function() {
				const maxScroll = viewport.scrollHeight - viewport.clientHeight;
				const canScrollDown2 = Math.ceil(viewport.scrollTop) < maxScroll;
				setCanScrollDown(canScrollDown2);
			};
			__name(handleScroll2, "handleScroll");
			const viewport = contentContext.viewport;
			handleScroll2();
			viewport.addEventListener("scroll", handleScroll2);
			return () => viewport.removeEventListener("scroll", handleScroll2);
		}
	}, [contentContext.viewport, contentContext.isPositioned]);
	return canScrollDown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollButtonImpl, {
		...props,
		ref: composedRefs,
		onAutoScroll: () => {
			const { viewport, selectedItem } = contentContext;
			if (viewport && selectedItem) viewport.scrollTop = viewport.scrollTop + selectedItem.offsetHeight;
		}
	}) : null;
}, "SelectScrollDownButton"));
var SelectScrollButtonImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectScrollButtonImpl2(props, forwardedRef) {
	const { __scopeSelect, onAutoScroll, ...scrollIndicatorProps } = props;
	const contentContext = useSelectContentContext("SelectScrollButton", __scopeSelect);
	const autoScrollTimerRef = import_react.useRef(null);
	const getItems = useCollection(__scopeSelect);
	const clearAutoScrollTimer = import_react.useCallback(() => {
		if (autoScrollTimerRef.current !== null) {
			window.clearInterval(autoScrollTimerRef.current);
			autoScrollTimerRef.current = null;
		}
	}, []);
	import_react.useEffect(() => {
		return () => clearAutoScrollTimer();
	}, [clearAutoScrollTimer]);
	useLayoutEffect2(() => {
		getItems().find((item) => item.ref.current === document.activeElement)?.ref.current?.scrollIntoView({ block: "nearest" });
	}, [getItems]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		"aria-hidden": true,
		...scrollIndicatorProps,
		ref: forwardedRef,
		style: {
			flexShrink: 0,
			...scrollIndicatorProps.style
		},
		onPointerDown: composeEventHandlers(scrollIndicatorProps.onPointerDown, () => {
			if (autoScrollTimerRef.current === null) autoScrollTimerRef.current = window.setInterval(onAutoScroll, 50);
		}),
		onPointerMove: composeEventHandlers(scrollIndicatorProps.onPointerMove, () => {
			contentContext.onItemLeave?.();
			if (autoScrollTimerRef.current === null) autoScrollTimerRef.current = window.setInterval(onAutoScroll, 50);
		}),
		onPointerLeave: composeEventHandlers(scrollIndicatorProps.onPointerLeave, () => {
			clearAutoScrollTimer();
		})
	});
}, "SelectScrollButtonImpl"));
var SelectSeparator$1 = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectSeparator2(props, forwardedRef) {
	const { __scopeSelect, ...separatorProps } = props;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		"aria-hidden": true,
		...separatorProps,
		ref: forwardedRef
	});
}, "SelectSeparator"));
var BUBBLE_INPUT_NAME = "SelectBubbleInput";
var SelectBubbleInput = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function SelectBubbleInput2({ __scopeSelect, ...props }, forwardedRef) {
	const context = useSelectContext(BUBBLE_INPUT_NAME, __scopeSelect);
	const { value, onValueChange, required, disabled, name, autoComplete, form, userSelection } = context;
	const { nativeOptions, nativeSelectKey } = context;
	const ref = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, ref);
	const selectValue = value ?? "";
	const prevValueRef = import_react.useRef(selectValue);
	const handledUserSelectionRef = import_react.useRef(userSelection);
	const isDispatchingUserSelectionRef = import_react.useRef(false);
	const hasEmptyValueOption = Array.from(nativeOptions).some((option) => (option.props.value ?? "") === "");
	import_react.useEffect(() => {
		const select = ref.current;
		if (!select) return;
		const selectProto = window.HTMLSelectElement.prototype;
		const setValue = Object.getOwnPropertyDescriptor(selectProto, "value").set;
		const isNewUserSelection = userSelection !== null && userSelection !== handledUserSelectionRef.current;
		handledUserSelectionRef.current = userSelection;
		const valueChanged = prevValueRef.current !== selectValue;
		prevValueRef.current = selectValue;
		const isUserInteraction = isNewUserSelection && valueChanged;
		if (isNewUserSelection && !valueChanged && userSelection.value !== selectValue && !userSelection.hasConsumerStoppedPropagation && setValue) {
			isDispatchingUserSelectionRef.current = true;
			try {
				setValue.call(select, userSelection.value);
				select.dispatchEvent(new Event("change", { bubbles: true }));
			} finally {
				isDispatchingUserSelectionRef.current = false;
				setValue.call(select, selectValue);
			}
			return;
		}
		const bubbles = isUserInteraction && !userSelection.hasConsumerStoppedPropagation;
		if (valueChanged && setValue) {
			const event = new Event("change", { bubbles });
			setValue.call(select, selectValue);
			select.dispatchEvent(event);
		}
	}, [selectValue, userSelection]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Primitive.select, {
		"aria-hidden": true,
		required,
		tabIndex: -1,
		name,
		autoComplete,
		disabled,
		form,
		onChange: (event) => {
			if (!isDispatchingUserSelectionRef.current) onValueChange(event.target.value);
		},
		...props,
		style: {
			...VISUALLY_HIDDEN_STYLES,
			...props.style
		},
		ref: composedRefs,
		defaultValue: selectValue,
		children: [shouldShowPlaceholder(value) && !hasEmptyValueOption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "" }) : null, Array.from(nativeOptions)]
	}, nativeSelectKey);
}, "SelectBubbleInput"));
function isFunction(value) {
	return typeof value === "function";
}
__name(isFunction, "isFunction");
function shouldShowPlaceholder(value) {
	return value === "" || value === void 0;
}
__name(shouldShowPlaceholder, "shouldShowPlaceholder");
function useTypeaheadSearch(onSearchChange) {
	const handleSearchChange = useCallbackRef(onSearchChange);
	const searchRef = import_react.useRef("");
	const timerRef = import_react.useRef(0);
	const handleTypeaheadSearch = import_react.useCallback((key) => {
		const search = searchRef.current + key;
		handleSearchChange(search);
		function updateSearch(value) {
			searchRef.current = value;
			window.clearTimeout(timerRef.current);
			if (value !== "") timerRef.current = window.setTimeout(() => updateSearch(""), 1e3);
		}
		__name(updateSearch, "updateSearch");
		updateSearch(search);
	}, [handleSearchChange]);
	const resetTypeahead = import_react.useCallback(() => {
		searchRef.current = "";
		window.clearTimeout(timerRef.current);
	}, []);
	import_react.useEffect(() => {
		return () => window.clearTimeout(timerRef.current);
	}, []);
	return [
		searchRef,
		handleTypeaheadSearch,
		resetTypeahead
	];
}
__name(useTypeaheadSearch, "useTypeaheadSearch");
function findNextItem(items, search, currentItem) {
	const normalizedSearch = search.length > 1 && Array.from(search).every((char) => char === search[0]) ? search[0] : search;
	const currentItemIndex = currentItem ? items.indexOf(currentItem) : -1;
	let wrappedItems = wrapArray(items, Math.max(currentItemIndex, 0));
	if (normalizedSearch.length === 1) wrappedItems = wrappedItems.filter((v) => v !== currentItem);
	const nextItem = wrappedItems.find((item) => item.textValue.toLowerCase().startsWith(normalizedSearch.toLowerCase()));
	return nextItem !== currentItem ? nextItem : void 0;
}
__name(findNextItem, "findNextItem");
function wrapArray(array, startIndex) {
	return array.map((_, index) => array[(startIndex + index) % array.length]);
}
__name(wrapArray, "wrapArray");
/**
* @license lucide-react v0.575.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Check = createLucideIcon("check", [["path", {
	d: "M20 6 9 17l-5-5",
	key: "1gmf2c"
}]]);
/**
* @license lucide-react v0.575.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ChevronDown = createLucideIcon("chevron-down", [["path", {
	d: "m6 9 6 6 6-6",
	key: "qrunsl"
}]]);
/**
* @license lucide-react v0.575.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ChevronUp = createLucideIcon("chevron-up", [["path", {
	d: "m18 15-6-6-6 6",
	key: "153udz"
}]]);
//#endregion
//#region src/components/ui/select.tsx
var Select = Select$1;
var SelectValue = SelectValue$1;
var SelectTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger$1, {
	ref,
	className: cn("flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm font-normal shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectIcon, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 opacity-50" })
	})]
}));
SelectTrigger.displayName = SelectTrigger$1.displayName;
var SelectScrollUpButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-4 w-4" })
}));
SelectScrollUpButton.displayName = SelectScrollUpButton$1.displayName;
var SelectScrollDownButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })
}));
SelectScrollDownButton.displayName = SelectScrollDownButton$1.displayName;
var SelectContent = import_react.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent$1, {
	ref,
	className: cn("relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
	position,
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewport, {
			className: cn("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton, {})
	]
}) }));
SelectContent.displayName = SelectContent$1.displayName;
var SelectLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectLabel$1, {
	ref,
	className: cn("px-2 py-1.5 text-xs font-semibold tracking-label", className),
	...props
}));
SelectLabel.displayName = SelectLabel$1.displayName;
var SelectItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem$1, {
	ref,
	className: cn("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm font-normal outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemText, { children })]
}));
SelectItem.displayName = SelectItem$1.displayName;
var SelectSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectSeparator$1, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
SelectSeparator.displayName = SelectSeparator$1.displayName;
//#endregion
//#region src/components/workshop/record-pages.tsx
var QUOTATION_VAT_RATE = 16;
var nextDraftLineSeq = 1;
var createDraftLineRowId = () => `qline-${nextDraftLineSeq++}`;
var initialQuotationLines = () => [
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "air filter",
		description: "ford",
		unitPrice: "450.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "oil filter",
		description: "ford",
		unitPrice: "250.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "fuel filter",
		description: "ford",
		unitPrice: "250.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "cabin filter",
		description: "ford",
		unitPrice: "350.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "2",
		item: "wipers",
		description: "ford",
		unitPrice: "350.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "brake pads",
		description: "ford",
		unitPrice: "1950.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "brake pads",
		description: "ford",
		unitPrice: "1950.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "brake booster",
		description: "ford",
		unitPrice: "1950.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "labour",
		description: "ford",
		unitPrice: "2000.00"
	}
];
var emptyQuotationLine = () => ({
	rowId: createDraftLineRowId(),
	item: "",
	description: "",
	quantity: "1",
	unitPrice: ""
});
var initialPaperFields = () => ({
	companyName: "Hirider 4x4 World (Kwacha)",
	address: "Makeni Road, Lusaka",
	email: "mkessa@hotmail.com",
	phone: "+260 966 766 693",
	bankName: "Access Bank",
	accountNumber: "0060211407831",
	vatNumber: "1004021290",
	quoteNo: "12844",
	date: "13/10/2026",
	salesperson: "PRECIOUS",
	billTo1: "RTSA",
	billTo2: "RTSA",
	shipTo1: "RTSA",
	shipTo2: "FORD RANGER",
	shipTo3: "BAK 6213",
	preparedBy: "PRECIOUS",
	signature: "",
	invoiceReference: ""
});
var roundMoney = (amount) => Math.round((amount + Number.EPSILON) * 100) / 100;
var config = {
	quotations: {
		title: "Quotation Management",
		subtitle: "Prepare quotations and record customer authorization",
		singular: "quotation",
		headers: [
			{
				label: "Quotation",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Customer",
				sortKey: "customer"
			},
			{
				label: "Amount",
				sortKey: "amount",
				align: "right"
			},
			{
				label: "Status",
				sortKey: "status"
			},
			"Actions"
		]
	},
	inventory: {
		title: "Inventory Cards",
		subtitle: "Vehicle belongings, accessories and condition records",
		singular: "inventory card",
		headers: [
			{
				label: "Inventory card",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Items recorded",
				sortKey: "items"
			},
			{
				label: "Created",
				sortKey: "date"
			},
			"Actions"
		]
	},
	jobs: {
		title: "Job Card Management",
		subtitle: "Assign repair work to the relevant workshop departments",
		singular: "job card",
		headers: [
			{
				label: "Job card",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Work instructions",
				sortKey: "work"
			},
			{
				label: "Status",
				sortKey: "status"
			},
			"Actions"
		]
	},
	requisitions: {
		title: "Parts Requisitions",
		subtitle: "Required parts, director authorization and purchasing status",
		singular: "parts requisition",
		headers: [
			{
				label: "Requisition",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Part / item",
				sortKey: "part"
			},
			{
				label: "Qty",
				sortKey: "quantity",
				align: "right"
			},
			{
				label: "Status",
				sortKey: "status"
			},
			"Actions"
		]
	},
	inspections: {
		title: "Vehicle Inspections",
		subtitle: "Final checks, inspection results and foreman sign-off",
		singular: "inspection",
		headers: [
			{
				label: "Inspection",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Foreman",
				sortKey: "foreman"
			},
			{
				label: "Date",
				sortKey: "date"
			},
			{
				label: "Result",
				sortKey: "result"
			},
			"Actions"
		]
	}
};
function QuotationItemsTable({ items, rowKeyPrefix, className }) {
	const [itemSort, setItemSort] = (0, import_react.useState)(null);
	const sortedItems = sortRecords(items, itemSort, (entry, key) => {
		switch (key) {
			case "quantity": return entry.quantity;
			case "item": return entry.item;
			case "description": return entry.description;
			case "unitPrice": return entry.unitPrice;
			case "total": return entry.lineTotal ?? entry.quantity * entry.unitPrice;
		}
	});
	const toggle = (key) => setItemSort((current) => nextSortState(current, key));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				align: "right",
				sortDirection: itemSort?.key === "quantity" ? itemSort.direction : null,
				onSort: () => toggle("quantity"),
				children: "Qty"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				sortDirection: itemSort?.key === "item" ? itemSort.direction : null,
				onSort: () => toggle("item"),
				children: "Item"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				sortDirection: itemSort?.key === "description" ? itemSort.direction : null,
				onSort: () => toggle("description"),
				children: "Description"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				align: "right",
				sortDirection: itemSort?.key === "unitPrice" ? itemSort.direction : null,
				onSort: () => toggle("unitPrice"),
				children: "Unit Price"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				align: "right",
				sortDirection: itemSort?.key === "total" ? itemSort.direction : null,
				onSort: () => toggle("total"),
				children: "Total"
			})
		] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: sortedItems.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right tabular-nums",
				children: entry.quantity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: entry.item }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: entry.description }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right tabular-nums",
				children: money(entry.unitPrice)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right tabular-nums",
				children: money(entry.lineTotal ?? entry.quantity * entry.unitPrice)
			})
		] }, `${rowKeyPrefix}-${entry.item}-${index}`)) })]
	}), sortedItems.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "empty-state-wrap",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			compact: true,
			icon: FileText,
			tone: "muted",
			title: "No quotation line items",
			description: "No itemized parts or labour entries are recorded on this quotation yet."
		})
	})] });
}
function RecordsPage({ kind }) {
	const w = useWorkspace();
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [sort, setSort] = (0, import_react.useState)(null);
	const [create, setCreate] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setSort(null);
	}, [kind]);
	const [paperInventory, setPaperInventory] = (0, import_react.useState)([]);
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [request, setRequest] = (0, import_react.useState)(null);
	const [selectedInspection, setSelectedInspection] = (0, import_react.useState)(null);
	const [quote, setQuote] = (0, import_react.useState)(null);
	const [paperQuote, setPaperQuote] = (0, import_react.useState)(null);
	const [recordDetail, setRecordDetail] = (0, import_react.useState)(null);
	const [approvalView, setApprovalView] = (0, import_react.useState)(null);
	const [approvalToken, setApprovalToken] = (0, import_react.useState)("");
	const [approvalDecisions, setApprovalDecisions] = (0, import_react.useState)({});
	const c = config[kind];
	const records = kind === "quotations" ? w.quotations : kind === "inventory" ? [...paperInventory, ...w.inventory] : kind === "jobs" ? w.jobs : kind === "requisitions" ? w.requisitions : w.inspections;
	const matches = (row) => {
		const vehicle = w.vehicleFor(row.vehicleId);
		return `${row.id} ${vehicle?.make} ${vehicle?.plate} ${vehicle?.customer}`.toLowerCase().includes(`${query} ${w.search}`.trim().toLowerCase()) && (filter === "All" || row.status === filter || row.result === filter);
	};
	const count = records.filter(matches).length;
	const isFiltered = Boolean(query.trim() || w.search.trim() || filter !== "All");
	const emptyMeta = {
		quotations: {
			icon: FileText,
			title: "No quotations created yet",
			description: "Prepare itemized customer quotations and record authorization status here."
		},
		inventory: {
			icon: Archive,
			title: "No inventory cards recorded",
			description: "Document vehicle accessories, belongings, fuel levels, and incoming condition notes."
		},
		jobs: {
			icon: ClipboardList,
			title: "No job cards open",
			description: "Create job cards to assign repair instructions to workshop departments."
		},
		requisitions: {
			icon: Package,
			title: "No parts requisitions submitted",
			description: "Request replacement parts and consumables for director authorization and purchasing."
		},
		inspections: {
			icon: ClipboardCheck,
			title: "No vehicle inspections recorded",
			description: "Record final quality checks and foreman sign-off before releasing completed vehicles."
		}
	}[kind];
	const createLabel = kind === "inventory" ? "New vehicle inventory" : `New ${c.singular}`;
	const choices = kind === "quotations" ? [
		"Draft",
		"Awaiting approval",
		"Approved"
	] : kind === "requisitions" ? [
		"Pending",
		"Approved",
		"Rejected",
		"Ordered",
		"Dispatched"
	] : kind === "jobs" ? [
		"In progress",
		"Awaiting parts",
		"Complete"
	] : kind === "inspections" ? [
		"Pending",
		"Passed",
		"Rework required"
	] : [];
	function sendQuote(q) {
		w.setQuotations((prev) => prev.map((item) => item.id === q.id ? {
			...item,
			status: "Awaiting approval"
		} : item));
		w.updateVehicleStage(q.vehicleId, 2);
		w.addActivity(`Quotation marked as sent to customer`, q.id);
		toast.success("Quotation marked as sent. Awaiting customer authorization.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeading, {
			title: c.title,
			subtitle: c.subtitle,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
					filename: kind,
					rows: records
				}),
				w.role === "Foreman" && kind === "inventory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setCreate(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "New vehicle inventory"]
				}),
				w.role === "Foreman" && kind !== "inventory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setCreate(true),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}),
						"New ",
						c.singular
					]
				})
			]
		}),
		w.error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "alert",
			className: "rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive",
			children: [
				w.error,
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => void w.refresh(),
					children: "Retry"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "toolbar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarSearch, {
				ariaLabel: `Search ${c.title}`,
				placeholder: `Search ${c.title.toLowerCase()}...`,
				value: query,
				onChange: setQuery
			}), choices.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: filter,
				onValueChange: setFilter,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "w-[175px] h-[38px] rounded-[6px] border-[#d1d5db] bg-background text-sm font-normal shadow-none",
					"aria-label": "Filter status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "All",
					children: "All statuses"
				}), choices.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: s,
					children: s
				}, s))] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTable, {
			headers: c.headers,
			loading: w.loading,
			sort,
			onSort: (key) => setSort((current) => nextSortState(current, key)),
			empty: count === 0,
			emptyState: isFiltered ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Search,
				tone: "muted",
				title: `No matching ${c.title.toLowerCase()}`,
				description: "No records matched your current search term or selected status filter.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => {
						setQuery("");
						setFilter("All");
						w.setSearch("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Clear filters"]
				}), w.role === "Foreman" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setCreate(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), createLabel]
				})] })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: emptyMeta.icon,
				title: emptyMeta.title,
				description: emptyMeta.description,
				action: w.role === "Foreman" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setCreate(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), createLabel]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void w.refresh(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Refresh records"]
				})
			}),
			children: [
				kind === "quotations" && sortRecords(w.quotations.filter(matches), sort, (q, key) => {
					const vehicle = w.vehicleFor(q.vehicleId);
					switch (key) {
						case "id": return q.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "customer": return vehicle?.customer ?? "";
						case "amount": return q.amount;
						case "status": return q.status;
						default: return "";
					}
				}).map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: q.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(q.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: w.vehicleFor(q.vehicleId)?.customer }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title text-right tabular-nums",
						children: money(q.amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: q.status }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							w.role === "Foreman" && q.status === "Draft" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => sendQuote(q),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {}), "Mark sent"]
							}),
							w.role === "Foreman" && q.status === "Awaiting approval" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => {
									setApprovalView(null);
									setApprovalToken("");
									setApprovalDecisions({});
									setQuote(q);
								},
								children: "Record approval"
							}),
							kind === "quotations" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setPaperQuote(q),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), "Print / Preview"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								title: "Quotation details",
								"aria-label": `View ${q.id}`,
								onClick: () => setRecordDetail({
									title: q.id,
									body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(q.vehicleId) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 grid grid-cols-2 gap-3 text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "Bill To"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													w.vehicleFor(q.vehicleId)?.customer
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "Ship To"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													w.vehicleFor(q.vehicleId)?.customer,
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													w.vehicleFor(q.vehicleId)?.make,
													" ·",
													" ",
													w.vehicleFor(q.vehicleId)?.plate
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "Date"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													q.quotationDate ? new Date(q.quotationDate).toLocaleDateString() : "—"
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "Prepared By"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													q.preparedByName ?? "—"
												] })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-4 overflow-x-auto rounded-md border",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotationItemsTable, {
												items: q.items ?? [],
												rowKeyPrefix: q.id
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "ml-auto mt-4 grid w-full max-w-xs grid-cols-2 gap-y-2 text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-right",
													children: money(q.subtotal ?? q.amount)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VAT" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-right",
													children: money(q.taxAmount ?? 0)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Total" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-right",
													children: money(q.amount)
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-5 text-center text-sm",
											children: "Thank you for your business."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: q.status })
										}),
										q.approvalReference && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 text-muted-foreground",
											children: q.approvalReference
										})
									] })
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
							})
						]
					}) })
				] }, q.id)),
				kind === "inventory" && sortRecords([...paperInventory, ...w.inventory].filter(matches), sort, (i, key) => {
					const vehicle = w.vehicleFor(i.vehicleId);
					switch (key) {
						case "id": return i.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "items": return i.items;
						case "date": return i.date;
						default: return "";
					}
				}).map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: i.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(i.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "max-w-[280px] whitespace-normal leading-relaxed",
						children: i.items
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: i.date }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: "Inventory details",
						"aria-label": `View ${i.id}`,
						onClick: () => setRecordDetail({
							title: i.id,
							body: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "paperFields" in i && i.paperFields ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperInventoryView, { fields: i.paperFields }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(i.vehicleId) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold mt-5 mb-2",
									children: "Vehicle belongings & accessories"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: i.items }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold mt-5 mb-2",
									children: "Condition record"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: i.condition })
							] }) })
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
					}) })
				] }, i.id)),
				kind === "jobs" && sortRecords(w.jobs.filter(matches), sort, (j, key) => {
					const vehicle = w.vehicleFor(j.vehicleId);
					switch (key) {
						case "id": return j.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "work": return j.work;
						case "status": return j.status;
						default: return "";
					}
				}).map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: j.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(j.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: j.work }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: j.status }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: "Job card details",
						"aria-label": `View ${j.id}`,
						onClick: () => setRecordDetail({
							title: `Job Card ${j.id}`,
							body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(j.vehicleId) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3 text-xs bg-muted/30 p-3 rounded-lg border border-border/50",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground block text-[11px] font-semibold uppercase tracking-wider",
												children: "Department"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: j.department || "Workshop"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground block text-[11px] font-semibold uppercase tracking-wider",
												children: "Target Due Date"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: j.due || "To be confirmed"
											})] }),
											j.preparedBy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground block text-[11px] font-semibold uppercase tracking-wider",
												children: "Prepared By"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: j.preparedBy
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground block text-[11px] font-semibold uppercase tracking-wider",
												children: "Status"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-1",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: j.status })
											})] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1",
										children: "Work Instructions"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-foreground bg-background p-3 rounded border border-border/40 whitespace-pre-wrap",
										children: j.work
									})] }),
									j.remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1",
										children: "Foreman Remarks"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-foreground bg-muted/20 p-3 rounded border border-border/40 italic",
										children: j.remarks
									})] }),
									j.photos && j.photos.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2",
										children: [
											"Damaged Vehicle Photographs (",
											j.photos.length,
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "uploaded-photos",
										children: j.photos.map((url, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: url,
											target: "_blank",
											rel: "noopener noreferrer",
											className: "block overflow-hidden rounded border border-border hover:border-primary transition-colors",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: url,
												alt: `Damaged vehicle condition ${i + 1}`,
												className: "w-20 h-16 object-cover"
											})
										}, i))
									})] })
								]
							})
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
					}) })
				] }, j.id)),
				kind === "requisitions" && sortRecords(w.requisitions.filter(matches), sort, (r, key) => {
					const vehicle = w.vehicleFor(r.vehicleId);
					switch (key) {
						case "id": return r.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "part": return r.part;
						case "quantity": return r.quantity;
						case "status": return r.status;
						default: return "";
					}
				}).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: r.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(r.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.part }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "text-right tabular-nums",
						children: r.quantity
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: r.status }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setRequest(r),
						children: ["View request", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 12 })]
					}) })
				] }, r.id)),
				kind === "inspections" && sortRecords(w.inspections.filter(matches), sort, (i, key) => {
					const vehicle = w.vehicleFor(i.vehicleId);
					switch (key) {
						case "id": return i.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "foreman": return i.foreman;
						case "date": return i.date;
						case "result": return i.result;
						default: return "";
					}
				}).map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: i.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(i.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: i.foreman }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: i.date }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: i.result }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: "Inspection details",
						"aria-label": `View ${i.id}`,
						onClick: () => setSelectedInspection(i),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
					}) })
				] }, i.id))
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableFooter, { count }),
		kind === "inventory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "attention-band mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Customer authorization comes first" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Inventory cards are generated by the backend during vehicle intake." })] })]
		}),
		kind === "requisitions" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "attention-band mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Director authorization required" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Submitted requisitions await the Director's approval before procurement." })] })]
		}),
		kind === "inventory" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewVehicleInventory, {
			open: create,
			onClose: () => setCreate(false),
			onSave: (fields) => {
				const id = `INV-${Date.now()}`;
				const vehicle = w.vehicles.find((item) => item.plate.toLowerCase() === fields.registrationNo.trim().toLowerCase());
				const items = fields.accessories.filter((item) => item.present === "Present").map((item) => `${item.name}${item.quantity ? ` (${item.quantity})` : ""}`).join(", ");
				const record = {
					id,
					vehicleId: vehicle?.id ?? "",
					items,
					condition: fields.damages.map((damage) => `${damage.type} ${damage.area}`).join("; "),
					date: fields.date
				};
				setPaperInventory((previous) => [{
					...record,
					paperFields: fields
				}, ...previous]);
				toast.success("Inventory captured for this session. The backend has no create endpoint yet.");
				setCreate(false);
			}
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateRecord, {
			kind,
			open: create,
			onClose: () => setCreate(false)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleDetail, {
			id: detail,
			onClose: () => setDetail(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestDetail, {
			request,
			onClose: () => setRequest(null),
			allowDecision: false
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InspectionDetail, {
			inspection: selectedInspection,
			onClose: () => setSelectedInspection(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!recordDetail,
			onOpenChange: (o) => {
				if (!o) setRecordDetail(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: recordDetail?.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Workshop record details" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm leading-relaxed",
				children: recordDetail?.body
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!paperQuote,
			onOpenChange: (isOpen) => {
				if (!isOpen) setPaperQuote(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "modal-scroll max-w-6xl sm:max-w-6xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Quotation preview" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Paper quotation layout" })] }), paperQuote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperQuotationPreview, {
					quotation: paperQuote,
					onPrint: () => window.print()
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!quote,
			onOpenChange: (o) => {
				if (!o) setQuote(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Record customer authorization" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				quote?.id,
				" · ",
				quote && w.vehicleFor(quote.vehicleId)?.customer
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => {
					e.preventDefault();
					if (!quote) return;
					if (!approvalView) {
						w.viewCustomerApproval(approvalToken).then(setApprovalView).catch((error) => toast.error(error.message));
						return;
					}
					const items = Array.isArray(approvalView["items"]) ? approvalView["items"] : [];
					if (items.some((item) => !approvalDecisions[Number(item["quotationItemId"] ?? item["itemId"])])) {
						toast.error("Choose a decision for every quotation item.");
						return;
					}
					w.submitCustomerApproval(approvalToken, items.map((item) => ({
						quotationItemId: Number(item["quotationItemId"] ?? item["itemId"]),
						decision: approvalDecisions[Number(item["quotationItemId"] ?? item["itemId"])]
					}))).then(async () => {
						await w.refresh();
						setQuote(null);
						setApprovalView(null);
						setApprovalToken("");
						toast.success("Customer decisions submitted to the backend.");
					}).catch((error) => toast.error(error.message));
				},
				children: [!approvalView ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-row-compact pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						htmlFor: "auth-token-input",
						className: "registration-label",
						children: ["Authorization Token ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "registration-required",
							children: "*"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "auth-token-input",
						required: true,
						value: approvalToken,
						onChange: (e) => setApprovalToken(e.target.value),
						placeholder: "Enter the token received by the customer",
						className: "registration-input"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3 pt-2",
					children: (Array.isArray(approvalView["items"]) ? approvalView["items"] : []).map((item) => {
						const id = Number(item["quotationItemId"] ?? item["itemId"]);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-row-compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-label",
								children: String(item["description"] ?? item["itemName"] ?? `Item ${id}`)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: approvalDecisions[id] ?? "",
								onValueChange: (value) => setApprovalDecisions((prev) => ({
									...prev,
									[id]: value
								})),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "registration-select-trigger",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose decision" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "APPROVED",
									children: "Approve"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "REJECTED",
									children: "Reject"
								})] })]
							})]
						}, id);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-actions-modal",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						className: "registration-submit-btn",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check$1, {}), approvalView ? "Submit" : "Verify token"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						className: "registration-reset-btn",
						onClick: () => setQuote(null),
						children: "Cancel"
					})]
				})]
			})] })
		})
	] });
}
var inventoryAccessories = [
	"Sparewheel",
	"Jack",
	"Jack handle",
	"Triangles",
	"Wheel spanner",
	"Fire extinguisher",
	"Tool kit",
	"Wheel covers",
	"Car mats"
];
var newPaperInventoryFields = () => ({
	jobNo: "",
	registrationNo: "",
	make: "",
	date: (() => {
		const today = /* @__PURE__ */ new Date();
		return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
	})(),
	ownedBy: "",
	driver: "",
	accessories: inventoryAccessories.map((name) => ({
		name,
		present: "",
		...name === "Wheel covers" || name === "Car mats" ? { quantity: "" } : {}
	})),
	fuelIn: "",
	fuelOut: "",
	kmsIn: "",
	kmsOut: "",
	damages: Array.from({ length: 14 }, () => ({
		area: "",
		type: ""
	})),
	jobToBeDone: Array.from({ length: 14 }, () => ""),
	additional: Array.from({ length: 5 }, () => ({
		name: "",
		present: ""
	})),
	remarks: ["", ""],
	deliveredBy: "",
	deliveredSignature: "",
	deliveredTel: "",
	receivedCheckedBy: "",
	collectedBy: "",
	collectedSignature: "",
	collectedDate: "",
	collectedPhone: "",
	releasedBy: "",
	timeOut: ""
});
function NewVehicleInventory({ open, onClose, onSave }) {
	const [fields, setFields] = (0, import_react.useState)(newPaperInventoryFields);
	const [accessorySort, setAccessorySort] = (0, import_react.useState)(null);
	const setField = (key, value) => setFields((current) => ({
		...current,
		[key]: value
	}));
	const sortedAccessories = sortRecords(fields.accessories, accessorySort, (item, key) => {
		switch (key) {
			case "name": return item.name;
			case "present": return item.present;
			case "quantity": return item.quantity ? Number(item.quantity) || item.quantity : "";
		}
	});
	const input = "h-9";
	const statusOptions = ["Present", "Missing"];
	const renderStatus = (value, onChange, label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "group",
		"aria-label": label,
		className: "flex items-center gap-3 whitespace-nowrap text-sm",
		children: statusOptions.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "radio",
					name: label,
					checked: value === status,
					onChange: () => onChange(status)
				}),
				status === "Present" ? "✓" : "✗",
				" ",
				status
			]
		}, status))
	});
	const renderText = (label, value, onChange) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "registration-row-compact min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "registration-label",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			className: "registration-input",
			value,
			onChange: (event) => onChange(event.target.value)
		})]
	});
	const renderFuel = (label, value, onChange) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
			className: "text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-x-5 gap-y-2",
			children: [
				"E",
				"1/4",
				"1/2",
				"3/4",
				"F"
			].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "radio",
					name: label,
					checked: value === option,
					onChange: () => onChange(option)
				}), option]
			}, option))
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (isOpen) => !isOpen && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "modal-scroll max-w-6xl sm:max-w-6xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New vehicle inventory" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "VEHICLE INVENTORY" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-5",
				onSubmit: (event) => {
					event.preventDefault();
					onSave(fields);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "space-y-1 border-b pb-4 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-semibold",
								children: "Hirider 4x4 World"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kafue Road" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cell +260 966 766 693" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Email mkessa@hotmail.com" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "pt-2 text-lg font-semibold tracking-wide",
								children: "VEHICLE INVENTORY"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "registration-section-box",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "registration-section-title",
							children: "Vehicle & Customer Details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 p-5 md:grid-cols-2",
							children: [
								renderText("JOB No.", fields.jobNo, (value) => setField("jobNo", value)),
								renderText("Registration No.", fields.registrationNo, (value) => setField("registrationNo", value)),
								renderText("Make", fields.make, (value) => setField("make", value)),
								renderText("Date", fields.date, (value) => setField("date", value)),
								renderText("Owned by", fields.ownedBy, (value) => setField("ownedBy", value)),
								renderText("Driver", fields.driver, (value) => setField("driver", value))
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "ACCESSORIES"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-md border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									sortDirection: accessorySort?.key === "name" ? accessorySort.direction : null,
									onSort: () => setAccessorySort((current) => nextSortState(current, "name")),
									children: "Item"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									sortDirection: accessorySort?.key === "present" ? accessorySort.direction : null,
									onSort: () => setAccessorySort((current) => nextSortState(current, "present")),
									children: "Present (✓) / Missing (✗)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									align: "right",
									sortDirection: accessorySort?.key === "quantity" ? accessorySort.direction : null,
									onSort: () => setAccessorySort((current) => nextSortState(current, "quantity")),
									children: "Quantity"
								})
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: sortedAccessories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: item.name }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: renderStatus(item.present, (present) => setField("accessories", fields.accessories.map((row) => row.name === item.name ? {
									...row,
									present
								} : row)), `${item.name} status`) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right tabular-nums",
									children: item.quantity !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: `${input} text-right tabular-nums`,
										"aria-label": `${item.name} quantity`,
										value: item.quantity,
										onChange: (event) => setField("accessories", fields.accessories.map((row) => row.name === item.name ? {
											...row,
											quantity: event.target.value
										} : row))
									})
								})
							] }, item.name)) })] })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-5 rounded-md border p-4 sm:grid-cols-2",
						children: [
							renderFuel("FUEL IN", fields.fuelIn, (value) => setField("fuelIn", value)),
							renderFuel("FUEL OUT", fields.fuelOut, (value) => setField("fuelOut", value)),
							renderText("KMS/Miles IN", fields.kmsIn, (value) => setField("kmsIn", value)),
							renderText("KMS/Miles OUT", fields.kmsOut, (value) => setField("kmsOut", value))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "DAMAGES"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "C = Chip, D = Dent, S = Scratch"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-2 sm:grid-cols-2",
								children: fields.damages.map((damage, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-[1fr_110px] items-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Area ", index + 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: damage.area,
											onChange: (event) => setField("damages", fields.damages.map((row, i) => i === index ? {
												...row,
												area: event.target.value
											} : row))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "C / D / S" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											className: "h-9 rounded-md border bg-background px-3 text-sm font-normal",
											value: damage.type,
											onChange: (event) => setField("damages", fields.damages.map((row, i) => i === index ? {
												...row,
												type: event.target.value
											} : row)),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "C",
													children: "C"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "D",
													children: "D"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "S",
													children: "S"
												})
											]
										})]
									})]
								}, index))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "JOB TO BE DONE"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-3 md:grid-cols-2",
								children: fields.jobToBeDone.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "registration-label",
										children: ["Line ", index + 1]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "registration-input",
										value: line,
										onChange: (event) => setField("jobToBeDone", fields.jobToBeDone.map((value, i) => i === index ? event.target.value : value))
									})]
								}, index))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								onClick: () => setField("jobToBeDone", [...fields.jobToBeDone, ""]),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add line"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "ADDITIONAL"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: fields.additional.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid items-end gap-3 sm:grid-cols-[1fr_auto]",
								children: [renderText(`Item ${index + 1}`, item.name, (name) => setField("additional", fields.additional.map((row, i) => i === index ? {
									...row,
									name
								} : row))), renderStatus(item.present, (present) => setField("additional", fields.additional.map((row, i) => i === index ? {
									...row,
									present
								} : row)), `Additional item ${index + 1} status`)]
							}, index))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Remarks"
						}), fields.remarks.map((remark, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Line ", index + 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: remark,
								onChange: (event) => setField("remarks", fields.remarks.map((value, i) => i === index ? event.target.value : value))
							})]
						}, index))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3 rounded-md border p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Customer's Conditions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Service Management"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "registration-section-box",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "registration-section-title",
							children: "Handover & Collection"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-4 p-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 md:grid-cols-2",
								children: [
									renderText("Delivered By", fields.deliveredBy, (value) => setField("deliveredBy", value)),
									renderText("Delivered Signature", fields.deliveredSignature, (value) => setField("deliveredSignature", value)),
									renderText("Delivered Tel", fields.deliveredTel, (value) => setField("deliveredTel", value)),
									renderText("Received & Checked By", fields.receivedCheckedBy, (value) => setField("receivedCheckedBy", value)),
									renderText("Collected By", fields.collectedBy, (value) => setField("collectedBy", value)),
									renderText("Collected Signature", fields.collectedSignature, (value) => setField("collectedSignature", value)),
									renderText("Collection Date", fields.collectedDate, (value) => setField("collectedDate", value)),
									renderText("Phone No", fields.collectedPhone, (value) => setField("collectedPhone", value)),
									renderText("Released By", fields.releasedBy, (value) => setField("releasedBy", value)),
									renderText("Time Out (Hrs)", fields.timeOut, (value) => setField("timeOut", value))
								]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-actions-flush",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								className: "registration-submit-btn",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), " Submit"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								className: "registration-reset-btn",
								onClick: () => setFields(newPaperInventoryFields()),
								children: "Reset"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								className: "registration-reset-btn",
								onClick: onClose,
								children: "Cancel"
							})
						]
					})
				]
			})]
		})
	});
}
function PaperInventoryView({ fields }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Hirider 4x4 World" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kafue Road" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cell +260 966 766 693" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Email mkessa@hotmail.com" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "VEHICLE INVENTORY" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-3",
				children: [
					["JOB No.", fields.jobNo],
					["Registration No.", fields.registrationNo],
					["Make", fields.make],
					["Date", fields.date],
					["Owned by", fields.ownedBy],
					["Driver", fields.driver]
				].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: label }),
					": ",
					value
				] }, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "ACCESSORIES"
			}),
			fields.accessories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				item.name,
				":",
				" ",
				item.present === "Present" ? "✓ Present" : item.present === "Missing" ? "✗ Missing" : "",
				item.quantity ? ` · Quantity ${item.quantity}` : ""
			] }, item.name)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["FUEL IN: ", fields.fuelIn] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["FUEL OUT: ", fields.fuelOut] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["KMS/Miles IN: ", fields.kmsIn] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["KMS/Miles OUT: ", fields.kmsOut] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "DAMAGES (C = Chip, D = Dent, S = Scratch)"
			}),
			fields.damages.filter((row) => row.area || row.type).map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				row.area,
				" ",
				row.type
			] }, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "JOB TO BE DONE"
			}),
			fields.jobToBeDone.filter(Boolean).map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: line }, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "ADDITIONAL"
			}),
			fields.additional.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				item.name,
				" ",
				item.present === "Present" ? "✓" : item.present === "Missing" ? "✗" : ""
			] }, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Remarks"
			}),
			fields.remarks.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: line }, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Customer's Conditions"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Service Management"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"DELIVERED BY: ",
				fields.deliveredBy,
				" · Signature: ",
				fields.deliveredSignature,
				" · Tel:",
				" ",
				fields.deliveredTel
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["RECEIVED & CHECKED BY: ", fields.receivedCheckedBy] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"COLLECTED BY: ",
				fields.collectedBy,
				" · Signature: ",
				fields.collectedSignature,
				" · Date:",
				" ",
				fields.collectedDate,
				" · Phone No: ",
				fields.collectedPhone
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Released by: ",
				fields.releasedBy,
				" · Time Out (Hrs): ",
				fields.timeOut
			] })
		]
	});
}
function CreateRecord({ kind, open, onClose }) {
	const w = useWorkspace();
	const [vehicleId, setVehicleId] = (0, import_react.useState)("");
	const [catalogPartId, setCatalogPartId] = (0, import_react.useState)("");
	const [quotationLines, setQuotationLines] = (0, import_react.useState)(initialQuotationLines);
	const [lineSort, setLineSort] = (0, import_react.useState)(null);
	const [paperFields, setPaperFields] = (0, import_react.useState)(initialPaperFields);
	const editedPaperFields = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const [jobDepartment, setJobDepartment] = (0, import_react.useState)("Mechanical");
	const [jobDueDate, setJobDueDate] = (0, import_react.useState)("");
	const [jobRemarks, setJobRemarks] = (0, import_react.useState)("");
	const [jobPreparedByEmployeeId, setJobPreparedByEmployeeId] = (0, import_react.useState)("");
	const [jobPhotos, setJobPhotos] = (0, import_react.useState)([]);
	const [isDraggingPhoto, setIsDraggingPhoto] = (0, import_react.useState)(false);
	const photoInputRef = (0, import_react.useRef)(null);
	const c = config[kind];
	(0, import_react.useEffect)(() => {
		if (!open || kind !== "quotations") return;
		let active = true;
		Promise.resolve().then(() => backendApi.getCompanySettings()).then((settings) => {
			const settingFields = {
				companyName: "companyName",
				address: "address",
				email: "email",
				phone: "phone",
				bankName: "bankName",
				accountNumber: "bankAccountNumber",
				vatNumber: "vatNumber"
			};
			if (active) setPaperFields((current) => {
				const next = { ...current };
				for (const [field, source] of Object.entries(settingFields)) {
					const value = settings[source];
					if (!editedPaperFields.current.has(field) && typeof value === "string" && value) next[field] = value;
				}
				return next;
			});
		}).catch(() => void 0);
		return () => {
			active = false;
		};
	}, [kind, open]);
	(0, import_react.useEffect)(() => {
		if (open && kind === "quotations") {
			setQuotationLines(initialQuotationLines());
			setLineSort(null);
			setPaperFields(initialPaperFields());
			editedPaperFields.current = /* @__PURE__ */ new Set();
			setVehicleId("");
		}
	}, [kind, open]);
	(0, import_react.useEffect)(() => {
		if (open && kind === "jobs") {
			setJobDepartment("Mechanical");
			setJobDueDate("");
			setJobRemarks("");
			setJobPhotos([]);
			setIsDraggingPhoto(false);
			setVehicleId("");
			const employees = Array.isArray(w.workflowOptions["employees"]) ? w.workflowOptions["employees"] : [];
			const configuredEmployee = Number({
				"BASE_URL": "/",
				"DEV": false,
				"MODE": "production",
				"PROD": true,
				"SSR": false,
				"TSS_DEV_SERVER": "false",
				"TSS_DEV_SSR_STYLES_BASEPATH": "/",
				"TSS_DEV_SSR_STYLES_ENABLED": "true",
				"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
				"TSS_INLINE_CSS_ENABLED": "false",
				"TSS_ROUTER_BASEPATH": "",
				"TSS_SERVER_FN_BASE": "/_serverFn/"
			}["VITE_EMPLOYEE_ID"]);
			if (configuredEmployee > 0 && employees.some((e) => Number(e["id"]) === configuredEmployee)) setJobPreparedByEmployeeId(String(configuredEmployee));
			else if (employees.length > 0) setJobPreparedByEmployeeId(String(employees[0]["id"] ?? ""));
			else setJobPreparedByEmployeeId("foreman");
		}
	}, [
		open,
		kind,
		w.workflowOptions
	]);
	const handlePhotoFiles = (files) => {
		const fileArray = Array.from(files);
		if (fileArray.length === 0) return;
		fileArray.forEach((file) => {
			if (!file.type.startsWith("image/")) {
				toast.error(`${file.name} is not an image file.`);
				return;
			}
			if (file.size > 10485760) {
				toast.error(`${file.name} exceeds 10MB limit.`);
				return;
			}
			const reader = new FileReader();
			reader.onload = (event) => {
				const url = event.target?.result;
				if (url) setJobPhotos((prev) => [...prev, {
					id: `photo-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
					name: file.name,
					url,
					size: file.size
				}]);
			};
			reader.readAsDataURL(file);
		});
	};
	const removePhoto = (id) => {
		setJobPhotos((prev) => prev.filter((p) => p.id !== id));
	};
	(0, import_react.useEffect)(() => {
		if (!open || kind !== "quotations") return;
		const employees = Array.isArray(w.workflowOptions["employees"]) ? w.workflowOptions["employees"] : [];
		const configuredEmployee = Number({
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": false,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/"
		}["VITE_EMPLOYEE_ID"]);
		const name = String(employees.find((employee) => Number(employee["id"]) === configuredEmployee)?.["name"] ?? "");
		if (!name) return;
		setPaperFields((current) => ({
			...current,
			...editedPaperFields.current.has("salesperson") ? {} : { salesperson: name },
			...editedPaperFields.current.has("preparedBy") ? {} : { preparedBy: name }
		}));
	}, [
		kind,
		open,
		w.workflowOptions
	]);
	const eligible = w.vehicles.filter((v) => !v.released && (kind === "inventory" ? w.quotations.some((q) => q.vehicleId === v.id && canCreateInventory(q.status)) && !w.inventory.some((i) => i.vehicleId === v.id) : kind === "jobs" ? w.inventory.some((i) => i.vehicleId === v.id) || w.quotations.some((q) => q.vehicleId === v.id && canCreateInventory(q.status)) || v.stage >= 3 : kind === "requisitions" ? w.jobs.some((j) => j.vehicleId === v.id) || v.stage >= 4 : kind === "inspections" ? v.stage >= 5 : true));
	const quoteSubtotal = roundMoney(quotationLines.reduce((sum, line) => sum + (Number(line.quantity) || 0) * (Number(line.unitPrice) || 0), 0));
	const quoteTax = roundMoney(quotationLines.reduce((sum, line) => {
		return sum + roundMoney(roundMoney((Number(line.quantity) || 0) * (Number(line.unitPrice) || 0)) * QUOTATION_VAT_RATE / 100);
	}, 0));
	const quoteTotal = roundMoney(quoteSubtotal + quoteTax);
	const validQuotationLines = quotationLines.filter((line) => line.item.trim() && line.description.trim() && Number.isFinite(Number(line.quantity)) && Number(line.quantity) > 0 && Number.isFinite(Number(line.unitPrice)) && Number(line.unitPrice) > 0);
	const hasPartialLine = quotationLines.some((line) => (line.item.trim() || line.description.trim() || line.unitPrice.trim()) && !validQuotationLines.includes(line));
	const quoteMissingMessage = [
		!vehicleId ? "Select a registered vehicle." : "",
		validQuotationLines.length === 0 ? "Add at least one valid line with an item, description, positive quantity and price." : "",
		hasPartialLine ? "Complete or remove each partially filled line." : ""
	].filter(Boolean).join(" ");
	const updatePaperField = (field, value) => {
		editedPaperFields.current.add(field);
		setPaperFields((current) => ({
			...current,
			[field]: value
		}));
	};
	const fillFromVehicle = (field, value) => {
		if (!editedPaperFields.current.has(field)) setPaperFields((current) => ({
			...current,
			[field]: value
		}));
	};
	function submit(e) {
		e.preventDefault();
		if (!eligible.find((v) => v.id === vehicleId)) {
			toast.error("Select an eligible vehicle.");
			return;
		}
		const f = new FormData(e.currentTarget);
		const text = (name) => String(f.get(name) ?? "");
		if (kind === "requisitions" && !catalogPartId) {
			toast.error("Select a catalog part.");
			return;
		}
		let id = "";
		if (kind === "quotations") {
			if (hasPartialLine) {
				toast.error("Complete or remove each partially filled line.");
				return;
			}
			const normalizedLines = validQuotationLines.map((line) => ({
				...line,
				quantity: Number(line.quantity),
				unitPrice: Number(line.unitPrice)
			}));
			if (!normalizedLines.length) {
				toast.error("Add at least one quotation line item.");
				return;
			}
			if (!Number.isSafeInteger(Number({
				"BASE_URL": "/",
				"DEV": false,
				"MODE": "production",
				"PROD": true,
				"SSR": false,
				"TSS_DEV_SERVER": "false",
				"TSS_DEV_SSR_STYLES_BASEPATH": "/",
				"TSS_DEV_SSR_STYLES_ENABLED": "true",
				"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
				"TSS_INLINE_CSS_ENABLED": "false",
				"TSS_ROUTER_BASEPATH": "",
				"TSS_SERVER_FN_BASE": "/_serverFn/"
			}["VITE_EMPLOYEE_ID"])) || Number({
				"BASE_URL": "/",
				"DEV": false,
				"MODE": "production",
				"PROD": true,
				"SSR": false,
				"TSS_DEV_SERVER": "false",
				"TSS_DEV_SSR_STYLES_BASEPATH": "/",
				"TSS_DEV_SSR_STYLES_ENABLED": "true",
				"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
				"TSS_INLINE_CSS_ENABLED": "false",
				"TSS_ROUTER_BASEPATH": "",
				"TSS_SERVER_FN_BASE": "/_serverFn/"
			}["VITE_EMPLOYEE_ID"]) <= 0) {
				toast.error("Set VITE_EMPLOYEE_ID to an active workshop employee before creating a quotation.");
				return;
			}
			id = `NEW-${Date.now()}`;
			const items = normalizedLines.map((line) => ({
				itemType: line.item.trim().toLowerCase() === "labour" ? "LABOUR" : "PART",
				item: line.item.trim(),
				description: line.description.trim(),
				quantity: line.quantity,
				unitPrice: line.unitPrice,
				lineTotal: roundMoney(line.quantity * line.unitPrice),
				taxAmount: roundMoney(roundMoney(line.quantity * line.unitPrice) * QUOTATION_VAT_RATE / 100)
			}));
			w.setQuotations((prev) => [{
				id,
				vehicleId,
				amount: quoteTotal,
				subtotal: quoteSubtotal,
				taxAmount: quoteTax,
				description: items.map((item) => item.description).join("; "),
				preparedByName: paperFields["preparedBy"],
				paperFields,
				items,
				status: "Draft"
			}, ...prev]);
			w.updateVehicleStage(vehicleId, 1);
		}
		if (kind === "inventory") {
			id = `IC-${452 + w.inventory.length - 3}`;
			w.setInventory((prev) => [{
				id,
				vehicleId,
				items: text("items"),
				condition: text("condition"),
				date: "11 Nov 2026"
			}, ...prev]);
			w.updateVehicleStage(vehicleId, 4);
		}
		if (kind === "jobs") {
			id = `JC-${882 + w.jobs.length - 5}`;
			const selectedEmp = (Array.isArray(w.workflowOptions["employees"]) ? w.workflowOptions["employees"] : []).find((emp) => String(emp["id"]) === jobPreparedByEmployeeId);
			const preparedByName = selectedEmp ? String(selectedEmp["name"] ?? "") : jobPreparedByEmployeeId === "foreman" ? w.foreman : void 0;
			const preparedByEmpId = selectedEmp && Number(selectedEmp["id"]) > 0 ? Number(selectedEmp["id"]) : Number({
				"BASE_URL": "/",
				"DEV": false,
				"MODE": "production",
				"PROD": true,
				"SSR": false,
				"TSS_DEV_SERVER": "false",
				"TSS_DEV_SSR_STYLES_BASEPATH": "/",
				"TSS_DEV_SSR_STYLES_ENABLED": "true",
				"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
				"TSS_INLINE_CSS_ENABLED": "false",
				"TSS_ROUTER_BASEPATH": "",
				"TSS_SERVER_FN_BASE": "/_serverFn/"
			}["VITE_EMPLOYEE_ID"]) || void 0;
			const newJobPhotos = jobPhotos.map((p) => p.url);
			const finalDepartment = jobDepartment || text("department") || "Mechanical";
			w.setJobs((prev) => [{
				id,
				vehicleId,
				department: finalDepartment,
				work: text("description"),
				status: "Pending",
				due: text("due") || jobDueDate || "To be confirmed",
				remarks: (text("remarks") || jobRemarks).trim() || void 0,
				preparedBy: preparedByName,
				preparedByEmployeeId: preparedByEmpId,
				photos: newJobPhotos.length > 0 ? newJobPhotos : void 0
			}, ...prev]);
			w.setVehicles((prev) => prev.map((item) => item.id === vehicleId ? {
				...item,
				stage: Math.max(item.stage, 5),
				department: finalDepartment,
				...newJobPhotos.length > 0 ? { photos: [...item.photos ?? [], ...newJobPhotos] } : {}
			} : item));
		}
		if (kind === "requisitions") {
			id = `PR-${452 + w.requisitions.length - 6}`;
			w.setRequisitions((prev) => [{
				id,
				vehicleId,
				part: w.parts.find((part) => part.id === Number(catalogPartId))?.name ?? "",
				quantity: 1,
				department: "Workshop",
				reason: text("description"),
				amount: 0,
				foreman: w.foreman,
				status: "Pending",
				date: "11 Nov 2026"
			}, ...prev]);
			w.updateVehicleStage(vehicleId, 6);
		}
		if (kind === "inspections") {
			id = `IN-${213 + w.inspections.length - 2}`;
			w.setInspections((prev) => [{
				id,
				vehicleId,
				foreman: w.foreman,
				date: "11 Nov 2026",
				result: "Rework required",
				notes: text("description")
			}, ...prev]);
			w.setVehicles((prev) => prev.map((item) => item.id === vehicleId ? {
				...item,
				stage: 9,
				progress: 90
			} : item));
		}
		w.addActivity(`${c.singular.charAt(0).toUpperCase() + c.singular.slice(1)} ${kind === "requisitions" ? "submitted" : "created"}`, `${w.foreman} · ${id}`);
		toast.success(kind === "requisitions" ? `${id} submitted for Director authorization.` : `${id} saved.`);
		setVehicleId("");
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (o) => {
			if (!o) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: kind === "quotations" ? "modal-scroll max-w-6xl sm:max-w-6xl" : kind === "jobs" ? "modal-scroll max-w-2xl sm:max-w-2xl" : "modal-scroll",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["New ", c.singular] }), kind !== "quotations" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [w.foreman, " · 11 November 2026"] })] }), kind === "quotations" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-section-box",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "registration-section-title",
							children: "Company Header"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4 p-5 md:grid-cols-2",
							children: [
								["companyName", "Company Name"],
								["address", "Address"],
								["email", "Email"],
								["phone", "Phone"],
								["bankName", "Bank Details"],
								["accountNumber", "Account Number"],
								["vatNumber", "VAT"]
							].map(([field, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: `quote-${field}`,
									className: "registration-label",
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: `quote-${field}`,
										className: "registration-input",
										value: paperFields[field] ?? "",
										onChange: (event) => updatePaperField(field, event.target.value)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
										className: "block text-xs font-medium text-muted-foreground",
										children: "Kept in quotation print metadata."
									})]
								})]
							}, field))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-section-box",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "registration-section-title",
							children: "Quote Details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4 p-5 md:grid-cols-2",
							children: [
								["date", "Date"],
								["quoteNo", "Quote No."],
								["salesperson", "Salesperson"]
							].map(([field, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: `quote-${field}`,
									className: "registration-label",
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: `quote-${field}`,
											className: "registration-input",
											value: paperFields[field] ?? "",
											onChange: (event) => updatePaperField(field, event.target.value)
										}),
										field === "quoteNo" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
											className: "block text-xs font-medium text-muted-foreground",
											children: "Backend generates the saved quotation number; value kept for print."
										}),
										field === "date" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
											className: "block text-xs font-medium text-muted-foreground",
											children: "Retained in quotation print metadata."
										}),
										field === "salesperson" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
											className: "block text-xs font-medium text-muted-foreground",
											children: "Printed name retained in quotation metadata."
										})
									]
								})]
							}, field))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "registration-section-box",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "registration-section-title",
								children: "Bill To"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-4 p-5",
								children: ["billTo1", "billTo2"].map((field, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact registration-row-top",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: `quote-${field}`,
										className: "registration-label",
										children: ["Line ", index + 1]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: `quote-${field}`,
											className: "registration-input",
											value: paperFields[field] ?? "",
											onChange: (event) => updatePaperField(field, event.target.value)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
											className: "block text-xs font-medium text-muted-foreground",
											children: index === 0 ? "Backend uses the linked customer; retained for print." : "Retained for printing."
										})]
									})]
								}, field))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "registration-section-box",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "registration-section-title",
								children: "Ship To"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "registration-row-compact",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "registration-label",
											children: ["Registered Vehicle ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "registration-required",
												children: "*"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: vehicleId,
											onValueChange: (nextId) => {
												setVehicleId(nextId);
												const selected = eligible.find((vehicle) => vehicle.id === nextId);
												if (!selected) return;
												fillFromVehicle("billTo1", selected.customer);
												fillFromVehicle("shipTo1", selected.customer);
												fillFromVehicle("shipTo2", selected.make);
												fillFromVehicle("shipTo3", selected.plate);
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												"aria-label": "Registered vehicle",
												className: "registration-select-trigger",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a registered vehicle" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: eligible.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
												value: vehicle.id,
												children: [
													vehicle.make,
													" · ",
													vehicle.plate,
													" · ",
													vehicle.customer
												]
											}, vehicle.id)) })]
										})]
									}),
									w.vehicles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 text-xs text-muted-foreground",
										children: ["No vehicles loaded. Register a vehicle first.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											size: "sm",
											variant: "outline",
											className: "registration-reset-btn",
											onClick: () => void w.refresh(),
											children: "Retry"
										})]
									}) : eligible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "No eligible registered vehicles are available."
									}) : null,
									[
										["shipTo1", "Customer"],
										["shipTo2", "Make & Model"],
										["shipTo3", "Registration No."]
									].map(([field, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "registration-row-compact",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											htmlFor: `quote-${field}`,
											className: "registration-label",
											children: label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: `quote-${field}`,
											className: "registration-input",
											value: paperFields[field] ?? "",
											onChange: (event) => updatePaperField(field, event.target.value)
										})]
									}, field))
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "Line items"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "overflow-x-auto rounded-md border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
									className: "min-w-[1040px] table-fixed",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("colgroup", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[88px]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[244px]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[334px]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[175px]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[175px]" })
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												align: "right",
												sortDirection: lineSort?.key === "quantity" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "quantity")),
												children: "Qty"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												sortDirection: lineSort?.key === "item" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "item")),
												children: "Item"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												sortDirection: lineSort?.key === "description" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "description")),
												children: "Description"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												align: "right",
												sortDirection: lineSort?.key === "unitPrice" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "unitPrice")),
												children: "Unit Price"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												align: "right",
												sortDirection: lineSort?.key === "total" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "total")),
												children: "Total"
											})
										] }) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: sortRecords(quotationLines, lineSort, (entry, key) => {
											switch (key) {
												case "quantity": return Number(entry.quantity) || 0;
												case "item": return entry.item;
												case "description": return entry.description;
												case "unitPrice": return Number(entry.unitPrice) || 0;
												case "total": return (Number(entry.quantity) || 0) * (Number(entry.unitPrice) || 0);
											}
										}).map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
												className: "text-right tabular-nums",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													"aria-label": `Line ${index + 1} quantity`,
													className: "text-right tabular-nums",
													type: "number",
													step: "0.01",
													value: line.quantity,
													onChange: (event) => setQuotationLines((lines) => lines.map((current) => current.rowId === line.rowId ? {
														...current,
														quantity: event.target.value
													} : current))
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													"aria-label": `Line ${index + 1} item`,
													maxLength: 80,
													value: line.item,
													onChange: (event) => setQuotationLines((lines) => lines.map((current) => current.rowId === line.rowId ? {
														...current,
														item: event.target.value
													} : current))
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													type: "button",
													variant: "ghost",
													size: "icon",
													"aria-label": `Remove line ${index + 1}`,
													onClick: () => setQuotationLines((lines) => lines.filter((current) => current.rowId !== line.rowId)),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
												})]
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												"aria-label": `Line ${index + 1} description`,
												maxLength: 255,
												value: line.description,
												onChange: (event) => setQuotationLines((lines) => lines.map((current) => current.rowId === line.rowId ? {
													...current,
													description: event.target.value
												} : current))
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
												className: "text-right tabular-nums",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "K" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														className: "min-w-0 flex-1 text-right tabular-nums",
														"aria-label": `Line ${index + 1} unit price in ZMW`,
														type: "number",
														step: "0.01",
														value: line.unitPrice,
														onChange: (event) => setQuotationLines((lines) => lines.map((current) => current.rowId === line.rowId ? {
															...current,
															unitPrice: event.target.value
														} : current))
													})]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
												className: "text-right tabular-nums",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													"aria-label": `Line ${index + 1} total`,
													className: "text-right tabular-nums",
													readOnly: true,
													value: money((Number(line.quantity) || 0) * (Number(line.unitPrice) || 0))
												})
											})
										] }, line.rowId)) })
									]
								}), quotationLines.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "empty-state-wrap",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
										compact: true,
										icon: FileText,
										title: "No quotation line items",
										description: "Add parts, consumables, or labour entries to calculate the quotation subtotal and VAT.",
										action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => setQuotationLines((lines) => [...lines, emptyQuotationLine()]),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add line"]
										})
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								onClick: () => setQuotationLines((lines) => [...lines, emptyQuotationLine()]),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add line"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto grid max-w-sm grid-cols-2 gap-y-2 rounded-md border p-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Subtotal",
								readOnly: true,
								value: money(quoteSubtotal)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VAT (16%)" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "VAT",
								readOnly: true,
								value: money(quoteTax)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Total" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Total",
								readOnly: true,
								value: money(quoteTotal)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "registration-section-box p-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2",
							children: [[
								"preparedBy",
								"signature",
								"invoiceReference"
							].map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: `quote-${field}`,
									className: "registration-label",
									children: field === "preparedBy" ? "Prepared By" : field === "signature" ? "Signature" : "Invoice Reference"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: `quote-${field}`,
									className: "registration-input",
									value: paperFields[field] ?? "",
									onChange: (event) => updatePaperField(field, event.target.value)
								})]
							}, field)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "self-center text-xs font-medium text-muted-foreground",
								children: "Thank you for your business."
							})]
						})
					}),
					quoteMissingMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: quoteMissingMessage
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-actions-flush",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: !vehicleId || validQuotationLines.length === 0,
							className: "registration-submit-btn",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), " Submit"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "registration-reset-btn",
							onClick: onClose,
							children: "Cancel"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				onReset: () => {
					setVehicleId("");
					setCatalogPartId("");
					setJobDepartment("Mechanical");
					setJobDueDate("");
					setJobRemarks("");
					setJobPhotos([]);
					if (photoInputRef.current) photoInputRef.current.value = "";
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-row-compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "registration-label",
								children: ["Vehicle ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "registration-required",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: vehicleId,
								onValueChange: setVehicleId,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									"aria-label": "Vehicle",
									className: "registration-select-trigger",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a vehicle" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: eligible.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: v.id,
									children: [
										v.make,
										" · ",
										v.plate
									]
								}, v.id)) })]
							})]
						}),
						eligible.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-muted-foreground",
							children: kind === "inventory" ? "No vehicles with customer-approved quotations are awaiting an inventory card." : kind === "jobs" ? "No vehicles with inventory cards are awaiting a job card." : kind === "inspections" ? "No vehicles are currently awaiting inspection." : "No eligible vehicle records are available."
						}),
						kind === "inventory" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Inventory cards are created automatically during vehicle intake."
						}) : kind === "jobs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "registration-label",
									children: ["Department ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "registration-required",
										children: "*"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: jobDepartment,
									onValueChange: setJobDepartment,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										id: "job-department-trigger",
										"aria-label": "Department",
										className: "registration-select-trigger",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select department" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: departments.map((dept) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: dept,
										children: dept
									}, dept)) })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "registration-label",
									children: "Prepared By"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: jobPreparedByEmployeeId,
									onValueChange: setJobPreparedByEmployeeId,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										id: "job-prepared-by-trigger",
										"aria-label": "Prepared By",
										className: "registration-select-trigger",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select employee / foreman" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [(Array.isArray(w.workflowOptions["employees"]) ? w.workflowOptions["employees"] : []).map((emp) => {
										const empId = String(emp["id"] ?? "");
										const empName = String(emp["name"] ?? `Employee #${empId}`);
										const empRole = String(emp["designation"] ?? emp["role"] ?? "");
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
											value: empId,
											children: [
												empName,
												" ",
												empRole ? `(${empRole})` : ""
											]
										}, empId);
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: "foreman",
										children: [w.foreman, " (Foreman)"]
									})] })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "job-due-date",
									className: "registration-label",
									children: "Target Due Date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "job-due-date",
									name: "due",
									type: "date",
									value: jobDueDate,
									onChange: (e) => setJobDueDate(e.target.value),
									className: "registration-input",
									"aria-label": "Target Due Date"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									htmlFor: "record-desc",
									className: "registration-label",
									children: ["Work Instructions ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "registration-required",
										children: "*"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "record-desc",
									name: "description",
									required: true,
									rows: 3,
									placeholder: "Enter detailed repair tasks and work instructions...",
									className: "registration-textarea"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "job-remarks",
									className: "registration-label",
									children: "Foreman Remarks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "job-remarks",
									name: "remarks",
									value: jobRemarks,
									onChange: (e) => setJobRemarks(e.target.value),
									rows: 2,
									placeholder: "Special handling instructions, customer damage observations...",
									className: "registration-textarea"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "registration-label",
									children: "Damage Photos"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onDragOver: (e) => {
											e.preventDefault();
											setIsDraggingPhoto(true);
										},
										onDragLeave: () => setIsDraggingPhoto(false),
										onDrop: (e) => {
											e.preventDefault();
											setIsDraggingPhoto(false);
											if (e.dataTransfer.files) handlePhotoFiles(e.dataTransfer.files);
										},
										className: cn("job-photo-dropzone", isDraggingPhoto && "job-photo-dropzone-active"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											ref: photoInputRef,
											id: "job-photo-input",
											type: "file",
											accept: "image/*",
											multiple: true,
											className: "sr-only",
											onChange: (e) => {
												if (e.target.files) handlePhotoFiles(e.target.files);
												e.target.value = "";
											}
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											htmlFor: "job-photo-input",
											className: "flex flex-col items-center justify-center p-4 cursor-pointer text-center w-full",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "w-5 h-5 text-muted-foreground mb-1.5" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-semibold text-foreground",
													children: "Click to select damaged vehicle photos or drag & drop"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-muted-foreground mt-0.5",
													children: "Supports PNG, JPG, WebP · Visual thumbnails displayed below"
												})
											]
										})]
									}), jobPhotos.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs text-muted-foreground px-0.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium text-foreground",
												children: [
													jobPhotos.length,
													" photo",
													jobPhotos.length > 1 ? "s" : "",
													" selected"
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setJobPhotos([]),
												className: "text-xs text-destructive hover:underline font-medium cursor-pointer",
												children: "Clear all"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "job-photo-thumbnails",
											"data-testid": "job-photo-thumbnails",
											children: jobPhotos.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "job-photo-thumb group",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: photo.url,
														alt: photo.name
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														"aria-label": `Remove photo ${photo.name}`,
														title: `Remove ${photo.name}`,
														onClick: () => removePhoto(photo.id),
														className: "job-photo-thumb-remove",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-2.5 h-2.5" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "job-photo-thumb-name",
														title: photo.name,
														children: photo.name
													})
												]
											}, photo.id))
										})]
									})]
								})]
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							kind === "requisitions" && w.parts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "registration-label",
									children: ["Catalog Part ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "registration-required",
										children: "*"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: catalogPartId,
									onValueChange: setCatalogPartId,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "registration-select-trigger",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a catalog part" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: w.parts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: String(part.id),
										children: [
											part.code,
											" · ",
											part.name
										]
									}, part.id)) })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									htmlFor: "record-desc",
									className: "registration-label",
									children: [
										kind === "requisitions" ? "Reason for Parts" : "Inspection Notes",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "registration-required",
											children: "*"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "record-desc",
									name: "description",
									required: true,
									rows: 3,
									className: "registration-textarea"
								})]
							}),
							kind === "requisitions" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-muted-foreground",
								children: "The backend creates requisition lines from linked job card parts and current stock."
							}),
							kind === "inspections" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-muted-foreground",
								children: "Starting an inspection creates the backend checklist. Checklist outcomes are recorded through the backend inspection workflow."
							})
						] })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-actions-modal",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: !vehicleId,
							className: "registration-submit-btn",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), "Submit"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "reset",
							variant: "outline",
							className: "registration-reset-btn",
							children: "Reset"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "registration-reset-btn",
							onClick: onClose,
							children: "Cancel"
						})
					]
				})]
			})]
		})
	});
}
function PaperQuotationPreview({ quotation, onPrint }) {
	const fields = {
		...initialPaperFields(),
		...quotation.paperFields ?? {}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				onClick: onPrint,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), " Print"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "space-y-5 rounded-md border bg-white p-6 text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "border-b pb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: fields.companyName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.address }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							fields.email,
							" · ",
							fields.phone
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							fields.bankName,
							" · ",
							fields.accountNumber
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["VAT: ", fields.vatNumber] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-[1fr_2fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-semibold",
						children: "Quote"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.date })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Quote No."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.quoteNo }),
								fields.quoteNo !== quotation.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
									className: "text-muted-foreground",
									children: ["Backend assigned: ", quotation.id]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Salesperson"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.salesperson })] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-5 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Bill To"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.billTo1 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.billTo2 })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Ship To"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.shipTo1 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.shipTo2 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.shipTo3 })
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotationItemsTable, {
						items: quotation.items ?? [],
						rowKeyPrefix: `${quotation.id}-paper`,
						className: "min-w-[720px]"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto grid max-w-xs grid-cols-2 gap-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right",
							children: money(quotation.subtotal ?? quotation.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VAT (16%)" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right",
							children: money(quotation.taxAmount ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Total" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-right",
							children: money(quotation.amount)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "grid gap-5 border-t pt-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Prepared By"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.preparedBy })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Signature"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.signature })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Invoice reference"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.invoiceReference })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "self-end text-sm",
							children: "Thank you for your business."
						})
					]
				})
			]
		})]
	});
}
function InspectionDetail({ inspection, onClose }) {
	const w = useWorkspace();
	const [statuses, setStatuses] = (0, import_react.useState)({});
	const [comments, setComments] = (0, import_react.useState)({});
	const [departments, setDepartments] = (0, import_react.useState)({});
	const id = inspection?.backendId;
	const stored = id ? w.inspectionDetails.get(id) : void 0;
	const details = stored?.["details"];
	const signoffData = stored?.["signoffs"];
	const checklist = Array.isArray(details?.["checklist"]) ? details["checklist"] : [];
	const signoffs = Array.isArray(signoffData?.["signoffs"]) ? signoffData["signoffs"] : [];
	const options = w.workflowOptions["departments"] ?? [];
	const run = (action, message) => void action().then(async () => {
		await w.refresh();
		toast.success(message);
	}).catch((error) => toast.error(error.message));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!inspection,
		onOpenChange: (open) => {
			if (!open) {
				setStatuses({});
				setComments({});
				setDepartments({});
				onClose();
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "modal-scroll max-w-4xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Final inspection · ", inspection?.id] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				w.vehicleFor(inspection?.vehicleId ?? "")?.plate,
				" ·",
				" ",
				String(details?.["inspectionStatus"] ?? inspection?.result ?? ""),
				" ·",
				" ",
				String(details?.["inspectionDecision"] ?? "Decision pending")
			] })] }), !details ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => void w.refresh(),
				children: "Load checklist"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[45vh] space-y-3 overflow-auto",
					children: checklist.map((item) => {
						const itemId = Number(item["id"]);
						const saved = String(item["checkStatus"] ?? "PENDING");
						const status = statuses[itemId] ?? (saved === "PASS" || saved === "FAIL" ? saved : void 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
									String(item["itemCode"]),
									" · ",
									String(item["itemName"])
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-medium text-muted-foreground",
									children: [
										String(item["inspectionCategory"]),
										" · ",
										saved
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: status ?? "",
									onValueChange: (value) => setStatuses((prev) => ({
										...prev,
										[itemId]: value
									})),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "registration-select-trigger w-36",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Set result" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "PASS",
										children: "Pass"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "FAIL",
										children: "Fail"
									})] })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "registration-input",
										placeholder: "Comments",
										value: comments[itemId] ?? String(item["comments"] ?? ""),
										onChange: (e) => setComments((prev) => ({
											...prev,
											[itemId]: e.target.value
										}))
									}),
									status === "FAIL" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: departments[itemId] ?? String(item["responsibleDepartmentId"] ?? ""),
										onValueChange: (value) => setDepartments((prev) => ({
											...prev,
											[itemId]: value
										})),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "registration-select-trigger w-52",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Responsible department" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: options.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: String(d["id"]),
											children: String(d["name"])
										}, String(d["id"]))) })]
									}),
									status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: () => {
											const dept = departments[itemId] ?? String(item["responsibleDepartmentId"] ?? "");
											if (status === "FAIL" && !dept) {
												toast.error("Select the responsible department for a failed item.");
												return;
											}
											run(() => w.api.updateInspectionItem(id, itemId, status, comments[itemId] ?? String(item["comments"] ?? ""), dept ? Number(dept) : void 0), "Inspection item updated.");
										},
										children: "Save"
									})
								]
							})]
						}, itemId);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "Department sign-offs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: signoffs.map((item) => {
						const departmentId = Number(item["departmentId"]);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 rounded border p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								String(item["departmentName"]),
								" · ",
								String(item["signoffStatus"])
							] }), String(item["signoffStatus"]) === "PENDING" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => run(() => w.api.signoffInspectionDepartment(id, departmentId, "Final inspection department sign-off"), "Department sign-off recorded."),
								children: "Sign off"
							})]
						}, departmentId);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => run(() => w.api.createCorrectiveWorkOrders(id), "Corrective work orders generated."),
						children: "Generate corrective work orders"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => run(() => w.api.completeInspection(id), "Final inspection completed."),
						children: "Complete inspection"
					})]
				})
			] })]
		})
	});
}
function RequestDetail({ request, onClose, allowDecision }) {
	const w = useWorkspace();
	const [rejection, setRejection] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const current = w.requisitions.find((r) => r.id === request?.id);
	function decide(status) {
		if (!current || !canDecideParts(w.role)) return;
		if (status === "Rejected" && !note.trim()) {
			toast.error("Please record the reason for rejection.");
			return;
		}
		toast.error(`The backend does not provide a requisition ${status.toLowerCase()} endpoint. No decision was saved.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!current,
		onOpenChange: (o) => {
			if (!o) {
				setRejection(false);
				setNote("");
				onClose();
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "modal-scroll",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Parts request · ", current?.id] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: ["Submitted ", current?.date] })] }), current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(current.vehicleId) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "detail-grid",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Part / item" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: current.part })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Requested quantity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: current.quantity })] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "detail-notes",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Reason for requesting parts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: current.reason
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: current.status }),
				current.decisionNote && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-medium text-muted-foreground",
					children: ["Director note: ", current.decisionNote]
				}),
				allowDecision && current.status === "Pending" && canDecideParts(w.role) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [rejection && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-row-compact registration-row-top",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						htmlFor: "req-reject-note",
						className: "registration-label",
						children: ["Rejection Reason ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "registration-required",
							children: "*"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "req-reject-note",
						className: "registration-textarea",
						value: note,
						onChange: (e) => setNote(e.target.value),
						placeholder: "Explain why this request is being rejected"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-actions-flush",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => decide("Approved"),
						className: "registration-submit-btn",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check$1, {}), "Approve request"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "registration-reset-btn",
						onClick: () => rejection ? decide("Rejected") : setRejection(true),
						children: rejection ? "Confirm rejection" : "Reject request"
					})]
				})] })
			] })]
		})
	});
}
//#endregion
export { SelectItem as a, SelectContent as i, RequestDetail as n, SelectTrigger as o, Select as r, SelectValue as s, RecordsPage as t };
