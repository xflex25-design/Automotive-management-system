import { i as ProcurementPage } from "./monitor-pages-B-tlhenF.js";
//#region src/routes/procurement.tsx?tsr-split=component
var SplitComponent = ProcurementPage;
//#endregion
export { SplitComponent as component };
