//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-EM_Ap-XQ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/applet/src/routes/__root.tsx",
		children: [
			"/",
			"/alerts",
			"/approvals",
			"/departments",
			"/director",
			"/employee",
			"/inspections",
			"/inventory",
			"/job-cards",
			"/management",
			"/procurement",
			"/profile",
			"/quotations",
			"/registration",
			"/reports",
			"/requisitions",
			"/settings",
			"/vehicles",
			"/workflow",
			"/workshop"
		],
		css: ["/assets/index-BCOHKaIK.css"],
		preloads: ["/assets/index-DDvlJ1GD.js", "/assets/button-ByH67M_G.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DDvlJ1GD.js"
		} }]
	},
	"/": {
		filePath: "/app/applet/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-qWzjjTjF.js", "/assets/dashboard-BjlMLzjf.js"]
	},
	"/alerts": {
		filePath: "/app/applet/src/routes/alerts.tsx",
		children: void 0,
		preloads: ["/assets/alerts-bSz5gUqN.js", "/assets/monitor-pages-B-tlhenF.js"]
	},
	"/approvals": {
		filePath: "/app/applet/src/routes/approvals.tsx",
		children: void 0,
		preloads: ["/assets/approvals-CWj05XuW.js", "/assets/monitor-pages-B-tlhenF.js"]
	},
	"/departments": {
		filePath: "/app/applet/src/routes/departments.tsx",
		children: void 0,
		preloads: ["/assets/departments-FmUdlX8B.js", "/assets/monitor-pages-B-tlhenF.js"]
	},
	"/director": {
		filePath: "/app/applet/src/routes/director.tsx",
		children: void 0,
		preloads: ["/assets/director-DYHvkNLn.js", "/assets/dashboard-BjlMLzjf.js"]
	},
	"/employee": {
		filePath: "/app/applet/src/routes/employee.tsx",
		children: void 0,
		preloads: [
			"/assets/employee-HGJKPXHm.js",
			"/assets/dist-pmrAdYzb.js",
			"/assets/shared-D1FqIhYl.js"
		]
	},
	"/inspections": {
		filePath: "/app/applet/src/routes/inspections.tsx",
		children: void 0,
		preloads: ["/assets/inspections-DHFJ0eCA.js", "/assets/record-pages-Zto0897Q.js"]
	},
	"/inventory": {
		filePath: "/app/applet/src/routes/inventory.tsx",
		children: void 0,
		preloads: ["/assets/inventory-BV7DQ0nk.js", "/assets/record-pages-Zto0897Q.js"]
	},
	"/job-cards": {
		filePath: "/app/applet/src/routes/job-cards.tsx",
		children: void 0,
		preloads: ["/assets/job-cards-CFmMVLvJ.js", "/assets/record-pages-Zto0897Q.js"]
	},
	"/management": {
		filePath: "/app/applet/src/routes/management.tsx",
		children: void 0,
		preloads: ["/assets/management-BF4uBNdC.js", "/assets/dashboard-BjlMLzjf.js"]
	},
	"/procurement": {
		filePath: "/app/applet/src/routes/procurement.tsx",
		children: void 0,
		preloads: ["/assets/procurement-R20vqe96.js", "/assets/monitor-pages-B-tlhenF.js"]
	},
	"/profile": {
		filePath: "/app/applet/src/routes/profile.tsx",
		children: void 0,
		preloads: ["/assets/profile-Dic5C1Q5.js", "/assets/shared-D1FqIhYl.js"]
	},
	"/quotations": {
		filePath: "/app/applet/src/routes/quotations.tsx",
		children: void 0,
		preloads: ["/assets/quotations-ByA8PPHk.js", "/assets/record-pages-Zto0897Q.js"]
	},
	"/registration": {
		filePath: "/app/applet/src/routes/registration.tsx",
		children: void 0,
		preloads: ["/assets/registration-D_NO4IZG.js", "/assets/textarea-CehZkQXX.js"]
	},
	"/reports": {
		filePath: "/app/applet/src/routes/reports.tsx",
		children: void 0,
		preloads: ["/assets/reports-K6OjhOzk.js", "/assets/monitor-pages-B-tlhenF.js"]
	},
	"/requisitions": {
		filePath: "/app/applet/src/routes/requisitions.tsx",
		children: void 0,
		preloads: ["/assets/requisitions-DEJDY-4Q.js", "/assets/record-pages-Zto0897Q.js"]
	},
	"/settings": {
		filePath: "/app/applet/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-VT_D4zz6.js", "/assets/shared-D1FqIhYl.js"]
	},
	"/vehicles": {
		filePath: "/app/applet/src/routes/vehicles.tsx",
		children: void 0,
		preloads: ["/assets/vehicles-0SfOK6-v.js", "/assets/monitor-pages-B-tlhenF.js"]
	},
	"/workflow": {
		filePath: "/app/applet/src/routes/workflow.tsx",
		children: void 0,
		preloads: ["/assets/workflow-AYcKlSua.js", "/assets/monitor-pages-B-tlhenF.js"]
	},
	"/workshop": {
		filePath: "/app/applet/src/routes/workshop.tsx",
		children: void 0,
		preloads: ["/assets/workshop-Bh1OGZ8c.js", "/assets/monitor-pages-B-tlhenF.js"]
	}
} });
//#endregion
export { tsrStartManifest };
