import { n as require_jsx_runtime } from "../_libs/@fortawesome/react-fontawesome+[...].mjs";
import { t as Dashboard } from "./dashboard-BJttEjJk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/management-DyvhKDPs.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, { role: "Management" });
//#endregion
export { SplitComponent as component };
