import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/@fortawesome/react-fontawesome+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as Save, E as KeyRound, F as Moon, P as Monitor, Y as Sun, _t as useWorkspace, j as Mail, s as Button, ut as departments } from "./button-BBYFtzM6.mjs";
import { s as PageHeading } from "./shared-d2hkU1_Q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-CKi20gtZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfileComponent() {
	const { currentUser, role, setRole, employeeDepartment, setEmployeeDepartment } = useWorkspace();
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [passwordLoading, setPasswordLoading] = (0, import_react.useState)(false);
	const [themeMode, setThemeMode] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined" && window.localStorage) {
			const saved = localStorage.getItem("hi_rider_theme");
			if (saved === "light" || saved === "dark" || saved === "system") setThemeMode(saved);
		}
	}, []);
	const [emailNotifications, setEmailNotifications] = (0, import_react.useState)(true);
	const [smsAlerts, setSmsAlerts] = (0, import_react.useState)(true);
	const [compactDensity, setCompactDensity] = (0, import_react.useState)(false);
	const [preferredRole, setPreferredRole] = (0, import_react.useState)(role);
	const [preferredDept, setPreferredDept] = (0, import_react.useState)(employeeDepartment);
	function handleUpdatePassword(e) {
		e.preventDefault();
		if (!currentPassword || !newPassword || !confirmPassword) {
			toast.error("Please fill in all password fields.");
			return;
		}
		if (newPassword !== confirmPassword) {
			toast.error("New passwords do not match.");
			return;
		}
		if (newPassword.length < 4) {
			toast.error("Password must be at least 4 characters long.");
			return;
		}
		setPasswordLoading(true);
		setTimeout(() => {
			setPasswordLoading(false);
			setCurrentPassword("");
			setNewPassword("");
			setConfirmPassword("");
			toast.success("Password updated successfully with BCrypt verification.");
		}, 600);
	}
	function handleSavePreferences(e) {
		e.preventDefault();
		setRole(preferredRole);
		setEmployeeDepartment(preferredDept);
		if (typeof window !== "undefined" && window.localStorage) {
			localStorage.setItem("hi_rider_theme", themeMode);
			localStorage.setItem("hi_rider_role", preferredRole);
			localStorage.setItem("hi_rider_department", preferredDept);
		}
		toast.success("Display preferences and profile settings saved successfully.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 max-w-4xl mx-auto pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
				title: "User Profile & Account Settings",
				subtitle: "Manage your personal details, secure password, and display preferences"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-card border border-border rounded-2xl p-6 shadow-sm space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center gap-5 border-b border-border pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-20 h-20 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary font-bold text-2xl shadow-inner",
						children: currentUser?.displayName ? currentUser.displayName.split(/\s+/).map((p) => p[0]).join("").toUpperCase().slice(0, 2) : "HR"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-semibold text-foreground",
								children: currentUser?.displayName || "Workshop User"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20",
								children: role
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground flex items-center gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { size: 14 }),
								" ",
								currentUser?.email || "user@hirider.com"
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-xl bg-muted/40 border border-border space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground uppercase tracking-label font-semibold",
								children: "User ID"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tabular-nums font-semibold text-foreground text-sm",
								children: ["#", currentUser?.userId || "1042"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-xl bg-muted/40 border border-border space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground uppercase tracking-label font-semibold",
								children: "Employee ID"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "tabular-nums font-semibold text-foreground text-sm",
								children: ["#", currentUser?.employeeId || "EMP-084"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-4 rounded-xl bg-muted/40 border border-border space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground uppercase tracking-label font-semibold",
								children: "Workshop / Company"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-medium text-foreground text-sm",
								children: "Hi Rider 4x4 World (Branch 01)"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "registration-panel flex flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-header",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
								size: 16,
								className: "text-primary"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Security & Password" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Account credentials"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						id: "profile-password-form",
						className: "flex-1 flex flex-col justify-between",
						onSubmit: handleUpdatePassword,
						onReset: (e) => {
							e.preventDefault();
							setCurrentPassword("");
							setNewPassword("");
							setConfirmPassword("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-stack",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "prof-current-pw",
										className: "registration-label",
										children: ["Current Password ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "registration-required",
											children: "*"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "prof-current-pw",
										type: "password",
										required: true,
										placeholder: "••••••••",
										value: currentPassword,
										onChange: (e) => setCurrentPassword(e.target.value),
										className: "registration-input w-full"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "prof-new-pw",
										className: "registration-label",
										children: ["New Password ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "registration-required",
											children: "*"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "prof-new-pw",
										type: "password",
										required: true,
										placeholder: "••••••••",
										value: newPassword,
										onChange: (e) => setNewPassword(e.target.value),
										className: "registration-input w-full"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "prof-confirm-pw",
										className: "registration-label",
										children: ["Confirm Password ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "registration-required",
											children: "*"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "prof-confirm-pw",
										type: "password",
										required: true,
										placeholder: "••••••••",
										value: confirmPassword,
										onChange: (e) => setConfirmPassword(e.target.value),
										className: "registration-input w-full"
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-actions-compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: passwordLoading,
								className: "registration-submit-btn",
								children: passwordLoading ? "Updating..." : "Submit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "reset",
								variant: "outline",
								className: "registration-reset-btn",
								children: "Reset"
							})]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "registration-panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-header",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, {
								size: 16,
								className: "text-primary"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Display & Workspace" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Layout & defaults"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSavePreferences,
						onReset: (e) => {
							e.preventDefault();
							setPreferredRole(role);
							setPreferredDept(employeeDepartment);
							setThemeMode("light");
							setEmailNotifications(true);
							setSmsAlerts(true);
							setCompactDensity(false);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-stack",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "prof-role",
										className: "registration-label",
										children: "Default Role"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "prof-role",
										value: preferredRole,
										onChange: (e) => setPreferredRole(e.target.value),
										className: "registration-input w-full",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Foreman",
												children: "Foreman"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Director",
												children: "Director"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Management",
												children: "Management"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Employee",
												children: "Employee"
											})
										]
									})]
								}),
								preferredRole === "Employee" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "prof-dept",
										className: "registration-label",
										children: "Department"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: "prof-dept",
										value: preferredDept,
										onChange: (e) => setPreferredDept(e.target.value),
										className: "registration-input w-full",
										children: departments.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: d,
											children: d
										}, d))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "registration-label",
										children: "Appearance Mode"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid grid-cols-3 gap-2",
										children: [
											{
												mode: "light",
												label: "Light",
												icon: Sun
											},
											{
												mode: "dark",
												label: "Dark",
												icon: Moon
											},
											{
												mode: "system",
												label: "System",
												icon: Monitor
											}
										].map(({ mode, label, icon: Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => setThemeMode(mode),
											className: `flex items-center justify-center gap-1.5 h-[34px] px-2.5 rounded-[3px] border text-sm font-medium transition cursor-pointer ${themeMode === mode ? "bg-primary text-primary-foreground border-primary" : "bg-background text-foreground border-[#d1d5db] hover:bg-muted"}`,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 13 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
										}, mode))
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact registration-row-top",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "registration-label",
										children: "Notifications"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2.5 pt-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "flex items-center gap-2.5 text-xs cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "checkbox",
													checked: emailNotifications,
													onChange: (e) => setEmailNotifications(e.target.checked),
													className: "rounded border-[#d1d5db] text-primary focus:ring-primary w-4 h-4"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium text-foreground",
													children: "Email Notifications (Requisitions & Approvals)"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "flex items-center gap-2.5 text-xs cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "checkbox",
													checked: smsAlerts,
													onChange: (e) => setSmsAlerts(e.target.checked),
													className: "rounded border-[#d1d5db] text-primary focus:ring-primary w-4 h-4"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium text-foreground",
													children: "SMS Alerts for Urgent Dispatch"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "flex items-center gap-2.5 text-xs cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "checkbox",
													checked: compactDensity,
													onChange: (e) => setCompactDensity(e.target.checked),
													className: "rounded border-[#d1d5db] text-primary focus:ring-primary w-4 h-4"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-medium text-foreground",
													children: "Compact Table Density Mode"
												})]
											})
										]
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-actions-compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								className: "registration-submit-btn",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { size: 14 }), " Submit"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "reset",
								variant: "outline",
								className: "registration-reset-btn",
								children: "Reset"
							})]
						})]
					})]
				})]
			})
		]
	});
}
function ProfilePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileComponent, {});
}
//#endregion
export { ProfilePage as component };
