import { n as __toESM } from "../_runtime.mjs";
import { t as config$1 } from "../_libs/@fortawesome/fontawesome-svg-core+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/@fortawesome/react-fontawesome+[...].mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { $ as UserCheck, A as LogOut, C as FileText, D as LayoutDashboard, G as ShieldCheck, I as Package, M as Menu, N as MessageSquare, O as Loader2, Q as User, S as EyeOff, T as GitBranch, U as Settings, V as Search, W as Shield, _ as ClipboardList, _t as useWorkspace, a as Bell, b as Download, d as ChartNoAxesColumnIncreasing, et as UserRound, g as ClipboardCheck, j as Mail, k as Lock, m as ChevronDown, n as Archive, nt as Wrench, o as Briefcase, p as CheckCircle2, r as ArrowRight, rt as X, s as Button, t as AlertCircle, tt as WorkspaceProvider, u as Car, ut as departments, w as FolderOpen, x as Eye } from "./button-BBYFtzM6.mjs";
import { S as useRouter, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useNavigate, y as createRootRouteWithContext } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-m2eunxh4.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DdNzuB1z.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message: describeThrown(error),
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var MAX_SERIALIZED_LENGTH = 2e3;
function describeThrown(error) {
	if (error instanceof Response) return `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`;
	if (error instanceof Error) return error.message;
	if (typeof error === "string") return error;
	const { message } = error ?? {};
	if (typeof message === "string" && message.length > 0) return message;
	try {
		return JSON.stringify(error)?.slice(0, MAX_SERIALIZED_LENGTH) ?? String(error);
	} catch {
		return String(error);
	}
}
var operationalLinks = [
	{
		title: "Vehicle Registration",
		to: "/registration",
		icon: Car
	},
	{
		title: "Quotations",
		to: "/quotations",
		icon: FileText
	},
	{
		title: "Inventory Cards",
		to: "/inventory",
		icon: Archive
	},
	{
		title: "Job Cards",
		to: "/job-cards",
		icon: ClipboardList
	},
	{
		title: "Parts Requisitions",
		to: "/requisitions",
		icon: Package
	},
	{
		title: "Workshop Progress",
		to: "/workshop",
		icon: Wrench
	},
	{
		title: "Inspections",
		to: "/inspections",
		icon: ClipboardCheck
	},
	{
		title: "Vehicle Records",
		to: "/vehicles",
		icon: FolderOpen
	}
];
var oversightLinks = [
	{
		title: "Vehicle Overview",
		to: "/vehicles",
		icon: Car
	},
	{
		title: "Quotations",
		to: "/quotations",
		icon: FileText
	},
	{
		title: "Inventory Cards",
		to: "/inventory",
		icon: Archive
	},
	{
		title: "Job Cards",
		to: "/job-cards",
		icon: ClipboardList
	},
	{
		title: "Workflow Tracking",
		to: "/workflow",
		icon: GitBranch
	},
	{
		title: "Workshop Progress",
		to: "/workshop",
		icon: Wrench
	},
	{
		title: "Department Performance",
		to: "/departments",
		icon: ChartNoAxesColumnIncreasing
	},
	{
		title: "Parts Requisitions",
		to: "/requisitions",
		icon: Package
	},
	{
		title: "Procurement & Dispatch",
		to: "/procurement",
		icon: Archive
	},
	{
		title: "Inspection Results",
		to: "/inspections",
		icon: ClipboardCheck
	}
];
var employeeLinks = [
	{
		title: "Employee Dashboard",
		to: "/employee",
		icon: LayoutDashboard
	},
	{
		title: "Job Cards",
		to: "/job-cards",
		icon: ClipboardList
	},
	{
		title: "Parts Requisitions",
		to: "/requisitions",
		icon: Package
	},
	{
		title: "Workshop Progress",
		to: "/workshop",
		icon: Wrench
	}
];
function AppShell({ children }) {
	const { role: selectedRole, foreman, employeeDepartment, search, setSearch, requisitions, logout, setShowOnboarding, currentUser } = useWorkspace();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const role = pathname === "/management" ? "Management" : pathname === "/director" || pathname === "/approvals" ? "Director" : pathname === "/employee" ? "Employee" : pathname === "/" ? "Foreman" : selectedRole;
	const pageTitle = pathname === "/management" ? "Management Dashboard" : pathname === "/director" || pathname === "/approvals" ? "Director Dashboard" : pathname === "/employee" ? "Employee Dashboard" : pathname === "/" ? "Foreman Dashboard" : (pathname.split("/").filter(Boolean).at(-1) ?? "Workshop").replaceAll("-", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
	const initials = (role === "Foreman" ? foreman : role === "Employee" ? employeeDepartment : role).split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase()).join("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const profileMenuRef = (0, import_react.useRef)(null);
	const closeProfileMenu = () => {
		if (profileMenuRef.current) profileMenuRef.current.open = false;
	};
	const [searchScope, setSearchScope] = (0, import_react.useState)("/vehicles");
	const navigate = useNavigate();
	const home = role === "Management" ? "/management" : role === "Director" ? "/director" : role === "Employee" ? "/employee" : "/";
	const pending = requisitions.filter((r) => r.status === "Pending").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-shell",
		children: [
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sidebar-backdrop",
				onClick: () => setOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: `app-sidebar ${open ? "sidebar-open" : ""}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mobile-close",
						variant: "navigation",
						size: "icon",
						title: "Close navigation",
						"aria-label": "Close navigation",
						onClick: () => setOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "brand",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/hirider-logo-official.jpeg",
							alt: "Hi Rider 4x4 World Logo",
							className: "brand-logo"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "brand-text",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "brand-name",
								children: "Hi Rider 4x4 World"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "brand-subtitle",
								children: "VEHICLE GARAGE MANAGEMENT"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sidebar-dashboard-wrap",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: home,
							activeOptions: { exact: true },
							className: "sidebar-dashboard-link",
							onClick: () => setOpen(false),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, {}), "Dashboard"]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sidebar-label",
						children: role === "Foreman" ? "Workshop workspace" : "Business workspace"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "sidebar-nav",
						"aria-label": "Main navigation",
						children: [role === "Director" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/approvals",
							className: "sidebar-link",
							onClick: () => setOpen(false),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {}),
								"Parts Approvals",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto inline-flex items-center justify-center rounded-full bg-white text-xs font-medium tabular-nums text-blue-700 px-2 py-0.5 leading-none",
									children: pending
								})
							]
						}), (role === "Foreman" ? operationalLinks : role === "Employee" ? employeeLinks : oversightLinks).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							className: "sidebar-link",
							onClick: () => setOpen(false),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {}), item.title]
						}, item.to))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sidebar-footer",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "/automotive-management-system-updated.zip?v=2",
							download: "automotive-management-system-updated.zip",
							className: "w-full flex items-center justify-center gap-2 rounded-lg bg-white hover:bg-blue-50 px-3 py-2 text-sm font-medium text-blue-700 transition cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 15 }), "Download Zip"]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-body",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "app-topbar",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "topbar-brand",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "navigation",
									size: "icon",
									className: "mobile-menu",
									"aria-label": "Open navigation",
									title: "Open navigation",
									onClick: () => setOpen(true),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									className: "topbar-logo",
									src: "/hirider-logo-official.jpeg",
									alt: "Hi Rider 4x4 World"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "topbar-divider" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "topbar-page-title",
									children: pageTitle
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "global-search",
							role: "search",
							onSubmit: (e) => {
								e.preventDefault();
								navigate({ to: searchScope });
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "global-search-scope",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										"aria-label": "Search scope",
										value: searchScope,
										onChange: (e) => setSearchScope(e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "/vehicles",
												children: "All records"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "/quotations",
												children: "Quotations"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "/job-cards",
												children: "Job cards"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "/requisitions",
												children: "Parts"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "/inspections",
												children: "Inspections"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
										size: 11,
										className: "global-search-scope-icon",
										"aria-hidden": "true"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "global-search-field",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
											size: 14,
											className: "global-search-icon",
											"aria-hidden": "true"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											"aria-label": "Search vehicles, customers, quotations, job cards",
											placeholder: "Search vehicles, customers, quotations, job cards...",
											value: search,
											onChange: (e) => setSearch(e.target.value)
										}),
										search && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											className: "global-search-clear",
											"aria-label": "Clear search",
											title: "Clear search",
											onClick: () => setSearch(""),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 13 })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "submit",
									className: "global-search-submit",
									"aria-label": "Submit search",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
										size: 13,
										"aria-hidden": "true"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "global-search-submit-label",
										children: "Search"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "topbar-actions",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "topbar-action",
									"aria-label": "Notifications",
									title: "Notifications",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { size: 19 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "topbar-notification-badge" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "topbar-action topbar-optional-action",
									"aria-label": "Messages",
									title: "Messages",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { size: 19 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/settings",
									className: "topbar-action topbar-optional-action",
									"aria-label": "Settings",
									title: "Settings",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { size: 19 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
									className: "topbar-profile",
									ref: profileMenuRef,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
										className: "topbar-action topbar-profile-trigger",
										"aria-label": "User profile menu",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "topbar-avatar",
											children: initials || "U"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "topbar-profile-menu",
										children: [
											currentUser?.email && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "px-3 py-1.5 border-b border-border text-xs font-medium text-muted-foreground truncate tabular-nums",
												children: currentUser.email
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/profile",
												onClick: closeProfileMenu,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, { size: 16 }), " Profile"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													closeProfileMenu();
													setShowOnboarding(true);
												},
												className: "cursor-pointer",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { size: 16 }), " Switch Dashboard"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
												to: "/settings",
												onClick: closeProfileMenu,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { size: 16 }), " Account Settings"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "topbar-menu-divider" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													closeProfileMenu();
													logout();
												},
												className: "cursor-pointer text-destructive hover:text-destructive",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 16 }), " Logout"]
											})
										]
									})]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "workspace",
					children
				})]
			})
		]
	});
}
function OnboardingModal() {
	const { role, setRole, setEmployeeDepartment, isAuthenticated, currentUser, showOnboarding, setShowOnboarding } = useWorkspace();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [showModal, setShowModal] = (0, import_react.useState)(false);
	const [selectedRole, setSelectedRole] = (0, import_react.useState)("Foreman");
	const [selectedDept, setSelectedDept] = (0, import_react.useState)("Mechanical");
	(0, import_react.useEffect)(() => {
		setMounted(true);
		if (typeof window === "undefined" || !window.localStorage) return;
		const onboarded = localStorage.getItem("hi_rider_onboarded");
		if (showOnboarding || isAuthenticated && !onboarded) setShowModal(true);
		else setShowModal(false);
	}, [showOnboarding, isAuthenticated]);
	(0, import_react.useEffect)(() => {
		if (currentUser?.role) setSelectedRole(currentUser.role);
		else if (role) setSelectedRole(role);
	}, [currentUser, role]);
	const dashboardOptions = [
		{
			role: "Foreman",
			title: "Foreman Dashboard",
			description: "Intake, job cards, requisitions & shop floor oversight",
			icon: Wrench
		},
		{
			role: "Director",
			title: "Director Dashboard",
			description: "Business overview & parts authorization queue",
			icon: Shield
		},
		{
			role: "Management",
			title: "Manager Dashboard",
			description: "Department performance, procurement, invoices & reports",
			icon: Briefcase
		},
		{
			role: "Employee",
			title: "Employee Dashboard",
			description: "Department work orders, task progress & technician scratchpad",
			icon: UserCheck
		}
	];
	function handleCompleteOnboarding(e) {
		e.preventDefault();
		if (typeof window !== "undefined" && window.localStorage) {
			localStorage.setItem("hi_rider_onboarded", "true");
			localStorage.setItem("hi_rider_role", selectedRole);
			if (selectedRole === "Employee") localStorage.setItem("hi_rider_department", selectedDept);
		}
		setRole(selectedRole);
		if (selectedRole === "Employee") setEmployeeDepartment(selectedDept);
		if (selectedRole === "Management") {
			window.location.hash = "#management";
			if (window.location.pathname !== "/management") window.history.pushState(null, "", "/management");
		} else if (selectedRole === "Director") {
			window.location.hash = "#director";
			if (window.location.pathname !== "/director") window.history.pushState(null, "", "/director");
		} else if (selectedRole === "Employee") {
			window.location.hash = "#employee";
			if (window.location.pathname !== "/employee") window.history.pushState(null, "", "/employee");
		} else {
			window.location.hash = "#foreman";
			if (window.location.pathname !== "/") window.history.pushState(null, "", "/");
		}
		setShowModal(false);
		setShowOnboarding(false);
		const greetingName = currentUser?.displayName || "User";
		const deptInfo = selectedRole === "Employee" ? ` (${selectedDept})` : "";
		toast.success(`Welcome ${greetingName}! Connected to ${selectedRole} Dashboard${deptInfo}.`);
	}
	if (!mounted || !showModal || !isAuthenticated) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-card border border-border rounded-2xl p-7 max-w-xl w-full space-y-6 shadow-2xl animate-in fade-in zoom-in-95 duration-200 my-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 border-b border-border pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center text-primary shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { size: 24 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold text-foreground",
					children: "Welcome to Hi Rider Workshop"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Select your dashboard to configure your workspace view"
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleCompleteOnboarding,
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "block text-xs font-semibold uppercase tracking-label text-muted-foreground",
							children: "Select Your Dashboard"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
							children: dashboardOptions.map(({ role: r, title, description, icon: Icon }) => {
								const isSelected = selectedRole === r;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setSelectedRole(r),
									className: `p-3.5 rounded-xl border text-left transition-all cursor-pointer relative flex flex-col justify-between gap-2 ${isSelected ? "border-primary bg-primary/10 text-foreground ring-2 ring-primary/30 shadow-sm" : "border-border bg-background hover:bg-accent/60 hover:border-muted-foreground/50 text-foreground"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
												size: 18,
												className: isSelected ? "text-primary" : "text-muted-foreground"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-sm",
												children: title.replace(" Dashboard", "")
											})]
										}), isSelected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCircle2, {
											size: 16,
											className: "text-primary shrink-0"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium text-muted-foreground leading-snug",
										children: description
									})]
								}, r);
							})
						})]
					}),
					selectedRole === "Employee" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-4 rounded-xl bg-accent/40 border border-primary/30 space-y-3 animate-in fade-in slide-in-from-top-2 duration-200",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, {
									size: 16,
									className: "text-primary"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "block text-xs font-semibold uppercase tracking-label text-foreground",
									children: "Employee Department / Specialty"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Choose your workshop discipline to filter your work queue and task scratchpad:"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 sm:grid-cols-3 gap-2",
								children: departments.map((dept) => {
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setSelectedDept(dept),
										className: `px-3 py-2.5 rounded-lg border text-sm font-medium transition cursor-pointer text-center ${selectedDept === dept ? "bg-primary text-primary-foreground border-primary shadow-sm" : "bg-background text-foreground border-border hover:bg-accent"}`,
										children: dept
									}, dept);
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							className: "w-full py-3 text-sm font-medium rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Enter ",
								selectedRole,
								" Workspace"
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 })]
						})
					})
				]
			})]
		})
	});
}
function Login() {
	const { login, register } = useWorkspace();
	const [isRegistering, setIsRegistering] = (0, import_react.useState)(false);
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [rememberMe, setRememberMe] = (0, import_react.useState)(false);
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [errorMessage, setErrorMessage] = (0, import_react.useState)(null);
	async function handleSubmit(e) {
		e.preventDefault();
		if (!email.trim() || !password) {
			setErrorMessage("Please enter both email and password.");
			return;
		}
		if (isRegistering && !fullName.trim()) {
			setErrorMessage("Please enter your full name.");
			return;
		}
		setLoading(true);
		setErrorMessage(null);
		try {
			let result;
			if (isRegistering) result = await register(email, password, fullName);
			else result = await login(email, password);
			if (!result.success) setErrorMessage(result.error || (isRegistering ? "Registration failed." : "Authentication failed."));
		} catch (err) {
			setErrorMessage(err instanceof Error ? err.message : "An unexpected error occurred.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-[#F0F2F5] flex items-center justify-center p-4 sm:p-6 lg:p-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-5xl bg-white rounded-3xl shadow-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-2 border border-slate-100",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-8 sm:p-12 flex flex-col justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col items-center text-center gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/hirider-logo-official.jpeg",
								alt: "Hi Rider 4x4 World Logo",
								className: "h-14 w-auto object-contain rounded-lg shadow-sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-xl font-semibold text-slate-900 tracking-tight",
								children: "Hi Rider 4x4 World"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-slate-500 uppercase tracking-label mt-0.5",
								children: "Vehicle Garage Management"
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center space-y-1.5 pt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-semibold text-slate-900 tracking-tight",
								children: isRegistering ? "Create Account" : "Welcome Back!"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-slate-500",
								children: isRegistering ? "Please fill in your details to get started" : "Please login to your account"
							})]
						}),
						errorMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "p-3.5 rounded-xl bg-red-50 border border-red-200 text-red-600 text-xs flex items-start gap-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertCircle, {
								size: 16,
								className: "shrink-0 mt-0.5"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: errorMessage })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleSubmit,
							className: "space-y-4 pt-2",
							children: [
								isRegistering && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5 animate-in fade-in slide-in-from-top-2 duration-150",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "register-name",
										className: "block text-xs font-semibold text-slate-700 uppercase tracking-label",
										children: "Full Name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, {
											size: 16,
											className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "register-name",
											type: "text",
											required: isRegistering,
											placeholder: "Enter your full name",
											value: fullName,
											onChange: (e) => setFullName(e.target.value),
											className: "w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-normal text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "login-email",
										className: "block text-xs font-semibold text-slate-700 uppercase tracking-label",
										children: "Email Address"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
											size: 16,
											className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											id: "login-email",
											type: "email",
											required: true,
											autoComplete: "username",
											placeholder: "Email Address",
											value: email,
											onChange: (e) => setEmail(e.target.value),
											className: "w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-normal text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "login-password",
										className: "block text-xs font-semibold text-slate-700 uppercase tracking-label",
										children: "Password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
												size: 16,
												className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												id: "login-password",
												type: showPassword ? "text" : "password",
												required: true,
												autoComplete: isRegistering ? "new-password" : "current-password",
												placeholder: "Password",
												value: password,
												onChange: (e) => setPassword(e.target.value),
												className: "w-full pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-normal text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:bg-white transition"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setShowPassword(!showPassword),
												className: "absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1 cursor-pointer",
												"aria-label": showPassword ? "Hide password" : "Show password",
												children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 16 })
											})
										]
									})]
								}),
								!isRegistering && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-xs pt-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2 cursor-pointer text-slate-600",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: rememberMe,
											onChange: (e) => setRememberMe(e.target.checked),
											className: "rounded border-slate-300 text-blue-600 focus:ring-blue-600 w-4 h-4"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Remember Me" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#forgot",
										onClick: (e) => {
											e.preventDefault();
											setErrorMessage("Please contact your workshop system administrator to reset credentials.");
										},
										className: "text-blue-600 hover:text-blue-700 font-medium",
										children: "Forgot Password?"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "pt-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										disabled: loading,
										className: "w-full py-3 px-4 bg-primary hover:bg-primary/90 text-primary-foreground font-medium rounded-xl transition cursor-pointer flex items-center justify-center gap-2 text-sm tracking-wide",
										children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loader2, {
											size: 16,
											className: "animate-spin"
										}), isRegistering ? "Creating account..." : "Logging in..."] }) : isRegistering ? "Create Account" : "Login"
									})
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pt-6 text-center text-xs font-medium text-slate-500",
					children: isRegistering ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Already have an account?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setIsRegistering(false);
								setErrorMessage(null);
							},
							className: "text-blue-600 text-sm font-medium hover:underline cursor-pointer",
							children: "Login here"
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						"Don't have an account yet?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setIsRegistering(true);
								setErrorMessage(null);
							},
							className: "text-blue-600 text-sm font-medium hover:underline cursor-pointer",
							children: "Create a Boss account"
						})
					] })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden lg:flex relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-900 items-center justify-center p-12 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px] opacity-15" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-10 flex flex-col items-center text-center space-y-6 max-w-md",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full bg-gradient-to-b from-sky-100 to-blue-100 rounded-2xl p-6 shadow-xl border border-white/30 relative overflow-hidden group",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-tr from-blue-500/10 to-transparent pointer-events-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative py-8 flex flex-col items-center justify-center space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-48 h-28 bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl shadow-lg relative flex items-center justify-center transform -rotate-1 group-hover:rotate-0 transition duration-300",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-2 w-28 h-12 bg-sky-100/90 rounded-lg border border-blue-300 shadow-inner" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute bottom-2 left-4 w-8 h-8 rounded-full bg-slate-900 border-2 border-slate-300 shadow flex items-center justify-center text-white text-xs font-medium",
										children: "4x4"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute bottom-2 right-4 w-8 h-8 rounded-full bg-slate-900 border-2 border-slate-300 shadow flex items-center justify-center text-white text-xs font-medium",
										children: "4x4"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "absolute bottom-4 bg-white px-2 py-0.5 rounded text-xs font-medium tabular-nums tracking-tight text-slate-900 shadow",
										children: "CAR 2255"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full h-3 bg-slate-800 rounded-full shadow-inner relative overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-r from-transparent via-blue-400 to-transparent animate-pulse" })
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg font-semibold text-white tracking-tight",
							children: "Precision Garage & Workshop Control"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-blue-100 leading-relaxed",
							children: "Streamline vehicle registration, quotations, inventory cards, job cards, parts requisitions, and departmental dispatch with real-time tracking."
						})]
					})]
				})]
			})]
		})
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
config$1.autoAddCss = false;
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-7xl font-semibold tabular-nums text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$20 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Hi Rider 4x4 World | Workshop Management" },
			{
				name: "description",
				content: "Hi Rider 4x4 World vehicle garage and workshop management."
			},
			{
				property: "og:title",
				content: "Hi Rider 4x4 World"
			},
			{
				property: "og:description",
				content: "Vehicle garage and workshop management."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootShellContent() {
	const { isAuthenticated } = useWorkspace();
	if (!isAuthenticated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Login, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OnboardingModal, {})] });
}
function RootComponent() {
	const { queryClient } = Route$20.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkspaceProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RootShellContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, { position: "bottom-right" })]
	});
}
function workshopHead(title, description) {
	return { meta: [
		{ title: `${title} | Hi Rider 4x4 World` },
		{
			name: "description",
			content: description
		},
		{
			property: "og:title",
			content: `${title} | Hi Rider 4x4 World`
		},
		{
			property: "og:description",
			content: description
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] };
}
var $$splitComponentImporter$19 = () => import("./routes-BEdHyMXj.mjs");
var Route$19 = createFileRoute("/")({
	head: () => workshopHead("Foreman Dashboard", "Hi Rider 4x4 World foreman workspace for vehicle intake, job cards, parts requisitions and inspections."),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var $$splitComponentImporter$18 = () => import("./alerts-BbFGs9QR.mjs");
var Route$18 = createFileRoute("/alerts")({
	head: () => workshopHead("Operational Alerts", "Pending authorizations, delayed vehicles and release priorities at Hi Rider 4x4 World."),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./approvals-D2M4MUkI.mjs");
var Route$17 = createFileRoute("/approvals")({
	head: () => workshopHead("Parts Approval Screen", "Director review, approval and rejection of workshop parts requisitions before procurement."),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./departments-BruShQXI.mjs");
var Route$16 = createFileRoute("/departments")({
	head: () => workshopHead("Department Performance", "Mechanical, panel beating, fitting, painting and sanding performance monitoring."),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./director--Z8WwCnq.mjs");
var Route$15 = createFileRoute("/director")({
	head: () => workshopHead("Director Dashboard", "Hi Rider 4x4 World business overview and director parts-order authorization."),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./employee-DfprGCyB.mjs");
var Route$14 = createFileRoute("/employee")({
	head: () => workshopHead("Employee Dashboard", "Department employee portal for tracking task progress and requisitions at Hi Rider 4x4 World."),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./inspections-CPE9FMur.mjs");
var Route$13 = createFileRoute("/inspections")({
	head: () => workshopHead("Vehicle Inspections", "Foreman inspection results, completion information and workshop sign-off."),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./inventory-Dwy8PGwC.mjs");
var Route$12 = createFileRoute("/inventory")({
	head: () => workshopHead("Inventory Card Management", "Vehicle belongings, accessories and condition inventory following customer quotation approval."),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./job-cards-XHWQbLiU.mjs");
var Route$11 = createFileRoute("/job-cards")({
	head: () => workshopHead("Job Card Management", "Workshop job cards, departmental assignments and repair instructions at Hi Rider 4x4 World."),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./management-DyvhKDPs.mjs");
var Route$10 = createFileRoute("/management")({
	head: () => workshopHead("Management Dashboard", "Workshop operations, vehicle workflow, departments, delays and release oversight for Hi Rider 4x4 World."),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./procurement-Bq8gCqvt.mjs");
var Route$9 = createFileRoute("/procurement")({
	head: () => workshopHead("Procurement and Dispatch", "Purchasing authorized parts and recording their dispatch to workshop departments."),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./profile-CKi20gtZ.mjs");
var Route$8 = createFileRoute("/profile")({
	head: () => workshopHead("User Profile & Settings", "Manage user details, password security, and display preferences at Hi Rider 4x4 World."),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./quotations-JD8YM3-k.mjs");
var Route$7 = createFileRoute("/quotations")({
	head: () => workshopHead("Quotation Management", "Repair quotations and customer authorizations for Hi Rider 4x4 World."),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./registration-BN8cF070.mjs");
var Route$6 = createFileRoute("/registration")({
	head: () => workshopHead("Vehicle Registration", "Customer details, vehicle intake, existing damage and intake photographs at Hi Rider 4x4 World."),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./reports-IOUPOloB.mjs");
var Route$5 = createFileRoute("/reports")({
	head: () => workshopHead("Operational Reports", "Workshop operations, parts orders, departmental performance and vehicle inspection reports."),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./requisitions-DOEZHen7.mjs");
var Route$4 = createFileRoute("/requisitions")({
	head: () => workshopHead("Parts Requisitions", "Required parts, quantities, request reasons and director authorization status."),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./settings-CWVdXrr_.mjs");
var Route$3 = createFileRoute("/settings")({
	head: () => workshopHead("Account Settings", "Account and view settings for the Hi Rider 4x4 World workshop."),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./vehicles-CQA6h7qJ.mjs");
var Route$2 = createFileRoute("/vehicles")({
	head: () => workshopHead("Vehicle Records", "Complete vehicle records, customer history, workshop progress and final release references."),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./workflow-DsepVDke.mjs");
var Route$1 = createFileRoute("/workflow")({
	head: () => workshopHead("Workflow Tracking", "Track all twelve official stages from vehicle intake through quotation, repairs, inspection and release."),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./workshop-CQ7Fh1_-.mjs");
var Route = createFileRoute("/workshop")({
	head: () => workshopHead("Workshop Progress", "Department repair progress recorded and coordinated by Hi Rider 4x4 World foremen."),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$19.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$20
	}),
	AlertsRoute: Route$18.update({
		id: "/alerts",
		path: "/alerts",
		getParentRoute: () => Route$20
	}),
	ApprovalsRoute: Route$17.update({
		id: "/approvals",
		path: "/approvals",
		getParentRoute: () => Route$20
	}),
	DepartmentsRoute: Route$16.update({
		id: "/departments",
		path: "/departments",
		getParentRoute: () => Route$20
	}),
	DirectorRoute: Route$15.update({
		id: "/director",
		path: "/director",
		getParentRoute: () => Route$20
	}),
	EmployeeRoute: Route$14.update({
		id: "/employee",
		path: "/employee",
		getParentRoute: () => Route$20
	}),
	InspectionsRoute: Route$13.update({
		id: "/inspections",
		path: "/inspections",
		getParentRoute: () => Route$20
	}),
	InventoryRoute: Route$12.update({
		id: "/inventory",
		path: "/inventory",
		getParentRoute: () => Route$20
	}),
	JobCardsRoute: Route$11.update({
		id: "/job-cards",
		path: "/job-cards",
		getParentRoute: () => Route$20
	}),
	ManagementRoute: Route$10.update({
		id: "/management",
		path: "/management",
		getParentRoute: () => Route$20
	}),
	ProcurementRoute: Route$9.update({
		id: "/procurement",
		path: "/procurement",
		getParentRoute: () => Route$20
	}),
	ProfileRoute: Route$8.update({
		id: "/profile",
		path: "/profile",
		getParentRoute: () => Route$20
	}),
	QuotationsRoute: Route$7.update({
		id: "/quotations",
		path: "/quotations",
		getParentRoute: () => Route$20
	}),
	RegistrationRoute: Route$6.update({
		id: "/registration",
		path: "/registration",
		getParentRoute: () => Route$20
	}),
	ReportsRoute: Route$5.update({
		id: "/reports",
		path: "/reports",
		getParentRoute: () => Route$20
	}),
	RequisitionsRoute: Route$4.update({
		id: "/requisitions",
		path: "/requisitions",
		getParentRoute: () => Route$20
	}),
	SettingsRoute: Route$3.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$20
	}),
	VehiclesRoute: Route$2.update({
		id: "/vehicles",
		path: "/vehicles",
		getParentRoute: () => Route$20
	}),
	WorkflowRoute: Route$1.update({
		id: "/workflow",
		path: "/workflow",
		getParentRoute: () => Route$20
	}),
	WorkshopRoute: Route.update({
		id: "/workshop",
		path: "/workshop",
		getParentRoute: () => Route$20
	})
};
var routeTree = Route$20._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
