import { c as WorkshopPage } from "./monitor-pages-C0fryP1_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workshop-CQ7Fh1_-.js
var SplitComponent = WorkshopPage;
//#endregion
export { SplitComponent as component };
