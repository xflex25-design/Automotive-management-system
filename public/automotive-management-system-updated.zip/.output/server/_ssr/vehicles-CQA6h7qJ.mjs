import { o as VehiclesPage } from "./monitor-pages-C0fryP1_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vehicles-CQA6h7qJ.js
var SplitComponent = VehiclesPage;
//#endregion
export { SplitComponent as component };
