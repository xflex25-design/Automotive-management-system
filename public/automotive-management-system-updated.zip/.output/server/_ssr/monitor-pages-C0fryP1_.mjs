import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/@fortawesome/react-fontawesome+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as FileText, G as ShieldCheck, I as Package, L as Plus, T as GitBranch, V as Search, Z as Truck, _ as ClipboardList, _t as useWorkspace, at as canAuthorizeRelease, b as Download, f as Check, i as ArrowUpRight, lt as departmentStats, mt as sortRecords, nt as Wrench, pt as nextSortState, r as ArrowRight, s as Button, u as Car, v as Clock, vt as workflowStages, z as RotateCcw } from "./button-BBYFtzM6.mjs";
import { t as Input } from "./textarea-Cb3rjgmV.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as metricIcons, S as exportCsv, c as ProgressBar, i as ExportButton, l as SectionHeading, m as TableFooter, o as Metrics, r as EmptyState, s as PageHeading, t as DataTable, u as Status, v as ToolbarSearch, x as Workflow, y as VehicleCell } from "./shared-d2hkU1_Q.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as VehicleDetail, r as DialogDescription, t as Dialog } from "./vehicle-detail-CJwnoZF3.mjs";
import { a as SelectItem, i as SelectContent, n as RequestDetail, o as SelectTrigger, r as Select, s as SelectValue } from "./record-pages-n9pGtuMy.mjs";
import { n as DepartmentCards } from "./dashboard-BJttEjJk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/monitor-pages-C0fryP1_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VehiclesPage() {
	const w = useWorkspace();
	const [query, setQuery] = (0, import_react.useState)("");
	const [stage, setStage] = (0, import_react.useState)("All");
	const [sort, setSort] = (0, import_react.useState)(null);
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [release, setRelease] = (0, import_react.useState)(null);
	const filtered = sortRecords(w.vehicles.filter((v) => `${v.make} ${v.id} ${v.plate} ${v.customer}`.toLowerCase().includes(`${query} ${w.search}`.trim().toLowerCase()) && (stage === "All" || String(v.stage) === stage)), sort, (v, key) => {
		switch (key) {
			case "vehicle": return `${v.make} ${v.plate}`;
			case "customer": return v.customer;
			case "received": return v.received;
			case "stage": return v.released ? 999 : v.stage;
			case "foreman": return v.foreman;
			default: return "";
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeading, {
			title: "Vehicle Records",
			subtitle: "Complete vehicle history, customer details and workshop records",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				filename: "vehicle-records",
				rows: w.vehicles
			}), w.role === "Foreman" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/registration",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Register vehicle"]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "toolbar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarSearch, {
				ariaLabel: "Search vehicle records",
				placeholder: "Search vehicle, registration or customer...",
				value: query,
				onChange: setQuery
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: stage,
				onValueChange: setStage,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "w-[220px] h-[38px] rounded-[6px] border-[#d1d5db] bg-background text-sm font-normal shadow-none",
					"aria-label": "Filter workflow stage",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "All",
					children: "All workflow stages"
				}), workflowStages.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: String(i),
					children: s
				}, s))] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
			headers: [
				{
					label: "Vehicle",
					sortKey: "vehicle"
				},
				{
					label: "Customer",
					sortKey: "customer"
				},
				{
					label: "Received",
					sortKey: "received"
				},
				{
					label: "Current stage",
					sortKey: "stage"
				},
				{
					label: "Foreman",
					sortKey: "foreman"
				},
				"Actions"
			],
			loading: w.loading,
			sort,
			onSort: (key) => setSort((current) => nextSortState(current, key)),
			empty: filtered.length === 0,
			emptyState: query.trim() || w.search.trim() || stage !== "All" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Search,
				tone: "muted",
				title: "No matching vehicles",
				description: "No vehicle records matched your search query or selected workflow stage.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => {
						setQuery("");
						setStage("All");
						w.setSearch("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Clear filters"]
				}), w.role === "Foreman" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/registration",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Register vehicle"]
					})
				})] })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Car,
				title: "No vehicles in workshop",
				description: "Register an incoming customer vehicle to track repairs, quotations, parts, and final handover.",
				action: w.role === "Foreman" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/registration",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Register vehicle"]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void w.refresh(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Refresh records"]
				})
			}),
			children: filtered.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: v }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: v.customer }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: v.received }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: v.released ? "Released" : workflowStages[v.stage] ?? "Intake" }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: v.foreman }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [v.stage === 11 && !v.released && canAuthorizeRelease(w.role) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setRelease(v.id),
						children: "Authorize release"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: `View ${v.plate}`,
						"aria-label": `View ${v.plate}`,
						onClick: () => setDetail(v.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
					})]
				}) })
			] }, v.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableFooter, {
			count: filtered.length,
			label: "vehicles"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleDetail, {
			id: detail,
			onClose: () => setDetail(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!release,
			onOpenChange: (o) => {
				if (!o) setRelease(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Invoice & vehicle release" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: ["Management final authorization · ", release && w.vehicleFor(release)?.plate] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => {
					e.preventDefault();
					if (!release || !canAuthorizeRelease(w.role)) return;
					const data = new FormData(e.currentTarget);
					w.setVehicles((prev) => prev.map((v) => v.id === release ? {
						...v,
						released: true
					} : v));
					w.addActivity("Vehicle release authorized", `${release} · Invoice ${String(data.get("invoice"))}`);
					toast.success("Final release authorized and invoice reference recorded.");
					setRelease(null);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row-compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "release-invoice",
							className: "registration-label",
							children: ["Invoice Reference ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-required",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "release-invoice",
							required: true,
							name: "invoice",
							placeholder: "e.g. INV-2026-1042",
							className: "registration-input"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-row-compact",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "registration-label",
							children: ["Confirmation ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-required",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2.5 text-xs cursor-pointer",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								required: true,
								className: "rounded border-[#d1d5db] w-4 h-4"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Inspection passed and final release approved" })]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-actions-modal",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						className: "registration-submit-btn",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), "Submit"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						className: "registration-reset-btn",
						onClick: () => setRelease(null),
						children: "Cancel"
					})]
				})]
			})] })
		})
	] });
}
function ApprovalPage() {
	const w = useWorkspace();
	const [filter, setFilter] = (0, import_react.useState)("Pending");
	const [sort, setSort] = (0, import_react.useState)(null);
	const [request, setRequest] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => w.setRole("Director"), [w.setRole]);
	const pending = w.requisitions.filter((r) => r.status === "Pending");
	const shown = sortRecords(w.requisitions.filter((r) => (filter === "All" || r.status === filter) && `${r.id} ${r.part} ${w.vehicleFor(r.vehicleId)?.plate}`.toLowerCase().includes(w.search.toLowerCase())), sort, (r, key) => {
		const vehicle = w.vehicleFor(r.vehicleId);
		switch (key) {
			case "id": return r.id;
			case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
			case "part": return r.part;
			case "quantity": return r.quantity;
			case "status": return r.status;
			default: return "";
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
			title: "Parts Approvals",
			subtitle: "Director authorization · Review parts before procurement",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				filename: "parts-approvals",
				rows: w.requisitions
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `attention-band ${pending.length > 0 ? "attention-band-warning" : ""}`.trim(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 22 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [pending.length, " parts requests require your authorization"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The backend currently has no requisition approval endpoint, so a decision cannot be saved." })] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metrics, { items: [
			{
				label: "Pending approvals",
				value: pending.length,
				note: "Awaiting your decision",
				icon: metricIcons.Clock,
				tone: pending.length > 0 ? "warning" : "default"
			},
			{
				label: "Approved requests",
				value: w.requisitions.filter((r) => r.status === "Approved").length,
				note: "Ready for procurement",
				icon: metricIcons.ClipboardCheck,
				tone: "success"
			},
			{
				label: "Rejected requests",
				value: w.requisitions.filter((r) => r.status === "Rejected").length,
				note: "Returned to foremen",
				icon: metricIcons.FileText
			},
			{
				label: "Ordered & dispatched",
				value: w.requisitions.filter((r) => ["Ordered", "Dispatched"].includes(r.status)).length,
				note: "Procurement in progress",
				icon: metricIcons.Package
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "toolbar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold",
				children: "Parts authorization queue"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: filter,
				onValueChange: setFilter,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "w-[180px] h-[38px] rounded-[6px] border-[#d1d5db] bg-background text-sm font-normal shadow-none",
					"aria-label": "Approval queue status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: [
					"Pending",
					"Approved",
					"Rejected",
					"All"
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: s,
					children: s === "All" ? "All requests" : s
				}, s)) })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
			headers: [
				{
					label: "Request",
					sortKey: "id"
				},
				{
					label: "Vehicle",
					sortKey: "vehicle"
				},
				{
					label: "Part / item",
					sortKey: "part"
				},
				{
					label: "Qty",
					sortKey: "quantity",
					align: "right"
				},
				{
					label: "Status",
					sortKey: "status"
				},
				"Action"
			],
			loading: w.loading,
			sort,
			onSort: (key) => setSort((current) => nextSortState(current, key)),
			empty: shown.length === 0,
			emptyState: filter !== "All" || Boolean(w.search.trim()) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: ShieldCheck,
				tone: "muted",
				title: filter === "Pending" && !w.search.trim() ? "No pending parts approvals" : "No matching parts requests",
				description: filter === "Pending" && !w.search.trim() ? "There are no requisitions awaiting director authorization right now." : "No parts requisitions match the active status filter or search query.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => {
						setFilter("All");
						w.setSearch("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Show all requests"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void w.refresh(),
					children: "Refresh queue"
				})] })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: ShieldCheck,
				title: "No parts requisitions submitted",
				description: "Parts requests submitted by foremen for director authorization will appear in this queue.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void w.refresh(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Refresh queue"]
				})
			}),
			children: shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "cell-title",
					children: r.id
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(r.vehicleId) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.part }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "text-right tabular-nums",
					children: r.quantity
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: r.status }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: r.status === "Pending" ? "default" : "outline",
					onClick: () => setRequest(r),
					children: [r.status === "Pending" ? "Review request" : "View details", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 13 })]
				}) })
			] }, r.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableFooter, {
			count: shown.length,
			label: "requests"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestDetail, {
			request,
			allowDecision: true,
			onClose: () => setRequest(null)
		})
	] });
}
function WorkflowPage() {
	const w = useWorkspace();
	const [vehicleId, setVehicleId] = (0, import_react.useState)(w.vehicles[0]?.id ?? "");
	const [sort, setSort] = (0, import_react.useState)(null);
	const v = w.vehicleFor(vehicleId);
	const sortedVehicles = sortRecords(w.vehicles, sort, (vehicle, key) => {
		switch (key) {
			case "vehicle": return `${vehicle.make} ${vehicle.plate}`;
			case "stage": return vehicle.released ? 999 : vehicle.stage;
			case "department": return vehicle.department;
			case "progress": return vehicle.progress;
			case "due": return vehicle.due;
			default: return "";
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
			title: "Workflow Tracking",
			subtitle: "From vehicle intake to invoice and final release",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				filename: "workflow-tracking",
				rows: w.vehicles.map((v) => ({
					vehicle: v.plate,
					customer: v.customer,
					stage: workflowStages[v.stage],
					department: v.department,
					foreman: v.foreman
				}))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "toolbar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-semibold",
				children: "Vehicle workflow"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium text-muted-foreground mt-1",
				children: [
					v?.customer,
					" · ",
					v?.foreman
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: vehicleId,
				onValueChange: setVehicleId,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "w-[270px] h-[38px] rounded-[6px] border-[#d1d5db] bg-background text-sm font-normal shadow-none",
					"aria-label": "Track vehicle",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: w.vehicles.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
					value: v.id,
					children: [
						v.make,
						" · ",
						v.plate
					]
				}, v.id)) })]
			})]
		}),
		v && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "attention-band",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { size: 18 }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
					v.make,
					" · ",
					v.plate
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					"Current stage: ",
					v.released ? "Released" : workflowStages[v.stage],
					" · Expected completion: ",
					v.due
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: `${v.progress}% complete` })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Workflow, { stage: v.stage })] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "table-section mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				title: "All vehicles",
				subtitle: "Live position within the official 12-stage workshop process"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				headers: [
					{
						label: "Vehicle",
						sortKey: "vehicle"
					},
					{
						label: "Current stage",
						sortKey: "stage"
					},
					{
						label: "Department",
						sortKey: "department"
					},
					{
						label: "Progress",
						sortKey: "progress"
					},
					{
						label: "Expected completion",
						sortKey: "due"
					}
				],
				loading: w.loading,
				sort,
				onSort: (key) => setSort((current) => nextSortState(current, key)),
				empty: sortedVehicles.length === 0,
				emptyState: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: GitBranch,
					title: "No vehicles in workflow",
					description: "Vehicles appear across the 12-stage workshop process as soon as intake registration begins.",
					action: w.role === "Foreman" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/registration",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Register vehicle"]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => void w.refresh(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Refresh workflow"]
					})
				}),
				children: sortedVehicles.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: v }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: v.released ? "Released" : workflowStages[v.stage] ?? "Intake" }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: v.department }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-[100px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: v.progress }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs font-medium tabular-nums mt-2 text-muted-foreground",
							children: [v.progress, "%"]
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: v.due })
				] }, v.id))
			})]
		})
	] });
}
function DepartmentsPage() {
	const w = useWorkspace();
	const [selected, setSelected] = (0, import_react.useState)("All");
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [deptSort, setDeptSort] = (0, import_react.useState)(null);
	const [jobSort, setJobSort] = (0, import_react.useState)(null);
	const sortedDepartments = sortRecords(departmentStats, deptSort, (d, key) => {
		switch (key) {
			case "name": return d.name;
			case "assigned": return d.active + d.pending;
			case "active": return d.active;
			case "completed": return d.completed;
			case "pending": return d.pending;
			case "delays": return d.delays;
			case "efficiency": return d.efficiency;
			default: return "";
		}
	});
	const filteredJobs = sortRecords(w.jobs.filter((j) => selected === "All" || j.department === selected), jobSort, (j, key) => {
		const vehicle = w.vehicleFor(j.vehicleId);
		switch (key) {
			case "id": return j.id;
			case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
			case "department": return j.department;
			case "work": return j.work;
			case "status": return j.status;
			default: return "";
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
			title: "Department Performance",
			subtitle: "Mechanical, panel beating, fitting, painting and sanding",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				filename: "department-performance",
				rows: departmentStats
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DepartmentCards, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "table-section mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				title: "Department overview",
				subtitle: "Work coordinated and recorded by the foremen"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				headers: [
					{
						label: "Department",
						sortKey: "name"
					},
					{
						label: "Assigned vehicles",
						sortKey: "assigned",
						align: "right"
					},
					{
						label: "In progress",
						sortKey: "active",
						align: "right"
					},
					{
						label: "Completed jobs",
						sortKey: "completed",
						align: "right"
					},
					{
						label: "Pending work",
						sortKey: "pending",
						align: "right"
					},
					{
						label: "Delays",
						sortKey: "delays",
						align: "right"
					},
					{
						label: "Completion rate",
						sortKey: "efficiency"
					}
				],
				loading: w.loading,
				sort: deptSort,
				onSort: (key) => setDeptSort((current) => nextSortState(current, key)),
				empty: sortedDepartments.length === 0,
				emptyState: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: Wrench,
					title: "No department metrics yet",
					description: "Department throughput and delay metrics appear as repair tasks are tracked.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => void w.refresh(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Refresh metrics"]
					})
				}),
				children: sortedDepartments.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: d.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "text-right tabular-nums",
						children: d.active + d.pending
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "text-right tabular-nums",
						children: d.active
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "text-right tabular-nums",
						children: d.completed
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "text-right tabular-nums",
						children: d.pending
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "text-right tabular-nums",
						children: d.delays
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-[80px]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: d.efficiency })
							}),
							d.efficiency,
							"%"
						]
					}) })
				] }, d.name))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "table-section",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
				title: "Department assignments",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: selected,
					onValueChange: setSelected,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						className: "w-[180px] h-[38px] rounded-[6px] border-[#d1d5db] bg-background text-sm font-normal shadow-none",
						"aria-label": "Select department",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "All",
						children: "All departments"
					}), departmentStats.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: d.name,
						children: d.name
					}, d.name))] })]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				headers: [
					{
						label: "Job card",
						sortKey: "id"
					},
					{
						label: "Vehicle",
						sortKey: "vehicle"
					},
					{
						label: "Department",
						sortKey: "department"
					},
					{
						label: "Work instructions",
						sortKey: "work"
					},
					{
						label: "Status",
						sortKey: "status"
					},
					"Actions"
				],
				loading: w.loading,
				sort: jobSort,
				onSort: (key) => setJobSort((current) => nextSortState(current, key)),
				empty: filteredJobs.length === 0,
				emptyState: selected !== "All" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: Wrench,
					tone: "muted",
					title: `No job cards for ${selected}`,
					description: "There are no active or completed job cards assigned to this department.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setSelected("All"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Show all departments"]
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: ClipboardList,
					title: "No department assignments yet",
					description: "Job cards assigned to mechanical, panel beating, fitting, painting, and sanding appear here.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/job-cards",
							children: ["Go to job cards", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})
				}),
				children: filteredJobs.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: j.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(j.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: j.department }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "whitespace-normal max-w-[260px]",
						children: j.work
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: j.status }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						"aria-label": `View ${j.id}`,
						title: "View vehicle",
						onClick: () => setDetail(j.vehicleId),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
					}) })
				] }, j.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleDetail, {
			id: detail,
			onClose: () => setDetail(null)
		})
	] });
}
function WorkshopPage() {
	const w = useWorkspace();
	const [employeeId, setEmployeeId] = (0, import_react.useState)(String({
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/"
	}["VITE_EMPLOYEE_ID"] ?? ""));
	const [sort, setSort] = (0, import_react.useState)(null);
	const employees = w.workflowOptions["employees"] ?? [];
	const workOrders = sortRecords(w.workflows.flatMap((plan) => (Array.isArray(plan["workOrders"]) ? plan["workOrders"] : []).map((order) => ({
		...order,
		planId: Number(plan["repairPlanId"]),
		planStatus: String(plan["repairPlanStatus"]),
		jobId: Number(plan["jobId"])
	}))), sort, (order, key) => {
		const job = w.jobs.find((item) => item.backendJobId === order["jobId"]);
		const vehicle = job && w.vehicleFor(job.vehicleId);
		switch (key) {
			case "workOrder": return String(order["workOrderNumber"] ?? order["taskTitle"] ?? "");
			case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
			case "department": return String(order["departmentName"] ?? "");
			case "status": return String(order["status"] ?? "");
			default: return "";
		}
	});
	const run = (action, success) => void action().then(async () => {
		await w.refresh();
		toast.success(success);
	}).catch((error) => toast.error(error.message));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
			title: "Workshop Progress",
			subtitle: "Repair plan, work orders and department visits from the backend",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				filename: "workshop-progress",
				rows: w.jobs
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "field max-w-sm mb-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Employee performing workshop actions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: employeeId,
				onValueChange: setEmployeeId,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select employee" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: employees.map((employee) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
					value: String(employee["id"]),
					children: [
						String(employee["name"]),
						" · ",
						String(employee["title"])
					]
				}, String(employee["id"]))) })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "table-section mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, { title: "Repair plan work orders" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				headers: [
					{
						label: "Work order",
						sortKey: "workOrder"
					},
					{
						label: "Vehicle",
						sortKey: "vehicle"
					},
					{
						label: "Department",
						sortKey: "department"
					},
					{
						label: "Status",
						sortKey: "status"
					},
					"Assignments / visits / evidence"
				],
				loading: w.loading,
				sort,
				onSort: (key) => setSort((current) => nextSortState(current, key)),
				empty: workOrders.length === 0,
				emptyState: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: Wrench,
					title: "No repair plan work orders",
					description: "Work orders appear here once repair plans are initialized from open job cards.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/job-cards",
							children: ["View job cards", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => void w.refresh(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Refresh"]
					})] })
				}),
				children: workOrders.map((order) => {
					const job = w.jobs.find((item) => item.backendJobId === order["jobId"]);
					const vehicle = job && w.vehicleFor(job.vehicleId);
					const assignments = Array.isArray(order["assignments"]) ? order["assignments"] : [];
					const visits = Array.isArray(order["departmentVisits"]) ? order["departmentVisits"] : [];
					const activeVisit = visits.find((visit) => visit["status"] === "OPEN");
					const evidence = Array.isArray(order["evidence"]) ? order["evidence"] : [];
					const sessions = Array.isArray(order["sessions"]) ? order["sessions"] : [];
					const id = Number(order["workOrderId"]);
					const departmentId = Number(order["departmentId"]);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "cell-title",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: String(order["workOrderNumber"]) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								String(order["taskTitle"]),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground mt-1",
									children: String(order["workInstructions"] ?? order["workDescription"] ?? "")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: String(order["departmentName"]) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: String(order["status"]) }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs",
								children: assignments.map((a) => String(a["employeeName"])).join(", ") || "No assignment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: visits.map((v) => `${v["departmentName"]} · ${v["status"]}`).join("; ") || "No department visit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [
									evidence.length,
									" evidence files · ",
									sessions.length,
									" work sessions"
								]
							}),
							String(order["planStatus"]) === "DRAFT" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => run(() => w.api.acceptRepairPlan(Number(order["planId"]), Number(employeeId)), "Repair plan accepted."),
								children: "Accept repair plan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-1 mt-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: "",
										onValueChange: (value) => run(() => w.api.assignWorkOrder(id, Number(value), "TECHNICIAN", Number(employeeId)), "Work order assigned."),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "h-8 w-40",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Assign employee" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: employees.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: String(e["id"]),
											children: String(e["name"])
										}, String(e["id"]))) })]
									}),
									!activeVisit && (String(order["status"]) === "READY" || String(order["status"]) === "ASSIGNED") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => run(() => w.api.arriveAtDepartment(id, departmentId, "Vehicle arrived at department", Number(employeeId)), "Department arrival recorded."),
										children: "Record arrival"
									}),
									activeVisit && [
										"READY",
										"ASSIGNED",
										"PAUSED",
										"WAITING"
									].includes(String(order["status"])) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => run(() => w.api.workOrderAction(id, String(order["status"]) === "PAUSED" ? "resume" : "start", "Workshop work started", Number(employeeId)), "Work started."),
										children: String(order["status"]) === "PAUSED" ? "Resume" : "Start"
									}),
									activeVisit && String(order["status"]) === "IN_PROGRESS" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => run(() => w.api.workOrderAction(id, "pause", "Work paused", Number(employeeId)), "Work paused."),
											children: "Pause"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => run(() => w.api.workOrderAction(id, "waiting", "Waiting for parts or information", Number(employeeId)), "Work marked waiting."),
											children: "Waiting"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "sm",
											onClick: () => {
												const notes = window.prompt("Completion notes");
												if (notes) run(() => w.api.submitWorkOrder(id, notes, Number(employeeId)), "Submitted for confirmation.");
											},
											children: "Submit completion"
										})
									] }),
									activeVisit && String(order["status"]) === "AWAITING_CONFIRMATION" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: () => run(() => w.api.confirmWorkOrder(id, "Work completion confirmed", Number(employeeId)), "Work order completed."),
										children: "Confirm completion"
									}),
									activeVisit && String(order["status"]) === "COMPLETED" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => run(() => w.api.sendOffDepartment(id, departmentId, Number(activeVisit["visitId"]), "Department work completed", Number(employeeId)), "Department send-off recorded."),
										children: "Send off"
									}),
									activeVisit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-xs",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "sr-only",
											children: "Upload work photo evidence"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											className: "h-8 w-48",
											type: "file",
											accept: "image/*",
											onChange: (e) => {
												const file = e.target.files?.[0];
												if (file) run(() => w.api.uploadWorkEvidence(id, file, "Work order evidence", Number(employeeId)), "Evidence uploaded.");
												e.currentTarget.value = "";
											}
										})]
									})
								]
							}),
							sessions.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 text-xs",
								children: sessions.map((session) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
									String(session["startedAt"]),
									" · ",
									String(session["sessionStatus"]),
									" ·",
									" ",
									String(session["durationMinutes"]),
									" min"
								] }, String(session["sessionId"])))
							})
						] })
					] }, id);
				})
			})]
		})
	] });
}
function ProcurementPage() {
	const w = useWorkspace();
	const [reqSort, setReqSort] = (0, import_react.useState)(null);
	const [poSort, setPoSort] = (0, import_react.useState)(null);
	const options = w.workflowOptions;
	const suppliers = options.suppliers ?? [];
	const locations = options.stockLocations ?? [];
	const requests = sortRecords(w.requisitions, reqSort, (r, key) => {
		const vehicle = w.vehicleFor(r.vehicleId);
		switch (key) {
			case "id": return r.id;
			case "part": return r.part;
			case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
			case "quantity": return r.quantity;
			case "status": return r.status;
			default: return "";
		}
	});
	const orders = sortRecords(w.purchaseOrders, poSort, (order, key) => {
		const items = Array.isArray(order["items"]) ? order["items"] : [];
		switch (key) {
			case "order": return String(order["purchaseOrderNumber"] ?? order["purchaseOrderId"] ?? "");
			case "supplier": return String(order["supplierName"] ?? "");
			case "status": return String(order["status"] ?? "");
			case "items": return items.length;
			default: return "";
		}
	});
	const reportError = (error) => toast.error(error instanceof Error ? error.message : "The backend request failed.");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
			title: "Procurement & Parts Dispatch",
			subtitle: "Purchasing and departmental dispatch after director authorization",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				filename: "procurement-dispatch",
				rows: requests
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metrics, { items: [
			{
				label: "Ready to purchase",
				value: requests.filter((r) => r.status === "Approved").length,
				note: "Approved and ready for PO",
				icon: metricIcons.ClipboardCheck,
				tone: "success"
			},
			{
				label: "On order",
				value: orders.length,
				note: "Awaiting supplier delivery",
				icon: metricIcons.Package,
				tone: orders.length > 0 ? "warning" : "default"
			},
			{
				label: "Parts dispatched",
				value: w.dispatches.length,
				note: "Workshop dispatch orders",
				icon: metricIcons.Wrench
			},
			{
				label: "Total requisitions",
				value: requests.length,
				note: "Matching current records",
				icon: metricIcons.FileText
			}
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
			headers: [
				{
					label: "Requisition",
					sortKey: "id"
				},
				{
					label: "Part / item",
					sortKey: "part"
				},
				{
					label: "Vehicle",
					sortKey: "vehicle"
				},
				{
					label: "Quantity",
					sortKey: "quantity",
					align: "right"
				},
				{
					label: "Status",
					sortKey: "status"
				},
				"Purchase order"
			],
			loading: w.loading,
			sort: reqSort,
			onSort: (key) => setReqSort((current) => nextSortState(current, key)),
			empty: requests.length === 0,
			emptyState: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Package,
				title: "No parts requisitions to process",
				description: "Approved parts requests ready for supplier purchase orders will appear here.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/requisitions",
						children: ["View requisitions", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
					})
				})
			}),
			children: requests.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "cell-title",
					children: r.id
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.part }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(r.vehicleId) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "text-right tabular-nums",
					children: r.quantity
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: r.status }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.status === "Approved" && r.backendId && suppliers.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex flex-wrap gap-2",
					onSubmit: async (e) => {
						e.preventDefault();
						const form = new FormData(e.currentTarget);
						try {
							await w.api.createPurchaseOrder(Number(r.backendId), Number(form.get("supplier")), (r.lines ?? []).map((line) => ({
								requisitionItemId: line.id,
								quantityOrdered: line.quantity,
								unitPrice: 0
							})), String(form.get("reference") ?? ""));
							await w.refresh();
							toast.success("Purchase order created.");
						} catch (error) {
							reportError(error);
						}
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							name: "supplier",
							required: true,
							"aria-label": "Supplier",
							className: "field-input",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Supplier"
							}), suppliers.map((supplier) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: supplier.supplierId,
								children: supplier.supplierName
							}, supplier.supplierId))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "reference",
							"aria-label": "Supplier reference",
							placeholder: "Supplier ref",
							className: "registration-input w-36"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							className: "registration-submit-btn",
							children: "Create PO"
						})
					]
				}) })
			] }, r.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableFooter, {
			count: requests.length,
			label: "backend requisitions"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, { title: "Purchase orders" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
			headers: [
				{
					label: "Order",
					sortKey: "order"
				},
				{
					label: "Supplier",
					sortKey: "supplier"
				},
				{
					label: "Status",
					sortKey: "status"
				},
				{
					label: "Items",
					sortKey: "items"
				},
				"Receive"
			],
			loading: w.loading,
			sort: poSort,
			onSort: (key) => setPoSort((current) => nextSortState(current, key)),
			empty: !orders.length,
			emptyState: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Truck,
				title: "No purchase orders placed",
				description: "Create a purchase order from an approved requisition above to track supplier deliveries and stock receipt.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void w.refresh(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Refresh orders"]
				})
			}),
			children: orders.map((order) => {
				const items = Array.isArray(order["items"]) ? order["items"] : [];
				const id = Number(order["purchaseOrderId"]);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: String(order["purchaseOrderNumber"] ?? id)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: String(order["supplierName"] ?? "") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: String(order["status"] ?? "") }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: items.map((item) => `${String(item["partName"] ?? item["partCode"])} × ${String(item["quantityOrdered"] ?? "")}`).join(", ") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: locations.length > 0 && String(order["status"]).toUpperCase() !== "RECEIVED" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex gap-2",
						onSubmit: async (e) => {
							e.preventDefault();
							const form = new FormData(e.currentTarget);
							try {
								await w.api.receivePurchaseOrder(id, Number(form.get("location")), items.map((item) => ({
									purchaseOrderItemId: Number(item["purchaseOrderItemId"]),
									quantityDelivered: Number(item["quantityOrdered"]) - Number(item["quantityReceived"] ?? 0),
									quantityAccepted: Number(item["quantityOrdered"]) - Number(item["quantityReceived"] ?? 0)
								})), String(form.get("deliveryRef") ?? ""));
								await w.refresh();
								toast.success("Purchase order receipt recorded.");
							} catch (error) {
								reportError(error);
							}
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								name: "location",
								required: true,
								"aria-label": "Receiving stock location",
								className: "field-input",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "Location"
								}), locations.map((location) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: location.stockLocationId,
									children: location.locationName
								}, location.stockLocationId))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								name: "deliveryRef",
								"aria-label": "Delivery reference",
								placeholder: "Delivery ref",
								className: "registration-input w-36"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "registration-submit-btn",
								children: "Receive"
							})
						]
					}) })
				] }, id);
			})
		})
	] });
}
function ReportsPage() {
	const w = useWorkspace();
	const reports = [
		{
			name: "Workshop operations report",
			description: "Vehicle intake, current stage, departments and completion dates",
			data: w.vehicles,
			filename: "workshop-operations"
		},
		{
			name: "Parts requisitions & approvals",
			description: "Requested parts, quantities, values and authorization status",
			data: w.requisitions,
			filename: "parts-requisitions"
		},
		{
			name: "Department performance",
			description: "Active, completed and delayed work by department",
			data: departmentStats,
			filename: "department-performance"
		},
		{
			name: "Customer quotations",
			description: "Quotation values and customer approval records",
			data: w.quotations,
			filename: "customer-quotations"
		},
		{
			name: "Vehicle inspection results",
			description: "Foreman inspections, final checks and completion notes",
			data: w.inspections,
			filename: "vehicle-inspections"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
		title: "Operational Reports",
		subtitle: "Workshop and business reporting · November 2026"
	}), reports.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "report-row",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { size: 23 }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: r.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: r.description })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				className: "report-action",
				onClick: () => exportCsv(r.filename, r.data),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Download CSV"]
			})
		]
	}, r.name))] });
}
function AlertsPage() {
	const w = useWorkspace();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
			title: "Operational Alerts",
			subtitle: "Outstanding approvals, vehicle delays and release priorities"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, { title: "Requires attention" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `attention-band ${w.requisitions.filter((r) => r.status === "Pending").length > 0 ? "attention-band-warning" : ""}`.trim(),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 20 }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [w.requisitions.filter((r) => r.status === "Pending").length, " parts requests awaiting Director authorization"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Procurement is held until parts are authorized." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "link",
						className: "band-action",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/requisitions",
							children: ["View requests", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "attention-band attention-band-warning",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { size: 20 }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Nissan Navara · BAL 5643 · Completion delayed" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Rear quarter panel on order. Expected completion was 10 November." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "link",
						className: "band-action",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/procurement",
							children: ["View procurement", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "attention-band",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { size: 20 }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [w.vehicles.filter((v) => v.stage === 11 && !v.released).length, " vehicles awaiting final release authorization"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Management approval and invoice reference are required." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "link",
						className: "band-action",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/vehicles",
							children: ["View vehicles", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})
				]
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, { title: "Recent workshop activity" }), w.activities.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "activity-row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: a.text }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: a.detail })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: a.time })
				]
			}, i))]
		})
	] });
}
//#endregion
export { ReportsPage as a, WorkshopPage as c, ProcurementPage as i, ApprovalPage as n, VehiclesPage as o, DepartmentsPage as r, WorkflowPage as s, AlertsPage as t };
