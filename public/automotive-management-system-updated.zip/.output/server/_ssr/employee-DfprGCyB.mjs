import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/@fortawesome/react-fontawesome+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { I as Package, J as StickyNote, L as Plus, V as Search, X as Trash2, _ as ClipboardList, _t as useWorkspace, ct as cn, f as Check, mt as sortRecords, nt as Wrench, p as CheckCircle2, pt as nextSortState, q as Sparkles, s as Button, ut as departments, v as Clock, y as Copy, z as RotateCcw } from "./button-BBYFtzM6.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as SectionHeading, m as TableFooter, o as Metrics, r as EmptyState, s as PageHeading, t as DataTable, u as Status, v as ToolbarSearch, y as VehicleCell } from "./shared-d2hkU1_Q.mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/employee-DfprGCyB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold leading-[var(--type-heading-leading)] text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm font-normal text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
function EmployeeScratchpad({ department }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [scratchpadText, setScratchpadText] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)([]);
	const [newNoteInput, setNewNoteInput] = (0, import_react.useState)("");
	const [copiedId, setCopiedId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		if (typeof window === "undefined" || !window.sessionStorage) return;
		try {
			const savedText = sessionStorage.getItem("hi_rider_scratchpad_text");
			if (savedText) setScratchpadText(savedText);
			const savedNotes = sessionStorage.getItem("hi_rider_scratchpad_notes");
			if (savedNotes) setNotes(JSON.parse(savedNotes));
		} catch (err) {
			console.warn(err);
		}
	}, []);
	function handleSaveText(text) {
		setScratchpadText(text);
		if (typeof window !== "undefined" && window.sessionStorage) try {
			sessionStorage.setItem("hi_rider_scratchpad_text", text);
		} catch (err) {
			console.warn(err);
		}
	}
	function handleAddNote(e) {
		e.preventDefault();
		if (!newNoteInput.trim()) return;
		const updated = [{
			id: `note-${Date.now()}`,
			text: newNoteInput.trim(),
			time: (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			})
		}, ...notes];
		setNotes(updated);
		setNewNoteInput("");
		if (typeof window !== "undefined" && window.sessionStorage) try {
			sessionStorage.setItem("hi_rider_scratchpad_notes", JSON.stringify(updated));
		} catch (err) {
			console.warn(err);
		}
		toast.success("Quick note added to scratchpad");
	}
	function handleDeleteNote(id) {
		const updated = notes.filter((n) => n.id !== id);
		setNotes(updated);
		if (typeof window !== "undefined" && window.sessionStorage) try {
			sessionStorage.setItem("hi_rider_scratchpad_notes", JSON.stringify(updated));
		} catch (err) {
			console.warn(err);
		}
		toast.info("Note removed");
	}
	function handleCopyNote(id, text) {
		if (typeof navigator !== "undefined" && navigator.clipboard) {
			navigator.clipboard.writeText(text);
			setCopiedId(id);
			setTimeout(() => setCopiedId(null), 2e3);
			toast.success("Copied to clipboard");
		}
	}
	function handleClearAll() {
		setScratchpadText("");
		setNotes([]);
		if (typeof window !== "undefined" && window.sessionStorage) try {
			sessionStorage.removeItem("hi_rider_scratchpad_text");
			sessionStorage.removeItem("hi_rider_scratchpad_notes");
		} catch (err) {
			console.warn(err);
		}
		toast.success("Scratchpad cleared");
	}
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "outline",
		size: "sm",
		className: "gap-2 h-9",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, {
			size: 14,
			className: "text-amber-500"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Scratchpad" })]
	});
	const totalCount = notes.length + (scratchpadText.trim() ? 1 : 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				className: "gap-2 h-9 relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, {
						size: 14,
						className: "text-amber-500"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Scratchpad" }),
					totalCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-4 h-4 text-xs font-medium tabular-nums bg-amber-500 text-white rounded-full flex items-center justify-center",
						children: totalCount
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: "right",
			className: "w-full sm:max-w-md flex flex-col p-6 overflow-y-auto bg-background border-l border-border",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, {
					className: "pb-4 border-b border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-8 h-8 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { size: 18 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetTitle, {
							className: "text-lg font-semibold text-foreground",
							children: [department, " Floor Scratchpad"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, {
							className: "text-sm text-muted-foreground",
							children: "Session-only notes. Kept during your shift without touching the database."
						})] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 py-4 space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleAddNote,
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								htmlFor: "scratchpad-note-input",
								className: "registration-label block",
								children: "Add Quick Floor Reminder"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: "scratchpad-note-input",
									type: "text",
									placeholder: "e.g. Bay 2 torque wrench recalibration, test drive note...",
									value: newNoteInput,
									onChange: (e) => setNewNoteInput(e.target.value),
									className: "registration-input flex-1"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "submit",
									size: "sm",
									className: "registration-submit-btn gap-1.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 13 }), " Add"]
								})]
							})]
						}),
						notes.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-between text-xs text-muted-foreground font-medium",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Active Shift Notes (",
									notes.length,
									")"
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2 max-h-48 overflow-y-auto pr-1",
								children: notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3 bg-muted/60 border border-border rounded-lg flex items-start justify-between gap-3 group transition-colors hover:bg-muted",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1 flex-1 min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-normal text-foreground break-words",
											children: note.text
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1 text-xs font-medium text-muted-foreground tabular-nums",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { size: 10 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: note.time })]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => handleCopyNote(note.id, note.text),
											className: "p-1 rounded text-muted-foreground hover:text-foreground hover:bg-background transition-colors",
											title: "Copy note",
											"aria-label": "Copy note",
											children: copiedId === note.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
												size: 13,
												className: "text-emerald-500"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { size: 13 })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => handleDeleteNote(note.id),
											className: "p-1 rounded text-muted-foreground hover:text-destructive hover:bg-background transition-colors",
											title: "Delete note",
											"aria-label": "Delete note",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 13 })
										})]
									})]
								}, note.id))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-semibold text-muted-foreground uppercase tracking-label block",
									children: "Freeform Scratchpad"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-medium text-muted-foreground",
									children: "Auto-saved to session"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								rows: 8,
								value: scratchpadText,
								onChange: (e) => handleSaveText(e.target.value),
								placeholder: "Paste part numbers, measurements, diagnostic readings, or notes here. This workspace is ephemeral and auto-saved for your current browser session...",
								className: "w-full p-3 bg-background border border-border rounded-xl text-sm font-normal text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary leading-relaxed resize-none"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pt-4 border-t border-border flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5 text-xs font-medium text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {
							size: 12,
							className: "text-amber-500"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Session storage only · No DB writes" })]
					}), (notes.length > 0 || scratchpadText.trim()) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: handleClearAll,
						className: "gap-1.5 text-destructive hover:text-destructive hover:bg-destructive/10 h-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 12 }), " Clear Scratchpad"]
					})]
				})
			]
		})]
	});
}
function EmployeeDashboard() {
	const { employeeDepartment, setEmployeeDepartment, vehicles, jobs, setJobs, requisitions, addActivity, loading } = useWorkspace();
	const [selectedJobForProgress, setSelectedJobForProgress] = (0, import_react.useState)(null);
	const [newProgress, setNewProgress] = (0, import_react.useState)(50);
	const [newStatus, setNewStatus] = (0, import_react.useState)("In progress");
	const [progressNote, setProgressNote] = (0, import_react.useState)("");
	const [jobFilterTab, setJobFilterTab] = (0, import_react.useState)("All");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [jobSort, setJobSort] = (0, import_react.useState)(null);
	const [reqSort, setReqSort] = (0, import_react.useState)(null);
	const departmentJobs = (0, import_react.useMemo)(() => {
		return jobs.filter((job) => job.department.toLowerCase() === employeeDepartment.toLowerCase() || job.department === "Workshop" || !job.department);
	}, [jobs, employeeDepartment]);
	const filteredAndSortedJobs = (0, import_react.useMemo)(() => {
		const result = departmentJobs.filter((job) => {
			const vehicle = vehicles.find((v) => v.id === job.vehicleId);
			if (jobFilterTab !== "All") {
				const normStatus = job.status.toLowerCase();
				if (jobFilterTab === "Pending") {
					if (!normStatus.includes("pending") && !normStatus.includes("awaiting")) return false;
				} else if (jobFilterTab === "Approved") {
					if (!normStatus.includes("approved") && !normStatus.includes("complete")) return false;
				} else if (jobFilterTab === "Flagged") {
					if (!normStatus.includes("rework") && !normStatus.includes("flag") && !normStatus.includes("reject")) return false;
				} else if (jobFilterTab === "In progress") {
					if (!normStatus.includes("progress")) return false;
				}
			}
			if (searchQuery.trim()) {
				const q = searchQuery.toLowerCase().trim();
				const matchesId = job.id.toLowerCase().includes(q);
				const matchesWork = job.work.toLowerCase().includes(q);
				const matchesDue = (job.due || "").toLowerCase().includes(q);
				const matchesStatus = job.status.toLowerCase().includes(q);
				const matchesVehicle = vehicle && (vehicle.make.toLowerCase().includes(q) || vehicle.plate.toLowerCase().includes(q) || vehicle.customer.toLowerCase().includes(q) || vehicle.received.toLowerCase().includes(q));
				if (!matchesId && !matchesWork && !matchesDue && !matchesStatus && !matchesVehicle) return false;
			}
			return true;
		});
		return sortRecords(result, jobSort, (job, key) => {
			switch (key) {
				case "id": return job.id;
				case "project": {
					const vehicle = vehicles.find((v) => v.id === job.vehicleId);
					return `${vehicle?.make ?? ""} ${vehicle?.customer ?? ""}`;
				}
				case "work": return job.work;
				case "status": return job.status;
				case "date": return job.due || "";
			}
		});
	}, [
		departmentJobs,
		vehicles,
		jobFilterTab,
		searchQuery,
		jobSort
	]);
	const departmentRequisitions = (0, import_react.useMemo)(() => {
		const filtered = requisitions.filter((req) => req.department.toLowerCase() === employeeDepartment.toLowerCase());
		return sortRecords(filtered, reqSort, (req, key) => {
			switch (key) {
				case "id": return req.id;
				case "vehicle": return req.vehicleId;
				case "part": return req.part;
				case "quantity": return req.quantity;
				case "status": return req.status;
				case "date": return req.date;
			}
		});
	}, [
		requisitions,
		employeeDepartment,
		reqSort
	]);
	const activeCount = departmentJobs.filter((j) => ![
		"COMPLETED",
		"CANCELLED",
		"CLOSED"
	].includes(j.status.toUpperCase())).length;
	const pendingReqCount = departmentRequisitions.filter((r) => r.status === "Pending").length;
	function handleClearAllFilters() {
		setJobFilterTab("All");
		setSearchQuery("");
		setJobSort(null);
		toast.success("Filters cleared: showing all department records");
	}
	function handleUpdateProgress(e) {
		e.preventDefault();
		if (!selectedJobForProgress) return;
		setJobs((prev) => prev.map((j) => j.id === selectedJobForProgress.id ? {
			...j,
			status: newStatus
		} : j));
		addActivity({
			text: `${employeeDepartment} updated job ${selectedJobForProgress.id} to ${newStatus} (${newProgress}%)`,
			detail: `${employeeDepartment} · ${progressNote || "Daily progress update recorded"}`,
			time: (/* @__PURE__ */ new Date()).toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			})
		});
		toast.success(`Job ${selectedJobForProgress.id} progress updated to ${newProgress}% (${newStatus})`);
		setSelectedJobForProgress(null);
		setProgressNote("");
	}
	const isFiltered = jobFilterTab !== "All" || Boolean(searchQuery.trim()) || jobSort !== null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
				title: `${employeeDepartment} Department Portal`,
				subtitle: `Manage repair tasks, log daily progress, and submit parts requisitions for the ${employeeDepartment} workshop floor.`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2.5 flex-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmployeeScratchpad, { department: employeeDepartment }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						"aria-label": "Select employee department",
						className: "h-9 px-3 bg-background border border-[#d1d5db] rounded-[5px] text-sm font-normal text-foreground focus:outline-none focus:border-primary",
						value: employeeDepartment,
						onChange: (e) => {
							setEmployeeDepartment(e.target.value);
							toast.success(`Switched to ${e.target.value} department view`);
						},
						children: departments.map((dept) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: dept,
							children: dept
						}, dept))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metrics, { items: [
				{
					label: "Active Department Jobs",
					value: activeCount,
					hint: `${departmentJobs.length} total assigned to floor`,
					icon: Wrench
				},
				{
					label: "Completed Jobs",
					value: departmentJobs.length - activeCount,
					hint: departmentJobs.length ? `${Math.round((departmentJobs.length - activeCount) / departmentJobs.length * 100)}% floor completion` : "No jobs assigned yet",
					icon: CheckCircle2,
					tone: "success"
				},
				{
					label: "Pending Requisitions",
					value: pendingReqCount,
					hint: `${departmentRequisitions.length} total requisitions`,
					icon: Package,
					tone: pendingReqCount > 0 ? "warning" : "default"
				},
				{
					label: "Department Efficiency",
					value: departmentJobs.length ? `${Math.round((departmentJobs.length - activeCount) / departmentJobs.length * 100)}%` : "0%",
					hint: "Live job completion index",
					icon: ClipboardList
				}
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
							title: "Department Job Queue",
							subtitle: "Active repair orders and job cards assigned to your department."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/job-cards",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								className: "gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { size: 14 }), " View All Job Cards"]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col lg:flex-row lg:items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center gap-1 p-1 bg-muted border border-border rounded-[6px] overflow-x-auto max-w-full",
								children: [
									"All",
									"Pending",
									"In progress",
									"Approved",
									"Flagged"
								].map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setJobFilterTab(tab),
									className: `px-3 py-1.5 text-sm font-medium whitespace-nowrap rounded-[4px] transition-colors cursor-pointer ${jobFilterTab === tab ? "bg-background text-primary shadow-none border border-border" : "text-muted-foreground hover:text-foreground"}`,
									children: tab
								}, tab))
							}), isFiltered && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: handleClearAllFilters,
								className: "gap-1.5",
								title: "Reset search and filters",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 13 }), "Clear All Filters"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarSearch, {
							ariaLabel: "Search department jobs",
							placeholder: "Search project name, date, ID...",
							value: searchQuery,
							onChange: setSearchQuery
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
						headers: [
							{
								label: "Job Card",
								sortKey: "id"
							},
							{
								label: "Project & Customer",
								sortKey: "project"
							},
							{
								label: "Work Description",
								sortKey: "work"
							},
							{
								label: "Status",
								sortKey: "status"
							},
							{
								label: "Submission / Due Date",
								sortKey: "date"
							},
							"Actions"
						],
						loading,
						sort: jobSort,
						onSort: (key) => setJobSort((current) => nextSortState(current, key)),
						empty: filteredAndSortedJobs.length === 0,
						emptyState: isFiltered ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							icon: Search,
							tone: "muted",
							title: "No jobs match your filters",
							description: "Try switching status tabs, clearing your search query, or resetting column sorting.",
							action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: handleClearAllFilters,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Clear All Filters"]
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							icon: Wrench,
							title: `No jobs in ${employeeDepartment}`,
							description: `There are currently no repair orders assigned to the ${employeeDepartment} department.`,
							action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/job-cards",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, {}), "View All Job Cards"]
								})
							})
						}),
						children: filteredAndSortedJobs.map((job) => {
							const vehicle = vehicles.find((v) => v.id === job.vehicleId);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums font-semibold text-foreground",
									children: job.id
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: vehicle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: job.vehicleId }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground max-w-xs truncate block",
									children: job.work
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: job.status }) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-muted-foreground",
									children: job.due || "14 Nov 2026"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => {
										setSelectedJobForProgress(job);
										setNewStatus(job.status);
									},
									children: "Update Progress"
								}) })
							] }, job.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableFooter, {
						count: filteredAndSortedJobs.length,
						label: "jobs"
					})
				]
			}),
			selectedJobForProgress && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-panel max-w-lg w-full shadow-xl overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-header",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", { children: ["Update Progress · ", selectedJobForProgress.id] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "sm",
							"aria-label": "Close modal",
							onClick: () => setSelectedJobForProgress(null),
							children: "✕"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleUpdateProgress,
						onReset: (e) => {
							e.preventDefault();
							setNewStatus(selectedJobForProgress.status);
							setNewProgress(50);
							setProgressNote("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-stack",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "emp-task-status",
										className: "registration-label",
										children: ["Task Status ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "registration-required",
											children: "*"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										id: "emp-task-status",
										className: "registration-input w-full",
										value: newStatus,
										onChange: (e) => setNewStatus(e.target.value),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "In progress",
												children: "In progress"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Pending",
												children: "Pending"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Awaiting parts",
												children: "Awaiting parts"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Approved",
												children: "Approved"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Complete",
												children: "Complete"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Flagged",
												children: "Flagged"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "Rework required",
												children: "Rework required"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: "emp-task-progress",
										className: "registration-label",
										children: [
											"Progress (",
											newProgress,
											"%)"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "emp-task-progress",
										type: "range",
										min: "0",
										max: "100",
										value: newProgress,
										onChange: (e) => setNewProgress(Number(e.target.value)),
										className: "w-full accent-primary"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact registration-row-top",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										htmlFor: "emp-task-note",
										className: "registration-label",
										children: "Progress Note"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										id: "emp-task-note",
										rows: 3,
										className: "registration-textarea w-full",
										placeholder: "Describe parts fitted, repairs performed, or technician observations...",
										value: progressNote,
										onChange: (e) => setProgressNote(e.target.value)
									})]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-actions-compact",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "submit",
									className: "registration-submit-btn",
									children: "Submit"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "reset",
									variant: "outline",
									className: "registration-reset-btn",
									children: "Reset"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "outline",
									className: "registration-reset-btn",
									onClick: () => setSelectedJobForProgress(null),
									children: "Cancel"
								})
							]
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeading, {
						title: "Department Parts Requisitions",
						subtitle: "Recent parts requests submitted by your department."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/requisitions",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							className: "gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " New Requisition"]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					headers: [
						{
							label: "Requisition",
							sortKey: "id"
						},
						{
							label: "Vehicle",
							sortKey: "vehicle"
						},
						{
							label: "Part Name",
							sortKey: "part"
						},
						{
							label: "Quantity",
							sortKey: "quantity",
							align: "right"
						},
						{
							label: "Status",
							sortKey: "status"
						},
						{
							label: "Date",
							sortKey: "date"
						}
					],
					loading,
					sort: reqSort,
					onSort: (key) => setReqSort((current) => nextSortState(current, key)),
					empty: departmentRequisitions.length === 0,
					emptyState: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						icon: Package,
						title: `No parts requisitions for ${employeeDepartment}`,
						description: "Submit a parts requisition when replacement components or consumables are needed for a repair.",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/requisitions",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "New Requisition"]
							})
						})
					}),
					children: departmentRequisitions.map((req) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums font-semibold text-foreground",
							children: req.id
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground",
							children: req.vehicleId
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground font-medium",
							children: req.part
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "text-right tabular-nums",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: req.quantity
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: req.status }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-muted-foreground",
							children: req.date
						}) })
					] }, req.id))
				})]
			})
		]
	});
}
var SplitComponent = EmployeeDashboard;
//#endregion
export { SplitComponent as component };
