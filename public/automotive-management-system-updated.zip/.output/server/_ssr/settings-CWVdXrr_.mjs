import { n as require_jsx_runtime } from "../_libs/@fortawesome/react-fontawesome+[...].mjs";
import { _t as useWorkspace } from "./button-BBYFtzM6.mjs";
import { s as PageHeading } from "./shared-d2hkU1_Q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-CWVdXrr_.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const w = useWorkspace();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeading, {
		title: "Account Settings",
		subtitle: "Your current workspace view"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-lg border bg-card p-5 text-sm space-y-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: "Current view:"
			}),
			" ",
			w.role
		] })
	})] });
}
//#endregion
export { SettingsPage as component };
