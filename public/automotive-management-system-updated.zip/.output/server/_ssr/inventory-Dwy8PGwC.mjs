import { n as require_jsx_runtime } from "../_libs/@fortawesome/react-fontawesome+[...].mjs";
import { t as RecordsPage } from "./record-pages-n9pGtuMy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory-Dwy8PGwC.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordsPage, { kind: "inventory" });
//#endregion
export { SplitComponent as component };
