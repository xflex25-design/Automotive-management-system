import { r as DepartmentsPage } from "./monitor-pages-C0fryP1_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/departments-BruShQXI.js
var SplitComponent = DepartmentsPage;
//#endregion
export { SplitComponent as component };
