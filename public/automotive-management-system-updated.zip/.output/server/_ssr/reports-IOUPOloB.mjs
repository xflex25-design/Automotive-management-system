import { a as ReportsPage } from "./monitor-pages-C0fryP1_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-IOUPOloB.js
var SplitComponent = ReportsPage;
//#endregion
export { SplitComponent as component };
