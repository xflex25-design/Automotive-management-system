import { t as AlertsPage } from "./monitor-pages-C0fryP1_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/alerts-BbFGs9QR.js
var SplitComponent = AlertsPage;
//#endregion
export { SplitComponent as component };
