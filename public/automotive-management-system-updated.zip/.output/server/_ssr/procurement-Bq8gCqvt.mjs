import { i as ProcurementPage } from "./monitor-pages-C0fryP1_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement-Bq8gCqvt.js
var SplitComponent = ProcurementPage;
//#endregion
export { SplitComponent as component };
