import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/@fortawesome/react-fontawesome+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { B as Save, C as FileText, G as ShieldCheck, H as Send, I as Package, L as Plus, R as Printer, V as Search, _ as ClipboardList, _t as useWorkspace, ct as cn, f as Check, ft as money, g as ClipboardCheck, i as ArrowUpRight, it as backendApi, l as Camera, mt as sortRecords, n as Archive, ot as canCreateInventory, pt as nextSortState, rt as X, s as Button, st as canDecideParts, ut as departments, z as RotateCcw } from "./button-BBYFtzM6.mjs";
import { n as Textarea, t as Input } from "./textarea-Cb3rjgmV.mjs";
import { _ as TableRow, d as Table, f as TableBody, g as TableHeader, h as TableHead, i as ExportButton, m as TableFooter, p as TableCell, r as EmptyState, s as PageHeading, t as DataTable, u as Status, v as ToolbarSearch, y as VehicleCell } from "./shared-d2hkU1_Q.mjs";
import { i as Check$1, n as ChevronUp, r as ChevronDown } from "../_libs/lucide-react.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, o as VehicleDetail, r as DialogDescription, t as Dialog } from "./vehicle-detail-CJwnoZF3.mjs";
import { a as SelectItemIndicator, c as SelectPortal, d as SelectSeparator$1, f as SelectTrigger$1, i as SelectItem$1, l as SelectScrollDownButton$1, m as SelectViewport, n as SelectContent$1, o as SelectItemText, p as SelectValue$1, r as SelectIcon, s as SelectLabel$1, t as Select$1, u as SelectScrollUpButton$1 } from "../_libs/@radix-ui/react-select+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/record-pages-n9pGtuMy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Select = Select$1;
var SelectValue = SelectValue$1;
var SelectTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectTrigger$1, {
	ref,
	className: cn("flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm font-normal shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectIcon, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 opacity-50" })
	})]
}));
SelectTrigger.displayName = SelectTrigger$1.displayName;
var SelectScrollUpButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { className: "h-4 w-4" })
}));
SelectScrollUpButton.displayName = SelectScrollUpButton$1.displayName;
var SelectScrollDownButton = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton$1, {
	ref,
	className: cn("flex cursor-default items-center justify-center py-1", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4" })
}));
SelectScrollDownButton.displayName = SelectScrollDownButton$1.displayName;
var SelectContent = import_react.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent$1, {
	ref,
	className: cn("relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)", position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1", className),
	position,
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollUpButton, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectViewport, {
			className: cn("p-1", position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectScrollDownButton, {})
	]
}) }));
SelectContent.displayName = SelectContent$1.displayName;
var SelectLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectLabel$1, {
	ref,
	className: cn("px-2 py-1.5 text-xs font-semibold tracking-label", className),
	...props
}));
SelectLabel.displayName = SelectLabel$1.displayName;
var SelectItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem$1, {
	ref,
	className: cn("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm font-normal outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check$1, { className: "h-4 w-4" }) })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItemText, { children })]
}));
SelectItem.displayName = SelectItem$1.displayName;
var SelectSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectSeparator$1, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
SelectSeparator.displayName = SelectSeparator$1.displayName;
var QUOTATION_VAT_RATE = 16;
var nextDraftLineSeq = 1;
var createDraftLineRowId = () => `qline-${nextDraftLineSeq++}`;
var initialQuotationLines = () => [
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "air filter",
		description: "ford",
		unitPrice: "450.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "oil filter",
		description: "ford",
		unitPrice: "250.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "fuel filter",
		description: "ford",
		unitPrice: "250.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "cabin filter",
		description: "ford",
		unitPrice: "350.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "2",
		item: "wipers",
		description: "ford",
		unitPrice: "350.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "brake pads",
		description: "ford",
		unitPrice: "1950.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "brake pads",
		description: "ford",
		unitPrice: "1950.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "brake booster",
		description: "ford",
		unitPrice: "1950.00"
	},
	{
		rowId: createDraftLineRowId(),
		quantity: "1",
		item: "labour",
		description: "ford",
		unitPrice: "2000.00"
	}
];
var emptyQuotationLine = () => ({
	rowId: createDraftLineRowId(),
	item: "",
	description: "",
	quantity: "1",
	unitPrice: ""
});
var initialPaperFields = () => ({
	companyName: "Hirider 4x4 World (Kwacha)",
	address: "Makeni Road, Lusaka",
	email: "mkessa@hotmail.com",
	phone: "+260 966 766 693",
	bankName: "Access Bank",
	accountNumber: "0060211407831",
	vatNumber: "1004021290",
	quoteNo: "12844",
	date: "13/10/2026",
	salesperson: "PRECIOUS",
	billTo1: "RTSA",
	billTo2: "RTSA",
	shipTo1: "RTSA",
	shipTo2: "FORD RANGER",
	shipTo3: "BAK 6213",
	preparedBy: "PRECIOUS",
	signature: "",
	invoiceReference: ""
});
var roundMoney = (amount) => Math.round((amount + Number.EPSILON) * 100) / 100;
var config = {
	quotations: {
		title: "Quotation Management",
		subtitle: "Prepare quotations and record customer authorization",
		singular: "quotation",
		headers: [
			{
				label: "Quotation",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Customer",
				sortKey: "customer"
			},
			{
				label: "Amount",
				sortKey: "amount",
				align: "right"
			},
			{
				label: "Status",
				sortKey: "status"
			},
			"Actions"
		]
	},
	inventory: {
		title: "Inventory Cards",
		subtitle: "Vehicle belongings, accessories and condition records",
		singular: "inventory card",
		headers: [
			{
				label: "Inventory card",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Items recorded",
				sortKey: "items"
			},
			{
				label: "Created",
				sortKey: "date"
			},
			"Actions"
		]
	},
	jobs: {
		title: "Job Card Management",
		subtitle: "Assign repair work to the relevant workshop departments",
		singular: "job card",
		headers: [
			{
				label: "Job card",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Work instructions",
				sortKey: "work"
			},
			{
				label: "Status",
				sortKey: "status"
			},
			"Actions"
		]
	},
	requisitions: {
		title: "Parts Requisitions",
		subtitle: "Required parts, director authorization and purchasing status",
		singular: "parts requisition",
		headers: [
			{
				label: "Requisition",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Part / item",
				sortKey: "part"
			},
			{
				label: "Qty",
				sortKey: "quantity",
				align: "right"
			},
			{
				label: "Status",
				sortKey: "status"
			},
			"Actions"
		]
	},
	inspections: {
		title: "Vehicle Inspections",
		subtitle: "Final checks, inspection results and foreman sign-off",
		singular: "inspection",
		headers: [
			{
				label: "Inspection",
				sortKey: "id"
			},
			{
				label: "Vehicle",
				sortKey: "vehicle"
			},
			{
				label: "Foreman",
				sortKey: "foreman"
			},
			{
				label: "Date",
				sortKey: "date"
			},
			{
				label: "Result",
				sortKey: "result"
			},
			"Actions"
		]
	}
};
function QuotationItemsTable({ items, rowKeyPrefix, className }) {
	const [itemSort, setItemSort] = (0, import_react.useState)(null);
	const sortedItems = sortRecords(items, itemSort, (entry, key) => {
		switch (key) {
			case "quantity": return entry.quantity;
			case "item": return entry.item;
			case "description": return entry.description;
			case "unitPrice": return entry.unitPrice;
			case "total": return entry.lineTotal ?? entry.quantity * entry.unitPrice;
		}
	});
	const toggle = (key) => setItemSort((current) => nextSortState(current, key));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				align: "right",
				sortDirection: itemSort?.key === "quantity" ? itemSort.direction : null,
				onSort: () => toggle("quantity"),
				children: "Qty"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				sortDirection: itemSort?.key === "item" ? itemSort.direction : null,
				onSort: () => toggle("item"),
				children: "Item"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				sortDirection: itemSort?.key === "description" ? itemSort.direction : null,
				onSort: () => toggle("description"),
				children: "Description"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				align: "right",
				sortDirection: itemSort?.key === "unitPrice" ? itemSort.direction : null,
				onSort: () => toggle("unitPrice"),
				children: "Unit Price"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
				align: "right",
				sortDirection: itemSort?.key === "total" ? itemSort.direction : null,
				onSort: () => toggle("total"),
				children: "Total"
			})
		] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: sortedItems.map((entry, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right tabular-nums",
				children: entry.quantity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: entry.item }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: entry.description }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right tabular-nums",
				children: money(entry.unitPrice)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right tabular-nums",
				children: money(entry.lineTotal ?? entry.quantity * entry.unitPrice)
			})
		] }, `${rowKeyPrefix}-${entry.item}-${index}`)) })]
	}), sortedItems.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "empty-state-wrap",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			compact: true,
			icon: FileText,
			tone: "muted",
			title: "No quotation line items",
			description: "No itemized parts or labour entries are recorded on this quotation yet."
		})
	})] });
}
function RecordsPage({ kind }) {
	const w = useWorkspace();
	const [query, setQuery] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("All");
	const [sort, setSort] = (0, import_react.useState)(null);
	const [create, setCreate] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setSort(null);
	}, [kind]);
	const [paperInventory, setPaperInventory] = (0, import_react.useState)([]);
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [request, setRequest] = (0, import_react.useState)(null);
	const [selectedInspection, setSelectedInspection] = (0, import_react.useState)(null);
	const [quote, setQuote] = (0, import_react.useState)(null);
	const [paperQuote, setPaperQuote] = (0, import_react.useState)(null);
	const [recordDetail, setRecordDetail] = (0, import_react.useState)(null);
	const [approvalView, setApprovalView] = (0, import_react.useState)(null);
	const [approvalToken, setApprovalToken] = (0, import_react.useState)("");
	const [approvalDecisions, setApprovalDecisions] = (0, import_react.useState)({});
	const c = config[kind];
	const records = kind === "quotations" ? w.quotations : kind === "inventory" ? [...paperInventory, ...w.inventory] : kind === "jobs" ? w.jobs : kind === "requisitions" ? w.requisitions : w.inspections;
	const matches = (row) => {
		const vehicle = w.vehicleFor(row.vehicleId);
		return `${row.id} ${vehicle?.make} ${vehicle?.plate} ${vehicle?.customer}`.toLowerCase().includes(`${query} ${w.search}`.trim().toLowerCase()) && (filter === "All" || row.status === filter || row.result === filter);
	};
	const count = records.filter(matches).length;
	const isFiltered = Boolean(query.trim() || w.search.trim() || filter !== "All");
	const emptyMeta = {
		quotations: {
			icon: FileText,
			title: "No quotations created yet",
			description: "Prepare itemized customer quotations and record authorization status here."
		},
		inventory: {
			icon: Archive,
			title: "No inventory cards recorded",
			description: "Document vehicle accessories, belongings, fuel levels, and incoming condition notes."
		},
		jobs: {
			icon: ClipboardList,
			title: "No job cards open",
			description: "Create job cards to assign repair instructions to workshop departments."
		},
		requisitions: {
			icon: Package,
			title: "No parts requisitions submitted",
			description: "Request replacement parts and consumables for director authorization and purchasing."
		},
		inspections: {
			icon: ClipboardCheck,
			title: "No vehicle inspections recorded",
			description: "Record final quality checks and foreman sign-off before releasing completed vehicles."
		}
	}[kind];
	const createLabel = kind === "inventory" ? "New vehicle inventory" : `New ${c.singular}`;
	const choices = kind === "quotations" ? [
		"Draft",
		"Awaiting approval",
		"Approved"
	] : kind === "requisitions" ? [
		"Pending",
		"Approved",
		"Rejected",
		"Ordered",
		"Dispatched"
	] : kind === "jobs" ? [
		"In progress",
		"Awaiting parts",
		"Complete"
	] : kind === "inspections" ? [
		"Pending",
		"Passed",
		"Rework required"
	] : [];
	function sendQuote(q) {
		w.setQuotations((prev) => prev.map((item) => item.id === q.id ? {
			...item,
			status: "Awaiting approval"
		} : item));
		w.updateVehicleStage(q.vehicleId, 2);
		w.addActivity(`Quotation marked as sent to customer`, q.id);
		toast.success("Quotation marked as sent. Awaiting customer authorization.");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PageHeading, {
			title: c.title,
			subtitle: c.subtitle,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
					filename: kind,
					rows: records
				}),
				w.role === "Foreman" && kind === "inventory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setCreate(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "New vehicle inventory"]
				}),
				w.role === "Foreman" && kind !== "inventory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setCreate(true),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}),
						"New ",
						c.singular
					]
				})
			]
		}),
		w.error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "alert",
			className: "rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive",
			children: [
				w.error,
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => void w.refresh(),
					children: "Retry"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "toolbar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolbarSearch, {
				ariaLabel: `Search ${c.title}`,
				placeholder: `Search ${c.title.toLowerCase()}...`,
				value: query,
				onChange: setQuery
			}), choices.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: filter,
				onValueChange: setFilter,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: "w-[175px] h-[38px] rounded-[6px] border-[#d1d5db] bg-background text-sm font-normal shadow-none",
					"aria-label": "Filter status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: "All",
					children: "All statuses"
				}), choices.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
					value: s,
					children: s
				}, s))] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTable, {
			headers: c.headers,
			loading: w.loading,
			sort,
			onSort: (key) => setSort((current) => nextSortState(current, key)),
			empty: count === 0,
			emptyState: isFiltered ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Search,
				tone: "muted",
				title: `No matching ${c.title.toLowerCase()}`,
				description: "No records matched your current search term or selected status filter.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => {
						setQuery("");
						setFilter("All");
						w.setSearch("");
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Clear filters"]
				}), w.role === "Foreman" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setCreate(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), createLabel]
				})] })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: emptyMeta.icon,
				title: emptyMeta.title,
				description: emptyMeta.description,
				action: w.role === "Foreman" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setCreate(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), createLabel]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => void w.refresh(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Refresh records"]
				})
			}),
			children: [
				kind === "quotations" && sortRecords(w.quotations.filter(matches), sort, (q, key) => {
					const vehicle = w.vehicleFor(q.vehicleId);
					switch (key) {
						case "id": return q.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "customer": return vehicle?.customer ?? "";
						case "amount": return q.amount;
						case "status": return q.status;
						default: return "";
					}
				}).map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: q.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(q.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: w.vehicleFor(q.vehicleId)?.customer }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title text-right tabular-nums",
						children: money(q.amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: q.status }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							w.role === "Foreman" && q.status === "Draft" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => sendQuote(q),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {}), "Mark sent"]
							}),
							w.role === "Foreman" && q.status === "Awaiting approval" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => {
									setApprovalView(null);
									setApprovalToken("");
									setApprovalDecisions({});
									setQuote(q);
								},
								children: "Record approval"
							}),
							kind === "quotations" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => setPaperQuote(q),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), "Print / Preview"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								title: "Quotation details",
								"aria-label": `View ${q.id}`,
								onClick: () => setRecordDetail({
									title: q.id,
									body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(q.vehicleId) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 grid grid-cols-2 gap-3 text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "Bill To"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													w.vehicleFor(q.vehicleId)?.customer
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "Ship To"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													w.vehicleFor(q.vehicleId)?.customer,
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													w.vehicleFor(q.vehicleId)?.make,
													" ·",
													" ",
													w.vehicleFor(q.vehicleId)?.plate
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "Date"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													q.quotationDate ? new Date(q.quotationDate).toLocaleDateString() : "—"
												] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-muted-foreground",
														children: "Prepared By"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													q.preparedByName ?? "—"
												] })
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-4 overflow-x-auto rounded-md border",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotationItemsTable, {
												items: q.items ?? [],
												rowKeyPrefix: q.id
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "ml-auto mt-4 grid w-full max-w-xs grid-cols-2 gap-y-2 text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-right",
													children: money(q.subtotal ?? q.amount)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VAT" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-right",
													children: money(q.taxAmount ?? 0)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Total" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
													className: "text-right",
													children: money(q.amount)
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-5 text-center text-sm",
											children: "Thank you for your business."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: q.status })
										}),
										q.approvalReference && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-4 text-muted-foreground",
											children: q.approvalReference
										})
									] })
								}),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
							})
						]
					}) })
				] }, q.id)),
				kind === "inventory" && sortRecords([...paperInventory, ...w.inventory].filter(matches), sort, (i, key) => {
					const vehicle = w.vehicleFor(i.vehicleId);
					switch (key) {
						case "id": return i.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "items": return i.items;
						case "date": return i.date;
						default: return "";
					}
				}).map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: i.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(i.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "max-w-[280px] whitespace-normal leading-relaxed",
						children: i.items
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: i.date }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: "Inventory details",
						"aria-label": `View ${i.id}`,
						onClick: () => setRecordDetail({
							title: i.id,
							body: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: "paperFields" in i && i.paperFields ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperInventoryView, { fields: i.paperFields }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(i.vehicleId) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold mt-5 mb-2",
									children: "Vehicle belongings & accessories"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: i.items }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold mt-5 mb-2",
									children: "Condition record"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: i.condition })
							] }) })
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
					}) })
				] }, i.id)),
				kind === "jobs" && sortRecords(w.jobs.filter(matches), sort, (j, key) => {
					const vehicle = w.vehicleFor(j.vehicleId);
					switch (key) {
						case "id": return j.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "work": return j.work;
						case "status": return j.status;
						default: return "";
					}
				}).map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: j.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(j.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: j.work }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: j.status }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: "Job card details",
						"aria-label": `View ${j.id}`,
						onClick: () => setRecordDetail({
							title: `Job Card ${j.id}`,
							body: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(j.vehicleId) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3 text-xs bg-muted/30 p-3 rounded-lg border border-border/50",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground block text-[11px] font-semibold uppercase tracking-wider",
												children: "Department"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: j.department || "Workshop"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground block text-[11px] font-semibold uppercase tracking-wider",
												children: "Target Due Date"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: j.due || "To be confirmed"
											})] }),
											j.preparedBy && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground block text-[11px] font-semibold uppercase tracking-wider",
												children: "Prepared By"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium text-foreground",
												children: j.preparedBy
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground block text-[11px] font-semibold uppercase tracking-wider",
												children: "Status"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-1",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: j.status })
											})] })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1",
										children: "Work Instructions"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-foreground bg-background p-3 rounded border border-border/40 whitespace-pre-wrap",
										children: j.work
									})] }),
									j.remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1",
										children: "Foreman Remarks"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-foreground bg-muted/20 p-3 rounded border border-border/40 italic",
										children: j.remarks
									})] }),
									j.photos && j.photos.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h4", {
										className: "text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2",
										children: [
											"Damaged Vehicle Photographs (",
											j.photos.length,
											")"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "uploaded-photos",
										children: j.photos.map((url, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: url,
											target: "_blank",
											rel: "noopener noreferrer",
											className: "block overflow-hidden rounded border border-border hover:border-primary transition-colors",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: url,
												alt: `Damaged vehicle condition ${i + 1}`,
												className: "w-20 h-16 object-cover"
											})
										}, i))
									})] })
								]
							})
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
					}) })
				] }, j.id)),
				kind === "requisitions" && sortRecords(w.requisitions.filter(matches), sort, (r, key) => {
					const vehicle = w.vehicleFor(r.vehicleId);
					switch (key) {
						case "id": return r.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "part": return r.part;
						case "quantity": return r.quantity;
						case "status": return r.status;
						default: return "";
					}
				}).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: r.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(r.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: r.part }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "text-right tabular-nums",
						children: r.quantity
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: r.status }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setRequest(r),
						children: ["View request", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 12 })]
					}) })
				] }, r.id)),
				kind === "inspections" && sortRecords(w.inspections.filter(matches), sort, (i, key) => {
					const vehicle = w.vehicleFor(i.vehicleId);
					switch (key) {
						case "id": return i.id;
						case "vehicle": return `${vehicle?.make ?? ""} ${vehicle?.plate ?? ""}`;
						case "foreman": return i.foreman;
						case "date": return i.date;
						case "result": return i.result;
						default: return "";
					}
				}).map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "cell-title",
						children: i.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(i.vehicleId) }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: i.foreman }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: i.date }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: i.result }) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						title: "Inspection details",
						"aria-label": `View ${i.id}`,
						onClick: () => setSelectedInspection(i),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})
					}) })
				] }, i.id))
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableFooter, { count }),
		kind === "inventory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "attention-band mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Customer authorization comes first" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Inventory cards are generated by the backend during vehicle intake." })] })]
		}),
		kind === "requisitions" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "attention-band mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Director authorization required" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Submitted requisitions await the Director's approval before procurement." })] })]
		}),
		kind === "inventory" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewVehicleInventory, {
			open: create,
			onClose: () => setCreate(false),
			onSave: (fields) => {
				const id = `INV-${Date.now()}`;
				const vehicle = w.vehicles.find((item) => item.plate.toLowerCase() === fields.registrationNo.trim().toLowerCase());
				const items = fields.accessories.filter((item) => item.present === "Present").map((item) => `${item.name}${item.quantity ? ` (${item.quantity})` : ""}`).join(", ");
				const record = {
					id,
					vehicleId: vehicle?.id ?? "",
					items,
					condition: fields.damages.map((damage) => `${damage.type} ${damage.area}`).join("; "),
					date: fields.date
				};
				setPaperInventory((previous) => [{
					...record,
					paperFields: fields
				}, ...previous]);
				toast.success("Inventory captured for this session. The backend has no create endpoint yet.");
				setCreate(false);
			}
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateRecord, {
			kind,
			open: create,
			onClose: () => setCreate(false)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleDetail, {
			id: detail,
			onClose: () => setDetail(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestDetail, {
			request,
			onClose: () => setRequest(null),
			allowDecision: false
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InspectionDetail, {
			inspection: selectedInspection,
			onClose: () => setSelectedInspection(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!recordDetail,
			onOpenChange: (o) => {
				if (!o) setRecordDetail(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: recordDetail?.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Workshop record details" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm leading-relaxed",
				children: recordDetail?.body
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!paperQuote,
			onOpenChange: (isOpen) => {
				if (!isOpen) setPaperQuote(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "modal-scroll max-w-6xl sm:max-w-6xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Quotation preview" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Paper quotation layout" })] }), paperQuote && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaperQuotationPreview, {
					quotation: paperQuote,
					onPrint: () => window.print()
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: !!quote,
			onOpenChange: (o) => {
				if (!o) setQuote(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Record customer authorization" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				quote?.id,
				" · ",
				quote && w.vehicleFor(quote.vehicleId)?.customer
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => {
					e.preventDefault();
					if (!quote) return;
					if (!approvalView) {
						w.viewCustomerApproval(approvalToken).then(setApprovalView).catch((error) => toast.error(error.message));
						return;
					}
					const items = Array.isArray(approvalView["items"]) ? approvalView["items"] : [];
					if (items.some((item) => !approvalDecisions[Number(item["quotationItemId"] ?? item["itemId"])])) {
						toast.error("Choose a decision for every quotation item.");
						return;
					}
					w.submitCustomerApproval(approvalToken, items.map((item) => ({
						quotationItemId: Number(item["quotationItemId"] ?? item["itemId"]),
						decision: approvalDecisions[Number(item["quotationItemId"] ?? item["itemId"])]
					}))).then(async () => {
						await w.refresh();
						setQuote(null);
						setApprovalView(null);
						setApprovalToken("");
						toast.success("Customer decisions submitted to the backend.");
					}).catch((error) => toast.error(error.message));
				},
				children: [!approvalView ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-row-compact pt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						htmlFor: "auth-token-input",
						className: "registration-label",
						children: ["Authorization Token ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "registration-required",
							children: "*"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "auth-token-input",
						required: true,
						value: approvalToken,
						onChange: (e) => setApprovalToken(e.target.value),
						placeholder: "Enter the token received by the customer",
						className: "registration-input"
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3 pt-2",
					children: (Array.isArray(approvalView["items"]) ? approvalView["items"] : []).map((item) => {
						const id = Number(item["quotationItemId"] ?? item["itemId"]);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-row-compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "registration-label",
								children: String(item["description"] ?? item["itemName"] ?? `Item ${id}`)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: approvalDecisions[id] ?? "",
								onValueChange: (value) => setApprovalDecisions((prev) => ({
									...prev,
									[id]: value
								})),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "registration-select-trigger",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Choose decision" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "APPROVED",
									children: "Approve"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "REJECTED",
									children: "Reject"
								})] })]
							})]
						}, id);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-actions-modal",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						className: "registration-submit-btn",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), approvalView ? "Submit" : "Verify token"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						className: "registration-reset-btn",
						onClick: () => setQuote(null),
						children: "Cancel"
					})]
				})]
			})] })
		})
	] });
}
var inventoryAccessories = [
	"Sparewheel",
	"Jack",
	"Jack handle",
	"Triangles",
	"Wheel spanner",
	"Fire extinguisher",
	"Tool kit",
	"Wheel covers",
	"Car mats"
];
var newPaperInventoryFields = () => ({
	jobNo: "",
	registrationNo: "",
	make: "",
	date: (() => {
		const today = /* @__PURE__ */ new Date();
		return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
	})(),
	ownedBy: "",
	driver: "",
	accessories: inventoryAccessories.map((name) => ({
		name,
		present: "",
		...name === "Wheel covers" || name === "Car mats" ? { quantity: "" } : {}
	})),
	fuelIn: "",
	fuelOut: "",
	kmsIn: "",
	kmsOut: "",
	damages: Array.from({ length: 14 }, () => ({
		area: "",
		type: ""
	})),
	jobToBeDone: Array.from({ length: 14 }, () => ""),
	additional: Array.from({ length: 5 }, () => ({
		name: "",
		present: ""
	})),
	remarks: ["", ""],
	deliveredBy: "",
	deliveredSignature: "",
	deliveredTel: "",
	receivedCheckedBy: "",
	collectedBy: "",
	collectedSignature: "",
	collectedDate: "",
	collectedPhone: "",
	releasedBy: "",
	timeOut: ""
});
function NewVehicleInventory({ open, onClose, onSave }) {
	const [fields, setFields] = (0, import_react.useState)(newPaperInventoryFields);
	const [accessorySort, setAccessorySort] = (0, import_react.useState)(null);
	const setField = (key, value) => setFields((current) => ({
		...current,
		[key]: value
	}));
	const sortedAccessories = sortRecords(fields.accessories, accessorySort, (item, key) => {
		switch (key) {
			case "name": return item.name;
			case "present": return item.present;
			case "quantity": return item.quantity ? Number(item.quantity) || item.quantity : "";
		}
	});
	const input = "h-9";
	const statusOptions = ["Present", "Missing"];
	const renderStatus = (value, onChange, label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "group",
		"aria-label": label,
		className: "flex items-center gap-3 whitespace-nowrap text-sm",
		children: statusOptions.map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "radio",
					name: label,
					checked: value === status,
					onChange: () => onChange(status)
				}),
				status === "Present" ? "✓" : "✗",
				" ",
				status
			]
		}, status))
	});
	const renderText = (label, value, onChange) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "registration-row-compact min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "registration-label",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			className: "registration-input",
			value,
			onChange: (event) => onChange(event.target.value)
		})]
	});
	const renderFuel = (label, value, onChange) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
			className: "text-sm font-medium",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap gap-x-5 gap-y-2",
			children: [
				"E",
				"1/4",
				"1/2",
				"3/4",
				"F"
			].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "flex items-center gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "radio",
					name: label,
					checked: value === option,
					onChange: () => onChange(option)
				}), option]
			}, option))
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (isOpen) => !isOpen && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "modal-scroll max-w-6xl sm:max-w-6xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New vehicle inventory" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "VEHICLE INVENTORY" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-5",
				onSubmit: (event) => {
					event.preventDefault();
					onSave(fields);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "space-y-1 border-b pb-4 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg font-semibold",
								children: "Hirider 4x4 World"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kafue Road" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cell +260 966 766 693" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Email mkessa@hotmail.com" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "pt-2 text-lg font-semibold tracking-wide",
								children: "VEHICLE INVENTORY"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "registration-section-box",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "registration-section-title",
							children: "Vehicle & Customer Details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 p-5 md:grid-cols-2",
							children: [
								renderText("JOB No.", fields.jobNo, (value) => setField("jobNo", value)),
								renderText("Registration No.", fields.registrationNo, (value) => setField("registrationNo", value)),
								renderText("Make", fields.make, (value) => setField("make", value)),
								renderText("Date", fields.date, (value) => setField("date", value)),
								renderText("Owned by", fields.ownedBy, (value) => setField("ownedBy", value)),
								renderText("Driver", fields.driver, (value) => setField("driver", value))
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "ACCESSORIES"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-x-auto rounded-md border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									sortDirection: accessorySort?.key === "name" ? accessorySort.direction : null,
									onSort: () => setAccessorySort((current) => nextSortState(current, "name")),
									children: "Item"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									sortDirection: accessorySort?.key === "present" ? accessorySort.direction : null,
									onSort: () => setAccessorySort((current) => nextSortState(current, "present")),
									children: "Present (✓) / Missing (✗)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
									align: "right",
									sortDirection: accessorySort?.key === "quantity" ? accessorySort.direction : null,
									onSort: () => setAccessorySort((current) => nextSortState(current, "quantity")),
									children: "Quantity"
								})
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: sortedAccessories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: item.name }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: renderStatus(item.present, (present) => setField("accessories", fields.accessories.map((row) => row.name === item.name ? {
									...row,
									present
								} : row)), `${item.name} status`) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right tabular-nums",
									children: item.quantity !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: `${input} text-right tabular-nums`,
										"aria-label": `${item.name} quantity`,
										value: item.quantity,
										onChange: (event) => setField("accessories", fields.accessories.map((row) => row.name === item.name ? {
											...row,
											quantity: event.target.value
										} : row))
									})
								})
							] }, item.name)) })] })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-5 rounded-md border p-4 sm:grid-cols-2",
						children: [
							renderFuel("FUEL IN", fields.fuelIn, (value) => setField("fuelIn", value)),
							renderFuel("FUEL OUT", fields.fuelOut, (value) => setField("fuelOut", value)),
							renderText("KMS/Miles IN", fields.kmsIn, (value) => setField("kmsIn", value)),
							renderText("KMS/Miles OUT", fields.kmsOut, (value) => setField("kmsOut", value))
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "DAMAGES"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "C = Chip, D = Dent, S = Scratch"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-2 sm:grid-cols-2",
								children: fields.damages.map((damage, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-[1fr_110px] items-end gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Area ", index + 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											value: damage.area,
											onChange: (event) => setField("damages", fields.damages.map((row, i) => i === index ? {
												...row,
												area: event.target.value
											} : row))
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "field",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "C / D / S" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											className: "h-9 rounded-md border bg-background px-3 text-sm font-normal",
											value: damage.type,
											onChange: (event) => setField("damages", fields.damages.map((row, i) => i === index ? {
												...row,
												type: event.target.value
											} : row)),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "C",
													children: "C"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "D",
													children: "D"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "S",
													children: "S"
												})
											]
										})]
									})]
								}, index))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "JOB TO BE DONE"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-3 md:grid-cols-2",
								children: fields.jobToBeDone.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "registration-row-compact",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "registration-label",
										children: ["Line ", index + 1]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "registration-input",
										value: line,
										onChange: (event) => setField("jobToBeDone", fields.jobToBeDone.map((value, i) => i === index ? event.target.value : value))
									})]
								}, index))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								onClick: () => setField("jobToBeDone", [...fields.jobToBeDone, ""]),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add line"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "ADDITIONAL"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: fields.additional.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid items-end gap-3 sm:grid-cols-[1fr_auto]",
								children: [renderText(`Item ${index + 1}`, item.name, (name) => setField("additional", fields.additional.map((row, i) => i === index ? {
									...row,
									name
								} : row))), renderStatus(item.present, (present) => setField("additional", fields.additional.map((row, i) => i === index ? {
									...row,
									present
								} : row)), `Additional item ${index + 1} status`)]
							}, index))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Remarks"
						}), fields.remarks.map((remark, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "field",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Line ", index + 1] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: remark,
								onChange: (event) => setField("remarks", fields.remarks.map((value, i) => i === index ? event.target.value : value))
							})]
						}, index))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3 rounded-md border p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Customer's Conditions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Service Management"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "registration-section-box",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "registration-section-title",
							children: "Handover & Collection"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-4 p-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 md:grid-cols-2",
								children: [
									renderText("Delivered By", fields.deliveredBy, (value) => setField("deliveredBy", value)),
									renderText("Delivered Signature", fields.deliveredSignature, (value) => setField("deliveredSignature", value)),
									renderText("Delivered Tel", fields.deliveredTel, (value) => setField("deliveredTel", value)),
									renderText("Received & Checked By", fields.receivedCheckedBy, (value) => setField("receivedCheckedBy", value)),
									renderText("Collected By", fields.collectedBy, (value) => setField("collectedBy", value)),
									renderText("Collected Signature", fields.collectedSignature, (value) => setField("collectedSignature", value)),
									renderText("Collection Date", fields.collectedDate, (value) => setField("collectedDate", value)),
									renderText("Phone No", fields.collectedPhone, (value) => setField("collectedPhone", value)),
									renderText("Released By", fields.releasedBy, (value) => setField("releasedBy", value)),
									renderText("Time Out (Hrs)", fields.timeOut, (value) => setField("timeOut", value))
								]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-actions-flush",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								className: "registration-submit-btn",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), " Submit"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								className: "registration-reset-btn",
								onClick: () => setFields(newPaperInventoryFields()),
								children: "Reset"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								className: "registration-reset-btn",
								onClick: onClose,
								children: "Cancel"
							})
						]
					})
				]
			})]
		})
	});
}
function PaperInventoryView({ fields }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Hirider 4x4 World" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kafue Road" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cell +260 966 766 693" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Email mkessa@hotmail.com" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "VEHICLE INVENTORY" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2 sm:grid-cols-3",
				children: [
					["JOB No.", fields.jobNo],
					["Registration No.", fields.registrationNo],
					["Make", fields.make],
					["Date", fields.date],
					["Owned by", fields.ownedBy],
					["Driver", fields.driver]
				].map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: label }),
					": ",
					value
				] }, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "ACCESSORIES"
			}),
			fields.accessories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				item.name,
				":",
				" ",
				item.present === "Present" ? "✓ Present" : item.present === "Missing" ? "✗ Missing" : "",
				item.quantity ? ` · Quantity ${item.quantity}` : ""
			] }, item.name)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["FUEL IN: ", fields.fuelIn] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["FUEL OUT: ", fields.fuelOut] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["KMS/Miles IN: ", fields.kmsIn] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["KMS/Miles OUT: ", fields.kmsOut] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "DAMAGES (C = Chip, D = Dent, S = Scratch)"
			}),
			fields.damages.filter((row) => row.area || row.type).map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				row.area,
				" ",
				row.type
			] }, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "JOB TO BE DONE"
			}),
			fields.jobToBeDone.filter(Boolean).map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: line }, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "ADDITIONAL"
			}),
			fields.additional.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				item.name,
				" ",
				item.present === "Present" ? "✓" : item.present === "Missing" ? "✗" : ""
			] }, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Remarks"
			}),
			fields.remarks.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: line }, index)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Customer's Conditions"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "font-semibold",
				children: "Service Management"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"DELIVERED BY: ",
				fields.deliveredBy,
				" · Signature: ",
				fields.deliveredSignature,
				" · Tel:",
				" ",
				fields.deliveredTel
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["RECEIVED & CHECKED BY: ", fields.receivedCheckedBy] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"COLLECTED BY: ",
				fields.collectedBy,
				" · Signature: ",
				fields.collectedSignature,
				" · Date:",
				" ",
				fields.collectedDate,
				" · Phone No: ",
				fields.collectedPhone
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Released by: ",
				fields.releasedBy,
				" · Time Out (Hrs): ",
				fields.timeOut
			] })
		]
	});
}
function CreateRecord({ kind, open, onClose }) {
	const w = useWorkspace();
	const [vehicleId, setVehicleId] = (0, import_react.useState)("");
	const [catalogPartId, setCatalogPartId] = (0, import_react.useState)("");
	const [quotationLines, setQuotationLines] = (0, import_react.useState)(initialQuotationLines);
	const [lineSort, setLineSort] = (0, import_react.useState)(null);
	const [paperFields, setPaperFields] = (0, import_react.useState)(initialPaperFields);
	const editedPaperFields = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const [jobDepartment, setJobDepartment] = (0, import_react.useState)("Mechanical");
	const [jobDueDate, setJobDueDate] = (0, import_react.useState)("");
	const [jobRemarks, setJobRemarks] = (0, import_react.useState)("");
	const [jobPreparedByEmployeeId, setJobPreparedByEmployeeId] = (0, import_react.useState)("");
	const [jobPhotos, setJobPhotos] = (0, import_react.useState)([]);
	const [isDraggingPhoto, setIsDraggingPhoto] = (0, import_react.useState)(false);
	const photoInputRef = (0, import_react.useRef)(null);
	const c = config[kind];
	(0, import_react.useEffect)(() => {
		if (!open || kind !== "quotations") return;
		let active = true;
		Promise.resolve().then(() => backendApi.getCompanySettings()).then((settings) => {
			const settingFields = {
				companyName: "companyName",
				address: "address",
				email: "email",
				phone: "phone",
				bankName: "bankName",
				accountNumber: "bankAccountNumber",
				vatNumber: "vatNumber"
			};
			if (active) setPaperFields((current) => {
				const next = { ...current };
				for (const [field, source] of Object.entries(settingFields)) {
					const value = settings[source];
					if (!editedPaperFields.current.has(field) && typeof value === "string" && value) next[field] = value;
				}
				return next;
			});
		}).catch(() => void 0);
		return () => {
			active = false;
		};
	}, [kind, open]);
	(0, import_react.useEffect)(() => {
		if (open && kind === "quotations") {
			setQuotationLines(initialQuotationLines());
			setLineSort(null);
			setPaperFields(initialPaperFields());
			editedPaperFields.current = /* @__PURE__ */ new Set();
			setVehicleId("");
		}
	}, [kind, open]);
	(0, import_react.useEffect)(() => {
		if (open && kind === "jobs") {
			setJobDepartment("Mechanical");
			setJobDueDate("");
			setJobRemarks("");
			setJobPhotos([]);
			setIsDraggingPhoto(false);
			setVehicleId("");
			const employees = Array.isArray(w.workflowOptions["employees"]) ? w.workflowOptions["employees"] : [];
			const configuredEmployee = Number({
				"BASE_URL": "/",
				"DEV": false,
				"MODE": "production",
				"PROD": true,
				"SSR": true,
				"TSS_DEV_SERVER": "false",
				"TSS_DEV_SSR_STYLES_BASEPATH": "/",
				"TSS_DEV_SSR_STYLES_ENABLED": "true",
				"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
				"TSS_INLINE_CSS_ENABLED": "false",
				"TSS_ROUTER_BASEPATH": "",
				"TSS_SERVER_FN_BASE": "/_serverFn/"
			}["VITE_EMPLOYEE_ID"]);
			if (configuredEmployee > 0 && employees.some((e) => Number(e["id"]) === configuredEmployee)) setJobPreparedByEmployeeId(String(configuredEmployee));
			else if (employees.length > 0) setJobPreparedByEmployeeId(String(employees[0]["id"] ?? ""));
			else setJobPreparedByEmployeeId("foreman");
		}
	}, [
		open,
		kind,
		w.workflowOptions
	]);
	const handlePhotoFiles = (files) => {
		const fileArray = Array.from(files);
		if (fileArray.length === 0) return;
		fileArray.forEach((file) => {
			if (!file.type.startsWith("image/")) {
				toast.error(`${file.name} is not an image file.`);
				return;
			}
			if (file.size > 10485760) {
				toast.error(`${file.name} exceeds 10MB limit.`);
				return;
			}
			const reader = new FileReader();
			reader.onload = (event) => {
				const url = event.target?.result;
				if (url) setJobPhotos((prev) => [...prev, {
					id: `photo-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
					name: file.name,
					url,
					size: file.size
				}]);
			};
			reader.readAsDataURL(file);
		});
	};
	const removePhoto = (id) => {
		setJobPhotos((prev) => prev.filter((p) => p.id !== id));
	};
	(0, import_react.useEffect)(() => {
		if (!open || kind !== "quotations") return;
		const employees = Array.isArray(w.workflowOptions["employees"]) ? w.workflowOptions["employees"] : [];
		const configuredEmployee = Number({
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/"
		}["VITE_EMPLOYEE_ID"]);
		const name = String(employees.find((employee) => Number(employee["id"]) === configuredEmployee)?.["name"] ?? "");
		if (!name) return;
		setPaperFields((current) => ({
			...current,
			...editedPaperFields.current.has("salesperson") ? {} : { salesperson: name },
			...editedPaperFields.current.has("preparedBy") ? {} : { preparedBy: name }
		}));
	}, [
		kind,
		open,
		w.workflowOptions
	]);
	const eligible = w.vehicles.filter((v) => !v.released && (kind === "inventory" ? w.quotations.some((q) => q.vehicleId === v.id && canCreateInventory(q.status)) && !w.inventory.some((i) => i.vehicleId === v.id) : kind === "jobs" ? w.inventory.some((i) => i.vehicleId === v.id) || w.quotations.some((q) => q.vehicleId === v.id && canCreateInventory(q.status)) || v.stage >= 3 : kind === "requisitions" ? w.jobs.some((j) => j.vehicleId === v.id) || v.stage >= 4 : kind === "inspections" ? v.stage >= 5 : true));
	const quoteSubtotal = roundMoney(quotationLines.reduce((sum, line) => sum + (Number(line.quantity) || 0) * (Number(line.unitPrice) || 0), 0));
	const quoteTax = roundMoney(quotationLines.reduce((sum, line) => {
		return sum + roundMoney(roundMoney((Number(line.quantity) || 0) * (Number(line.unitPrice) || 0)) * QUOTATION_VAT_RATE / 100);
	}, 0));
	const quoteTotal = roundMoney(quoteSubtotal + quoteTax);
	const validQuotationLines = quotationLines.filter((line) => line.item.trim() && line.description.trim() && Number.isFinite(Number(line.quantity)) && Number(line.quantity) > 0 && Number.isFinite(Number(line.unitPrice)) && Number(line.unitPrice) > 0);
	const hasPartialLine = quotationLines.some((line) => (line.item.trim() || line.description.trim() || line.unitPrice.trim()) && !validQuotationLines.includes(line));
	const quoteMissingMessage = [
		!vehicleId ? "Select a registered vehicle." : "",
		validQuotationLines.length === 0 ? "Add at least one valid line with an item, description, positive quantity and price." : "",
		hasPartialLine ? "Complete or remove each partially filled line." : ""
	].filter(Boolean).join(" ");
	const updatePaperField = (field, value) => {
		editedPaperFields.current.add(field);
		setPaperFields((current) => ({
			...current,
			[field]: value
		}));
	};
	const fillFromVehicle = (field, value) => {
		if (!editedPaperFields.current.has(field)) setPaperFields((current) => ({
			...current,
			[field]: value
		}));
	};
	function submit(e) {
		e.preventDefault();
		if (!eligible.find((v) => v.id === vehicleId)) {
			toast.error("Select an eligible vehicle.");
			return;
		}
		const f = new FormData(e.currentTarget);
		const text = (name) => String(f.get(name) ?? "");
		if (kind === "requisitions" && !catalogPartId) {
			toast.error("Select a catalog part.");
			return;
		}
		let id = "";
		if (kind === "quotations") {
			if (hasPartialLine) {
				toast.error("Complete or remove each partially filled line.");
				return;
			}
			const normalizedLines = validQuotationLines.map((line) => ({
				...line,
				quantity: Number(line.quantity),
				unitPrice: Number(line.unitPrice)
			}));
			if (!normalizedLines.length) {
				toast.error("Add at least one quotation line item.");
				return;
			}
			if (!Number.isSafeInteger(Number({
				"BASE_URL": "/",
				"DEV": false,
				"MODE": "production",
				"PROD": true,
				"SSR": true,
				"TSS_DEV_SERVER": "false",
				"TSS_DEV_SSR_STYLES_BASEPATH": "/",
				"TSS_DEV_SSR_STYLES_ENABLED": "true",
				"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
				"TSS_INLINE_CSS_ENABLED": "false",
				"TSS_ROUTER_BASEPATH": "",
				"TSS_SERVER_FN_BASE": "/_serverFn/"
			}["VITE_EMPLOYEE_ID"])) || Number({
				"BASE_URL": "/",
				"DEV": false,
				"MODE": "production",
				"PROD": true,
				"SSR": true,
				"TSS_DEV_SERVER": "false",
				"TSS_DEV_SSR_STYLES_BASEPATH": "/",
				"TSS_DEV_SSR_STYLES_ENABLED": "true",
				"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
				"TSS_INLINE_CSS_ENABLED": "false",
				"TSS_ROUTER_BASEPATH": "",
				"TSS_SERVER_FN_BASE": "/_serverFn/"
			}["VITE_EMPLOYEE_ID"]) <= 0) {
				toast.error("Set VITE_EMPLOYEE_ID to an active workshop employee before creating a quotation.");
				return;
			}
			id = `NEW-${Date.now()}`;
			const items = normalizedLines.map((line) => ({
				itemType: line.item.trim().toLowerCase() === "labour" ? "LABOUR" : "PART",
				item: line.item.trim(),
				description: line.description.trim(),
				quantity: line.quantity,
				unitPrice: line.unitPrice,
				lineTotal: roundMoney(line.quantity * line.unitPrice),
				taxAmount: roundMoney(roundMoney(line.quantity * line.unitPrice) * QUOTATION_VAT_RATE / 100)
			}));
			w.setQuotations((prev) => [{
				id,
				vehicleId,
				amount: quoteTotal,
				subtotal: quoteSubtotal,
				taxAmount: quoteTax,
				description: items.map((item) => item.description).join("; "),
				preparedByName: paperFields["preparedBy"],
				paperFields,
				items,
				status: "Draft"
			}, ...prev]);
			w.updateVehicleStage(vehicleId, 1);
		}
		if (kind === "inventory") {
			id = `IC-${452 + w.inventory.length - 3}`;
			w.setInventory((prev) => [{
				id,
				vehicleId,
				items: text("items"),
				condition: text("condition"),
				date: "11 Nov 2026"
			}, ...prev]);
			w.updateVehicleStage(vehicleId, 4);
		}
		if (kind === "jobs") {
			id = `JC-${882 + w.jobs.length - 5}`;
			const selectedEmp = (Array.isArray(w.workflowOptions["employees"]) ? w.workflowOptions["employees"] : []).find((emp) => String(emp["id"]) === jobPreparedByEmployeeId);
			const preparedByName = selectedEmp ? String(selectedEmp["name"] ?? "") : jobPreparedByEmployeeId === "foreman" ? w.foreman : void 0;
			const preparedByEmpId = selectedEmp && Number(selectedEmp["id"]) > 0 ? Number(selectedEmp["id"]) : Number({
				"BASE_URL": "/",
				"DEV": false,
				"MODE": "production",
				"PROD": true,
				"SSR": true,
				"TSS_DEV_SERVER": "false",
				"TSS_DEV_SSR_STYLES_BASEPATH": "/",
				"TSS_DEV_SSR_STYLES_ENABLED": "true",
				"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
				"TSS_INLINE_CSS_ENABLED": "false",
				"TSS_ROUTER_BASEPATH": "",
				"TSS_SERVER_FN_BASE": "/_serverFn/"
			}["VITE_EMPLOYEE_ID"]) || void 0;
			const newJobPhotos = jobPhotos.map((p) => p.url);
			const finalDepartment = jobDepartment || text("department") || "Mechanical";
			w.setJobs((prev) => [{
				id,
				vehicleId,
				department: finalDepartment,
				work: text("description"),
				status: "Pending",
				due: text("due") || jobDueDate || "To be confirmed",
				remarks: (text("remarks") || jobRemarks).trim() || void 0,
				preparedBy: preparedByName,
				preparedByEmployeeId: preparedByEmpId,
				photos: newJobPhotos.length > 0 ? newJobPhotos : void 0
			}, ...prev]);
			w.setVehicles((prev) => prev.map((item) => item.id === vehicleId ? {
				...item,
				stage: Math.max(item.stage, 5),
				department: finalDepartment,
				...newJobPhotos.length > 0 ? { photos: [...item.photos ?? [], ...newJobPhotos] } : {}
			} : item));
		}
		if (kind === "requisitions") {
			id = `PR-${452 + w.requisitions.length - 6}`;
			w.setRequisitions((prev) => [{
				id,
				vehicleId,
				part: w.parts.find((part) => part.id === Number(catalogPartId))?.name ?? "",
				quantity: 1,
				department: "Workshop",
				reason: text("description"),
				amount: 0,
				foreman: w.foreman,
				status: "Pending",
				date: "11 Nov 2026"
			}, ...prev]);
			w.updateVehicleStage(vehicleId, 6);
		}
		if (kind === "inspections") {
			id = `IN-${213 + w.inspections.length - 2}`;
			w.setInspections((prev) => [{
				id,
				vehicleId,
				foreman: w.foreman,
				date: "11 Nov 2026",
				result: "Rework required",
				notes: text("description")
			}, ...prev]);
			w.setVehicles((prev) => prev.map((item) => item.id === vehicleId ? {
				...item,
				stage: 9,
				progress: 90
			} : item));
		}
		w.addActivity(`${c.singular.charAt(0).toUpperCase() + c.singular.slice(1)} ${kind === "requisitions" ? "submitted" : "created"}`, `${w.foreman} · ${id}`);
		toast.success(kind === "requisitions" ? `${id} submitted for Director authorization.` : `${id} saved.`);
		setVehicleId("");
		onClose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (o) => {
			if (!o) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: kind === "quotations" ? "modal-scroll max-w-6xl sm:max-w-6xl" : kind === "jobs" ? "modal-scroll max-w-2xl sm:max-w-2xl" : "modal-scroll",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["New ", c.singular] }), kind !== "quotations" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [w.foreman, " · 11 November 2026"] })] }), kind === "quotations" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-section-box",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "registration-section-title",
							children: "Company Header"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4 p-5 md:grid-cols-2",
							children: [
								["companyName", "Company Name"],
								["address", "Address"],
								["email", "Email"],
								["phone", "Phone"],
								["bankName", "Bank Details"],
								["accountNumber", "Account Number"],
								["vatNumber", "VAT"]
							].map(([field, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: `quote-${field}`,
									className: "registration-label",
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: `quote-${field}`,
										className: "registration-input",
										value: paperFields[field] ?? "",
										onChange: (event) => updatePaperField(field, event.target.value)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
										className: "block text-xs font-medium text-muted-foreground",
										children: "Kept in quotation print metadata."
									})]
								})]
							}, field))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-section-box",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "registration-section-title",
							children: "Quote Details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4 p-5 md:grid-cols-2",
							children: [
								["date", "Date"],
								["quoteNo", "Quote No."],
								["salesperson", "Salesperson"]
							].map(([field, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: `quote-${field}`,
									className: "registration-label",
									children: label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: `quote-${field}`,
											className: "registration-input",
											value: paperFields[field] ?? "",
											onChange: (event) => updatePaperField(field, event.target.value)
										}),
										field === "quoteNo" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
											className: "block text-xs font-medium text-muted-foreground",
											children: "Backend generates the saved quotation number; value kept for print."
										}),
										field === "date" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
											className: "block text-xs font-medium text-muted-foreground",
											children: "Retained in quotation print metadata."
										}),
										field === "salesperson" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
											className: "block text-xs font-medium text-muted-foreground",
											children: "Printed name retained in quotation metadata."
										})
									]
								})]
							}, field))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "registration-section-box",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "registration-section-title",
								children: "Bill To"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-4 p-5",
								children: ["billTo1", "billTo2"].map((field, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "registration-row-compact registration-row-top",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										htmlFor: `quote-${field}`,
										className: "registration-label",
										children: ["Line ", index + 1]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: `quote-${field}`,
											className: "registration-input",
											value: paperFields[field] ?? "",
											onChange: (event) => updatePaperField(field, event.target.value)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
											className: "block text-xs font-medium text-muted-foreground",
											children: index === 0 ? "Backend uses the linked customer; retained for print." : "Retained for printing."
										})]
									})]
								}, field))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "registration-section-box",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "registration-section-title",
								children: "Ship To"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4 p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "registration-row-compact",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "registration-label",
											children: ["Registered Vehicle ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "registration-required",
												children: "*"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
											value: vehicleId,
											onValueChange: (nextId) => {
												setVehicleId(nextId);
												const selected = eligible.find((vehicle) => vehicle.id === nextId);
												if (!selected) return;
												fillFromVehicle("billTo1", selected.customer);
												fillFromVehicle("shipTo1", selected.customer);
												fillFromVehicle("shipTo2", selected.make);
												fillFromVehicle("shipTo3", selected.plate);
											},
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
												"aria-label": "Registered vehicle",
												className: "registration-select-trigger",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a registered vehicle" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: eligible.map((vehicle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
												value: vehicle.id,
												children: [
													vehicle.make,
													" · ",
													vehicle.plate,
													" · ",
													vehicle.customer
												]
											}, vehicle.id)) })]
										})]
									}),
									w.vehicles.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 text-xs text-muted-foreground",
										children: ["No vehicles loaded. Register a vehicle first.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											size: "sm",
											variant: "outline",
											className: "registration-reset-btn",
											onClick: () => void w.refresh(),
											children: "Retry"
										})]
									}) : eligible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "No eligible registered vehicles are available."
									}) : null,
									[
										["shipTo1", "Customer"],
										["shipTo2", "Make & Model"],
										["shipTo3", "Registration No."]
									].map(([field, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "registration-row-compact",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											htmlFor: `quote-${field}`,
											className: "registration-label",
											children: label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: `quote-${field}`,
											className: "registration-input",
											value: paperFields[field] ?? "",
											onChange: (event) => updatePaperField(field, event.target.value)
										})]
									}, field))
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-semibold",
								children: "Line items"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "overflow-x-auto rounded-md border",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, {
									className: "min-w-[1040px] table-fixed",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("colgroup", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[88px]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[244px]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[334px]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[175px]" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("col", { className: "w-[175px]" })
										] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												align: "right",
												sortDirection: lineSort?.key === "quantity" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "quantity")),
												children: "Qty"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												sortDirection: lineSort?.key === "item" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "item")),
												children: "Item"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												sortDirection: lineSort?.key === "description" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "description")),
												children: "Description"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												align: "right",
												sortDirection: lineSort?.key === "unitPrice" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "unitPrice")),
												children: "Unit Price"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
												align: "right",
												sortDirection: lineSort?.key === "total" ? lineSort.direction : null,
												onSort: () => setLineSort((current) => nextSortState(current, "total")),
												children: "Total"
											})
										] }) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: sortRecords(quotationLines, lineSort, (entry, key) => {
											switch (key) {
												case "quantity": return Number(entry.quantity) || 0;
												case "item": return entry.item;
												case "description": return entry.description;
												case "unitPrice": return Number(entry.unitPrice) || 0;
												case "total": return (Number(entry.quantity) || 0) * (Number(entry.unitPrice) || 0);
											}
										}).map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
												className: "text-right tabular-nums",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													"aria-label": `Line ${index + 1} quantity`,
													className: "text-right tabular-nums",
													type: "number",
													step: "0.01",
													value: line.quantity,
													onChange: (event) => setQuotationLines((lines) => lines.map((current) => current.rowId === line.rowId ? {
														...current,
														quantity: event.target.value
													} : current))
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													"aria-label": `Line ${index + 1} item`,
													maxLength: 80,
													value: line.item,
													onChange: (event) => setQuotationLines((lines) => lines.map((current) => current.rowId === line.rowId ? {
														...current,
														item: event.target.value
													} : current))
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													type: "button",
													variant: "ghost",
													size: "icon",
													"aria-label": `Remove line ${index + 1}`,
													onClick: () => setQuotationLines((lines) => lines.filter((current) => current.rowId !== line.rowId)),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
												})]
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
												"aria-label": `Line ${index + 1} description`,
												maxLength: 255,
												value: line.description,
												onChange: (event) => setQuotationLines((lines) => lines.map((current) => current.rowId === line.rowId ? {
													...current,
													description: event.target.value
												} : current))
											}) }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
												className: "text-right tabular-nums",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "K" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
														className: "min-w-0 flex-1 text-right tabular-nums",
														"aria-label": `Line ${index + 1} unit price in ZMW`,
														type: "number",
														step: "0.01",
														value: line.unitPrice,
														onChange: (event) => setQuotationLines((lines) => lines.map((current) => current.rowId === line.rowId ? {
															...current,
															unitPrice: event.target.value
														} : current))
													})]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
												className: "text-right tabular-nums",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													"aria-label": `Line ${index + 1} total`,
													className: "text-right tabular-nums",
													readOnly: true,
													value: money((Number(line.quantity) || 0) * (Number(line.unitPrice) || 0))
												})
											})
										] }, line.rowId)) })
									]
								}), quotationLines.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "empty-state-wrap",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
										compact: true,
										icon: FileText,
										title: "No quotation line items",
										description: "Add parts, consumables, or labour entries to calculate the quotation subtotal and VAT.",
										action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											type: "button",
											variant: "outline",
											size: "sm",
											onClick: () => setQuotationLines((lines) => [...lines, emptyQuotationLine()]),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add line"]
										})
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "button",
								variant: "outline",
								size: "sm",
								onClick: () => setQuotationLines((lines) => [...lines, emptyQuotationLine()]),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Add line"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto grid max-w-sm grid-cols-2 gap-y-2 rounded-md border p-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Subtotal",
								readOnly: true,
								value: money(quoteSubtotal)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VAT (16%)" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "VAT",
								readOnly: true,
								value: money(quoteTax)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Total" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								"aria-label": "Total",
								readOnly: true,
								value: money(quoteTotal)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "registration-section-box p-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2",
							children: [[
								"preparedBy",
								"signature",
								"invoiceReference"
							].map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: `quote-${field}`,
									className: "registration-label",
									children: field === "preparedBy" ? "Prepared By" : field === "signature" ? "Signature" : "Invoice Reference"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: `quote-${field}`,
									className: "registration-input",
									value: paperFields[field] ?? "",
									onChange: (event) => updatePaperField(field, event.target.value)
								})]
							}, field)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "self-center text-xs font-medium text-muted-foreground",
								children: "Thank you for your business."
							})]
						})
					}),
					quoteMissingMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: quoteMissingMessage
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "registration-actions-flush",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: !vehicleId || validQuotationLines.length === 0,
							className: "registration-submit-btn",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), " Submit"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "registration-reset-btn",
							onClick: onClose,
							children: "Cancel"
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				onReset: () => {
					setVehicleId("");
					setCatalogPartId("");
					setJobDepartment("Mechanical");
					setJobDueDate("");
					setJobRemarks("");
					setJobPhotos([]);
					if (photoInputRef.current) photoInputRef.current.value = "";
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "registration-row-compact",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "registration-label",
								children: ["Vehicle ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "registration-required",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: vehicleId,
								onValueChange: setVehicleId,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									"aria-label": "Vehicle",
									className: "registration-select-trigger",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a vehicle" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: eligible.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
									value: v.id,
									children: [
										v.make,
										" · ",
										v.plate
									]
								}, v.id)) })]
							})]
						}),
						eligible.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-muted-foreground",
							children: kind === "inventory" ? "No vehicles with customer-approved quotations are awaiting an inventory card." : kind === "jobs" ? "No vehicles with inventory cards are awaiting a job card." : kind === "inspections" ? "No vehicles are currently awaiting inspection." : "No eligible vehicle records are available."
						}),
						kind === "inventory" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium text-muted-foreground",
							children: "Inventory cards are created automatically during vehicle intake."
						}) : kind === "jobs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "registration-label",
									children: ["Department ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "registration-required",
										children: "*"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: jobDepartment,
									onValueChange: setJobDepartment,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										id: "job-department-trigger",
										"aria-label": "Department",
										className: "registration-select-trigger",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select department" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: departments.map((dept) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: dept,
										children: dept
									}, dept)) })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "registration-label",
									children: "Prepared By"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: jobPreparedByEmployeeId,
									onValueChange: setJobPreparedByEmployeeId,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										id: "job-prepared-by-trigger",
										"aria-label": "Prepared By",
										className: "registration-select-trigger",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select employee / foreman" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [(Array.isArray(w.workflowOptions["employees"]) ? w.workflowOptions["employees"] : []).map((emp) => {
										const empId = String(emp["id"] ?? "");
										const empName = String(emp["name"] ?? `Employee #${empId}`);
										const empRole = String(emp["designation"] ?? emp["role"] ?? "");
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
											value: empId,
											children: [
												empName,
												" ",
												empRole ? `(${empRole})` : ""
											]
										}, empId);
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: "foreman",
										children: [w.foreman, " (Foreman)"]
									})] })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "job-due-date",
									className: "registration-label",
									children: "Target Due Date"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "job-due-date",
									name: "due",
									type: "date",
									value: jobDueDate,
									onChange: (e) => setJobDueDate(e.target.value),
									className: "registration-input",
									"aria-label": "Target Due Date"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									htmlFor: "record-desc",
									className: "registration-label",
									children: ["Work Instructions ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "registration-required",
										children: "*"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "record-desc",
									name: "description",
									required: true,
									rows: 3,
									placeholder: "Enter detailed repair tasks and work instructions...",
									className: "registration-textarea"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "job-remarks",
									className: "registration-label",
									children: "Foreman Remarks"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "job-remarks",
									name: "remarks",
									value: jobRemarks,
									onChange: (e) => setJobRemarks(e.target.value),
									rows: 2,
									placeholder: "Special handling instructions, customer damage observations...",
									className: "registration-textarea"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "registration-label",
									children: "Damage Photos"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										onDragOver: (e) => {
											e.preventDefault();
											setIsDraggingPhoto(true);
										},
										onDragLeave: () => setIsDraggingPhoto(false),
										onDrop: (e) => {
											e.preventDefault();
											setIsDraggingPhoto(false);
											if (e.dataTransfer.files) handlePhotoFiles(e.dataTransfer.files);
										},
										className: cn("job-photo-dropzone", isDraggingPhoto && "job-photo-dropzone-active"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											ref: photoInputRef,
											id: "job-photo-input",
											type: "file",
											accept: "image/*",
											multiple: true,
											className: "sr-only",
											onChange: (e) => {
												if (e.target.files) handlePhotoFiles(e.target.files);
												e.target.value = "";
											}
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											htmlFor: "job-photo-input",
											className: "flex flex-col items-center justify-center p-4 cursor-pointer text-center w-full",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "w-5 h-5 text-muted-foreground mb-1.5" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-semibold text-foreground",
													children: "Click to select damaged vehicle photos or drag & drop"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[11px] text-muted-foreground mt-0.5",
													children: "Supports PNG, JPG, WebP · Visual thumbnails displayed below"
												})
											]
										})]
									}), jobPhotos.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between text-xs text-muted-foreground px-0.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-medium text-foreground",
												children: [
													jobPhotos.length,
													" photo",
													jobPhotos.length > 1 ? "s" : "",
													" selected"
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setJobPhotos([]),
												className: "text-xs text-destructive hover:underline font-medium cursor-pointer",
												children: "Clear all"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "job-photo-thumbnails",
											"data-testid": "job-photo-thumbnails",
											children: jobPhotos.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "job-photo-thumb group",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: photo.url,
														alt: photo.name
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														type: "button",
														"aria-label": `Remove photo ${photo.name}`,
														title: `Remove ${photo.name}`,
														onClick: () => removePhoto(photo.id),
														className: "job-photo-thumb-remove",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "w-2.5 h-2.5" })
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "job-photo-thumb-name",
														title: photo.name,
														children: photo.name
													})
												]
											}, photo.id))
										})]
									})]
								})]
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							kind === "requisitions" && w.parts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "registration-label",
									children: ["Catalog Part ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "registration-required",
										children: "*"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: catalogPartId,
									onValueChange: setCatalogPartId,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "registration-select-trigger",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a catalog part" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: w.parts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
										value: String(part.id),
										children: [
											part.code,
											" · ",
											part.name
										]
									}, part.id)) })]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "registration-row-compact registration-row-top",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									htmlFor: "record-desc",
									className: "registration-label",
									children: [
										kind === "requisitions" ? "Reason for Parts" : "Inspection Notes",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "registration-required",
											children: "*"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									id: "record-desc",
									name: "description",
									required: true,
									rows: 3,
									className: "registration-textarea"
								})]
							}),
							kind === "requisitions" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-muted-foreground",
								children: "The backend creates requisition lines from linked job card parts and current stock."
							}),
							kind === "inspections" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-muted-foreground",
								children: "Starting an inspection creates the backend checklist. Checklist outcomes are recorded through the backend inspection workflow."
							})
						] })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-actions-modal",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							disabled: !vehicleId,
							className: "registration-submit-btn",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), "Submit"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "reset",
							variant: "outline",
							className: "registration-reset-btn",
							children: "Reset"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							className: "registration-reset-btn",
							onClick: onClose,
							children: "Cancel"
						})
					]
				})]
			})]
		})
	});
}
function PaperQuotationPreview({ quotation, onPrint }) {
	const fields = {
		...initialPaperFields(),
		...quotation.paperFields ?? {}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "outline",
				onClick: onPrint,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), " Print"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "space-y-5 rounded-md border bg-white p-6 text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "border-b pb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: fields.companyName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.address }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							fields.email,
							" · ",
							fields.phone
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							fields.bankName,
							" · ",
							fields.accountNumber
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["VAT: ", fields.vatNumber] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-[1fr_2fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-semibold",
						children: "Quote"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.date })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "Quote No."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.quoteNo }),
								fields.quoteNo !== quotation.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("small", {
									className: "text-muted-foreground",
									children: ["Backend assigned: ", quotation.id]
								})
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: "Salesperson"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.salesperson })] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-5 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Bill To"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.billTo1 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.billTo2 })
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-semibold",
							children: "Ship To"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.shipTo1 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.shipTo2 }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.shipTo3 })
					] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotationItemsTable, {
						items: quotation.items ?? [],
						rowKeyPrefix: `${quotation.id}-paper`,
						className: "min-w-[720px]"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto grid max-w-xs grid-cols-2 gap-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right",
							children: money(quotation.subtotal ?? quotation.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "VAT (16%)" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-right",
							children: money(quotation.taxAmount ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Total" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-right",
							children: money(quotation.amount)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "grid gap-5 border-t pt-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Prepared By"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.preparedBy })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Signature"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.signature })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Invoice reference"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: fields.invoiceReference })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "self-end text-sm",
							children: "Thank you for your business."
						})
					]
				})
			]
		})]
	});
}
function InspectionDetail({ inspection, onClose }) {
	const w = useWorkspace();
	const [statuses, setStatuses] = (0, import_react.useState)({});
	const [comments, setComments] = (0, import_react.useState)({});
	const [departments, setDepartments] = (0, import_react.useState)({});
	const id = inspection?.backendId;
	const stored = id ? w.inspectionDetails.get(id) : void 0;
	const details = stored?.["details"];
	const signoffData = stored?.["signoffs"];
	const checklist = Array.isArray(details?.["checklist"]) ? details["checklist"] : [];
	const signoffs = Array.isArray(signoffData?.["signoffs"]) ? signoffData["signoffs"] : [];
	const options = w.workflowOptions["departments"] ?? [];
	const run = (action, message) => void action().then(async () => {
		await w.refresh();
		toast.success(message);
	}).catch((error) => toast.error(error.message));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!inspection,
		onOpenChange: (open) => {
			if (!open) {
				setStatuses({});
				setComments({});
				setDepartments({});
				onClose();
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "modal-scroll max-w-4xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Final inspection · ", inspection?.id] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
				w.vehicleFor(inspection?.vehicleId ?? "")?.plate,
				" ·",
				" ",
				String(details?.["inspectionStatus"] ?? inspection?.result ?? ""),
				" ·",
				" ",
				String(details?.["inspectionDecision"] ?? "Decision pending")
			] })] }), !details ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: () => void w.refresh(),
				children: "Load checklist"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-h-[45vh] space-y-3 overflow-auto",
					children: checklist.map((item) => {
						const itemId = Number(item["id"]);
						const saved = String(item["checkStatus"] ?? "PENDING");
						const status = statuses[itemId] ?? (saved === "PASS" || saved === "FAIL" ? saved : void 0);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-md border p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
									String(item["itemCode"]),
									" · ",
									String(item["itemName"])
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs font-medium text-muted-foreground",
									children: [
										String(item["inspectionCategory"]),
										" · ",
										saved
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
									value: status ?? "",
									onValueChange: (value) => setStatuses((prev) => ({
										...prev,
										[itemId]: value
									})),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
										className: "registration-select-trigger w-36",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Set result" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "PASS",
										children: "Pass"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "FAIL",
										children: "Fail"
									})] })]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										className: "registration-input",
										placeholder: "Comments",
										value: comments[itemId] ?? String(item["comments"] ?? ""),
										onChange: (e) => setComments((prev) => ({
											...prev,
											[itemId]: e.target.value
										}))
									}),
									status === "FAIL" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
										value: departments[itemId] ?? String(item["responsibleDepartmentId"] ?? ""),
										onValueChange: (value) => setDepartments((prev) => ({
											...prev,
											[itemId]: value
										})),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
											className: "registration-select-trigger w-52",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Responsible department" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: options.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: String(d["id"]),
											children: String(d["name"])
										}, String(d["id"]))) })]
									}),
									status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										onClick: () => {
											const dept = departments[itemId] ?? String(item["responsibleDepartmentId"] ?? "");
											if (status === "FAIL" && !dept) {
												toast.error("Select the responsible department for a failed item.");
												return;
											}
											run(() => w.api.updateInspectionItem(id, itemId, status, comments[itemId] ?? String(item["comments"] ?? ""), dept ? Number(dept) : void 0), "Inspection item updated.");
										},
										children: "Save"
									})
								]
							})]
						}, itemId);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-semibold",
					children: "Department sign-offs"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: signoffs.map((item) => {
						const departmentId = Number(item["departmentId"]);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2 rounded border p-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								String(item["departmentName"]),
								" · ",
								String(item["signoffStatus"])
							] }), String(item["signoffStatus"]) === "PENDING" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								variant: "outline",
								onClick: () => run(() => w.api.signoffInspectionDepartment(id, departmentId, "Final inspection department sign-off"), "Department sign-off recorded."),
								children: "Sign off"
							})]
						}, departmentId);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: () => run(() => w.api.createCorrectiveWorkOrders(id), "Corrective work orders generated."),
						children: "Generate corrective work orders"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => run(() => w.api.completeInspection(id), "Final inspection completed."),
						children: "Complete inspection"
					})]
				})
			] })]
		})
	});
}
function RequestDetail({ request, onClose, allowDecision }) {
	const w = useWorkspace();
	const [rejection, setRejection] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const current = w.requisitions.find((r) => r.id === request?.id);
	function decide(status) {
		if (!current || !canDecideParts(w.role)) return;
		if (status === "Rejected" && !note.trim()) {
			toast.error("Please record the reason for rejection.");
			return;
		}
		toast.error(`The backend does not provide a requisition ${status.toLowerCase()} endpoint. No decision was saved.`);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!current,
		onOpenChange: (o) => {
			if (!o) {
				setRejection(false);
				setNote("");
				onClose();
			}
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "modal-scroll",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Parts request · ", current?.id] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: ["Submitted ", current?.date] })] }), current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VehicleCell, { vehicle: w.vehicleFor(current.vehicleId) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "detail-grid",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Part / item" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: current.part })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: "Requested quantity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: current.quantity })] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "detail-notes",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Reason for requesting parts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: current.reason
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { children: current.status }),
				current.decisionNote && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs font-medium text-muted-foreground",
					children: ["Director note: ", current.decisionNote]
				}),
				allowDecision && current.status === "Pending" && canDecideParts(w.role) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [rejection && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-row-compact registration-row-top",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						htmlFor: "req-reject-note",
						className: "registration-label",
						children: ["Rejection Reason ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "registration-required",
							children: "*"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "req-reject-note",
						className: "registration-textarea",
						value: note,
						onChange: (e) => setNote(e.target.value),
						placeholder: "Explain why this request is being rejected"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "registration-actions-flush",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => decide("Approved"),
						className: "registration-submit-btn",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), "Approve request"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "registration-reset-btn",
						onClick: () => rejection ? decide("Rejected") : setRejection(true),
						children: rejection ? "Confirm rejection" : "Reject request"
					})]
				})] })
			] })]
		})
	});
}
//#endregion
export { SelectItem as a, SelectContent as i, RequestDetail as n, SelectTrigger as o, Select as r, SelectValue as s, RecordsPage as t };
