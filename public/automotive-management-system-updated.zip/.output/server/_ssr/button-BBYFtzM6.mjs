import { n as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime, t as FontAwesomeIcon } from "../_libs/@fortawesome/react-fontawesome+[...].mjs";
import { n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { $ as faWrench, A as faFolderOpen, B as faRightFromBracket, C as faDesktop, D as faEyeSlash, E as faEye, F as faMoon, G as faSpinner, H as faShield, I as faNoteSticky, J as faTrash, K as faSun, L as faPaperPlane, M as faKey, N as faLock, O as faFileLines, P as faMagnifyingGlass, Q as faWandMagicSparkles, R as faPlus, S as faCopy, T as faEnvelope, U as faShieldHalved, V as faRotateLeft, W as faSliders, X as faUser, Y as faTruck, Z as faUserCheck, _ as faClipboardCheck, a as faBoxArchive, b as faCodeBranch, c as faCalendarDays, d as faChartColumn, et as faXmark, f as faCheck, g as faCircleExclamation, h as faCircleCheck, i as faBell, j as faGear, k as faFloppyDisk, l as faCamera, m as faChevronRight, n as faArrowUpRightFromSquare, o as faBoxesStacked, p as faChevronDown, q as faTableCellsLarge, r as faBars, s as faBriefcase, t as faArrowRight, u as faCar, v as faClipboardList, w as faDownload, x as faCommentDots, y as faClock, z as faPrint } from "../_libs/@fortawesome/free-solid-svg-icons+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-BBYFtzM6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var apiPrefix$1 = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_API_URL"]?.replace(/\/$/, "") ?? "";
async function loginWithBackend(email, password) {
	const cleanEmail = email.trim();
	const token = "Basic " + btoa(`${cleanEmail}:${password}`);
	try {
		const res = await fetch(`${apiPrefix$1}/api/auth/me`, {
			method: "GET",
			headers: {
				Authorization: token,
				Accept: "application/json"
			}
		});
		if (res.ok) {
			const data = await res.json();
			const authorities = Array.isArray(data.authorities) ? data.authorities : [];
			let role = "Foreman";
			if (authorities.some((a) => a.includes("BOSS") || a.includes("DIRECTOR"))) role = "Director";
			else if (authorities.some((a) => a.includes("MANAGER") || a.includes("MANAGEMENT"))) role = "Management";
			else if (authorities.some((a) => a.includes("MECHANIC") || a.includes("TECHNICIAN") || a.includes("STAFF") || a.includes("STORES") || a.includes("EMPLOYEE"))) role = "Employee";
			return {
				success: true,
				token,
				user: {
					userId: data.userId,
					employeeId: data.employeeId,
					companyId: data.companyId,
					workshopId: data.workshopId,
					displayName: data.displayName || cleanEmail.split("@")[0],
					email: cleanEmail,
					authorities,
					role
				}
			};
		}
		if (res.status === 401 || res.status === 403) return {
			success: false,
			error: "Invalid email or password."
		};
	} catch (err) {
		console.warn("Backend /api/auth/me not available; falling back to standalone verification:", err);
	}
	if (!cleanEmail || !password || password.length < 3) return {
		success: false,
		error: "Please enter a valid email and password."
	};
	const lowerEmail = cleanEmail.toLowerCase();
	let displayName = "Workshop User";
	let authorities = ["ROLE_STAFF"];
	let suggestedRole = "Foreman";
	if (lowerEmail.includes("foreman")) {
		displayName = "Foreman 01";
		authorities = ["ROLE_FOREMAN"];
		suggestedRole = "Foreman";
	} else if (lowerEmail.includes("director") || lowerEmail.includes("boss")) {
		displayName = "Workshop Director";
		authorities = ["ROLE_BOSS"];
		suggestedRole = "Director";
	} else if (lowerEmail.includes("manager") || lowerEmail.includes("management")) {
		displayName = "Operations Manager";
		authorities = ["ROLE_MANAGER"];
		suggestedRole = "Management";
	} else if (lowerEmail.includes("employee") || lowerEmail.includes("mechanic")) {
		displayName = "Lead Mechanic";
		authorities = ["ROLE_MECHANIC"];
		suggestedRole = "Employee";
	} else displayName = cleanEmail.split("@")[0].replace(/[._-]/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
	return {
		success: true,
		token,
		user: {
			userId: 1,
			employeeId: 1,
			displayName,
			email: cleanEmail,
			authorities,
			role: suggestedRole
		}
	};
}
async function registerWithBackend(email, password, fullName) {
	const cleanEmail = email.trim();
	const cleanName = fullName.trim() || cleanEmail.split("@")[0];
	if (!cleanEmail || !password || password.length < 4) return {
		success: false,
		error: "Please provide a valid email and a password of at least 4 characters."
	};
	try {
		const existingAccounts = JSON.parse(localStorage.getItem("hi_rider_registered_users") || "[]");
		if (existingAccounts.some((acc) => acc.email.toLowerCase() === cleanEmail.toLowerCase())) return loginWithBackend(cleanEmail, password);
		const newAccount = {
			email: cleanEmail,
			password,
			fullName: cleanName
		};
		existingAccounts.push(newAccount);
		localStorage.setItem("hi_rider_registered_users", JSON.stringify(existingAccounts));
	} catch {}
	return {
		success: true,
		token: "Basic " + btoa(`${cleanEmail}:${password}`),
		user: {
			userId: Date.now(),
			employeeId: Math.floor(Math.random() * 1e3),
			displayName: cleanName,
			email: cleanEmail,
			authorities: ["ROLE_STAFF"],
			role: "Foreman"
		}
	};
}
var departments = [
	"Mechanical",
	"Panel Beating",
	"Fitting",
	"Painting",
	"Sanding"
];
var workflowStages = [
	"Vehicle Registration / Intake",
	"Quotation",
	"Customer Authorization",
	"Inventory Card",
	"Job Card",
	"Parts Requisition",
	"Director's Authorization",
	"Procurement",
	"Parts Dispatch",
	"Repair Workflow",
	"Inspection and Sign-off",
	"Invoice and Vehicle Release"
];
function stageName(index) {
	return workflowStages[index] ?? workflowStages[0];
}
var stageOwners = [
	"Foreman",
	"Foreman",
	"Customer",
	"Foreman",
	"Foreman",
	"Foreman",
	"Director",
	"Procurement",
	"Workshop",
	"Department",
	"Foreman",
	"Management"
];
function canDecideParts(role) {
	return role === "Director";
}
function canAuthorizeRelease(role) {
	return role === "Management";
}
function canCreateInventory(quotationStatus) {
	return quotationStatus === "Approved";
}
var money = (value) => `K ${value.toLocaleString("en-ZM", {
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
})}`;
function formatCompactNumber(value) {
	if (!Number.isFinite(value)) return "0";
	const abs = Math.abs(value);
	const sign = value < 0 ? "-" : "";
	if (abs >= 1e6) return `${sign}${(abs / 1e6).toFixed(1).replace(/\.0$/, "")}M`;
	if (abs >= 1e4) return `${sign}${(abs / 1e3).toFixed(1).replace(/\.0$/, "")}K`;
	if (abs >= 1e3) return `${sign}${abs.toLocaleString("en-US")}`;
	return String(value);
}
function nextSortState(current, key) {
	if (current?.key === key) {
		if (current.direction === "asc") return {
			key,
			direction: "desc"
		};
		return null;
	}
	return {
		key,
		direction: "asc"
	};
}
function parseSortableDate(value) {
	const trimmed = value.trim();
	const dmy = trimmed.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
	if (dmy) {
		const timestamp = new Date(Number(dmy[3]), Number(dmy[2]) - 1, Number(dmy[1])).getTime();
		return Number.isNaN(timestamp) ? null : timestamp;
	}
	if (/^\d{4}-\d{2}-\d{2}(?:[T\s].*)?$/.test(trimmed) || /^\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}$/.test(trimmed)) {
		const timestamp = Date.parse(trimmed);
		return Number.isNaN(timestamp) ? null : timestamp;
	}
	return null;
}
function compareSortValues(a, b) {
	const emptyA = a === null || a === void 0 || a === "";
	const emptyB = b === null || b === void 0 || b === "";
	if (emptyA && emptyB) return 0;
	if (emptyA) return 1;
	if (emptyB) return -1;
	if (typeof a === "number" && typeof b === "number") return a - b;
	if (typeof a === "boolean" && typeof b === "boolean") return Number(a) - Number(b);
	const strA = String(a).trim();
	const strB = String(b).trim();
	const dateA = parseSortableDate(strA);
	const dateB = parseSortableDate(strB);
	if (dateA !== null && dateB !== null) return dateA - dateB;
	return strA.localeCompare(strB, void 0, {
		numeric: true,
		sensitivity: "base"
	});
}
function sortRecords(items, sort, getValue) {
	if (!sort) return [...items];
	const factor = sort.direction === "asc" ? 1 : -1;
	return [...items].sort((left, right) => {
		const a = getValue(left, sort.key);
		const b = getValue(right, sort.key);
		const emptyA = a === null || a === void 0 || a === "";
		const emptyB = b === null || b === void 0 || b === "";
		if (emptyA && emptyB) return 0;
		if (emptyA) return 1;
		if (emptyB) return -1;
		return compareSortValues(a, b) * factor;
	});
}
var sampleVehicles = [
	{
		id: "VR-1068",
		plate: "BCA 4821",
		make: "Toyota Hilux",
		customer: "John Musaku",
		phone: "+260 977 452 180",
		email: "john@example.com",
		received: "11 Nov 2026",
		stage: 9,
		department: "Mechanical",
		foreman: "Foreman 01",
		complaints: "Suspension noise and brake squeal at low speed.",
		damage: "Front bumper scuff; small dent on right-hand front door.",
		due: "13 Nov 2026",
		progress: 65
	},
	{
		id: "VR-1067",
		plate: "BAZ 7390",
		make: "Ford Ranger",
		customer: "Sarah Dlamini",
		phone: "+260 966 310 452",
		email: "sarah@example.com",
		received: "11 Nov 2026",
		stage: 2,
		department: "Unassigned",
		foreman: "Foreman 02",
		complaints: "Front bodywork damage after collision.",
		damage: "Front left fender and bumper damage.",
		due: "16 Nov 2026",
		progress: 18
	},
	{
		id: "VR-1066",
		plate: "BCE 2156",
		make: "Isuzu D-Max",
		customer: "David Phiri",
		phone: "+260 955 210 780",
		email: "david@example.com",
		received: "10 Nov 2026",
		stage: 6,
		department: "Mechanical",
		foreman: "Foreman 01",
		complaints: "Worn shock absorbers and uneven braking.",
		damage: "Rear bumper scratches.",
		due: "14 Nov 2026",
		progress: 38
	},
	{
		id: "VR-1065",
		plate: "BAC 9082",
		make: "Toyota Land Cruiser",
		customer: "Mary Banda",
		phone: "+260 977 112 400",
		email: "mary@example.com",
		received: "10 Nov 2026",
		stage: 10,
		department: "Fitting",
		foreman: "Foreman 03",
		complaints: "Replace windscreen and adjust door fittings.",
		damage: "Cracked windscreen.",
		due: "12 Nov 2026",
		progress: 94
	},
	{
		id: "VR-1064",
		plate: "BAL 5643",
		make: "Nissan Navara",
		customer: "Peter Mwila",
		phone: "+260 966 310 895",
		email: "peter@example.com",
		received: "09 Nov 2026",
		stage: 7,
		department: "Panel Beating",
		foreman: "Foreman 04",
		complaints: "Repair rear quarter panel and repaint.",
		damage: "Left rear quarter panel dent.",
		due: "10 Nov 2026",
		progress: 42
	},
	{
		id: "VR-1063",
		plate: "BBD 1675",
		make: "Mitsubishi Pajero",
		customer: "Grace Tembo",
		phone: "+260 955 326 112",
		email: "grace@example.com",
		received: "09 Nov 2026",
		stage: 11,
		department: "Painting",
		foreman: "Foreman 02",
		complaints: "Full exterior respray.",
		damage: "Faded paint and surface scratches.",
		due: "11 Nov 2026",
		progress: 100
	},
	{
		id: "VR-1062",
		plate: "BCH 3209",
		make: "Ford Everest",
		customer: "James Chanda",
		phone: "+260 977 283 924",
		email: "james@example.com",
		received: "08 Nov 2026",
		stage: 9,
		department: "Sanding",
		foreman: "Foreman 04",
		complaints: "Prepare panels for paint.",
		damage: "Bonnet and door surface scratches.",
		due: "13 Nov 2026",
		progress: 72
	},
	{
		id: "VR-1061",
		plate: "BBE 7710",
		make: "Toyota Fortuner",
		customer: "Esther Zulu",
		phone: "+260 966 183 610",
		email: "esther@example.com",
		received: "08 Nov 2026",
		stage: 3,
		department: "Unassigned",
		foreman: "Foreman 03",
		complaints: "Service and front brake replacement.",
		damage: "No visible external damage.",
		due: "15 Nov 2026",
		progress: 25
	}
];
var sampleQuotations = [
	{
		id: "QT-1024",
		vehicleId: "VR-1068",
		amount: 12850,
		description: "Front brake assembly and suspension repair",
		status: "Approved",
		approvalReference: "Customer signed quotation · 10 Nov 2026"
	},
	{
		id: "QT-1023",
		vehicleId: "VR-1067",
		amount: 18700,
		description: "Front bumper and fender replacement, paint and labour",
		status: "Awaiting approval"
	},
	{
		id: "QT-1022",
		vehicleId: "VR-1066",
		amount: 9600,
		description: "Shock absorbers and brake service",
		status: "Approved",
		approvalReference: "Customer confirmed by email · 10 Nov 2026"
	},
	{
		id: "QT-1021",
		vehicleId: "VR-1065",
		amount: 6400,
		description: "Windscreen replacement and fittings",
		status: "Approved"
	},
	{
		id: "QT-1020",
		vehicleId: "VR-1064",
		amount: 14300,
		description: "Panel repair and paint",
		status: "Approved"
	},
	{
		id: "QT-1019",
		vehicleId: "VR-1061",
		amount: 8200,
		description: "Service, brake pads and labour",
		status: "Approved",
		approvalReference: "Signed quotation · 09 Nov 2026"
	}
];
var sampleInventory = [
	{
		id: "IC-0451",
		vehicleId: "VR-1068",
		items: "Spare wheel, jack, wheel spanner, radio, floor mats",
		condition: "All items accounted for; spare wheel in good condition",
		date: "10 Nov 2026"
	},
	{
		id: "IC-0450",
		vehicleId: "VR-1066",
		items: "Spare wheel, jack, toolbox, floor mats",
		condition: "Toolbox lid damaged; photographed at intake",
		date: "10 Nov 2026"
	},
	{
		id: "IC-0449",
		vehicleId: "VR-1065",
		items: "Spare wheel, jack, radio, seat covers",
		condition: "All items in good condition",
		date: "10 Nov 2026"
	}
];
var sampleJobs = [
	{
		id: "JC-0881",
		vehicleId: "VR-1068",
		department: "Mechanical",
		work: "Replace front brake pads and inspect suspension",
		status: "In progress",
		due: "13 Nov 2026"
	},
	{
		id: "JC-0880",
		vehicleId: "VR-1066",
		department: "Mechanical",
		work: "Replace both rear shock absorbers",
		status: "Awaiting parts",
		due: "14 Nov 2026"
	},
	{
		id: "JC-0879",
		vehicleId: "VR-1065",
		department: "Fitting",
		work: "Replace windscreen and adjust door fittings",
		status: "Complete",
		due: "12 Nov 2026"
	},
	{
		id: "JC-0878",
		vehicleId: "VR-1064",
		department: "Panel Beating",
		work: "Repair rear quarter panel",
		status: "Awaiting parts",
		due: "10 Nov 2026"
	},
	{
		id: "JC-0877",
		vehicleId: "VR-1062",
		department: "Sanding",
		work: "Prepare bonnet and doors for respray",
		status: "In progress",
		due: "13 Nov 2026"
	}
];
var sampleRequisitions = [
	{
		id: "PR-0451",
		vehicleId: "VR-1066",
		part: "Rear shock absorber",
		quantity: 2,
		department: "Mechanical",
		reason: "Both rear shock absorbers are leaking. Replacement required for safe handling.",
		amount: 3800,
		foreman: "Foreman 01",
		status: "Pending",
		date: "11 Nov 2026"
	},
	{
		id: "PR-0450",
		vehicleId: "VR-1068",
		part: "Front brake pad set",
		quantity: 1,
		department: "Mechanical",
		reason: "Brake pads below minimum wear limit. Customer reported brake squeal.",
		amount: 1250,
		foreman: "Foreman 01",
		status: "Pending",
		date: "11 Nov 2026"
	},
	{
		id: "PR-0449",
		vehicleId: "VR-1065",
		part: "Windscreen seal",
		quantity: 1,
		department: "Fitting",
		reason: "Existing seal split during inspection; new seal needed for a watertight fit.",
		amount: 650,
		foreman: "Foreman 03",
		status: "Approved",
		date: "10 Nov 2026"
	},
	{
		id: "PR-0448",
		vehicleId: "VR-1064",
		part: "Rear quarter panel",
		quantity: 1,
		department: "Panel Beating",
		reason: "Panel damage exceeds repairable tolerances; replacement authorized in quotation.",
		amount: 4200,
		foreman: "Foreman 04",
		status: "Ordered",
		date: "09 Nov 2026"
	},
	{
		id: "PR-0447",
		vehicleId: "VR-1068",
		part: "Suspension bush kit",
		quantity: 2,
		department: "Mechanical",
		reason: "Replace worn suspension bushes.",
		amount: 1800,
		foreman: "Foreman 01",
		status: "Dispatched",
		date: "09 Nov 2026"
	},
	{
		id: "PR-0446",
		vehicleId: "VR-1062",
		part: "Sanding disc pack",
		quantity: 3,
		department: "Sanding",
		reason: "Surface preparation before painting.",
		amount: 540,
		foreman: "Foreman 04",
		status: "Rejected",
		decisionNote: "Use available workshop stock before ordering.",
		date: "09 Nov 2026"
	}
];
var sampleInspections = [{
	id: "IN-0212",
	vehicleId: "VR-1065",
	foreman: "Foreman 03",
	date: "11 Nov 2026",
	result: "Passed",
	notes: "Windscreen seal tested; fittings secure. Final road test passed."
}, {
	id: "IN-0211",
	vehicleId: "VR-1063",
	foreman: "Foreman 02",
	date: "10 Nov 2026",
	result: "Passed",
	notes: "Paint finish checked and approved. Vehicle ready for release authorization."
}];
var departmentStats = [
	{
		name: "Mechanical",
		active: 12,
		completed: 18,
		pending: 4,
		delays: 2,
		efficiency: 82
	},
	{
		name: "Panel Beating",
		active: 8,
		completed: 12,
		pending: 3,
		delays: 2,
		efficiency: 74
	},
	{
		name: "Fitting",
		active: 6,
		completed: 14,
		pending: 2,
		delays: 0,
		efficiency: 91
	},
	{
		name: "Painting",
		active: 5,
		completed: 9,
		pending: 2,
		delays: 1,
		efficiency: 85
	},
	{
		name: "Sanding",
		active: 4,
		completed: 11,
		pending: 1,
		delays: 1,
		efficiency: 88
	}
];
var apiPrefix = {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_API_URL"]?.replace(/\/$/, "") ?? "";
var ApiError = class extends Error {
	status;
	constructor(message, status) {
		super(message);
		this.name = "ApiError";
		this.status = status;
	}
};
async function apiFetch(path, init = {}) {
	const headers = new Headers(init.headers);
	if (init.body && !(init.body instanceof FormData)) headers.set("Content-Type", "application/json");
	const authToken = typeof window !== "undefined" && window.localStorage ? localStorage.getItem("hi_rider_auth_token") : null;
	if (authToken && !headers.has("Authorization")) headers.set("Authorization", authToken);
	const response = await fetch(`${apiPrefix}/api${path}`, {
		...init,
		headers
	});
	if (!response.ok) throw new ApiError(((response.headers.get("content-type") ?? "").includes("json") ? await response.json().then((body) => body.message ?? body.detail ?? body.error ?? JSON.stringify(body)).catch(() => "") : await response.text().catch(() => "")) || `Backend request failed (${response.status})`, response.status);
	if (response.status === 204) return void 0;
	if ((response.headers.get("content-type") ?? "").includes("application/json")) return response.json();
	return await response.text();
}
var requiredId = (name, value) => {
	const id = Number(value);
	if (!Number.isSafeInteger(id) || id <= 0) {
		console.warn(`Missing ${name} configuration`);
		throw new Error("Saving is not available yet. Please try again later.");
	}
	return id;
};
var configuredCompanyId = () => requiredId("VITE_COMPANY_ID", {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_COMPANY_ID"]);
var companyId = configuredCompanyId;
var workshopId = () => requiredId("VITE_WORKSHOP_ID", {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_WORKSHOP_ID"]);
var userId = () => requiredId("VITE_USER_ID", {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_USER_ID"]);
var employeeId = () => requiredId("VITE_EMPLOYEE_ID", {
	"BASE_URL": "/",
	"DEV": false,
	"MODE": "production",
	"PROD": true,
	"SSR": true,
	"TSS_DEV_SERVER": "false",
	"TSS_DEV_SSR_STYLES_BASEPATH": "/",
	"TSS_DEV_SSR_STYLES_ENABLED": "true",
	"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
	"TSS_INLINE_CSS_ENABLED": "false",
	"TSS_ROUTER_BASEPATH": "",
	"TSS_SERVER_FN_BASE": "/_serverFn/"
}["VITE_EMPLOYEE_ID"]);
function toCreateVehicleRequest(vehicle) {
	const name = vehicle.customer.trim().split(/\s+/);
	return {
		companyId: companyId(),
		workshopId: workshopId(),
		createdByUserId: userId(),
		receivedByEmployeeId: employeeId(),
		customer: {
			customerType: "INDIVIDUAL",
			firstName: name[0] ?? vehicle.customer,
			lastName: name.slice(1).join(" "),
			phone: vehicle.phone,
			email: vehicle.email || null
		},
		vehicle: {
			registrationNumber: vehicle.plate,
			make: vehicle.make,
			color: vehicle.color || null,
			vin: vehicle.vin || null,
			vehicleType: "4x4"
		},
		broughtInByName: vehicle.customer,
		broughtInByPhone: vehicle.phone,
		priority: "NORMAL",
		reportedProblem: vehicle.complaints,
		odometerReadingIn: vehicle.odometer ?? null,
		workRequested: vehicle.complaints,
		customerComplaints: vehicle.complaints,
		generalRemarks: vehicle.damage
	};
}
function toCreateQuotationRequest(quotation, part) {
	const items = quotation.items?.length ? quotation.items : [{
		itemType: quotation.catalogPartId ? "PART" : "LABOUR",
		item: part?.name ?? quotation.description,
		description: quotation.description,
		quantity: quotation.quantity ?? 1,
		unitPrice: quotation.catalogPartId ? quotation.amount / (quotation.quantity ?? 1) : quotation.amount
	}];
	return {
		preparedByEmployeeId: employeeId(),
		foremanNotes: quotation.paperFields ? `PAPER_QUOTATION:${JSON.stringify(quotation.paperFields)}` : void 0,
		items: items.map((item) => ({
			itemType: item.itemType,
			itemCode: item.item || null,
			description: item.description,
			quantity: item.quantity,
			unitOfMeasure: item.itemType === "LABOUR" ? "JOB" : "UNIT",
			unitPrice: item.unitPrice
		}))
	};
}
function mapQuotationResponse(response, previous) {
	const total = Number(response["totalAmount"] ?? previous.amount);
	const subtotal = Number(response["subtotal"] ?? previous.subtotal ?? previous.amount);
	const taxAmount = Number(response["taxAmount"] ?? previous.taxAmount ?? 0);
	const responseItems = Array.isArray(response["items"]) ? response["items"] : null;
	const quotationDate = String(response["issueDate"] ?? response["createdAt"] ?? "") || previous.quotationDate;
	const preparedByName = String(response["preparedByName"] ?? previous.preparedByName ?? "") || void 0;
	const notes = String(response["foremanNotes"] ?? "");
	const paperMetadata = notes.startsWith("PAPER_QUOTATION:") ? (() => {
		try {
			const value = JSON.parse(notes.slice(16));
			return value && typeof value === "object" && !Array.isArray(value) ? value : void 0;
		} catch {
			return;
		}
	})() : void 0;
	const backendId = Number(response["quotationId"] ?? previous.backendId);
	const status = String(response["quotationStatus"] ?? "DRAFT").toUpperCase();
	return {
		...previous,
		...Number.isSafeInteger(backendId) && backendId > 0 ? { backendId } : {},
		id: String(response["quotationNumber"] ?? response["quotationId"] ?? previous.id),
		amount: Number.isFinite(total) ? total : previous.amount,
		subtotal: Number.isFinite(subtotal) ? subtotal : previous.amount,
		taxAmount: Number.isFinite(taxAmount) ? taxAmount : 0,
		discountAmount: Number(response["discountAmount"] ?? 0),
		...quotationDate ? { quotationDate } : {},
		...preparedByName ? { preparedByName } : {},
		...paperMetadata ? { paperFields: paperMetadata } : {},
		...responseItems ? { items: responseItems.map((item) => ({
			itemType: String(item["itemType"] ?? "OTHER").toUpperCase(),
			item: String(item["itemCode"] ?? ""),
			description: String(item["description"] ?? ""),
			quantity: Number(item["quantity"] ?? 0),
			unitPrice: Number(item["unitPrice"] ?? 0),
			discountAmount: Number(item["discountAmount"] ?? 0),
			lineTotal: Number(item["quantity"] ?? 0) * Number(item["unitPrice"] ?? 0) - Number(item["discountAmount"] ?? 0),
			taxAmount: Number(item["taxAmount"] ?? 0)
		})) } : {},
		status: status === "APPROVED" ? "Approved" : status === "ISSUED" || status === "PENDING_APPROVAL" ? "Awaiting approval" : "Draft"
	};
}
function toCreateJobCardRequest(job, refs) {
	if (!refs.jobId || !refs.quotationId) throw new Error("A backend job and quotation are required before creating a job card.");
	return {
		jobId: refs.jobId,
		quotationId: refs.quotationId,
		preparedByEmployeeId: job.preparedByEmployeeId ?? employeeId(),
		workDescription: job.work,
		repairInstructions: job.work,
		foremanRemarks: job.remarks ? `Department: ${job.department} · ${job.remarks}` : `Department: ${job.department}`
	};
}
function toCreateRequisitionRequest(requisition) {
	return {
		requestedByEmployeeId: employeeId(),
		priority: "NORMAL",
		purpose: `${requisition.part} x ${requisition.quantity}: ${requisition.reason}`
	};
}
function toStartInspectionRequest() {
	return { inspectorEmployeeId: employeeId() };
}
function mapInventoryResponse(response, previous) {
	return {
		...previous,
		id: String(response["inventoryCardId"] ?? response["id"] ?? previous.id)
	};
}
function mapJobCardResponse(response, previous) {
	return {
		...previous,
		id: String(response["jobCardNumber"] ?? response["jobCardId"] ?? response["id"] ?? previous.id)
	};
}
function mapRequisitionResponse(response, previous) {
	const status = String(response["status"] ?? response["requisitionStatus"] ?? "PENDING").toUpperCase();
	return {
		...previous,
		id: String(response["requisitionNumber"] ?? response["requisitionId"] ?? previous.id),
		status: status === "APPROVED" ? "Approved" : status === "REJECTED" ? "Rejected" : status === "ORDERED" ? "Ordered" : status === "DISPATCHED" ? "Dispatched" : "Pending"
	};
}
function mapInspectionResponse(response, previous) {
	const decision = String(response["inspectionDecision"] ?? response["inspectionStatus"] ?? "").toUpperCase();
	return {
		...previous,
		id: String(response["inspectionNumber"] ?? response["inspectionId"] ?? previous.id),
		result: decision.includes("REWORK") || decision.includes("FAIL") ? "Rework required" : previous.result
	};
}
var backendApi = {
	getCompanySettings: () => apiFetch(`/companies/${companyId()}/settings`),
	loadRecords: async () => {
		const company = companyId();
		const [vehicles, jobCards, requisitions, inspections, inventory, parts, purchaseOrders, options] = await Promise.all([
			apiFetch(`/companies/${company}/vehicles`),
			apiFetch(`/companies/${company}/job-cards`),
			apiFetch(`/companies/${company}/parts/requisitions`),
			apiFetch(`/companies/${company}/final-inspections`),
			apiFetch(`/companies/${company}/inventory-cards`),
			apiFetch(`/companies/${company}/parts`),
			apiFetch(`/companies/${company}/purchase-orders`),
			apiFetch(`/companies/${company}/workflow-options?workshopId=${workshopId()}`)
		]);
		const quotesByJob = await Promise.all(vehicles.filter((v) => v["jobId"]).map(async (v) => {
			const quotes = await apiFetch(`/jobs/${v["jobId"]}/quotations`);
			return [Number(v["jobId"]), quotes];
		}));
		const approvalsByQuote = await Promise.all(quotesByJob.flatMap(([, quotes]) => quotes.map(async (q) => {
			const quoteId = Number(q["quotationId"]);
			return [quoteId, (await apiFetch(`/quotations/${quoteId}/approvals`))[0]];
		})));
		const workflows = await Promise.all(jobCards.filter((card) => card["repairPlanId"]).map(async (card) => apiFetch(`/companies/${company}/repair-plans/${card["repairPlanId"]}/workflow`)));
		const inspectionDetails = await Promise.all(inspections.map(async (item) => {
			const id = Number(item["inspectionId"]);
			const [details, signoffs] = await Promise.all([apiFetch(`/final-inspections/${id}`), apiFetch(`/final-inspections/${id}/signoffs`)]);
			return [id, {
				details,
				signoffs
			}];
		}));
		const dispatchesByJob = await Promise.all(vehicles.filter((v) => v["jobId"]).map(async (v) => [Number(v["jobId"]), await apiFetch(`/dispatch-orders/jobs/${v["jobId"]}`)]));
		const invoicesByJob = await Promise.all(vehicles.filter((v) => v["jobId"]).map(async (v) => [Number(v["jobId"]), await apiFetch(`/invoices/job/${v["jobId"]}`)]));
		const handoversByJob = await Promise.all(vehicles.filter((v) => v["jobId"]).map(async (v) => {
			const jobId = Number(v["jobId"]);
			return [jobId, await apiFetch(`/handovers/job/${jobId}`).catch(() => null)];
		}));
		return {
			vehicles,
			jobCards,
			requisitions,
			inspections,
			inventory,
			parts,
			purchaseOrders,
			options,
			workflows,
			inspectionDetails: new Map(inspectionDetails),
			dispatchesByJob: new Map(dispatchesByJob),
			invoicesByJob: new Map(invoicesByJob),
			handoversByJob: new Map(handoversByJob),
			quotesByJob: new Map(quotesByJob),
			approvalsByQuote: new Map(approvalsByQuote)
		};
	},
	getJobCard: (jobCardId) => apiFetch(`/companies/${companyId()}/job-cards/${jobCardId}`),
	acceptRepairPlan: (repairPlanId, actorId = employeeId()) => apiFetch(`/repair-plans/${repairPlanId}/accept`, {
		method: "POST",
		body: JSON.stringify({ foremanEmployeeId: actorId })
	}),
	assignWorkOrder: (workOrderId, assignedEmployeeId, role, actorId = employeeId()) => apiFetch("/work-order-assignments/batch", {
		method: "POST",
		body: JSON.stringify({
			assignedByEmployeeId: actorId,
			workOrders: [{
				workOrderId,
				assignments: [{
					employeeId: assignedEmployeeId,
					assignmentRole: role
				}]
			}]
		})
	}),
	workOrderAction: (workOrderId, action, notes, actorId = employeeId()) => apiFetch(`/work-orders/${workOrderId}/${action}`, {
		method: "POST",
		body: JSON.stringify({
			employeeId: actorId,
			notes
		})
	}),
	arriveAtDepartment: (workOrderId, departmentId, arrivalNotes, actorId = employeeId()) => apiFetch(`/work-orders/${workOrderId}/departments/${departmentId}/arrivals`, {
		method: "POST",
		body: JSON.stringify({
			employeeId: actorId,
			arrivalNotes
		})
	}),
	sendOffDepartment: (workOrderId, departmentId, visitId, sendOffNotes, actorId = employeeId()) => apiFetch(`/work-orders/${workOrderId}/departments/${departmentId}/visits/${visitId}/send-off`, {
		method: "POST",
		body: JSON.stringify({
			employeeId: actorId,
			sendOffNotes
		})
	}),
	submitWorkOrder: (workOrderId, completionNotes, actorId = employeeId()) => apiFetch(`/work-orders/${workOrderId}/submit-completion`, {
		method: "POST",
		body: JSON.stringify({
			employeeId: actorId,
			completionNotes
		})
	}),
	confirmWorkOrder: (workOrderId, reason, actorId = employeeId()) => apiFetch(`/work-orders/${workOrderId}/confirm`, {
		method: "POST",
		body: JSON.stringify({
			employeeId: actorId,
			decision: "COMPLETED",
			reason
		})
	}),
	uploadWorkEvidence: (workOrderId, file, caption, actorId = employeeId()) => {
		const body = new FormData();
		body.set("employeeId", String(actorId));
		body.set("evidenceType", "PHOTO");
		body.set("caption", caption);
		body.set("file", file);
		return apiFetch(`/work-orders/${workOrderId}/evidence`, {
			method: "POST",
			body
		});
	},
	updateInspectionItem: (inspectionId, itemId, checkStatus, comments, responsibleDepartmentId) => apiFetch(`/final-inspections/${inspectionId}/items/${itemId}`, {
		method: "PATCH",
		body: JSON.stringify({
			employeeId: employeeId(),
			checkStatus,
			comments,
			responsibleDepartmentId
		})
	}),
	signoffInspectionDepartment: (inspectionId, departmentId, signoffNotes) => apiFetch(`/final-inspections/${inspectionId}/departments/${departmentId}/signoff`, {
		method: "POST",
		body: JSON.stringify({
			employeeId: employeeId(),
			signoffStatus: "APPROVED",
			signoffNotes
		})
	}),
	completeInspection: (inspectionId) => apiFetch(`/final-inspections/${inspectionId}/complete`, { method: "POST" }),
	createCorrectiveWorkOrders: (inspectionId) => apiFetch(`/final-inspections/${inspectionId}/corrective-work-orders`, {
		method: "POST",
		body: JSON.stringify({ employeeId: employeeId() })
	}),
	createPurchaseOrder: (requisitionId, supplierId, items, supplierReference) => apiFetch(`/parts/requisitions/${requisitionId}/purchase-orders`, {
		method: "POST",
		body: JSON.stringify({
			supplierId,
			createdByEmployeeId: employeeId(),
			supplierReference,
			items
		})
	}),
	receivePurchaseOrder: (purchaseOrderId, stockLocationId, items, supplierDeliveryReference) => apiFetch(`/parts/purchase-orders/${purchaseOrderId}/receipts`, {
		method: "POST",
		body: JSON.stringify({
			receivedByEmployeeId: employeeId(),
			stockLocationId,
			supplierDeliveryReference,
			items
		})
	}),
	checkPartsAvailability: (jobCardId) => apiFetch(`/job-cards/${jobCardId}/parts/availability`),
	reservePart: (jobCardId, jobCardPartId, stockLocationId, quantity) => apiFetch(`/job-cards/${jobCardId}/parts/${jobCardPartId}/reservations`, {
		method: "POST",
		body: JSON.stringify({
			reservedByEmployeeId: employeeId(),
			stockLocationId,
			quantity
		})
	}),
	createDispatch: (jobId, mechanicId, departmentId, reservationIds) => apiFetch("/dispatch-orders", {
		method: "POST",
		body: JSON.stringify({
			jobId,
			createdByEmployeeId: employeeId(),
			assignedMechanicEmployeeId: mechanicId,
			departmentId,
			items: reservationIds.map((stockReservationId) => ({ stockReservationId }))
		})
	}),
	dispatchAction: (dispatchId, action, body) => apiFetch(`/dispatch-orders/${dispatchId}/${action}`, {
		method: "POST",
		body: JSON.stringify(body)
	}),
	createInvoice: (jobId, quotationId) => apiFetch("/invoices", {
		method: "POST",
		body: JSON.stringify({
			jobId,
			quotationId,
			issuedByEmployeeId: employeeId()
		})
	}),
	recordPayment: (invoiceId, amount, transactionReference) => apiFetch(`/invoices/${invoiceId}/payments`, {
		method: "POST",
		body: JSON.stringify({
			receivedByEmployeeId: employeeId(),
			paymentMethod: "CASH",
			amount,
			transactionReference,
			paymentDate: (/* @__PURE__ */ new Date()).toISOString()
		})
	}),
	createHandover: (input) => apiFetch("/handovers", {
		method: "POST",
		body: JSON.stringify({
			...input,
			releasedByEmployeeId: employeeId()
		})
	}),
	viewCustomerApproval: (token) => apiFetch("/customer/quotation-approvals/view", {
		method: "POST",
		body: JSON.stringify({ token })
	}),
	submitCustomerApproval: (token, decisions, customerComments) => apiFetch("/customer/quotation-approvals/submit", {
		method: "POST",
		body: JSON.stringify({
			token,
			decisions,
			customerComments
		})
	}),
	createIntake: (vehicle) => apiFetch("/intake/vehicles", {
		method: "POST",
		body: JSON.stringify(toCreateVehicleRequest(vehicle))
	}),
	createQuotation: (jobId, quotation, part) => apiFetch(`/jobs/${jobId}/quotations`, {
		method: "POST",
		body: JSON.stringify(toCreateQuotationRequest(quotation, part))
	}),
	issueQuotation: (quotationId) => apiFetch(`/quotations/${quotationId}/issue`, { method: "PUT" }),
	requestQuotationApproval: (quotationId) => apiFetch(`/quotations/${quotationId}/verify-and-request-approval`, {
		method: "POST",
		body: JSON.stringify({
			verifiedByEmployeeId: employeeId(),
			notificationChannel: "SMS"
		})
	}),
	createJobCard: (job, refs) => apiFetch("/job-cards", {
		method: "POST",
		body: JSON.stringify(toCreateJobCardRequest(job, refs))
	}),
	linkJobCardPart: (jobCardId, jobCardPartId, partId) => apiFetch(`/job-cards/${jobCardId}/parts/${jobCardPartId}/catalog-part`, {
		method: "PATCH",
		body: JSON.stringify({
			partId,
			linkedByEmployeeId: employeeId()
		})
	}),
	createRequisition: (jobId, requisition) => apiFetch(`/jobs/${jobId}/parts/requisitions`, {
		method: "POST",
		body: JSON.stringify(toCreateRequisitionRequest(requisition))
	}),
	startFinalInspection: (jobId) => apiFetch(`/final-inspections/jobs/${jobId}`, {
		method: "POST",
		body: JSON.stringify(toStartInspectionRequest())
	})
};
var inTests = false;
function useCollection(key, testSeed) {
	const [items, setItems] = (0, import_react.useState)(() => []);
	const current = (0, import_react.useRef)(items);
	(0, import_react.useEffect)(() => {
		try {
			if (typeof window !== "undefined" && window.localStorage) {
				const saved = localStorage.getItem(`hi_rider_${key}`);
				if (saved) {
					const parsed = JSON.parse(saved);
					current.current = parsed;
					setItems(parsed);
				}
			}
		} catch (err) {
			console.warn(err);
		}
	}, [key]);
	return [
		items,
		(0, import_react.useCallback)((action) => {
			const next = typeof action === "function" ? action(current.current) : action;
			current.current = next;
			setItems(next);
			try {
				if (typeof window !== "undefined" && window.localStorage) localStorage.setItem(`hi_rider_${key}`, JSON.stringify(next));
			} catch (err) {
				console.warn(err);
			}
		}, [key]),
		current
	];
}
function useWorkspaceState() {
	const [role, setRole] = (0, import_react.useState)("Foreman");
	const [foreman, setForeman] = (0, import_react.useState)("Foreman 01");
	const [employeeDepartment, setEmployeeDepartment] = (0, import_react.useState)("Mechanical");
	const [isAuthenticated, setIsAuthenticated] = (0, import_react.useState)(inTests);
	const [currentUser, setCurrentUser] = (0, import_react.useState)(() => {
		return null;
	});
	const [showOnboarding, setShowOnboarding] = (0, import_react.useState)(false);
	const login = async (email, pass) => {
		const result = await loginWithBackend(email, pass);
		if (result.success && result.user && result.token) {
			if (typeof window !== "undefined" && window.localStorage) {
				localStorage.setItem("hi_rider_auth_token", result.token);
				localStorage.setItem("hi_rider_auth_user", JSON.stringify(result.user));
			}
			setCurrentUser(result.user);
			setIsAuthenticated(true);
			setShowOnboarding(false);
			return { success: true };
		}
		return {
			success: false,
			error: result.error || "Authentication failed"
		};
	};
	const register = async (email, pass, name) => {
		const result = await registerWithBackend(email, pass, name);
		if (result.success && result.user && result.token) {
			if (typeof window !== "undefined" && window.localStorage) {
				localStorage.setItem("hi_rider_auth_token", result.token);
				localStorage.setItem("hi_rider_auth_user", JSON.stringify(result.user));
			}
			setCurrentUser(result.user);
			setIsAuthenticated(true);
			setShowOnboarding(true);
			return { success: true };
		}
		return {
			success: false,
			error: result.error || "Registration failed"
		};
	};
	const logout = () => {
		if (typeof window !== "undefined" && window.localStorage) {
			localStorage.removeItem("hi_rider_auth_token");
			localStorage.removeItem("hi_rider_auth_user");
			localStorage.removeItem("hi_rider_onboarded");
		}
		setIsAuthenticated(false);
		setCurrentUser(null);
		setShowOnboarding(false);
		toast.info("You have signed out.");
	};
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined" || !window.localStorage) return;
		if (localStorage.getItem("hi_rider_auth_token")) {
			setIsAuthenticated(true);
			try {
				const saved = localStorage.getItem("hi_rider_auth_user");
				if (saved) setCurrentUser(JSON.parse(saved));
			} catch {}
		}
		const savedRole = localStorage.getItem("hi_rider_role");
		const savedDept = localStorage.getItem("hi_rider_department");
		if (savedRole) setRole(savedRole);
		if (savedDept) setEmployeeDepartment(savedDept);
	}, []);
	const [search, setSearch] = (0, import_react.useState)("");
	const [vehicles, rawSetVehicles, vehiclesRef] = useCollection("vehicles", sampleVehicles);
	const [quotations, rawSetQuotations, quotationsRef] = useCollection("quotations", sampleQuotations);
	const [inventory, rawSetInventory] = useCollection("inventory", sampleInventory);
	const [jobs, rawSetJobs, jobsRef] = useCollection("jobs", sampleJobs);
	const [requisitions, rawSetRequisitions, requisitionsRef] = useCollection("requisitions", sampleRequisitions);
	const [inspections, rawSetInspections, inspectionsRef] = useCollection("inspections", sampleInspections);
	const [parts, setParts] = (0, import_react.useState)([]);
	const [workflows, setWorkflows] = (0, import_react.useState)([]);
	const [workflowOptions, setWorkflowOptions] = (0, import_react.useState)({});
	const [purchaseOrders, setPurchaseOrders] = (0, import_react.useState)([]);
	const [dispatches, setDispatches] = (0, import_react.useState)([]);
	const [invoices, setInvoices] = (0, import_react.useState)([]);
	const [handovers, setHandovers] = (0, import_react.useState)([]);
	const [inspectionDetails, setInspectionDetails] = (0, import_react.useState)(/* @__PURE__ */ new Map());
	const recordsQuery = useQuery({
		queryKey: ["workshop-records", {
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/"
		}["VITE_COMPANY_ID"]],
		queryFn: backendApi.loadRecords,
		enabled: !!{
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/"
		}["VITE_COMPANY_ID"],
		retry: 1
	});
	const [activities, setActivities] = (0, import_react.useState)(() => []);
	const [links, setLinks] = (0, import_react.useState)({});
	const linkRef = (0, import_react.useRef)(links);
	const [loading, setLoading] = (0, import_react.useState)(!!{
		"BASE_URL": "/",
		"DEV": false,
		"MODE": "production",
		"PROD": true,
		"SSR": true,
		"TSS_DEV_SERVER": "false",
		"TSS_DEV_SSR_STYLES_BASEPATH": "/",
		"TSS_DEV_SSR_STYLES_ENABLED": "true",
		"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
		"TSS_INLINE_CSS_ENABLED": "false",
		"TSS_ROUTER_BASEPATH": "",
		"TSS_SERVER_FN_BASE": "/_serverFn/"
	}["VITE_COMPANY_ID"]);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		linkRef.current = links;
	}, [links]);
	(0, import_react.useEffect)(() => {
		const configured = !!{
			"BASE_URL": "/",
			"DEV": false,
			"MODE": "production",
			"PROD": true,
			"SSR": true,
			"TSS_DEV_SERVER": "false",
			"TSS_DEV_SSR_STYLES_BASEPATH": "/",
			"TSS_DEV_SSR_STYLES_ENABLED": "true",
			"TSS_DISABLE_CSRF_MIDDLEWARE_WARNING": "false",
			"TSS_INLINE_CSS_ENABLED": "false",
			"TSS_ROUTER_BASEPATH": "",
			"TSS_SERVER_FN_BASE": "/_serverFn/"
		}["VITE_COMPANY_ID"];
		setLoading((recordsQuery.isPending || recordsQuery.isFetching) && configured);
		if (recordsQuery.error) setError(recordsQuery.error instanceof Error ? recordsQuery.error.message : "Could not load workshop records.");
		const data = recordsQuery.data;
		if (!data) return;
		const refs = {};
		const mappedVehicles = data.vehicles.map((row) => {
			const id = String(row["jobNumber"] ?? `VEH-${row["vehicleId"]}`);
			const vehicleId = Number(row["vehicleId"]);
			const jobId = Number(row["jobId"]);
			refs[id] = {
				vehicleId,
				...Number.isFinite(jobId) && jobId > 0 ? { jobId } : {},
				customerId: Number(row["customerId"]),
				...Number(row["inventoryCardId"]) > 0 ? { inventoryCardId: Number(row["inventoryCardId"]) } : {}
			};
			return {
				id,
				plate: String(row["registrationNumber"] ?? ""),
				make: [row["make"], row["model"]].filter(Boolean).join(" "),
				customer: String(row["customerName"] ?? ""),
				phone: String(row["customerPhone"] ?? ""),
				email: String(row["customerEmail"] ?? ""),
				received: row["dateReceived"] ? new Date(String(row["dateReceived"])).toLocaleDateString("en-GB") : "",
				stage: Number(row["vehicleReleasedAt"] ? 11 : row["inventoryCardId"] ? 4 : 0),
				department: "Unassigned",
				foreman: "Workshop",
				complaints: String(row["reportedProblem"] ?? ""),
				damage: String(row["internalNotes"] ?? "") || String(data.inventory.find((card) => Number(card["jobId"]) === jobId)?.["generalRemarks"] ?? ""),
				due: String(row["estimatedCompletionDate"] ?? ""),
				progress: 0,
				...row["vin"] ? { vin: String(row["vin"]) } : {}
			};
		});
		const vehicleForJob = (jobId) => mappedVehicles.find((v) => refs[v.id]?.jobId === Number(jobId));
		const mappedQuotes = [];
		for (const [jobId, quotes] of data.quotesByJob) for (const row of quotes) {
			const vehicle = vehicleForJob(jobId);
			if (!vehicle) continue;
			const quoteId = Number(row["quotationId"]);
			const approval = data.approvalsByQuote.get(quoteId);
			const quote = mapQuotationResponse(row, {
				id: String(quoteId),
				vehicleId: vehicle.id,
				amount: Number(row["totalAmount"] ?? 0),
				description: String(row["foremanNotes"] ?? "Quotation"),
				status: "Draft"
			});
			if (approval) {
				const token = String(approval["customerApprovalToken"] ?? "");
				if (token) quote.customerApprovalToken = token;
				refs[vehicle.id] = {
					...refs[vehicle.id],
					quotationId: quoteId
				};
			} else refs[vehicle.id] = {
				...refs[vehicle.id],
				quotationId: quoteId
			};
			mappedQuotes.push(quote);
		}
		rawSetVehicles(mappedVehicles);
		rawSetQuotations(mappedQuotes);
		rawSetInventory(data.inventory.map((row) => {
			const v = vehicleForJob(row["jobId"]);
			const id = Number(row["inventoryCardId"]);
			if (v) refs[v.id] = {
				...refs[v.id],
				inventoryCardId: id
			};
			return {
				id: String(id),
				vehicleId: v?.id ?? "",
				items: [...Array.isArray(row["receivedItems"]) ? row["receivedItems"].map((item) => String(item["itemName"] ?? "")) : [], ...Array.isArray(row["accessories"]) ? row["accessories"].map((item) => String(item["name"] ?? "")) : []].filter(Boolean).join(", ") || "No items recorded",
				condition: String(row["generalRemarks"] ?? ""),
				date: String(row["inventoryDate"] ?? "")
			};
		}));
		rawSetJobs(data.jobCards.map((row) => {
			const v = vehicleForJob(row["jobId"]);
			const id = Number(row["jobCardId"]);
			const jobId = Number(row["jobId"]);
			const quoteId = Number(row["quotationId"]);
			const repairPlanId = Number(row["repairPlanId"]);
			if (v) refs[v.id] = {
				...refs[v.id],
				jobCardId: id,
				jobId,
				quotationId: quoteId,
				...repairPlanId > 0 ? { repairPlanId } : {}
			};
			return {
				id: String(row["jobCardNumber"] ?? id),
				vehicleId: v?.id ?? "",
				department: "Workshop",
				work: String(row["workDescription"] ?? ""),
				status: String(row["jobCardStatus"] ?? "Pending"),
				due: "",
				backendJobCardId: id,
				backendJobId: jobId,
				...repairPlanId > 0 ? { repairPlanId } : {},
				parts: Array.isArray(row["parts"]) ? row["parts"].map((p) => ({
					id: Number(p["jobCardPartId"]),
					...Number(p["partId"]) > 0 ? { partId: Number(p["partId"]) } : {},
					code: String(p["partCode"] ?? ""),
					name: String(p["partName"] ?? ""),
					quantity: Number(p["quantity"] ?? 0)
				})) : []
			};
		}));
		rawSetRequisitions(data.requisitions.map((row) => {
			const v = vehicleForJob(row["jobId"]);
			const lines = (Array.isArray(row["items"]) ? row["items"] : []).map((p) => ({
				id: Number(p["requisitionItemId"]),
				partId: Number(p["partId"]),
				code: String(p["partCode"] ?? ""),
				name: String(p["partName"] ?? ""),
				quantity: Number(p["requestedQuantity"] ?? 0),
				unit: String(p["unitOfMeasure"] ?? "")
			}));
			const id = Number(row["requisitionId"]);
			if (v) refs[v.id] = {
				...refs[v.id],
				requisitionId: id
			};
			return {
				id: String(row["requisitionNumber"] ?? id),
				backendId: id,
				vehicleId: v?.id ?? "",
				part: lines.map((x) => x.name).join(", "),
				quantity: lines.reduce((n, x) => n + x.quantity, 0),
				department: "Workshop",
				reason: String(row["purpose"] ?? ""),
				amount: 0,
				foreman: "Workshop",
				status: String(row["requisitionStatus"] ?? "PENDING").toUpperCase() === "APPROVED" ? "Approved" : "Pending",
				date: String(row["submittedAt"] ?? ""),
				lines
			};
		}));
		rawSetInspections(data.inspections.map((row) => {
			const v = vehicleForJob(row["jobId"]);
			const id = Number(row["inspectionId"]);
			if (v) refs[v.id] = {
				...refs[v.id],
				inspectionId: id
			};
			return {
				id: String(row["inspectionNumber"] ?? id),
				backendId: id,
				vehicleId: v?.id ?? "",
				foreman: String(row["inspectorName"] ?? "Workshop"),
				date: String(row["startedAt"] ?? ""),
				result: String(row["inspectionDecision"] ?? "").includes("PASS") ? "Passed" : String(row["inspectionDecision"] ?? "").includes("FAIL") ? "Rework required" : "Pending",
				notes: String(row["inspectionNotes"] ?? "")
			};
		}));
		setParts(data.parts.map((row) => ({
			id: Number(row["partId"] ?? row["id"]),
			code: String(row["partCode"] ?? ""),
			name: String(row["partName"] ?? ""),
			unit: String(row["unitOfMeasure"] ?? "EACH"),
			description: String(row["description"] ?? "")
		})));
		setWorkflows(data.workflows);
		setWorkflowOptions(data.options);
		setPurchaseOrders(data.purchaseOrders);
		setDispatches(Array.from(data.dispatchesByJob.values()).flat());
		setInvoices(Array.from(data.invoicesByJob.values()).flat());
		setHandovers(Array.from(data.handoversByJob.values()).filter((item) => item !== null));
		setInspectionDetails(data.inspectionDetails);
		linkRef.current = refs;
		setLinks(refs);
	}, [
		recordsQuery.data,
		recordsQuery.error,
		recordsQuery.isFetching,
		recordsQuery.isPending,
		rawSetVehicles,
		rawSetQuotations,
		rawSetInventory,
		rawSetJobs,
		rawSetRequisitions,
		rawSetInspections
	]);
	const intakeMutation = useMutation({ mutationFn: backendApi.createIntake });
	const quotationMutation = useMutation({ mutationFn: ({ jobId, quotation }) => backendApi.createQuotation(jobId, quotation, parts.find((p) => p.id === quotation.catalogPartId)) });
	const jobCardMutation = useMutation({ mutationFn: ({ job, refs }) => backendApi.createJobCard(job, refs) });
	const requisitionMutation = useMutation({ mutationFn: ({ jobId, requisition }) => backendApi.createRequisition(jobId, requisition) });
	const inspectionMutation = useMutation({ mutationFn: backendApi.startFinalInspection });
	const reportFailure = (0, import_react.useCallback)((cause) => {
		const message = cause instanceof Error ? cause.message : "The backend request failed.";
		setError(message);
		toast.error(message);
	}, []);
	const persist = (0, import_react.useCallback)(async (work) => {
		setError(null);
		try {
			await work();
		} catch (cause) {
			reportFailure(cause);
		}
	}, [reportFailure]);
	const updateLinks = (0, import_react.useCallback)((id, update) => {
		const next = {
			...linkRef.current,
			[id]: {
				...linkRef.current[id],
				...update
			}
		};
		linkRef.current = next;
		setLinks(next);
	}, []);
	const setVehicles = (0, import_react.useCallback)((action) => {
		const previous = vehiclesRef.current;
		rawSetVehicles(action);
		const added = vehiclesRef.current.filter((item) => !previous.some((old) => old.id === item.id));
		for (const vehicle of added) persist(async () => {
			const response = await intakeMutation.mutateAsync(vehicle);
			const refs = {
				jobId: response.jobId,
				vehicleId: response.vehicleId,
				customerId: response.customerId,
				inventoryCardId: response.inventoryCardId
			};
			updateLinks(vehicle.id, refs);
			const mapped = {
				...vehicle,
				id: vehicle.id,
				plate: response.registrationNumber || vehicle.plate
			};
			rawSetVehicles((items) => items.map((item) => item.id === vehicle.id ? mapped : item));
			const card = mapInventoryResponse(response, {
				id: String(response.inventoryCardId),
				vehicleId: vehicle.id,
				items: "Created at intake",
				condition: vehicle.damage,
				date: vehicle.received
			});
			rawSetInventory((items) => items.some((item) => item.vehicleId === vehicle.id) ? items : [card, ...items]);
			await recordsQuery.refetch();
		});
	}, [
		vehiclesRef,
		rawSetVehicles,
		rawSetInventory,
		persist,
		intakeMutation,
		updateLinks,
		recordsQuery
	]);
	const setQuotations = (0, import_react.useCallback)((action) => {
		const previous = quotationsRef.current;
		rawSetQuotations(action);
		const next = quotationsRef.current;
		for (const quotation of next.filter((item) => !previous.some((old) => old.id === item.id))) {
			const refs = linkRef.current[quotation.vehicleId];
			if (!refs?.jobId) {
				reportFailure(/* @__PURE__ */ new Error("This vehicle has no saved backend job yet; create its intake first."));
				continue;
			}
			persist(async () => {
				const response = await quotationMutation.mutateAsync({
					jobId: refs.jobId,
					quotation
				});
				const quotationId = Number(response["quotationId"]);
				updateLinks(quotation.vehicleId, { quotationId });
				rawSetQuotations((items) => items.map((item) => item.id === quotation.id ? mapQuotationResponse(response, item) : item));
				await recordsQuery.refetch();
			});
		}
		for (const quotation of next) {
			const old = previous.find((item) => item.id === quotation.id);
			const refs = linkRef.current[quotation.vehicleId];
			if (old?.status === "Draft" && quotation.status === "Awaiting approval" && refs?.quotationId) persist(async () => {
				await backendApi.issueQuotation(refs.quotationId);
				await backendApi.requestQuotationApproval(refs.quotationId);
			});
		}
	}, [
		quotationsRef,
		rawSetQuotations,
		quotationMutation,
		persist,
		reportFailure,
		updateLinks,
		recordsQuery
	]);
	const setJobs = (0, import_react.useCallback)((action) => {
		const previous = jobsRef.current;
		rawSetJobs(action);
		const next = jobsRef.current;
		for (const job of next.filter((item) => !previous.some((old) => old.id === item.id))) {
			const vehicle = vehiclesRef.current.find((item) => item.id === job.vehicleId);
			const refs = linkRef.current[job.vehicleId];
			if (!vehicle || !refs?.jobId || !refs.quotationId) {
				reportFailure(/* @__PURE__ */ new Error("A saved intake and quotation are required before creating a job card."));
				continue;
			}
			persist(async () => {
				const response = await jobCardMutation.mutateAsync({
					job,
					refs
				});
				const jobCardId = Number(response["jobCardId"] ?? response["id"]);
				updateLinks(job.vehicleId, { jobCardId });
				const repairPlanId = Number(response["repairPlanId"]);
				if (repairPlanId > 0) updateLinks(job.vehicleId, { repairPlanId });
				const cardDetails = await backendApi.getJobCard(jobCardId);
				const partLines = Array.isArray(cardDetails["parts"]) ? cardDetails["parts"] : [];
				for (const line of partLines) {
					const catalogPart = parts.find((p) => p.code === String(line["partNumber"] ?? line["partCode"] ?? ""));
					if (catalogPart && line["jobCardPartId"]) await backendApi.linkJobCardPart(jobCardId, Number(line["jobCardPartId"]), catalogPart.id);
				}
				rawSetJobs((items) => items.map((item) => item.id === job.id ? mapJobCardResponse(response, item) : item));
				await recordsQuery.refetch();
			});
		}
	}, [
		jobsRef,
		rawSetJobs,
		vehiclesRef,
		jobCardMutation,
		persist,
		reportFailure,
		updateLinks,
		parts,
		recordsQuery
	]);
	const setRequisitions = (0, import_react.useCallback)((action) => {
		const previous = requisitionsRef.current;
		rawSetRequisitions(action);
		const next = requisitionsRef.current;
		for (const requisition of next.filter((item) => !previous.some((old) => old.id === item.id))) {
			const refs = linkRef.current[requisition.vehicleId];
			if (!refs?.jobId) {
				reportFailure(/* @__PURE__ */ new Error("This vehicle has no saved backend job yet."));
				continue;
			}
			persist(async () => {
				const response = await requisitionMutation.mutateAsync({
					jobId: refs.jobId,
					requisition
				});
				const requisitionId = Number(response["requisitionId"]);
				updateLinks(requisition.vehicleId, { requisitionId });
				rawSetRequisitions((items) => items.map((item) => item.id === requisition.id ? mapRequisitionResponse(response, item) : item));
				await recordsQuery.refetch();
			});
		}
	}, [
		requisitionsRef,
		rawSetRequisitions,
		requisitionMutation,
		persist,
		reportFailure,
		updateLinks,
		recordsQuery
	]);
	const setInspections = (0, import_react.useCallback)((action) => {
		const previous = inspectionsRef.current;
		rawSetInspections(action);
		const next = inspectionsRef.current;
		for (const inspection of next.filter((item) => !previous.some((old) => old.id === item.id))) {
			const refs = linkRef.current[inspection.vehicleId];
			if (!refs?.jobId) {
				reportFailure(/* @__PURE__ */ new Error("This vehicle has no saved backend job yet."));
				continue;
			}
			persist(async () => {
				const response = await inspectionMutation.mutateAsync(refs.jobId);
				const inspectionId = Number(response["inspectionId"]);
				updateLinks(inspection.vehicleId, { inspectionId });
				rawSetInspections((items) => items.map((item) => item.id === inspection.id ? mapInspectionResponse(response, item) : item));
				await recordsQuery.refetch();
			});
		}
	}, [
		inspectionsRef,
		rawSetInspections,
		inspectionMutation,
		persist,
		reportFailure,
		updateLinks,
		recordsQuery
	]);
	function addActivity(text, detail) {
		setActivities((prev) => [{
			text,
			detail,
			time: "Just now"
		}, ...prev]);
	}
	function updateVehicleStage(id, stage) {
		setVehicles((prev) => prev.map((v) => v.id === id ? {
			...v,
			stage: Math.max(v.stage, stage)
		} : v));
	}
	function vehicleFor(id) {
		return vehicles.find((v) => v.id === id);
	}
	return {
		isAuthenticated,
		currentUser,
		showOnboarding,
		setShowOnboarding,
		login,
		register,
		logout,
		role,
		setRole,
		foreman,
		setForeman,
		employeeDepartment,
		setEmployeeDepartment,
		search,
		setSearch,
		vehicles,
		setVehicles,
		quotations,
		setQuotations,
		inventory,
		setInventory: rawSetInventory,
		jobs,
		setJobs,
		requisitions,
		setRequisitions,
		inspections,
		setInspections,
		activities,
		addActivity,
		updateVehicleStage,
		vehicleFor,
		loading,
		error,
		backendRefs: links,
		parts,
		refresh: recordsQuery.refetch,
		viewCustomerApproval: backendApi.viewCustomerApproval,
		submitCustomerApproval: backendApi.submitCustomerApproval,
		workflows,
		workflowOptions,
		purchaseOrders,
		dispatches,
		invoices,
		handovers,
		inspectionDetails,
		api: backendApi
	};
}
var WorkspaceContext = (0, import_react.createContext)(null);
function WorkspaceProvider({ children }) {
	const value = useWorkspaceState();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WorkspaceContext.Provider, {
		value,
		children
	});
}
function useWorkspace() {
	const context = (0, import_react.useContext)(WorkspaceContext);
	if (!context) throw new Error("Workshop screens require WorkspaceProvider");
	return context;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var SIZE_CLASSES = {
	10: "text-[10px]",
	11: "text-[11px]",
	12: "text-xs",
	13: "text-[13px]",
	14: "text-sm",
	15: "text-[15px]",
	16: "text-base",
	18: "text-lg",
	19: "text-[19px]",
	20: "text-xl",
	22: "text-[22px]",
	23: "text-[23px]",
	24: "text-2xl"
};
function createSolidIcon(icon) {
	return function SolidFaIcon({ size, className, "aria-hidden": ariaHidden }) {
		const sizeClass = size ? SIZE_CLASSES[size] : void 0;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FontAwesomeIcon, {
			icon,
			fixedWidth: true,
			"aria-hidden": ariaHidden,
			className: cn(sizeClass, className)
		});
	};
}
var AlertCircle = createSolidIcon(faCircleExclamation);
var Archive = createSolidIcon(faBoxArchive);
var ArrowRight = createSolidIcon(faArrowRight);
var ArrowUpRight = createSolidIcon(faArrowUpRightFromSquare);
var Bell = createSolidIcon(faBell);
var Briefcase = createSolidIcon(faBriefcase);
var CalendarDays = createSolidIcon(faCalendarDays);
var Camera = createSolidIcon(faCamera);
var Car = createSolidIcon(faCar);
var ChartNoAxesColumnIncreasing = createSolidIcon(faChartColumn);
var Check = createSolidIcon(faCheck);
var CheckCircle2 = createSolidIcon(faCircleCheck);
var ChevronDown = createSolidIcon(faChevronDown);
var ChevronRight = createSolidIcon(faChevronRight);
var ClipboardCheck = createSolidIcon(faClipboardCheck);
var ClipboardList = createSolidIcon(faClipboardList);
var Clock = createSolidIcon(faClock);
var Copy = createSolidIcon(faCopy);
var Download = createSolidIcon(faDownload);
var Eye = createSolidIcon(faEye);
var EyeOff = createSolidIcon(faEyeSlash);
var FileText = createSolidIcon(faFileLines);
var FolderOpen = createSolidIcon(faFolderOpen);
var GitBranch = createSolidIcon(faCodeBranch);
var KeyRound = createSolidIcon(faKey);
var LayoutDashboard = createSolidIcon(faTableCellsLarge);
var Loader2 = createSolidIcon(faSpinner);
var Lock = createSolidIcon(faLock);
var LogOut = createSolidIcon(faRightFromBracket);
var Mail = createSolidIcon(faEnvelope);
var Menu = createSolidIcon(faBars);
var MessageSquare = createSolidIcon(faCommentDots);
var Monitor = createSolidIcon(faDesktop);
var Moon = createSolidIcon(faMoon);
var Package = createSolidIcon(faBoxesStacked);
var Plus = createSolidIcon(faPlus);
var Printer = createSolidIcon(faPrint);
var RotateCcw = createSolidIcon(faRotateLeft);
var Save = createSolidIcon(faFloppyDisk);
var Search = createSolidIcon(faMagnifyingGlass);
var Send = createSolidIcon(faPaperPlane);
var Settings = createSolidIcon(faGear);
var Shield = createSolidIcon(faShield);
var ShieldCheck = createSolidIcon(faShieldHalved);
var SlidersHorizontal = createSolidIcon(faSliders);
var Sparkles = createSolidIcon(faWandMagicSparkles);
var StickyNote = createSolidIcon(faNoteSticky);
var Sun = createSolidIcon(faSun);
var Trash2 = createSolidIcon(faTrash);
var Truck = createSolidIcon(faTruck);
var User = createSolidIcon(faUser);
var UserCheck = createSolidIcon(faUserCheck);
var UserRound = createSolidIcon(faUser);
var Wrench = createSolidIcon(faWrench);
var X = createSolidIcon(faXmark);
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[5px] text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/30 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:bg-[var(--sidebar-royal-deep)] active:translate-y-px",
			navigation: "text-navy-muted hover:text-primary-foreground hover:bg-navy-border",
			destructive: "bg-[#dc2626] text-white hover:bg-[#b91c1c] active:translate-y-px",
			outline: "border-[1.5px] border-primary/85 bg-background text-primary hover:bg-accent hover:border-primary hover:text-[var(--sidebar-royal-deep)] active:translate-y-px",
			secondary: "border border-[#d1d5db] bg-[#f8fafc] text-[#1f2937] hover:bg-[#e5e7eb] hover:text-[#111827] active:translate-y-px",
			ghost: "text-foreground hover:bg-accent hover:text-primary",
			link: "text-primary font-medium underline decoration-[1.5px] underline-offset-4 hover:text-[var(--sidebar-royal-deep)]"
		},
		size: {
			default: "h-9 rounded-[5px] px-4 py-2",
			sm: "h-8 rounded-[5px] px-3 text-sm",
			lg: "h-10 rounded-[5px] px-7 text-sm",
			icon: "h-9 w-9 rounded-[5px]"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
//#endregion
export { UserCheck as $, LogOut as A, Save as B, FileText as C, LayoutDashboard as D, KeyRound as E, Moon as F, ShieldCheck as G, Send as H, Package as I, StickyNote as J, SlidersHorizontal as K, Plus as L, Menu as M, MessageSquare as N, Loader2 as O, Monitor as P, User as Q, Printer as R, EyeOff as S, GitBranch as T, Settings as U, Search as V, Shield as W, Trash2 as X, Sun as Y, Truck as Z, ClipboardList as _, useWorkspace as _t, Bell as a, canAuthorizeRelease as at, Download as b, CalendarDays as c, cn as ct, ChartNoAxesColumnIncreasing as d, formatCompactNumber as dt, UserRound as et, Check as f, money as ft, ClipboardCheck as g, stageOwners as gt, ChevronRight as h, stageName as ht, ArrowUpRight as i, backendApi as it, Mail as j, Lock as k, Camera as l, departmentStats as lt, ChevronDown as m, sortRecords as mt, Archive as n, Wrench as nt, Briefcase as o, canCreateInventory as ot, CheckCircle2 as p, nextSortState as pt, Sparkles as q, ArrowRight as r, X as rt, Button as s, canDecideParts as st, AlertCircle as t, WorkspaceProvider as tt, Car as u, departments as ut, Clock as v, workflowStages as vt, FolderOpen as w, Eye as x, Copy as y, RotateCcw as z };
