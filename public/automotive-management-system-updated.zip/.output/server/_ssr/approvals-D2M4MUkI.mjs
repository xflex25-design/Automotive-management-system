import { n as ApprovalPage } from "./monitor-pages-C0fryP1_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/approvals-D2M4MUkI.js
var SplitComponent = ApprovalPage;
//#endregion
export { SplitComponent as component };
