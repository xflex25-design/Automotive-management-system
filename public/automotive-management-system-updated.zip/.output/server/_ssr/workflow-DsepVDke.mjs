import { s as WorkflowPage } from "./monitor-pages-C0fryP1_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workflow-DsepVDke.js
var SplitComponent = WorkflowPage;
//#endregion
export { SplitComponent as component };
