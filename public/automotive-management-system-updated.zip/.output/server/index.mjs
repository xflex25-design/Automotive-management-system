globalThis.__nitro_main__ = import.meta.url;
import { n as defineLazyEventHandler, r as HTTPError, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/hirider-logo-official.jpeg": {
		"type": "image/jpeg",
		"etag": "\"cc76-gvMunpYMW1Qf1KMUWmrTrb/kF6A\"",
		"mtime": "2026-11-15T18:07:30.571Z",
		"size": 52342,
		"path": "../public/hirider-logo-official.jpeg"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-11-15T18:07:30.571Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-11-15T18:07:30.571Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/alerts-bSz5gUqN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c9-y/RF++csCXVCTR5oG3io3u0G6ww\"",
		"mtime": "2026-11-15T18:07:29.850Z",
		"size": 201,
		"path": "../public/assets/alerts-bSz5gUqN.js"
	},
	"/assets/approvals-CWj05XuW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d0-MI23tPu7QyIGionoOsX+EMJ+lOo\"",
		"mtime": "2026-11-15T18:07:29.850Z",
		"size": 208,
		"path": "../public/assets/approvals-CWj05XuW.js"
	},
	"/assets/dashboard-BjlMLzjf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a1e-7niU7x/hhKDZnTZjWSxIdN3CSwQ\"",
		"mtime": "2026-11-15T18:07:29.850Z",
		"size": 35358,
		"path": "../public/assets/dashboard-BjlMLzjf.js"
	},
	"/assets/departments-FmUdlX8B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d8-eH3dbxt+fejpLAJVTngV6F9yWiE\"",
		"mtime": "2026-11-15T18:07:29.850Z",
		"size": 216,
		"path": "../public/assets/departments-FmUdlX8B.js"
	},
	"/assets/director-DYHvkNLn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"180-UruNqo/KW/DJT7q/YnxBsXtTGmM\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 384,
		"path": "../public/assets/director-DYHvkNLn.js"
	},
	"/assets/dist-pmrAdYzb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15b73-Zpx8ArpAGItQOAaHh3Y7xz0gB04\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 88947,
		"path": "../public/assets/dist-pmrAdYzb.js"
	},
	"/assets/employee-HGJKPXHm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9284-yU0adkdft0MBnIacRsZrHUNWPQ8\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 37508,
		"path": "../public/assets/employee-HGJKPXHm.js"
	},
	"/assets/index-BCOHKaIK.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"7763-9PK4ZhgwuJs54Bw/nrRAfxey7Nc\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 30563,
		"path": "../public/assets/index-BCOHKaIK.css"
	},
	"/assets/inspections-DHFJ0eCA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18d-fvC8UlkNfVdXPzI/md1eVhvw5l0\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 397,
		"path": "../public/assets/inspections-DHFJ0eCA.js"
	},
	"/assets/management-BF4uBNdC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"184-PKX5GSwvmmpoBRZjtFHAMc1Xj+0\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 388,
		"path": "../public/assets/management-BF4uBNdC.js"
	},
	"/assets/procurement-R20vqe96.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d8-j7L4+JjcLyp9dMoc7WIeaeprWi8\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 216,
		"path": "../public/assets/procurement-R20vqe96.js"
	},
	"/assets/monitor-pages-B-tlhenF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f0e2-yFqfGbacPHIYkcZDc/bYtBccP2w\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 61666,
		"path": "../public/assets/monitor-pages-B-tlhenF.js"
	},
	"/assets/profile-Dic5C1Q5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"48bd-/CBNbtKvBCUKxMiRq/gprugNDKY\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 18621,
		"path": "../public/assets/profile-Dic5C1Q5.js"
	},
	"/assets/inventory-BV7DQ0nk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"189-CfLgNHCuzi3LVAI/plG0fdxwqks\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 393,
		"path": "../public/assets/inventory-BV7DQ0nk.js"
	},
	"/assets/quotations-ByA8PPHk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18b-+Hs4oyxADOjcn1EPRqMyW9G/fFM\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 395,
		"path": "../public/assets/quotations-ByA8PPHk.js"
	},
	"/assets/reports-K6OjhOzk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cc-KFLfV4+oNIAz4Bs3WpjsqSxe/HE\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 204,
		"path": "../public/assets/reports-K6OjhOzk.js"
	},
	"/assets/record-pages-Zto0897Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"429bd-wNBdznpkYkncQajg07odqTDVqlI\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 272829,
		"path": "../public/assets/record-pages-Zto0897Q.js"
	},
	"/assets/registration-D_NO4IZG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"252d-oiyUDIbKhwuSYB/LzcDk084GH0Y\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 9517,
		"path": "../public/assets/registration-D_NO4IZG.js"
	},
	"/assets/button-ByH67M_G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"81ec8-H7v840ulcQXx9rvutOeJxciR8cc\"",
		"mtime": "2026-11-15T18:07:29.850Z",
		"size": 532168,
		"path": "../public/assets/button-ByH67M_G.js"
	},
	"/assets/index-DDvlJ1GD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e642f-8znVfEL+M/3Q3nYGiXAxdkn25t8\"",
		"mtime": "2026-11-15T18:07:29.850Z",
		"size": 943151,
		"path": "../public/assets/index-DDvlJ1GD.js"
	},
	"/automotive-management-system-updated.zip": {
		"type": "application/zip",
		"etag": "\"1eb099-aqCEWIhkanypc4mYklC4OPWX2C0\"",
		"mtime": "2026-11-15T18:07:30.573Z",
		"size": 2011289,
		"path": "../public/automotive-management-system-updated.zip"
	},
	"/assets/job-cards-CFmMVLvJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"184-6bWGUHFSRv58toNJtv0PsrSF0ZI\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 388,
		"path": "../public/assets/job-cards-CFmMVLvJ.js"
	},
	"/assets/requisitions-DEJDY-4Q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18f-WYuYgpsD4tKRshukpljjeLy4KUY\"",
		"mtime": "2026-11-15T18:07:29.851Z",
		"size": 399,
		"path": "../public/assets/requisitions-DEJDY-4Q.js"
	},
	"/assets/settings-VT_D4zz6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"398-f+A69N6TseL87ERtOXsTsVYxvTI\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 920,
		"path": "../public/assets/settings-VT_D4zz6.js"
	},
	"/assets/routes-qWzjjTjF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"175-x4CGRQLvye5rzHJnUkjbqhBY514\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 373,
		"path": "../public/assets/routes-qWzjjTjF.js"
	},
	"/assets/shared-D1FqIhYl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5744-TfyknE++6IQH+gdz/K1RdyXV90g\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 22340,
		"path": "../public/assets/shared-D1FqIhYl.js"
	},
	"/assets/textarea-CehZkQXX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b5-FpXu2T/MWOxqLaf0xRzE4wzhvlc\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 1461,
		"path": "../public/assets/textarea-CehZkQXX.js"
	},
	"/assets/vehicle-detail-DCFpkq95.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c90-jdNZOq/AKqz+8YH6iJfhPz+1y9Q\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 7312,
		"path": "../public/assets/vehicle-detail-DCFpkq95.js"
	},
	"/assets/vehicles-0SfOK6-v.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-JnsyUQxWdVZ/yd1UhW2uDEW75Vo\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 207,
		"path": "../public/assets/vehicles-0SfOK6-v.js"
	},
	"/assets/workflow-AYcKlSua.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-pg+IWLhYi9yfVWV/6kxnHHTeQKU\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 207,
		"path": "../public/assets/workflow-AYcKlSua.js"
	},
	"/assets/workshop-Bh1OGZ8c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-GLeiQr/mgD+DKjFqnbEmJToHykk\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 207,
		"path": "../public/assets/workshop-Bh1OGZ8c.js"
	},
	"/assets/aistudio/fleet-management-software-ss1_6ba1efe4.png": {
		"type": "image/png",
		"etag": "\"139c4-gyjK6BtgbldfLW5XCHKuA3E4nKY\"",
		"mtime": "2026-11-15T18:07:30.571Z",
		"size": 80324,
		"path": "../public/assets/aistudio/fleet-management-software-ss1_6ba1efe4.png"
	},
	"/assets/styles-GYn-FZ1U.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"25fee-98ekeb18EoLtQBcG0BEWIb+EJTk\"",
		"mtime": "2026-11-15T18:07:29.852Z",
		"size": 155630,
		"path": "../public/assets/styles-GYn-FZ1U.css"
	},
	"/assets/aistudio/low-text-contrast-ratio-5_b7b3a679.png": {
		"type": "image/png",
		"etag": "\"ab50-9XunDsNkY9BI2luKoLONRiKyDi0\"",
		"mtime": "2026-11-15T18:07:30.571Z",
		"size": 43856,
		"path": "../public/assets/aistudio/low-text-contrast-ratio-5_b7b3a679.png"
	},
	"/assets/aistudio/original-1e7fd5da132ea50da491720e2886cd1c_e43258d2.jpg": {
		"type": "image/jpeg",
		"etag": "\"7001-BbP2LDt3ai1L4N77Djnz/frb2F8\"",
		"mtime": "2026-11-15T18:07:30.571Z",
		"size": 28673,
		"path": "../public/assets/aistudio/original-1e7fd5da132ea50da491720e2886cd1c_e43258d2.jpg"
	},
	"/assets/aistudio/original-34254d96dc006f545395c5608ee39fab_409c08a3.png": {
		"type": "image/png",
		"etag": "\"11f3b-lZfeUoFZ6rZztpwzAhKdse2Hw34\"",
		"mtime": "2026-11-15T18:07:30.571Z",
		"size": 73531,
		"path": "../public/assets/aistudio/original-34254d96dc006f545395c5608ee39fab_409c08a3.png"
	},
	"/assets/aistudio/original-39049d64f840a180e2b0d1c90de5444b_6ad822d0.jpg": {
		"type": "image/jpeg",
		"etag": "\"21208-/RImBz/G5LkYHE0oHqBJF6rmQLQ\"",
		"mtime": "2026-11-15T18:07:30.571Z",
		"size": 135688,
		"path": "../public/assets/aistudio/original-39049d64f840a180e2b0d1c90de5444b_6ad822d0.jpg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_6qWkqV = defineLazyEventHandler(() => import("./_chunks/renderer-template.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_6qWkqV
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
