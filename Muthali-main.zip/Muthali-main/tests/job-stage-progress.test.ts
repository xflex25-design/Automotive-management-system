import test from "node:test";
import assert from "node:assert/strict";
import {
  buildJobCardStageProgress,
  calculateQuotationTotals,
  evaluateJobStageReadiness,
} from "../src/lib/workshop-flow";
import type { JobCard, Quotation, Requisition, Vehicle } from "../src/lib/workshop";

function makeVehicle(): Vehicle {
  return {
    id: "VR-3001",
    plate: "BAK 9921",
    make: "Toyota",
    model: "Hilux",
    customer: "John Mwale",
    phone: "0977123456",
    email: "john@example.com",
    received: "17 Nov 2026",
    stage: 1,
    complaints: "Routine brake service",
    damage: "None",
    department: "Mechanical",
    foreman: "Foreman 01",
    due: "2026-11-20",
    progress: 13,
    odometer: 120000,
    intakeDetails: {
      customerType: "Individual",
      customerAddress: "",
      driverName: "John Mwale",
      model: "Hilux",
      year: "2018",
      engineNumber: "",
      mileageIn: 120000,
      fuelLevelIn: "Full",
      accessories: [],
      damageTypes: [],
      additionalRemarks: "",
      requestedRepairs: "",
      additionalInstructions: "",
      termsAccepted: true,
      customerSignature: "John Mwale",
      intakeOfficer: "Foreman 01",
      authorizationDate: "2026-11-17",
      deliveredBy: "Self",
      deliveredPhone: "0977123456",
      receivedBy: "Foreman 01",
      receivedSignature: "Foreman 01",
      status: "completed",
    },
  };
}

function makeApprovedQuotation(): Quotation {
  const totals = calculateQuotationTotals([{ quantity: 1, unitPrice: 850 }]);
  return {
    id: "QT-3001",
    vehicleId: "VR-3001",
    description: "Brake Pads",
    amount: totals.total,
    subtotal: totals.subtotal,
    taxAmount: totals.vat,
    quotationDate: "2026-11-17",
    preparedByName: "Foreman 01",
    status: "Approved",
    items: [
      {
        itemType: "PART",
        item: "Brake Pads",
        description: "Front brake pads",
        quantity: 1,
        unitPrice: 850,
      },
    ],
    paperFields: {
      signature: "Foreman 01",
    },
    authorization: {
      customerAcceptance: "Accepted",
      terms: {
        permissionRepairs: true,
        permissionMaterials: true,
        vehicleSecurity: true,
        additionalWork: true,
        paymentCollection: true,
      },
      requiredDepositPercent: 50,
      depositAmount: totals.requiredDeposit,
      paymentStatus: "Deposit Paid",
      paymentReference: "RCP-101",
      customerName: "John Mwale",
      customerSignature: "John Mwale",
      authorizationDate: "2026-11-17",
    },
  };
}

function makeJobCard(): JobCard {
  return {
    id: "JC-3001",
    vehicleId: "VR-3001",
    department: "Mechanical",
    work: "Replace front brake pads",
    status: "Completed",
    due: "2026-11-20",
    preparedBy: "Foreman 01",
    assignedEmployee: "Lead Mechanic",
    routedDepartments: ["Mechanical"],
    startDate: "2026-11-17",
    departmentProgress: [
      {
        department: "Mechanical",
        assignedMechanic: "Lead Mechanic",
        status: "Completed",
      },
    ],
    stagnationMeta: {
      foremanVerified: true,
      foremanVerifiedBy: "Foreman 01",
      workCompletedSummary: "Brake pads replaced and road tested",
      completionDate: "2026-11-17",
    },
  };
}

test("buildJobCardStageProgress initializes cleanly for a new intake at Stage 1", () => {
  const readiness = evaluateJobStageReadiness({
    vehicle: undefined,
    quotation: undefined,
    job: undefined,
    requisitions: [],
    dispatches: [],
  });

  const progress = buildJobCardStageProgress({
    creatingNew: true,
    readiness,
    stage8Unlocked: false,
    stage8Completed: false,
  });

  assert.equal(progress.jobRef, "New Job");
  assert.equal(progress.currentStageNumber, 1);
  assert.equal(progress.currentStageLabel, "Intake & Inspection");
  assert.equal(progress.completedStages, 0);
  assert.equal(progress.percentage, 12);
  assert.equal(progress.segments.length, 8);
  assert.equal(progress.segments[0]?.state, "current");
  assert.equal(progress.segments[1]?.state, "locked");
});

test("buildJobCardStageProgress tracks completed stages and highlights the job card current stage", () => {
  const vehicle = makeVehicle();
  const quotation = makeApprovedQuotation();
  const readiness = evaluateJobStageReadiness({
    vehicle,
    quotation,
    job: undefined,
    requisitions: [],
    dispatches: [],
  });

  const progress = buildJobCardStageProgress({
    creatingNew: false,
    readiness,
    stage8Unlocked: false,
    stage8Completed: false,
    vehicle,
  });

  assert.equal(progress.jobRef, "VR-3001");
  assert.equal(progress.currentStageNumber, 4);
  assert.equal(progress.currentStageLabel, "Job Card");
  assert.equal(progress.completedStages, 3);
  assert.equal(progress.percentage, 38);
  assert.equal(progress.segments[0]?.state, "completed");
  assert.equal(progress.segments[1]?.state, "completed");
  assert.equal(progress.segments[2]?.state, "completed");
  assert.equal(progress.segments[3]?.state, "current");
  assert.equal(progress.segments[4]?.state, "locked");
});

test("buildJobCardStageProgress reaches Stage 8 Final Release and 100% on completion", () => {
  const vehicle = makeVehicle();
  const quotation = makeApprovedQuotation();
  const job = makeJobCard();
  const requisition: Requisition = {
    id: "REQ-3001",
    vehicleId: "VR-3001",
    part: "Brake Pads",
    quantity: 1,
    department: "Mechanical",
    reason: "Front brakes",
    amount: 850,
    foreman: "Foreman 01",
    status: "Approved",
  };
  const dispatch = {
    id: "DSP-3001",
    dispatchNumber: "DSP-3001",
    requisitionId: "REQ-3001",
    jobNumber: "JC-3001",
    vehicleId: "VR-3001",
    status: "APPROVED_AND_DISPATCHED",
    managerDecision: "Approve",
  };

  const readiness = evaluateJobStageReadiness({
    vehicle,
    quotation,
    job,
    requisitions: [requisition],
    dispatches: [dispatch],
  });

  const unlockedProgress = buildJobCardStageProgress({
    readiness,
    stage8Unlocked: true,
    stage8Completed: false,
    vehicle,
    job,
  });

  assert.equal(unlockedProgress.jobRef, "JC-3001");
  assert.equal(unlockedProgress.currentStageNumber, 8);
  assert.equal(unlockedProgress.currentStageLabel, "Final Release");
  assert.equal(unlockedProgress.completedStages, 7);
  assert.equal(unlockedProgress.percentage, 88);
  assert.equal(unlockedProgress.segments[6]?.state, "completed");
  assert.equal(unlockedProgress.segments[7]?.state, "current");

  const completedProgress = buildJobCardStageProgress({
    readiness,
    stage8Unlocked: true,
    stage8Completed: true,
    vehicle: { ...vehicle, released: true },
    job,
  });

  assert.equal(completedProgress.completedStages, 8);
  assert.equal(completedProgress.percentage, 100);
  assert.equal(completedProgress.statusText, "Released");
  assert.ok(completedProgress.segments.every((seg) => seg.state === "completed"));
});
