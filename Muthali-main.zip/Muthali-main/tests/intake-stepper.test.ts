import test from "node:test";
import assert from "node:assert/strict";
import {
  calculateStepWizardPercentage,
  calculateWorkflowStepperProgress,
  evaluateIntakeStepProgress,
  evaluateJobStageReadiness,
} from "../src/lib/workshop-flow";

test("calculateStepWizardPercentage scales cleanly across multi-step wizards", () => {
  assert.equal(calculateStepWizardPercentage(0, 2, [false, false]), 25);
  assert.equal(calculateStepWizardPercentage(0, 2, [true, false]), 50);
  assert.equal(calculateStepWizardPercentage(1, 2, [true, false]), 75);
  assert.equal(calculateStepWizardPercentage(1, 2, [true, true]), 100);

  assert.equal(calculateStepWizardPercentage(0, 3, [false, false, false]), 17);
  assert.equal(calculateStepWizardPercentage(1, 3, [true, true, false]), 67);
  assert.equal(calculateStepWizardPercentage(2, 3, [true, true, true]), 100);
});

test("evaluateIntakeStepProgress starts cleanly on Step 1 of 6", () => {
  const res = evaluateIntakeStepProgress({
    activeStep: "customer",
    customerName: "",
    phone: "",
    plate: "",
    make: "",
    mileageIn: "",
    complaints: "",
    termsAccepted: true,
    customerSignature: "",
    authorizationDate: "2026-11-17",
  });

  assert.equal(res.activeStepNumber, 1);
  assert.equal(res.step1Done, false);
  assert.equal(res.step2Done, false);
  assert.equal(res.step3Done, false);
  assert.equal(res.step6Done, false);
  assert.equal(res.stepsCompletedCount, 0);
  assert.equal(res.progressPercentage, 8);
  assert.deepEqual(res.step1Missing, ["Customer Name", "Phone Number"]);
  assert.deepEqual(res.step2Missing, ["Registration No.", "Vehicle Make"]);
});

test("evaluateIntakeStepProgress updates completion cleanly across all 6 steps", () => {
  const afterStep1 = evaluateIntakeStepProgress({
    activeStep: "customer",
    customerName: "John Mwale",
    phone: "0977123456",
    plate: "",
    make: "",
    mileageIn: "",
    complaints: "",
    termsAccepted: true,
    customerSignature: "",
    authorizationDate: "2026-11-17",
  });
  assert.equal(afterStep1.step1Done, true);
  assert.equal(afterStep1.step2Done, false);
  assert.equal(afterStep1.progressPercentage, 17);

  const afterStep2 = evaluateIntakeStepProgress({
    activeStep: "vehicle",
    customerName: "John Mwale",
    phone: "0977123456",
    plate: "BAK 6213",
    make: "Toyota",
    mileageIn: "",
    complaints: "",
    termsAccepted: true,
    customerSignature: "",
    authorizationDate: "2026-11-17",
  });
  assert.equal(afterStep2.activeStepNumber, 2);
  assert.equal(afterStep2.step2Done, true);
  assert.equal(afterStep2.progressPercentage, 33);

  const afterStep3 = evaluateIntakeStepProgress({
    activeStep: "fuel_mileage",
    customerName: "John Mwale",
    phone: "0977123456",
    plate: "BAK 6213",
    make: "Toyota",
    mileageIn: "120000",
    complaints: "",
    termsAccepted: true,
    customerSignature: "",
    authorizationDate: "2026-11-17",
  });
  assert.equal(afterStep3.activeStepNumber, 3);
  assert.equal(afterStep3.step3Done, true);
  assert.equal(afterStep3.progressPercentage, 50);

  const onStep6Partial = evaluateIntakeStepProgress({
    activeStep: "scope_authorization",
    customerName: "John Mwale",
    phone: "0977123456",
    plate: "BAK 6213",
    make: "Toyota",
    mileageIn: "120000",
    accessoriesReviewed: true,
    conditionReviewed: true,
    complaints: "Brake squeak and oil change",
    termsAccepted: true,
    customerSignature: "",
    authorizationDate: "2026-11-17",
  });
  assert.equal(onStep6Partial.activeStepNumber, 6);
  assert.equal(onStep6Partial.step6Done, false);
  assert.equal(onStep6Partial.progressPercentage, 92);
  assert.deepEqual(onStep6Partial.step6Missing, ["Customer Signature"]);

  const allDone = evaluateIntakeStepProgress({
    activeStep: "scope_authorization",
    customerName: "John Mwale",
    phone: "0977123456",
    plate: "BAK 6213",
    make: "Toyota",
    mileageIn: "120000",
    accessoriesReviewed: true,
    conditionReviewed: true,
    complaints: "Brake squeak and oil change",
    termsAccepted: true,
    customerSignature: "John Mwale",
    authorizationDate: "2026-11-17",
  });
  assert.equal(allDone.step6Done, true);
  assert.equal(allDone.stepsCompletedCount, 6);
  assert.equal(allDone.progressPercentage, 100);
  assert.deepEqual(allDone.allMissing, []);
});

test("calculateWorkflowStepperProgress tracks 8-stage workflow completion accurately", () => {
  const emptyReadiness = evaluateJobStageReadiness({
    vehicle: undefined,
    quotation: undefined,
    job: undefined,
    requisitions: [],
    dispatches: [],
  });

  const newRes = calculateWorkflowStepperProgress({
    creatingNew: true,
    readiness: emptyReadiness,
    stage8Completed: false,
  });
  assert.deepEqual(newRes, { completedStages: 0, totalStages: 8, percentage: 12 });
});
