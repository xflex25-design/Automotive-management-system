import test from "node:test";
import assert from "node:assert/strict";
import {
  categorizeActivity,
  extractActivityEntityRef,
  filterActivities,
  formatActivityRelativeTime,
  getActivityCategoryMeta,
  DEFAULT_RECENT_ACTIVITIES,
  type ActivityCategory,
} from "../src/lib/activity-feed";

test("categorizeActivity detects primary workshop action domains", () => {
  assert.equal(categorizeActivity("Job card updated: JC-881"), "job_card");
  assert.equal(
    categorizeActivity("Bay progress moved to In Progress", "Mechanic Peter assigned"),
    "job_card",
  );
  assert.equal(categorizeActivity("New vehicle registered: Toyota Hilux (BAK 6213)"), "vehicle");
  assert.equal(categorizeActivity("Stage 1 Intake inspection completed"), "vehicle");
  assert.equal(categorizeActivity("Quotation issued: QT-1021"), "quotation");
  assert.equal(
    categorizeActivity("Customer authorization confirmed", "50% deposit received"),
    "authorization",
  );
  assert.equal(categorizeActivity("Parts verified & requisition approved"), "parts");
  assert.equal(categorizeActivity("Dispatch order approved to workshop floor"), "parts");
  assert.equal(categorizeActivity("Final Inspection passed: INS-301"), "inspection");
  assert.equal(categorizeActivity("System database synchronized"), "system");
});

test("getActivityCategoryMeta provides color badges and labels", () => {
  const categories: ActivityCategory[] = [
    "job_card",
    "vehicle",
    "quotation",
    "authorization",
    "parts",
    "inspection",
    "system",
  ];

  for (const cat of categories) {
    const meta = getActivityCategoryMeta(cat);
    assert.equal(meta.id, cat);
    assert.ok(meta.label.length > 0);
    assert.ok(meta.badgeClass.includes("text-"));
    assert.ok(meta.dotClass.includes("bg-"));
    assert.ok(meta.iconName.length > 0);
  }
});

test("formatActivityRelativeTime computes human-readable timestamps", () => {
  const baseNow = 1700000000000;

  // 10 seconds ago -> "Just now"
  assert.equal(formatActivityRelativeTime(baseNow - 10_000, "Old", baseNow), "Just now");

  // 12 minutes ago -> "12m ago"
  assert.equal(formatActivityRelativeTime(baseNow - 12 * 60 * 1000, "Old", baseNow), "12m ago");

  // 3 hours ago -> "3h ago"
  assert.equal(formatActivityRelativeTime(baseNow - 3 * 3600 * 1000, "Old", baseNow), "3h ago");

  // 2 days ago -> "2d ago"
  assert.equal(formatActivityRelativeTime(baseNow - 2 * 86400 * 1000, "Old", baseNow), "2d ago");

  // Missing or invalid timestamp falls back to timeString
  assert.equal(formatActivityRelativeTime(undefined, "Yesterday", baseNow), "Yesterday");
});

test("extractActivityEntityRef extracts job, vehicle, and quote IDs", () => {
  const jobRef = extractActivityEntityRef("Job card updated: JC-881", "Assigned to Mechanic");
  assert.equal(jobRef.entityType, "job");
  assert.equal(jobRef.referenceId, "JC-881");

  const vehRef = extractActivityEntityRef("New vehicle registered: Ford Ranger (VR-1002)");
  assert.equal(vehRef.entityType, "vehicle");
  assert.equal(vehRef.referenceId, "VR-1002");

  const quoteRef = extractActivityEntityRef("Quotation issued: QT-1021");
  assert.equal(quoteRef.entityType, "quotation");
  assert.equal(quoteRef.referenceId, "QT-1021");

  const plateRef = extractActivityEntityRef("Vehicle intake checked in", "Plate BAK 6213");
  assert.equal(plateRef.entityType, "vehicle");
  assert.equal(plateRef.referenceId, "BAK 6213");
});

test("filterActivities filters by query and category correctly", () => {
  const activities = [
    { text: "Job card updated: JC-881", detail: "Mechanical bay", time: "5m ago" },
    { text: "New vehicle registered: Hilux", detail: "BAK 6213", time: "10m ago" },
    { text: "Quotation issued: QT-1021", detail: "Major service", time: "20m ago" },
    { text: "Job card created: JC-882", detail: "Electrical bay", time: "30m ago" },
  ];

  // Filter by category
  const jobCards = filterActivities(activities, { category: "job_card" });
  assert.equal(jobCards.length, 2);
  assert.ok(jobCards.every((a) => a.text.includes("Job card")));

  // Filter by search query
  const searchResults = filterActivities(activities, { query: "BAK 6213" });
  assert.equal(searchResults.length, 1);
  assert.equal(searchResults[0]?.text, "New vehicle registered: Hilux");

  // Combined query & category
  const combined = filterActivities(activities, { category: "job_card", query: "Electrical" });
  assert.equal(combined.length, 1);
  assert.equal(combined[0]?.text, "Job card created: JC-882");

  // All category without query returns all
  const all = filterActivities(activities, { category: "all" });
  assert.equal(all.length, 4);
});

test("DEFAULT_RECENT_ACTIVITIES includes expected workshop actions", () => {
  assert.ok(DEFAULT_RECENT_ACTIVITIES.length >= 4);
  const titles = DEFAULT_RECENT_ACTIVITIES.map((a) => a.text);
  assert.ok(titles.some((t) => t.includes("Job card updated")));
  assert.ok(titles.some((t) => t.includes("New vehicle registered")));
});
