import test from "node:test";
import assert from "node:assert/strict";
import {
  getWorkflowStageLabel,
  getInspectionInspector,
  type DispatchOrder,
  type HandoverRecord,
  type Inspection,
  type InventoryCard,
  type JobCard,
  type Quotation,
  type Requisition,
  type Vehicle,
} from "../src/lib/workshop";
import {
  getCentralDatabase,
  migrateAndSaveDatabase,
  registerUserInDatabase,
  saveCentralDatabase,
  updateUserPasswordInDatabase,
  updateUserPreferencesInDatabase,
  updateUserRoleInDatabase,
  verifyUserCredentials,
} from "../src/lib/database-sync";
import {
  mapDispatchResponse,
  mapHandoverResponse,
  mapInspectionResponse,
  mapInventoryResponse,
  mapJobCardResponse,
  mapQuotationResponse,
  mapRequisitionResponse,
  mapVehicleResponse,
  toCreateDispatchRequest,
  toCreateHandoverRequest,
  toCreateJobCardRequest,
  toCreateQuotationRequest,
  toCreateRequisitionRequest,
  toCreateVehicleRequest,
} from "../src/lib/api";

function installMemoryStorage(seed: Record<string, string> = {}) {
  const store = new Map<string, string>(Object.entries(seed));
  const storage: Storage = {
    get length() {
      return store.size;
    },
    clear() {
      store.clear();
    },
    getItem(key: string) {
      return store.has(key) ? (store.get(key) ?? null) : null;
    },
    key(index: number) {
      return Array.from(store.keys())[index] ?? null;
    },
    removeItem(key: string) {
      store.delete(key);
    },
    setItem(key: string, value: string) {
      store.set(key, String(value));
    },
  };

  (globalThis as unknown as { localStorage: Storage }).localStorage = storage;
  (globalThis as unknown as { window: { localStorage: Storage } }).window = {
    localStorage: storage,
  };
  return store;
}

function withBackendEnv<T>(fn: () => T): T {
  const prevCompany = process.env["VITE_COMPANY_ID"];
  const prevWorkshop = process.env["VITE_WORKSHOP_ID"];
  const prevUser = process.env["VITE_USER_ID"];
  const prevEmployee = process.env["VITE_EMPLOYEE_ID"];
  process.env["VITE_COMPANY_ID"] = "1";
  process.env["VITE_WORKSHOP_ID"] = "1";
  process.env["VITE_USER_ID"] = "1001";
  process.env["VITE_EMPLOYEE_ID"] = "101";
  try {
    return fn();
  } finally {
    if (prevCompany === undefined) delete process.env["VITE_COMPANY_ID"];
    else process.env["VITE_COMPANY_ID"] = prevCompany;
    if (prevWorkshop === undefined) delete process.env["VITE_WORKSHOP_ID"];
    else process.env["VITE_WORKSHOP_ID"] = prevWorkshop;
    if (prevUser === undefined) delete process.env["VITE_USER_ID"];
    else process.env["VITE_USER_ID"] = prevUser;
    if (prevEmployee === undefined) delete process.env["VITE_EMPLOYEE_ID"];
    else process.env["VITE_EMPLOYEE_ID"] = prevEmployee;
  }
}

test("database-sync migrates v1 & legacy collections to v2 and persists user mutations", () => {
  const store = installMemoryStorage({
    hi_rider_central_db_v1: JSON.stringify({
      version: 1,
      users: [
        {
          email: "foreman@hirider.test",
          password: "Workshop123!",
          fullName: "Foreman 01",
          role: "Foreman",
        },
      ],
      vehicles: [{ id: "VR-2001", plate: "ABC 123" }],
    }),
    hi_rider_dispatches: JSON.stringify([{ id: "DO-200", dispatchNumber: "DO-200" }]),
    hi_rider_handovers: JSON.stringify([{ id: "HO-200", plate: "ABC 123" }]),
  });

  const migrated = migrateAndSaveDatabase();
  assert.equal(migrated.version, 2);
  assert.equal(migrated.vehicles.length, 1);
  assert.equal(migrated.dispatches.length, 1);
  assert.equal(migrated.handovers.length, 1);
  assert.equal(migrated.users[0]?.userId, 1001);
  assert.equal(migrated.users[0]?.employeeId, 101);
  assert.equal(migrated.users[0]?.companyName, "Hi Rider 4x4 World");
  assert.equal(migrated.users[0]?.preferences?.themeMode, "light");

  // Register new user and verify credentials
  const reg = registerUserInDatabase("tech@hirider.test", "Secret123!", "Diesel Tech");
  assert.equal(reg.success, true);
  assert.equal(reg.user?.email, "tech@hirider.test");
  assert.equal(reg.user?.userId, 1002);
  assert.equal(reg.user?.employeeId, 102);

  // Update password: wrong current password fails, valid updates and verifies
  const badPwd = updateUserPasswordInDatabase("tech@hirider.test", "WrongPwd", "NewPass99!");
  assert.equal(badPwd.success, false);
  const okPwd = updateUserPasswordInDatabase("tech@hirider.test", "Secret123!", "NewPass99!");
  assert.equal(okPwd.success, true);
  assert.equal(verifyUserCredentials("tech@hirider.test", "Secret123!").success, false);
  assert.equal(verifyUserCredentials("tech@hirider.test", "NewPass99!").success, true);

  // Update preferences & department
  const prefRes = updateUserPreferencesInDatabase("tech@hirider.test", {
    department: "Electrical",
    preferences: { themeMode: "dark", compactDensity: true, smsAlerts: false },
  });
  assert.equal(prefRes.success, true);
  assert.equal(prefRes.user?.department, "Electrical");
  assert.equal(prefRes.user?.preferences?.themeMode, "dark");
  assert.equal(prefRes.user?.preferences?.compactDensity, true);
  assert.equal(prefRes.user?.preferences?.smsAlerts, false);
  assert.equal(store.get("hi_rider_theme"), "dark");
  assert.equal(store.get("hi_rider_department"), "Electrical");

  // Update role & department in central DB
  const roleRes = updateUserRoleInDatabase("tech@hirider.test", "Employee", "Diagnostics");
  assert.equal(roleRes.success, true);
  assert.equal(roleRes.user?.role, "Employee");
  assert.equal(roleRes.user?.department, "Diagnostics");

  // Save dispatches and read back from central DB
  saveCentralDatabase({
    dispatches: [
      {
        id: "DO-301",
        dispatchNumber: "DO-301",
        vehicleId: "VR-2001",
        jobNumber: "VR-2001",
        departmentName: "Diagnostics",
        date: "2026-11-16",
        status: "APPROVED",
        items: [{ id: "1", item: "Sensor", quantity: 1, amount: 250 }],
      },
    ],
  });
  const reloaded = getCentralDatabase();
  assert.equal(reloaded.dispatches[0]?.dispatchNumber, "DO-301");
  assert.equal(reloaded.accountRoles["tech@hirider.test"]?.role, "Employee");
});

test("toCreateVehicleRequest and mapVehicleResponse align all intake & vehicle DB fields", () => {
  const vehicle: Vehicle = {
    id: "VR-9001",
    plate: "BAC 7710",
    make: "Toyota Land Cruiser",
    model: "Land Cruiser",
    year: "2022",
    color: "Pearl White",
    vin: "JT1234567890VIN",
    odometer: 84500,
    customer: "Chanda Banda",
    phone: "+260977112233",
    email: "chanda@example.com",
    received: "2026-11-16",
    due: "2026-11-20",
    stage: 0,
    department: "Mechanical",
    foreman: "Foreman 01",
    complaints: "4WD transfer case vibration",
    damage: "Minor scratch on rear bumper",
    progress: 10,
    intakeDetails: {
      customerType: "Corporate",
      customerAddress: "Plot 44 Kafue Rd, Lusaka",
      driverName: "Mulenga Phiri",
      model: "Land Cruiser",
      year: "2022",
      engineNumber: "1VD-099122",
      mileageIn: 84500,
      fuelLevelIn: "3/4",
      accessories: [{ name: "Jack", available: true, condition: "Good", remarks: "In boot" }],
      damageTypes: ["Scratch"],
      additionalRemarks: "Minor scratch on rear bumper",
      requestedRepairs: "Transfer case service",
      additionalInstructions: "Call before road test",
      termsAccepted: true,
      customerSignature: "C. Banda",
      intakeOfficer: "Foreman 01",
      authorizationDate: "2026-11-16",
      deliveredBy: "Mulenga Phiri",
      deliveredPhone: "+260966554433",
      receivedBy: "Foreman 01",
      receivedSignature: "F01",
      status: "completed",
    },
  };

  const payload = withBackendEnv(() => toCreateVehicleRequest(vehicle));
  assert.equal(payload.customer.customerType, "CORPORATE");
  assert.equal(payload.customer.address, "Plot 44 Kafue Rd, Lusaka");
  assert.equal(payload.vehicle.make, "Toyota");
  assert.equal(payload.vehicle.model, "Land Cruiser");
  assert.equal(payload.vehicle.year, "2022");
  assert.equal(payload.vehicle.engineNumber, "1VD-099122");
  assert.equal(payload.vehicle.color, "Pearl White");
  assert.equal(payload.vehicle.vin, "JT1234567890VIN");
  assert.equal(payload.broughtInByName, "Mulenga Phiri");
  assert.equal(payload.broughtInByPhone, "+260966554433");
  assert.equal(payload.odometerReadingIn, 84500);
  assert.equal(payload.fuelLevelIn, "3/4");
  assert.equal(payload.accessories.length, 1);
  assert.equal(payload.customerSignature, "C. Banda");
  assert.equal(payload.receivedSignature, "F01");

  const mapped = mapVehicleResponse(
    {
      jobId: 55,
      jobNumber: "JOB-0055",
      customerId: 12,
      customerName: "Chanda Banda",
      vehicleId: 34,
      registrationNumber: "BAC 7710",
      inventoryCardId: 77,
      jobStatus: "INTAKE",
      intakeStatus: "COMPLETED",
      dateReceived: "2026-11-16",
      make: "Toyota",
      model: "Land Cruiser",
      year: "2022",
      color: "Pearl White",
      odometerReadingIn: 84500,
    },
    vehicle,
  );
  assert.equal(mapped.id, "JOB-0055");
  assert.equal(mapped.make, "Toyota Land Cruiser");
  assert.equal(mapped.model, "Land Cruiser");
  assert.equal(mapped.year, "2022");
  assert.equal(mapped.color, "Pearl White");
  assert.equal(mapped.odometer, 84500);
  assert.equal(mapped.customerId, 12);
  assert.equal(mapped.jobId, 55);
  assert.equal(mapped.inventoryCardId, 77);
});

test("Quotation, JobCard, Requisition, Dispatch, Handover, Inventory & Inspection mappers align 1:1", () => {
  const quotation: Quotation = {
    id: "QT-501",
    vehicleId: "VR-9001",
    amount: 5800,
    subtotal: 5000,
    taxAmount: 800,
    discountAmount: 0,
    quotationDate: "2026-11-16",
    preparedByName: "Precious",
    description: "Transfer case overhaul",
    status: "Draft",
    paperFields: { quoteNo: "QT-501", salesperson: "Precious" },
    items: [
      {
        itemType: "PART",
        item: "TC-SEAL-01",
        description: "Transfer Case Seal Kit",
        quantity: 2,
        unitPrice: 1500,
        discountAmount: 0,
        lineTotal: 3000,
        taxAmount: 480,
      },
      {
        itemType: "LABOUR",
        item: "LAB-TC",
        description: "Labour",
        quantity: 1,
        unitPrice: 2000,
        discountAmount: 0,
        lineTotal: 2000,
        taxAmount: 320,
      },
    ],
  };

  const qReq = withBackendEnv(() => toCreateQuotationRequest(quotation));
  assert.equal(qReq.quotationNumber, "QT-501");
  assert.equal(qReq.issueDate, "2026-11-16");
  assert.equal(qReq.preparedByName, "Precious");
  assert.equal(qReq.subtotal, 5000);
  assert.equal(qReq.taxAmount, 800);
  assert.equal(qReq.items.length, 2);
  assert.ok(qReq.foremanNotes?.startsWith("PAPER_QUOTATION:"));

  const qMapped = mapQuotationResponse(
    {
      quotationId: 901,
      quotationNumber: "QT-501",
      quotationStatus: "PENDING_APPROVAL",
      subtotal: 5000,
      taxAmount: 800,
      totalAmount: 5800,
      issueDate: "2026-11-16",
      preparedByName: "Precious",
      foremanNotes: qReq.foremanNotes,
      items: [
        {
          itemType: "PART",
          itemCode: "TC-SEAL-01",
          description: "Transfer Case Seal Kit",
          quantity: 2,
          unitPrice: 1500,
          discountAmount: 0,
          taxAmount: 480,
        },
      ],
    },
    quotation,
  );
  assert.equal(qMapped.backendId, 901);
  assert.equal(qMapped.status, "Awaiting approval");
  assert.equal(qMapped.preparedByName, "Precious");
  assert.equal(qMapped.paperFields?.["quoteNo"], "QT-501");
  assert.equal(qMapped.items?.[0]?.lineTotal, 3000);

  // JobCard payload preserves the 6 core keys + extended routed/dates/instructions
  const job: JobCard = {
    id: "JC-881",
    vehicleId: "VR-9001",
    department: "Mechanical",
    routedDepartments: ["Mechanical", "Electrical"],
    work: "Overhaul transfer case",
    status: "In progress",
    startDate: "2026-11-16",
    due: "2026-11-19",
    assignedEmployee: "Lead Mechanic",
    approvedQuotationRef: "QT-501",
    repairsRequired: "Replace worn seals and bearings",
    inspectionFindings: "Oil weeping at output shaft",
    specialInstructions: "Torque to spec",
    remarks: "Priority 4x4",
  };
  const jcReq = withBackendEnv(() => toCreateJobCardRequest(job, { jobId: 55, quotationId: 901 }));
  assert.equal(jcReq.jobId, 55);
  assert.equal(jcReq.quotationId, 901);
  assert.equal(jcReq.preparedByEmployeeId, 101);
  assert.equal(jcReq.workDescription, "Overhaul transfer case");
  assert.equal(jcReq.repairInstructions, "Replace worn seals and bearings");
  assert.equal(jcReq.foremanRemarks, "Department: Mechanical · Priority 4x4");
  assert.deepEqual(jcReq.routedDepartments, ["Mechanical", "Electrical"]);

  const jcMapped = mapJobCardResponse(
    {
      jobCardId: 401,
      jobId: 55,
      jobCardNumber: "JC-881",
      departmentName: "Mechanical",
      routedDepartments: ["Mechanical", "Electrical"],
      workDescription: "Overhaul transfer case",
      jobCardStatus: "In progress",
      startDate: "2026-11-16",
      expectedCompletionDate: "2026-11-19",
      assignedEmployeeName: "Lead Mechanic",
    },
    job,
  );
  assert.equal(jcMapped.backendJobCardId, 401);
  assert.deepEqual(jcMapped.routedDepartments, ["Mechanical", "Electrical"]);
  assert.equal(jcMapped.assignedEmployee, "Lead Mechanic");

  // Requisition all 5 statuses
  const baseReq: Requisition = {
    id: "PR-451",
    vehicleId: "VR-9001",
    part: "Transfer Case Seal Kit",
    quantity: 2,
    department: "Mechanical",
    reason: "Leaking output seal",
    amount: 3000,
    foreman: "Foreman 01",
    status: "Pending",
    date: "2026-11-16",
  };
  const prReq = withBackendEnv(() => toCreateRequisitionRequest(baseReq));
  assert.equal(prReq.departmentName, "Mechanical");
  assert.equal(prReq.totalAmount, 3000);
  for (const [rawStatus, expected] of [
    ["PENDING", "Pending"],
    ["APPROVED", "Approved"],
    ["REJECTED", "Rejected"],
    ["ORDERED", "Ordered"],
    ["DISPATCHED", "Dispatched"],
  ] as const) {
    assert.equal(mapRequisitionResponse({ status: rawStatus }, baseReq).status, expected);
  }

  // Dispatch Order round-trip
  const dispatch: DispatchOrder = {
    id: "DO-101",
    dispatchNumber: "DO-101",
    vehicleId: "VR-9001",
    jobId: 55,
    jobNumber: "JOB-0055",
    departmentName: "Mechanical",
    date: "2026-11-16",
    status: "APPROVED",
    managerRemarks: "Approved for issue",
    items: [{ id: "1", item: "Transfer Case Seal Kit", quantity: 2, amount: 3000 }],
  };
  const doReq = withBackendEnv(() => toCreateDispatchRequest(dispatch));
  assert.equal(doReq.dispatchNumber, "DO-101");
  assert.equal(doReq.jobId, 55);
  assert.equal(doReq.departmentName, "Mechanical");
  const doMapped = mapDispatchResponse({
    dispatchOrderId: 77,
    dispatchNumber: "DO-101",
    jobId: 55,
    departmentName: "Mechanical",
    dispatchDate: "2026-11-16",
    status: "ISSUED",
    items: [{ dispatchItemId: 5, partName: "Transfer Case Seal Kit", quantity: 2, amount: 3000 }],
  });
  assert.equal(doMapped.dispatchOrderId, 77);
  assert.equal(doMapped.status, "ISSUED");
  assert.equal(doMapped.items[0]?.item, "Transfer Case Seal Kit");

  // Handover round-trip
  const handover: HandoverRecord = {
    id: "HO-55",
    vehicleId: "VR-9001",
    jobId: 55,
    plate: "BAC 7710",
    customerName: "Chanda Banda",
    collectedBy: "Chanda Banda",
    collectedPhone: "+260977112233",
    releasedBy: "Foreman 01",
    releaseSignature: "F01-SIG",
    mileageOut: 84512,
    fuelLevelOut: "Full",
    date: "2026-11-20",
    timeOut: "16:30",
  };
  const hoReq = toCreateHandoverRequest(handover);
  assert.equal(hoReq.releasedByName, "Foreman 01");
  assert.equal(hoReq.collectedPhone, "+260977112233");
  const hoMapped = mapHandoverResponse({
    handoverId: 88,
    handoverNumber: "HO-55",
    jobId: 55,
    registrationNumber: "BAC 7710",
    customerName: "Chanda Banda",
    collectedBy: "Chanda Banda",
    collectedPhone: "+260977112233",
    releasedByName: "Foreman 01",
    releaseSignature: "F01-SIG",
    mileageOut: 84512,
    fuelLevelOut: "Full",
    handoverDate: "2026-11-20",
    timeOut: "16:30",
  });
  assert.equal(hoMapped.handoverId, 88);
  assert.equal(hoMapped.releasedBy, "Foreman 01");
  assert.equal(hoMapped.mileageOut, 84512);

  // Inventory & Inspection response mapping
  const invBase: InventoryCard = {
    id: "IC-1",
    vehicleId: "VR-9001",
    items: "Jack, Spare Wheel",
    condition: "Good",
    date: "2026-11-16",
  };
  const invMapped = mapInventoryResponse(
    {
      inventoryCardId: 77,
      jobId: 55,
      generalRemarks: "Clean interior",
      fuelLevelIn: "3/4",
      odometerIn: 84500,
    },
    invBase,
  );
  assert.equal(invMapped.backendId, 77);
  assert.equal(invMapped.jobId, 55);
  assert.equal(invMapped.fuelLevelIn, "3/4");
  assert.equal(invMapped.odometerIn, 84500);

  const insBase: Inspection = {
    id: "IN-1",
    vehicleId: "VR-9001",
    foreman: "Foreman 01",
    date: "2026-11-19",
    result: "Pending",
    notes: "",
  };
  const insMapped = mapInspectionResponse(
    {
      inspectionId: 66,
      inspectionNumber: "IN-66",
      inspectorName: "Quality Foreman",
      inspectionDecision: "PASSED",
      inspectionNotes: "Road test OK",
    },
    insBase,
  );
  assert.equal(insMapped.backendId, 66);
  assert.equal(insMapped.inspector, "Quality Foreman");
  assert.equal(insMapped.result, "Passed");
  assert.equal(getInspectionInspector(insMapped), "Quality Foreman");
});

test("getWorkflowStageLabel maps all stages 0..10 and released vehicles consistently", () => {
  assert.equal(getWorkflowStageLabel({ stage: 0, released: false }), "Intake & Vehicle Inspection");
  assert.equal(getWorkflowStageLabel({ stage: 1, released: false }), "Itemized Quotation Builder");
  assert.equal(
    getWorkflowStageLabel({ stage: 6, released: false }),
    "Department Work State & Live Stagnation Monitor",
  );
  assert.equal(getWorkflowStageLabel({ stage: 7, released: false }), "Final Inspection");
  assert.equal(
    getWorkflowStageLabel({ stage: 10, released: false }),
    "Final Inspection & Handover",
  );
  assert.equal(getWorkflowStageLabel({ stage: 10, released: true }), "Released");
});
