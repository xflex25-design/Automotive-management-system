import type {
  CatalogPart,
  DispatchOrder,
  HandoverRecord,
  Inspection,
  InventoryCard,
  JobCard,
  Quotation,
  Requisition,
  Vehicle,
} from "./workshop";

const nodeEnv = typeof process !== "undefined" ? process.env : {};
const configuredApiUrl =
  (import.meta.env?.["VITE_API_URL"] ?? nodeEnv["VITE_API_URL"])?.replace(/\/$/, "") ?? "";
const apiPrefix = import.meta.env?.DEV ? "/backend-api" : configuredApiUrl;

export class ApiError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

export async function apiFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body && !(init.body instanceof FormData))
    headers.set("Content-Type", "application/json");
  const authToken =
    typeof window !== "undefined" && window.localStorage
      ? localStorage.getItem("hi_rider_auth_token")
      : null;
  if (authToken && !headers.has("Authorization")) {
    headers.set("Authorization", authToken);
  }
  const response = await fetch(`${apiPrefix}/api${path}`, { ...init, headers });
  if (!response.ok) {
    const contentType = response.headers.get("content-type") ?? "";
    const message = contentType.includes("json")
      ? await response
          .json()
          .then((body) => body.message ?? body.detail ?? body.error ?? JSON.stringify(body))
          .catch(() => "")
      : await response.text().catch(() => "");
    throw new ApiError(message || `Backend request failed (${response.status})`, response.status);
  }
  if (response.status === 204) return undefined as T;
  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) return response.json() as Promise<T>;
  return (await response.text()) as T;
}

export type BackendRefs = {
  jobId?: number;
  vehicleId?: number;
  customerId?: number;
  inventoryCardId?: number;
  quotationId?: number;
  jobCardId?: number;
  requisitionId?: number;
  inspectionId?: number;
  repairPlanId?: number;
  invoiceId?: number;
  handoverId?: number;
};

export type BackendIntakeResponse = {
  [field: string]: unknown;
  jobId: number;
  jobNumber: string;
  customerId: number;
  customerName: string;
  vehicleId: number;
  registrationNumber: string;
  inventoryCardId: number;
  jobStatus: string;
  intakeStatus: string;
  dateReceived: string;
};

export const requiredId = (name: string, value: string | undefined) => {
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id <= 0) {
    console.warn(`Missing ${name} configuration`);
    throw new Error("Saving is not available yet. Please try again later.");
  }
  return id;
};

export const configuredCompanyId = () =>
  requiredId("VITE_COMPANY_ID", import.meta.env?.["VITE_COMPANY_ID"] ?? nodeEnv["VITE_COMPANY_ID"]);
const companyId = configuredCompanyId;
const workshopId = () =>
  requiredId(
    "VITE_WORKSHOP_ID",
    import.meta.env?.["VITE_WORKSHOP_ID"] ?? nodeEnv["VITE_WORKSHOP_ID"],
  );
const userId = () =>
  requiredId("VITE_USER_ID", import.meta.env?.["VITE_USER_ID"] ?? nodeEnv["VITE_USER_ID"]);
const employeeId = () =>
  requiredId(
    "VITE_EMPLOYEE_ID",
    import.meta.env?.["VITE_EMPLOYEE_ID"] ?? nodeEnv["VITE_EMPLOYEE_ID"],
  );

export function toCreateVehicleRequest(vehicle: Vehicle) {
  const name = vehicle.customer.trim().split(/\s+/);
  const details = vehicle.intakeDetails;
  const resolvedModel = (vehicle.model || details?.model || "").trim();
  const rawMake = vehicle.make.trim();
  const resolvedMake =
    resolvedModel && rawMake.toLowerCase().endsWith(resolvedModel.toLowerCase())
      ? rawMake.slice(0, rawMake.length - resolvedModel.length).trim() || rawMake
      : rawMake;

  const broughtInByName =
    (details?.deliveredBy && details.deliveredBy.toLowerCase() !== "self"
      ? details.deliveredBy
      : details?.driverName) || vehicle.customer;
  const broughtInByPhone = details?.deliveredPhone || vehicle.phone;

  return {
    companyId: companyId(),
    workshopId: workshopId(),
    createdByUserId: userId(),
    receivedByEmployeeId: employeeId(),
    customer: {
      customerType: details?.customerType === "Corporate" ? "CORPORATE" : "INDIVIDUAL",
      firstName: name[0] ?? vehicle.customer,
      lastName: name.slice(1).join(" "),
      phone: vehicle.phone,
      email: vehicle.email || null,
      address: details?.customerAddress || null,
    },
    vehicle: {
      registrationNumber: vehicle.plate,
      make: resolvedMake,
      model: resolvedModel || null,
      year: details?.year || vehicle.year || null,
      engineNumber: details?.engineNumber || null,
      color: vehicle.color || null,
      vin: vehicle.vin || null,
      vehicleType: "4x4",
    },
    broughtInByName,
    broughtInByPhone,
    dateReceived: vehicle.received || null,
    estimatedCompletionDate: vehicle.due || null,
    fuelLevelIn: details?.fuelLevelIn || null,
    priority: "NORMAL",
    reportedProblem: vehicle.complaints,
    odometerReadingIn: details?.mileageIn ?? vehicle.odometer ?? null,
    workRequested: details?.requestedRepairs || vehicle.complaints,
    customerComplaints: vehicle.complaints,
    additionalInstructions: details?.additionalInstructions || null,
    generalRemarks: vehicle.damage,
    damageTypes: details?.damageTypes ?? [],
    accessories: (details?.accessories ?? []).map((acc) => ({
      name: acc.name,
      available: acc.available,
      condition: acc.condition,
      remarks: acc.remarks,
    })),
    termsAccepted: details?.termsAccepted ?? true,
    customerSignature: details?.customerSignature || null,
    intakeOfficer: details?.intakeOfficer || vehicle.foreman || null,
    authorizationDate: details?.authorizationDate || null,
    receivedBy: details?.receivedBy || vehicle.foreman || null,
    receivedSignature: details?.receivedSignature || null,
  };
}

export function mapVehicleResponse(response: BackendIntakeResponse, previous: Vehicle): Vehicle {
  const model =
    typeof response["model"] === "string" && response["model"].trim()
      ? response["model"].trim()
      : (previous.model ?? previous.intakeDetails?.model);
  const make =
    typeof response["make"] === "string" && response["make"].trim()
      ? [response["make"].trim(), model].filter(Boolean).join(" ")
      : previous.make;
  const year =
    typeof response["year"] === "string" && response["year"].trim()
      ? response["year"].trim()
      : (previous.year ?? previous.intakeDetails?.year);
  const color =
    typeof response["color"] === "string" && response["color"].trim()
      ? response["color"].trim()
      : previous.color;
  const odometerRaw = response["odometerReadingIn"] ?? response["odometer"];
  const odometer =
    odometerRaw !== undefined && odometerRaw !== null && Number.isFinite(Number(odometerRaw))
      ? Number(odometerRaw)
      : previous.odometer;
  return {
    ...previous,
    id: response.jobNumber || String(response.jobId),
    plate: response.registrationNumber || previous.plate,
    make,
    ...(model ? { model } : {}),
    ...(year ? { year } : {}),
    ...(color ? { color } : {}),
    ...(odometer !== undefined ? { odometer } : {}),
    ...(Number.isSafeInteger(response.customerId) ? { customerId: response.customerId } : {}),
    ...(Number.isSafeInteger(response.jobId) ? { jobId: response.jobId } : {}),
    ...(Number.isSafeInteger(response.inventoryCardId)
      ? { inventoryCardId: response.inventoryCardId }
      : {}),
    customer: response.customerName || previous.customer,
    received: response.dateReceived
      ? new Date(response.dateReceived).toLocaleDateString("en-GB")
      : previous.received,
  };
}

export function toCreateQuotationRequest(quotation: Quotation, part?: CatalogPart) {
  const items: NonNullable<Quotation["items"]> = quotation.items?.length
    ? quotation.items
    : [
        {
          itemType: quotation.catalogPartId ? ("PART" as const) : ("LABOUR" as const),
          item: part?.name ?? quotation.description,
          description: quotation.description,
          quantity: quotation.quantity ?? 1,
          unitPrice: quotation.catalogPartId
            ? quotation.amount / (quotation.quantity ?? 1)
            : quotation.amount,
        },
      ];
  return {
    quotationNumber: quotation.id,
    ...(quotation.quotationDate ? { issueDate: quotation.quotationDate } : {}),
    preparedByEmployeeId: employeeId(),
    ...(quotation.preparedByName ? { preparedByName: quotation.preparedByName } : {}),
    subtotal: quotation.subtotal ?? quotation.amount,
    taxAmount: quotation.taxAmount ?? 0,
    discountAmount: quotation.discountAmount ?? 0,
    foremanNotes: quotation.paperFields
      ? `PAPER_QUOTATION:${JSON.stringify(quotation.paperFields)}`
      : undefined,
    items: items.map((item) => ({
      itemType: item.itemType,
      itemCode: item.item || null,
      description: item.description,
      quantity: item.quantity,
      unitOfMeasure: item.itemType === "LABOUR" ? "JOB" : "UNIT",
      unitPrice: item.unitPrice,
      ...(item.discountAmount !== undefined ? { discountAmount: item.discountAmount } : {}),
      ...(item.lineTotal !== undefined ? { lineTotal: item.lineTotal } : {}),
      ...(item.taxAmount !== undefined ? { taxAmount: item.taxAmount } : {}),
    })),
  };
}

export function mapQuotationResponse(
  response: Record<string, unknown>,
  previous: Quotation,
): Quotation {
  const total = Number(response["totalAmount"] ?? previous.amount);
  const subtotal = Number(response["subtotal"] ?? previous.subtotal ?? previous.amount);
  const taxAmount = Number(response["taxAmount"] ?? previous.taxAmount ?? 0);
  const responseItems = Array.isArray(response["items"])
    ? (response["items"] as Record<string, unknown>[])
    : null;
  const quotationDate =
    String(response["issueDate"] ?? response["createdAt"] ?? "") || previous.quotationDate;
  const preparedByName =
    String(response["preparedByName"] ?? previous.preparedByName ?? "") || undefined;
  const notes = String(response["foremanNotes"] ?? "");
  const paperMetadata = notes.startsWith("PAPER_QUOTATION:")
    ? (() => {
        try {
          const value: unknown = JSON.parse(notes.slice("PAPER_QUOTATION:".length));
          return value && typeof value === "object" && !Array.isArray(value)
            ? (value as Record<string, string>)
            : undefined;
        } catch {
          return undefined;
        }
      })()
    : undefined;
  const backendId = Number(response["quotationId"] ?? previous.backendId);
  const status = String(response["quotationStatus"] ?? "DRAFT").toUpperCase();
  return {
    ...previous,
    ...(Number.isSafeInteger(backendId) && backendId > 0 ? { backendId } : {}),
    id: String(response["quotationNumber"] ?? response["quotationId"] ?? previous.id),
    amount: Number.isFinite(total) ? total : previous.amount,
    subtotal: Number.isFinite(subtotal) ? subtotal : previous.amount,
    taxAmount: Number.isFinite(taxAmount) ? taxAmount : 0,
    discountAmount: Number(response["discountAmount"] ?? 0),
    ...(quotationDate ? { quotationDate } : {}),
    ...(preparedByName ? { preparedByName } : {}),
    ...(paperMetadata ? { paperFields: paperMetadata } : {}),
    ...(responseItems
      ? {
          items: responseItems.map((item) => ({
            itemType: String(item["itemType"] ?? "OTHER").toUpperCase() as
              "PART" | "LABOUR" | "SERVICE" | "OTHER",
            item: String(item["itemCode"] ?? ""),
            description: String(item["description"] ?? ""),
            quantity: Number(item["quantity"] ?? 0),
            unitPrice: Number(item["unitPrice"] ?? 0),
            discountAmount: Number(item["discountAmount"] ?? 0),
            lineTotal:
              Number(item["quantity"] ?? 0) * Number(item["unitPrice"] ?? 0) -
              Number(item["discountAmount"] ?? 0),
            taxAmount: Number(item["taxAmount"] ?? 0),
          })),
        }
      : {}),
    status:
      status === "APPROVED"
        ? "Approved"
        : status === "ISSUED" || status === "PENDING_APPROVAL"
          ? "Awaiting approval"
          : "Draft",
  };
}

export function toCreateJobCardRequest(job: JobCard, refs: BackendRefs) {
  if (!refs.jobId || !refs.quotationId) {
    throw new Error("A backend job and quotation are required before creating a job card.");
  }
  return {
    jobId: refs.jobId,
    quotationId: refs.quotationId,
    jobCardNumber: job.id,
    preparedByEmployeeId: job.preparedByEmployeeId ?? employeeId(),
    departmentName: job.department,
    ...(job.routedDepartments?.length ? { routedDepartments: job.routedDepartments } : {}),
    ...(job.startDate ? { startDate: job.startDate } : {}),
    ...(job.due ? { expectedCompletionDate: job.due } : {}),
    ...(job.assignedEmployee ? { assignedEmployeeName: job.assignedEmployee } : {}),
    ...(job.approvedQuotationRef ? { approvedQuotationRef: job.approvedQuotationRef } : {}),
    workDescription: job.work,
    repairInstructions: job.repairsRequired || job.work,
    ...(job.repairsRequired ? { repairsRequired: job.repairsRequired } : {}),
    ...(job.inspectionFindings ? { inspectionFindings: job.inspectionFindings } : {}),
    ...(job.specialInstructions ? { specialInstructions: job.specialInstructions } : {}),
    ...(job.partsSheet?.length ? { partsSheet: job.partsSheet } : {}),
    foremanRemarks: job.remarks
      ? `Department: ${job.department} · ${job.remarks}`
      : `Department: ${job.department}`,
  };
}

export function toCreateRequisitionRequest(requisition: Requisition) {
  const items = requisition.partsCheck?.items?.length
    ? requisition.partsCheck.items.map((item) => ({
        partName: item.partName,
        requestedQuantity: item.requiredQty,
        unitPrice: item.unitPrice ?? 0,
      }))
    : requisition.lines?.length
      ? requisition.lines.map((line) => ({
          partId: line.partId,
          partCode: line.code,
          partName: line.name,
          requestedQuantity: line.quantity,
          unitOfMeasure: line.unit,
        }))
      : [
          {
            partName: requisition.part,
            requestedQuantity: requisition.quantity,
          },
        ];
  return {
    requisitionNumber: requisition.id,
    requestedByEmployeeId: employeeId(),
    departmentName: requisition.department,
    partName: requisition.part,
    quantity: requisition.quantity,
    totalAmount: requisition.amount,
    priority: "NORMAL",
    purpose: `${requisition.part} x ${requisition.quantity}: ${requisition.reason}`,
    items,
  };
}

export function toStartInspectionRequest() {
  return { inspectorEmployeeId: employeeId() };
}

export function toCreateDispatchRequest(
  dispatch: DispatchOrder,
  refs?: {
    jobId?: number;
    mechanicEmployeeId?: number;
    departmentId?: number;
    reservationIds?: number[];
  },
) {
  return {
    dispatchNumber: dispatch.dispatchNumber,
    jobId: refs?.jobId ?? dispatch.jobId ?? 0,
    createdByEmployeeId: employeeId(),
    ...(refs?.mechanicEmployeeId ? { assignedMechanicEmployeeId: refs.mechanicEmployeeId } : {}),
    ...(refs?.departmentId ? { departmentId: refs.departmentId } : {}),
    departmentName: dispatch.departmentName,
    dispatchDate: dispatch.date,
    managerRemarks: dispatch.managerRemarks ?? "",
    items: refs?.reservationIds?.length
      ? refs.reservationIds.map((stockReservationId) => ({ stockReservationId }))
      : dispatch.items.map((item) => ({
          itemName: item.item,
          quantity: item.quantity,
          amount: item.amount,
          ...(item.stockReservationId ? { stockReservationId: item.stockReservationId } : {}),
          ...(item.partId ? { partId: item.partId } : {}),
        })),
  };
}

export function mapDispatchResponse(
  response: Record<string, unknown>,
  previous?: Partial<DispatchOrder>,
): DispatchOrder {
  const dispatchOrderId = Number(response["dispatchOrderId"] ?? previous?.dispatchOrderId);
  const dispatchNumber = String(
    response["dispatchNumber"] ??
      previous?.dispatchNumber ??
      response["id"] ??
      previous?.id ??
      "DO-101",
  );
  const rawItems = Array.isArray(response["items"])
    ? (response["items"] as Record<string, unknown>[])
    : null;
  const items = rawItems
    ? rawItems.map((entry, idx) => ({
        id: String(entry["id"] ?? entry["dispatchItemId"] ?? `di-${idx}`),
        item: String(entry["itemName"] ?? entry["item"] ?? entry["partName"] ?? ""),
        quantity: Number(entry["quantity"] ?? 1),
        amount: Number(entry["amount"] ?? entry["lineTotal"] ?? 0),
        ...(Number(entry["stockReservationId"]) > 0
          ? { stockReservationId: Number(entry["stockReservationId"]) }
          : {}),
        ...(Number(entry["partId"]) > 0 ? { partId: Number(entry["partId"]) } : {}),
      }))
    : (previous?.items ?? []);

  return {
    ...(previous ?? {}),
    id: String(response["id"] ?? dispatchNumber),
    ...(Number.isSafeInteger(dispatchOrderId) && dispatchOrderId > 0 ? { dispatchOrderId } : {}),
    dispatchNumber,
    vehicleId: String(response["vehicleId"] ?? previous?.vehicleId ?? ""),
    ...(Number(response["jobId"] ?? previous?.jobId) > 0
      ? { jobId: Number(response["jobId"] ?? previous?.jobId) }
      : {}),
    jobNumber: String(response["jobNumber"] ?? previous?.jobNumber ?? ""),
    departmentName: String(response["departmentName"] ?? previous?.departmentName ?? "Workshop"),
    date: String(response["dispatchDate"] ?? response["date"] ?? previous?.date ?? ""),
    status: String(response["status"] ?? previous?.status ?? "PENDING_APPROVAL"),
    ...(response["managerRemarks"] !== undefined || previous?.managerRemarks !== undefined
      ? { managerRemarks: String(response["managerRemarks"] ?? previous?.managerRemarks ?? "") }
      : {}),
    items,
  };
}

export function toCreateHandoverRequest(handover: HandoverRecord) {
  return {
    jobId: handover.jobId,
    plate: handover.plate,
    customerName: handover.customerName,
    collectedBy: handover.collectedBy,
    ...(handover.collectedPhone ? { collectedPhone: handover.collectedPhone } : {}),
    releasedByName: handover.releasedBy,
    ...(handover.releaseSignature ? { releaseSignature: handover.releaseSignature } : {}),
    mileageOut: handover.mileageOut,
    fuelLevelOut: handover.fuelLevelOut,
    handoverDate: handover.date,
    timeOut: handover.timeOut,
    ...(handover.notes ? { notes: handover.notes } : {}),
  };
}

export function mapHandoverResponse(
  response: Record<string, unknown>,
  previous?: Partial<HandoverRecord>,
): HandoverRecord {
  const handoverId = Number(response["handoverId"] ?? previous?.handoverId);
  return {
    ...(previous ?? {}),
    id: String(
      response["handoverNumber"] ??
        response["handoverId"] ??
        previous?.id ??
        `HO-${handoverId || Date.now()}`,
    ),
    ...(Number.isSafeInteger(handoverId) && handoverId > 0 ? { handoverId } : {}),
    vehicleId: String(response["vehicleId"] ?? previous?.vehicleId ?? ""),
    jobId: (response["jobId"] as number | string | undefined) ?? previous?.jobId ?? "",
    plate: String(response["registrationNumber"] ?? response["plate"] ?? previous?.plate ?? ""),
    customerName: String(response["customerName"] ?? previous?.customerName ?? ""),
    collectedBy: String(response["collectedBy"] ?? previous?.collectedBy ?? ""),
    ...(response["collectedPhone"] || previous?.collectedPhone
      ? { collectedPhone: String(response["collectedPhone"] ?? previous?.collectedPhone) }
      : {}),
    releasedBy: String(
      response["releasedByName"] ?? response["releasedBy"] ?? previous?.releasedBy ?? "",
    ),
    ...(response["releaseSignature"] || previous?.releaseSignature
      ? {
          releaseSignature: String(response["releaseSignature"] ?? previous?.releaseSignature),
        }
      : {}),
    mileageOut: Number(
      response["mileageOut"] ?? response["odometerOut"] ?? previous?.mileageOut ?? 0,
    ),
    fuelLevelOut: String(response["fuelLevelOut"] ?? previous?.fuelLevelOut ?? ""),
    date: String(response["handoverDate"] ?? response["date"] ?? previous?.date ?? ""),
    timeOut: String(response["timeOut"] ?? previous?.timeOut ?? ""),
  };
}

export function mapInventoryResponse(
  response: Record<string, unknown>,
  previous: InventoryCard,
): InventoryCard {
  const backendId = Number(response["inventoryCardId"] ?? previous.backendId);
  const jobId = Number(response["jobId"] ?? previous.jobId);
  return {
    ...previous,
    ...(Number.isSafeInteger(backendId) && backendId > 0 ? { backendId } : {}),
    ...(Number.isSafeInteger(jobId) && jobId > 0 ? { jobId } : {}),
    id: String(response["inventoryCardId"] ?? response["id"] ?? previous.id),
    condition: String(response["generalRemarks"] ?? previous.condition ?? ""),
    date: String(response["inventoryDate"] ?? previous.date ?? ""),
    ...(response["fuelLevelIn"] ? { fuelLevelIn: String(response["fuelLevelIn"]) } : {}),
    ...(response["fuelLevelOut"] ? { fuelLevelOut: String(response["fuelLevelOut"]) } : {}),
    ...(response["odometerIn"] !== undefined ? { odometerIn: Number(response["odometerIn"]) } : {}),
    ...(response["odometerOut"] !== undefined
      ? { odometerOut: Number(response["odometerOut"]) }
      : {}),
  };
}

export function mapJobCardResponse(response: Record<string, unknown>, previous: JobCard): JobCard {
  const backendJobCardId = Number(
    response["jobCardId"] ?? response["id"] ?? previous.backendJobCardId,
  );
  const backendJobId = Number(response["jobId"] ?? previous.backendJobId);
  const repairPlanId = Number(response["repairPlanId"] ?? previous.repairPlanId);
  const rawDept = String(
    response["departmentName"] ?? response["department"] ?? previous.department ?? "Workshop",
  );
  const routedDepartments = Array.isArray(response["routedDepartments"])
    ? (response["routedDepartments"] as unknown[]).map((d) => String(d)).filter(Boolean)
    : previous.routedDepartments;

  return {
    ...previous,
    id: String(response["jobCardNumber"] ?? response["jobCardId"] ?? response["id"] ?? previous.id),
    ...(Number.isSafeInteger(backendJobCardId) && backendJobCardId > 0 ? { backendJobCardId } : {}),
    ...(Number.isSafeInteger(backendJobId) && backendJobId > 0 ? { backendJobId } : {}),
    ...(Number.isSafeInteger(repairPlanId) && repairPlanId > 0 ? { repairPlanId } : {}),
    department: rawDept,
    ...(routedDepartments ? { routedDepartments } : {}),
    work: String(response["workDescription"] ?? previous.work ?? ""),
    status: String(response["jobCardStatus"] ?? response["status"] ?? previous.status ?? "Pending"),
    due: String(response["expectedCompletionDate"] ?? response["due"] ?? previous.due ?? ""),
    ...(response["startDate"] || previous.startDate
      ? { startDate: String(response["startDate"] ?? previous.startDate) }
      : {}),
    ...(response["preparedByName"] || previous.preparedBy
      ? { preparedBy: String(response["preparedByName"] ?? previous.preparedBy) }
      : {}),
    ...(response["assignedEmployeeName"] || previous.assignedEmployee
      ? { assignedEmployee: String(response["assignedEmployeeName"] ?? previous.assignedEmployee) }
      : {}),
    ...(response["foremanRemarks"] || previous.remarks
      ? { remarks: String(response["foremanRemarks"] ?? previous.remarks) }
      : {}),
  };
}

export function mapRequisitionResponse(
  response: Record<string, unknown>,
  previous: Requisition,
): Requisition {
  const status = String(
    response["status"] ?? response["requisitionStatus"] ?? "PENDING",
  ).toUpperCase();
  const lines = Array.isArray(response["items"])
    ? (response["items"] as Record<string, unknown>[]).map((p) => ({
        id: Number(p["requisitionItemId"] ?? p["id"] ?? 0),
        partId: Number(p["partId"] ?? 0),
        code: String(p["partCode"] ?? ""),
        name: String(p["partName"] ?? ""),
        quantity: Number(p["requestedQuantity"] ?? p["quantity"] ?? 0),
        unit: String(p["unitOfMeasure"] ?? "EACH"),
      }))
    : previous.lines;
  const backendId = Number(response["requisitionId"] ?? previous.backendId);
  const totalAmount = Number(response["totalAmount"] ?? previous.amount ?? 0);

  return {
    ...previous,
    ...(Number.isSafeInteger(backendId) && backendId > 0 ? { backendId } : {}),
    id: String(response["requisitionNumber"] ?? response["requisitionId"] ?? previous.id),
    department: String(response["departmentName"] ?? previous.department ?? "Workshop"),
    part:
      lines && lines.length > 0
        ? lines
            .map((x) => x.name)
            .filter(Boolean)
            .join(", ")
        : String(response["partName"] ?? previous.part ?? ""),
    quantity:
      lines && lines.length > 0
        ? lines.reduce((sum, x) => sum + x.quantity, 0)
        : Number(response["quantity"] ?? previous.quantity ?? 0),
    amount: Number.isFinite(totalAmount) ? totalAmount : previous.amount,
    foreman: String(response["requestedByName"] ?? previous.foreman ?? "Workshop"),
    reason: String(response["purpose"] ?? previous.reason ?? ""),
    date: String(response["submittedAt"] ?? previous.date ?? ""),
    ...(lines ? { lines } : {}),
    status:
      status === "APPROVED"
        ? "Approved"
        : status === "REJECTED"
          ? "Rejected"
          : status === "ORDERED"
            ? "Ordered"
            : status === "DISPATCHED"
              ? "Dispatched"
              : "Pending",
  };
}

export function mapInspectionResponse(
  response: Record<string, unknown>,
  previous: Inspection,
): Inspection {
  const decision = String(
    response["inspectionDecision"] ?? response["inspectionStatus"] ?? "",
  ).toUpperCase();
  const backendId = Number(response["inspectionId"] ?? previous.backendId);
  const inspector = String(
    response["inspectorName"] ?? previous.inspector ?? previous.foreman ?? "Workshop",
  );
  return {
    ...previous,
    ...(Number.isSafeInteger(backendId) && backendId > 0 ? { backendId } : {}),
    id: String(response["inspectionNumber"] ?? response["inspectionId"] ?? previous.id),
    foreman: inspector,
    inspector,
    date: String(response["startedAt"] ?? previous.date ?? ""),
    notes: String(response["inspectionNotes"] ?? previous.notes ?? ""),
    result: decision.includes("PASS")
      ? "Passed"
      : decision.includes("REWORK") || decision.includes("FAIL")
        ? "Rework required"
        : previous.result,
  };
}

export const backendApi = {
  getCompanySettings: () => apiFetch<Record<string, unknown>>(`/companies/${companyId()}/settings`),
  loadRecords: async () => {
    const company = companyId();
    const [
      vehicles,
      jobCards,
      requisitions,
      inspections,
      inventory,
      parts,
      purchaseOrders,
      options,
    ] = await Promise.all([
      apiFetch<Record<string, unknown>[]>(`/companies/${company}/vehicles`),
      apiFetch<Record<string, unknown>[]>(`/companies/${company}/job-cards`),
      apiFetch<Record<string, unknown>[]>(`/companies/${company}/parts/requisitions`),
      apiFetch<Record<string, unknown>[]>(`/companies/${company}/final-inspections`),
      apiFetch<Record<string, unknown>[]>(`/companies/${company}/inventory-cards`),
      apiFetch<Record<string, unknown>[]>(`/companies/${company}/parts`),
      apiFetch<Record<string, unknown>[]>(`/companies/${company}/purchase-orders`),
      apiFetch<Record<string, unknown>>(
        `/companies/${company}/workflow-options?workshopId=${workshopId()}`,
      ),
    ]);
    const quotesByJob = await Promise.all(
      vehicles
        .filter((v) => v["jobId"])
        .map(async (v) => {
          const quotes = await apiFetch<Record<string, unknown>[]>(
            `/jobs/${v["jobId"]}/quotations`,
          );
          return [Number(v["jobId"]), quotes] as const;
        }),
    );
    const approvalsByQuote = await Promise.all(
      quotesByJob.flatMap(([, quotes]) =>
        quotes.map(async (q) => {
          const quoteId = Number(q["quotationId"]);
          const approvals = await apiFetch<Record<string, unknown>[]>(
            `/quotations/${quoteId}/approvals`,
          );
          return [quoteId, approvals[0]] as const;
        }),
      ),
    );
    const workflows = await Promise.all(
      jobCards
        .filter((card) => card["repairPlanId"])
        .map(async (card) =>
          apiFetch<Record<string, unknown>>(
            `/companies/${company}/repair-plans/${card["repairPlanId"]}/workflow`,
          ),
        ),
    );
    const inspectionDetails = await Promise.all(
      inspections.map(async (item) => {
        const id = Number(item["inspectionId"]);
        const [details, signoffs] = await Promise.all([
          apiFetch<Record<string, unknown>>(`/final-inspections/${id}`),
          apiFetch<Record<string, unknown>>(`/final-inspections/${id}/signoffs`),
        ]);
        return [id, { details, signoffs }] as const;
      }),
    );
    const dispatchesByJob = await Promise.all(
      vehicles
        .filter((v) => v["jobId"])
        .map(
          async (v) =>
            [
              Number(v["jobId"]),
              await apiFetch<Record<string, unknown>[]>(`/dispatch-orders/jobs/${v["jobId"]}`),
            ] as const,
        ),
    );
    const invoicesByJob = await Promise.all(
      vehicles
        .filter((v) => v["jobId"])
        .map(
          async (v) =>
            [
              Number(v["jobId"]),
              await apiFetch<Record<string, unknown>[]>(`/invoices/job/${v["jobId"]}`),
            ] as const,
        ),
    );
    const handoversByJob = await Promise.all(
      vehicles
        .filter((v) => v["jobId"])
        .map(async (v) => {
          const jobId = Number(v["jobId"]);
          const handover = await apiFetch<Record<string, unknown>>(`/handovers/job/${jobId}`).catch(
            () => null,
          );
          return [jobId, handover] as const;
        }),
    );
    return {
      vehicles,
      jobCards,
      requisitions,
      inspections,
      inventory,
      parts,
      purchaseOrders,
      options,
      workflows,
      inspectionDetails: new Map(inspectionDetails),
      dispatchesByJob: new Map(dispatchesByJob),
      invoicesByJob: new Map(invoicesByJob),
      handoversByJob: new Map(handoversByJob),
      quotesByJob: new Map(quotesByJob),
      approvalsByQuote: new Map(approvalsByQuote),
    };
  },
  getJobCard: (jobCardId: number) =>
    apiFetch<Record<string, unknown>>(`/companies/${companyId()}/job-cards/${jobCardId}`),
  acceptRepairPlan: (repairPlanId: number, actorId = employeeId()) =>
    apiFetch<Record<string, unknown>>(`/repair-plans/${repairPlanId}/accept`, {
      method: "POST",
      body: JSON.stringify({ foremanEmployeeId: actorId }),
    }),
  assignWorkOrder: (
    workOrderId: number,
    assignedEmployeeId: number,
    role: string,
    actorId = employeeId(),
  ) =>
    apiFetch<Record<string, unknown>>("/work-order-assignments/batch", {
      method: "POST",
      body: JSON.stringify({
        assignedByEmployeeId: actorId,
        workOrders: [
          { workOrderId, assignments: [{ employeeId: assignedEmployeeId, assignmentRole: role }] },
        ],
      }),
    }),
  workOrderAction: (
    workOrderId: number,
    action: "start" | "pause" | "resume" | "waiting",
    notes: string,
    actorId = employeeId(),
  ) =>
    apiFetch<Record<string, unknown>>(`/work-orders/${workOrderId}/${action}`, {
      method: "POST",
      body: JSON.stringify({ employeeId: actorId, notes }),
    }),
  arriveAtDepartment: (
    workOrderId: number,
    departmentId: number,
    arrivalNotes: string,
    actorId = employeeId(),
  ) =>
    apiFetch<Record<string, unknown>>(
      `/work-orders/${workOrderId}/departments/${departmentId}/arrivals`,
      { method: "POST", body: JSON.stringify({ employeeId: actorId, arrivalNotes }) },
    ),
  sendOffDepartment: (
    workOrderId: number,
    departmentId: number,
    visitId: number,
    sendOffNotes: string,
    actorId = employeeId(),
  ) =>
    apiFetch<Record<string, unknown>>(
      `/work-orders/${workOrderId}/departments/${departmentId}/visits/${visitId}/send-off`,
      { method: "POST", body: JSON.stringify({ employeeId: actorId, sendOffNotes }) },
    ),
  submitWorkOrder: (workOrderId: number, completionNotes: string, actorId = employeeId()) =>
    apiFetch<Record<string, unknown>>(`/work-orders/${workOrderId}/submit-completion`, {
      method: "POST",
      body: JSON.stringify({ employeeId: actorId, completionNotes }),
    }),
  confirmWorkOrder: (workOrderId: number, reason: string, actorId = employeeId()) =>
    apiFetch<Record<string, unknown>>(`/work-orders/${workOrderId}/confirm`, {
      method: "POST",
      body: JSON.stringify({ employeeId: actorId, decision: "COMPLETED", reason }),
    }),
  uploadWorkEvidence: (
    workOrderId: number,
    file: File,
    caption: string,
    actorId = employeeId(),
  ) => {
    const body = new FormData();
    body.set("employeeId", String(actorId));
    body.set("evidenceType", "PHOTO");
    body.set("caption", caption);
    body.set("file", file);
    return apiFetch<Record<string, unknown>>(`/work-orders/${workOrderId}/evidence`, {
      method: "POST",
      body,
    });
  },
  updateInspectionItem: (
    inspectionId: number,
    itemId: number,
    checkStatus: "PASS" | "FAIL",
    comments: string,
    responsibleDepartmentId?: number,
  ) =>
    apiFetch<Record<string, unknown>>(`/final-inspections/${inspectionId}/items/${itemId}`, {
      method: "PATCH",
      body: JSON.stringify({
        employeeId: employeeId(),
        checkStatus,
        comments,
        responsibleDepartmentId,
      }),
    }),
  signoffInspectionDepartment: (inspectionId: number, departmentId: number, signoffNotes: string) =>
    apiFetch<Record<string, unknown>>(
      `/final-inspections/${inspectionId}/departments/${departmentId}/signoff`,
      {
        method: "POST",
        body: JSON.stringify({ employeeId: employeeId(), signoffStatus: "APPROVED", signoffNotes }),
      },
    ),
  completeInspection: (inspectionId: number) =>
    apiFetch<Record<string, unknown>>(`/final-inspections/${inspectionId}/complete`, {
      method: "POST",
    }),
  createCorrectiveWorkOrders: (inspectionId: number) =>
    apiFetch<Record<string, unknown>>(`/final-inspections/${inspectionId}/corrective-work-orders`, {
      method: "POST",
      body: JSON.stringify({ employeeId: employeeId() }),
    }),
  createPurchaseOrder: (
    requisitionId: number,
    supplierId: number,
    items: Array<{ requisitionItemId: number; quantityOrdered: number; unitPrice: number }>,
    supplierReference?: string,
  ) =>
    apiFetch<Record<string, unknown>>(`/parts/requisitions/${requisitionId}/purchase-orders`, {
      method: "POST",
      body: JSON.stringify({
        supplierId,
        createdByEmployeeId: employeeId(),
        supplierReference,
        items,
      }),
    }),
  receivePurchaseOrder: (
    purchaseOrderId: number,
    stockLocationId: number,
    items: Array<{
      purchaseOrderItemId: number;
      quantityDelivered: number;
      quantityAccepted: number;
    }>,
    supplierDeliveryReference?: string,
  ) =>
    apiFetch<Record<string, unknown>>(`/parts/purchase-orders/${purchaseOrderId}/receipts`, {
      method: "POST",
      body: JSON.stringify({
        receivedByEmployeeId: employeeId(),
        stockLocationId,
        supplierDeliveryReference,
        items,
      }),
    }),
  checkPartsAvailability: (jobCardId: number) =>
    apiFetch<Record<string, unknown>>(`/job-cards/${jobCardId}/parts/availability`),
  reservePart: (
    jobCardId: number,
    jobCardPartId: number,
    stockLocationId: number,
    quantity: number,
  ) =>
    apiFetch<Record<string, unknown>>(
      `/job-cards/${jobCardId}/parts/${jobCardPartId}/reservations`,
      {
        method: "POST",
        body: JSON.stringify({ reservedByEmployeeId: employeeId(), stockLocationId, quantity }),
      },
    ),
  createDispatch: (
    jobId: number,
    mechanicId: number,
    departmentId: number,
    reservationIds: number[],
  ) =>
    apiFetch<Record<string, unknown>>("/dispatch-orders", {
      method: "POST",
      body: JSON.stringify({
        jobId,
        createdByEmployeeId: employeeId(),
        assignedMechanicEmployeeId: mechanicId,
        departmentId,
        items: reservationIds.map((stockReservationId) => ({ stockReservationId })),
      }),
    }),
  dispatchAction: (
    dispatchId: number,
    action: "approve" | "issue" | "receive",
    body: Record<string, unknown>,
  ) =>
    apiFetch<Record<string, unknown>>(`/dispatch-orders/${dispatchId}/${action}`, {
      method: "POST",
      body: JSON.stringify(body),
    }),
  createInvoice: (jobId: number, quotationId: number) =>
    apiFetch<Record<string, unknown>>("/invoices", {
      method: "POST",
      body: JSON.stringify({ jobId, quotationId, issuedByEmployeeId: employeeId() }),
    }),
  recordPayment: (invoiceId: number, amount: number, transactionReference: string) =>
    apiFetch<Record<string, unknown>>(`/invoices/${invoiceId}/payments`, {
      method: "POST",
      body: JSON.stringify({
        receivedByEmployeeId: employeeId(),
        paymentMethod: "CASH",
        amount,
        transactionReference,
        paymentDate: new Date().toISOString(),
      }),
    }),
  createHandover: (input: Record<string, unknown>) =>
    apiFetch<Record<string, unknown>>("/handovers", {
      method: "POST",
      body: JSON.stringify({ ...input, releasedByEmployeeId: employeeId() }),
    }),
  viewCustomerApproval: (token: string) =>
    apiFetch<Record<string, unknown>>("/customer/quotation-approvals/view", {
      method: "POST",
      body: JSON.stringify({ token }),
    }),
  submitCustomerApproval: (
    token: string,
    decisions: Array<{ quotationItemId: number; decision: "APPROVED" | "REJECTED" }>,
    customerComments?: string,
  ) =>
    apiFetch<Record<string, unknown>>("/customer/quotation-approvals/submit", {
      method: "POST",
      body: JSON.stringify({ token, decisions, customerComments }),
    }),
  createIntake: (vehicle: Vehicle) =>
    apiFetch<BackendIntakeResponse>("/intake/vehicles", {
      method: "POST",
      body: JSON.stringify(toCreateVehicleRequest(vehicle)),
    }),
  createQuotation: (jobId: number, quotation: Quotation, part?: CatalogPart) =>
    apiFetch<Record<string, unknown>>(`/jobs/${jobId}/quotations`, {
      method: "POST",
      body: JSON.stringify(toCreateQuotationRequest(quotation, part)),
    }),
  issueQuotation: (quotationId: number) =>
    apiFetch<Record<string, unknown>>(`/quotations/${quotationId}/issue`, { method: "PUT" }),
  requestQuotationApproval: (quotationId: number) =>
    apiFetch<Record<string, unknown>>(`/quotations/${quotationId}/verify-and-request-approval`, {
      method: "POST",
      body: JSON.stringify({ verifiedByEmployeeId: employeeId(), notificationChannel: "SMS" }),
    }),
  createJobCard: (job: JobCard, refs: BackendRefs) =>
    apiFetch<Record<string, unknown>>("/job-cards", {
      method: "POST",
      body: JSON.stringify(toCreateJobCardRequest(job, refs)),
    }),
  linkJobCardPart: (jobCardId: number, jobCardPartId: number, partId: number) =>
    apiFetch<Record<string, unknown>>(
      `/job-cards/${jobCardId}/parts/${jobCardPartId}/catalog-part`,
      {
        method: "PATCH",
        body: JSON.stringify({ partId, linkedByEmployeeId: employeeId() }),
      },
    ),
  createRequisition: (jobId: number, requisition: Requisition) =>
    apiFetch<Record<string, unknown>>(`/jobs/${jobId}/parts/requisitions`, {
      method: "POST",
      body: JSON.stringify(toCreateRequisitionRequest(requisition)),
    }),
  startFinalInspection: (jobId: number) =>
    apiFetch<Record<string, unknown>>(`/final-inspections/jobs/${jobId}`, {
      method: "POST",
      body: JSON.stringify(toStartInspectionRequest()),
    }),
};
