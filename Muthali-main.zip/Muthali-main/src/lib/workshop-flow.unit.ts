import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  buildJobCardStageProgress,
  calculateQuotationTotals,
  calculateStepWizardPercentage,
  canCreateDispatchFromParts,
  evaluateIntakeStepProgress,
  evaluateJobStageReadiness,
  INTAKE_STEPS,
} from "./workshop-flow.ts";

describe("3-step workshop flow pure domain logic", () => {
  it("defines exactly 3 standardized intake steps", () => {
    assert.equal(INTAKE_STEPS.length, 3);
    assert.deepEqual(
      INTAKE_STEPS.map((s) => [s.stepNumber, s.id, s.title]),
      [
        [1, "customer_vehicle", "Customer & Vehicle"],
        [2, "specs_condition", "Specs & Condition"],
        [3, "scope_signoff", "Scope & Sign-Off"],
      ],
    );
  });

  it("validates Stage 1 intake step completion and missing fields across 3 steps", () => {
    const emptyEval = evaluateIntakeStepProgress({
      activeStep: "customer_vehicle",
      customerName: "",
      phone: "",
      plate: "",
      make: "",
      mileageIn: "",
      complaints: "",
      termsAccepted: false,
      customerSignature: "",
      authorizationDate: "",
    });
    assert.equal(emptyEval.step1Done, false);
    assert.equal(emptyEval.step2Done, false);
    assert.equal(emptyEval.step3Done, false);
    assert.deepEqual(emptyEval.step1Missing, [
      "Customer Name",
      "Phone Number",
      "Registration No.",
      "Vehicle Make",
    ]);
    assert.deepEqual(emptyEval.step2Missing, ["Mileage / KM In"]);
    assert.equal(emptyEval.allMissing.length, 9);

    const completeEval = evaluateIntakeStepProgress({
      activeStep: "scope_signoff",
      customerName: "John Mwale",
      phone: "0977123456",
      plate: "BAK 6213",
      make: "Toyota",
      mileageIn: "120000",
      complaints: "Brake service",
      termsAccepted: true,
      customerSignature: "John Mwale",
      authorizationDate: "2026-11-17",
    });
    assert.equal(completeEval.step1Done, true);
    assert.equal(completeEval.step2Done, true);
    assert.equal(completeEval.step3Done, true);
    assert.equal(completeEval.stepsCompletedCount, 3);
    assert.equal(completeEval.progressPercentage, 100);
    assert.deepEqual(completeEval.allMissing, []);
  });

  it("computes uniform 3-step wizard progress percentages", () => {
    assert.equal(calculateStepWizardPercentage(0, 3, [false, false, false]), 17);
    assert.equal(calculateStepWizardPercentage(0, 3, [true, false, false]), 33);
    assert.equal(calculateStepWizardPercentage(1, 3, [true, false, false]), 50);
    assert.equal(calculateStepWizardPercentage(2, 3, [true, true, false]), 83);
    assert.equal(calculateStepWizardPercentage(2, 3, [true, true, true]), 100);
  });

  it("calculates quotation subtotal, 16% VAT, total, and 50% required deposit", () => {
    const totals = calculateQuotationTotals([
      { quantity: 2, unitPrice: 500 },
      { quantity: 1, unitPrice: 1000 },
    ]);
    assert.equal(totals.subtotal, 2000);
    assert.equal(totals.vat, 320);
    assert.equal(totals.total, 2320);
    assert.equal(totals.requiredDeposit, 1160);
  });

  it("blocks dispatch when parts are short and unlocks after stores stock update", () => {
    const blocked = canCreateDispatchFromParts([
      {
        id: "p1",
        partName: "Oil Filter",
        requiredQty: 2,
        availableQty: 1,
        status: "Partially available",
        unitPrice: 250,
      },
    ]);
    assert.equal(blocked.allowed, false);
    assert.equal(blocked.blockers.length, 1);

    const unlockedByReceiving = canCreateDispatchFromParts(
      [
        {
          id: "p1",
          partName: "Oil Filter",
          requiredQty: 2,
          availableQty: 1,
          status: "Partially available",
          unitPrice: 250,
        },
      ],
      {
        quantityReceived: 1,
        dateReceived: "2026-11-17",
        receivedBy: "Stores Officer",
        stockUpdated: true,
      },
    );
    assert.equal(unlockedByReceiving.allowed, true);
  });

  it("evaluates 8-stage job card readiness and progress summary accurately", () => {
    const vehicle = {
      id: "VR-2001",
      plate: "BAA 1001",
      make: "Toyota Hilux",
      customer: "Jane Phiri",
      phone: "0977000111",
      email: "",
      received: "17 Nov 2026",
      stage: 2,
      department: "Mechanical",
      foreman: "Foreman 01",
      complaints: "Full service",
      damage: "None",
      due: "19 Nov 2026",
      progress: 25,
    };
    const quotation = {
      id: "QT-2001",
      vehicleId: "VR-2001",
      description: "Service",
      amount: 2320,
      status: "Awaiting approval" as const,
    };

    const readiness = evaluateJobStageReadiness({
      vehicle,
      quotation,
      requisitions: [],
      dispatches: [],
    });

    assert.equal(readiness.stages[1].complete, true);
    assert.equal(readiness.stages[2].complete, true);
    assert.equal(readiness.stages[3].complete, false);
    assert.equal(readiness.maxUnlockedStageIndex, 2);

    const progress = buildJobCardStageProgress({
      creatingNew: false,
      readiness,
      stage8Unlocked: false,
      stage8Completed: false,
      vehicle,
    });
    assert.equal(progress.totalStages, 8);
    assert.equal(progress.completedStages, 2);
    assert.equal(progress.currentStageNumber, 3);
    assert.equal(progress.segments[0]?.state, "completed");
    assert.equal(progress.segments[1]?.state, "completed");
    assert.equal(progress.segments[2]?.state, "current");
    assert.equal(progress.segments[3]?.state, "locked");
  });
});
