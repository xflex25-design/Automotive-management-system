import type { ActivityRecord } from "./workshop";

export type ActivityCategory =
  | "all"
  | "job_card"
  | "vehicle"
  | "quotation"
  | "authorization"
  | "parts"
  | "inspection"
  | "system";

export type ActivityCategoryMeta = {
  id: ActivityCategory;
  label: string;
  badgeClass: string;
  dotClass: string;
  iconName: "Wrench" | "Car" | "FileText" | "ShieldCheck" | "Package" | "ClipboardCheck" | "Clock";
};

export const ACTIVITY_CATEGORIES: readonly { id: ActivityCategory; label: string }[] = [
  { id: "all", label: "All Activities" },
  { id: "job_card", label: "Job Cards" },
  { id: "vehicle", label: "Vehicles" },
  { id: "quotation", label: "Quotations" },
  { id: "authorization", label: "Authorizations" },
  { id: "parts", label: "Parts & Stores" },
  { id: "inspection", label: "Inspections" },
] as const;

export function categorizeActivity(text: string, detail = ""): ActivityCategory {
  const combined = `${text} ${detail}`.toLowerCase();
  if (
    combined.includes("job card") ||
    combined.includes("work order") ||
    combined.includes("bay progress") ||
    combined.includes("mechanic") ||
    combined.includes("technician") ||
    combined.includes("stagnation") ||
    combined.includes("rework")
  ) {
    return "job_card";
  }
  if (
    combined.includes("new vehicle") ||
    combined.includes("vehicle registered") ||
    combined.includes("intake") ||
    combined.includes("check-in") ||
    combined.includes("registration") ||
    combined.includes("inventory card")
  ) {
    return "vehicle";
  }
  if (combined.includes("quotation") || combined.includes("quote") || combined.includes("qt-")) {
    return "quotation";
  }
  if (
    combined.includes("authorization") ||
    combined.includes("deposit") ||
    combined.includes("authorized") ||
    combined.includes("customer acceptance")
  ) {
    return "authorization";
  }
  if (
    combined.includes("part") ||
    combined.includes("requisition") ||
    combined.includes("dispatch") ||
    combined.includes("stores") ||
    combined.includes("stock")
  ) {
    return "parts";
  }
  if (
    combined.includes("inspection") ||
    combined.includes("qa") ||
    combined.includes("release") ||
    combined.includes("handover")
  ) {
    return "inspection";
  }
  return "system";
}

export function getActivityCategoryMeta(category: ActivityCategory): ActivityCategoryMeta {
  switch (category) {
    case "job_card":
      return {
        id: "job_card",
        label: "Job Card",
        badgeClass: "bg-blue-50 text-blue-700 border-blue-200",
        dotClass: "bg-blue-600",
        iconName: "Wrench",
      };
    case "vehicle":
      return {
        id: "vehicle",
        label: "Vehicle",
        badgeClass: "bg-emerald-50 text-emerald-700 border-emerald-200",
        dotClass: "bg-emerald-600",
        iconName: "Car",
      };
    case "quotation":
      return {
        id: "quotation",
        label: "Quotation",
        badgeClass: "bg-purple-50 text-purple-700 border-purple-200",
        dotClass: "bg-purple-600",
        iconName: "FileText",
      };
    case "authorization":
      return {
        id: "authorization",
        label: "Authorization",
        badgeClass: "bg-amber-50 text-amber-700 border-amber-200",
        dotClass: "bg-amber-600",
        iconName: "ShieldCheck",
      };
    case "parts":
      return {
        id: "parts",
        label: "Parts & Stores",
        badgeClass: "bg-orange-50 text-orange-700 border-orange-200",
        dotClass: "bg-orange-600",
        iconName: "Package",
      };
    case "inspection":
      return {
        id: "inspection",
        label: "Inspection",
        badgeClass: "bg-teal-50 text-teal-700 border-teal-200",
        dotClass: "bg-teal-600",
        iconName: "ClipboardCheck",
      };
    default:
      return {
        id: "system",
        label: "Workshop",
        badgeClass: "bg-slate-50 text-slate-700 border-slate-200",
        dotClass: "bg-slate-500",
        iconName: "Clock",
      };
  }
}

export function formatActivityRelativeTime(
  timestampMs?: number,
  fallbackTimeString = "Just now",
  nowMs = Date.now(),
): string {
  if (!timestampMs || !Number.isFinite(timestampMs)) {
    return fallbackTimeString || "Just now";
  }
  const diffMs = Math.max(0, nowMs - timestampMs);
  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 60) return "Just now";
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHrs = Math.floor(diffMin / 60);
  if (diffHrs < 24) return `${diffHrs}h ago`;
  const diffDays = Math.floor(diffHrs / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return new Date(timestampMs).toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
  });
}

export function filterActivities(
  activities: readonly ActivityRecord[],
  options: { category?: string; query?: string } = {},
): ActivityRecord[] {
  const { category = "all", query = "" } = options;
  const cleanQuery = query.trim().toLowerCase();

  return activities.filter((item) => {
    if (category !== "all") {
      const itemCategory = categorizeActivity(item.text, item.detail);
      if (itemCategory !== category) return false;
    }
    if (cleanQuery) {
      const matchText = (item.text ?? "").toLowerCase().includes(cleanQuery);
      const matchDetail = (item.detail ?? "").toLowerCase().includes(cleanQuery);
      if (!matchText && !matchDetail) return false;
    }
    return true;
  });
}

export function extractActivityEntityRef(
  text: string,
  detail = "",
): {
  entityType?: "vehicle" | "job" | "quotation" | "inspection" | "requisition";
  referenceId?: string;
} {
  const combined = `${text} ${detail}`;
  const jcMatch = combined.match(/\b(JC-\d+)\b/i);
  if (jcMatch) return { entityType: "job", referenceId: jcMatch[1]?.toUpperCase() };
  const vrMatch = combined.match(/\b(VR-\d+)\b/i);
  if (vrMatch) return { entityType: "vehicle", referenceId: vrMatch[1]?.toUpperCase() };
  const qtMatch = combined.match(/\b(QT-\d+)\b/i);
  if (qtMatch) return { entityType: "quotation", referenceId: qtMatch[1]?.toUpperCase() };
  const insMatch = combined.match(/\b(INS-\d+)\b/i);
  if (insMatch) return { entityType: "inspection", referenceId: insMatch[1]?.toUpperCase() };
  const reqMatch = combined.match(/\b(REQ-\d+)\b/i);
  if (reqMatch) return { entityType: "requisition", referenceId: reqMatch[1]?.toUpperCase() };
  const plateMatch = combined.match(/\b([A-Z]{2,3}\s*\d{3,4})\b/);
  if (plateMatch) return { entityType: "vehicle", referenceId: plateMatch[1]?.toUpperCase() };
  return {};
}

export const DEFAULT_RECENT_ACTIVITIES: readonly ActivityRecord[] = [
  {
    text: "Job card updated: JC-881",
    detail: "Mechanical bay · Moved to In Progress by Peter Zulu",
    time: "5m ago",
    createdAtMs: Date.now() - 5 * 60 * 1000,
  },
  {
    text: "New vehicle registered: Toyota Hilux (BAK 6213)",
    detail: "Intake completed · Assigned to Stage 2 Quotation",
    time: "18m ago",
    createdAtMs: Date.now() - 18 * 60 * 1000,
  },
  {
    text: "Quotation issued: QT-1021",
    detail: "Ford Ranger (BAK 6213) · K 3,132.00 (Major service)",
    time: "42m ago",
    createdAtMs: Date.now() - 42 * 60 * 1000,
  },
  {
    text: "Customer authorization confirmed: QT-1020",
    detail: "50% deposit received (REC-88412) · Released for Job Card",
    time: "1h ago",
    createdAtMs: Date.now() - 65 * 60 * 1000,
  },
  {
    text: "Parts verified & requisition approved: REQ-501",
    detail: "Oil & air filter elements in stock · Stores ready",
    time: "2h ago",
    createdAtMs: Date.now() - 120 * 60 * 1000,
  },
  {
    text: "Final Inspection passed: INS-301",
    detail: "Road test & 24-point check verified · Handover ready",
    time: "3h ago",
    createdAtMs: Date.now() - 190 * 60 * 1000,
  },
];
