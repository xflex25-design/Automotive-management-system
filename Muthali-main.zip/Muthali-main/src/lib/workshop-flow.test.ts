import test from "node:test";
import assert from "node:assert/strict";
import {
  WORKSHOP_FLOW_STAGES,
  calculateQuotationTotals,
  derivePartStockStatus,
  deriveOverallStockStatus,
  canCreateDispatchFromParts,
  calculateStagnationSummary,
  evaluateJobStageReadiness,
  createDefaultAccessoriesChecklist,
  buildPartsSheetFromQuotation,
  isFinalInspectionAndReleaseComplete,
  classifyWorkshopQueueItem,
  matchesWorkshopQueueSearch,
  filterWorkshopQueueItems,
  calculateJobCompletionPercentage,
  deriveQueueDepartmentBadge,
} from "./workshop-flow";
import type { Inspection, JobCard, Quotation, Requisition, Vehicle } from "./workshop";

function makeCompleteVehicle(id = "VR-2001"): Vehicle {
  return {
    id,
    plate: "BAK 6213",
    make: "Toyota Hilux",
    customer: "John Mwale",
    phone: "0977 123 456",
    email: "john@example.com",
    received: "21 Nov 2026",
    stage: 0,
    department: "Mechanical",
    foreman: "Foreman 01",
    complaints: "Service and brake check",
    damage: "Small scratch on rear bumper",
    due: "2026-11-25",
    progress: 0,
    odometer: 120000,
    intakeDetails: {
      customerType: "Individual",
      customerAddress: "Plot 123, Lusaka",
      driverName: "John Mwale",
      model: "Hilux",
      year: "2016",
      engineNumber: "1KD-456789",
      mileageIn: 120000,
      fuelLevelIn: "Full",
      accessories: createDefaultAccessoriesChecklist(),
      damageTypes: ["Scratch"],
      additionalRemarks: "No major damage",
      requestedRepairs: "Full service and brake overhaul",
      additionalInstructions: "Call before replacing shocks",
      termsAccepted: true,
      customerSignature: "John Mwale",
      intakeOfficer: "Paul M",
      authorizationDate: "2026-11-21",
      status: "completed",
    },
  };
}

function makeApprovedQuotation(vehicleId = "VR-2001"): Quotation {
  const totals = calculateQuotationTotals([
    { quantity: 1, unitPrice: 450 },
    { quantity: 1, unitPrice: 250 },
    { quantity: 1, unitPrice: 250 },
    { quantity: 1, unitPrice: 2000 },
  ]);
  return {
    id: "QT-2001",
    vehicleId,
    amount: totals.total,
    subtotal: totals.subtotal,
    taxAmount: totals.vat,
    description: "Service and brake repair quotation",
    status: "Approved",
    quotationDate: "2026-11-21",
    preparedByName: "Sales Officer",
    items: [
      {
        itemType: "PART",
        item: "Air filter",
        description: "Air filter",
        quantity: 1,
        unitPrice: 450,
      },
      {
        itemType: "PART",
        item: "Oil filter",
        description: "Oil filter",
        quantity: 1,
        unitPrice: 250,
      },
      {
        itemType: "PART",
        item: "Fuel filter",
        description: "Fuel filter",
        quantity: 1,
        unitPrice: 250,
      },
      { itemType: "LABOUR", item: "Labour", description: "Labour", quantity: 1, unitPrice: 2000 },
    ],
    authorization: {
      customerAcceptance: "Accepted",
      terms: {
        permissionRepairs: true,
        permissionMaterials: true,
        vehicleSecurity: true,
        additionalWork: true,
        paymentCollection: true,
      },
      requiredDepositPercent: 50,
      depositAmount: totals.requiredDeposit,
      paymentStatus: "Deposit Paid",
      paymentReference: "REC-88412",
      customerName: "John Mwale",
      customerSignature: "John Mwale",
      authorizationDate: "2026-11-21",
    },
  };
}

function makeCompleteJobCard(vehicleId = "VR-2001"): JobCard {
  return {
    id: "JC-2001",
    vehicleId,
    department: "Mechanical",
    work: "Replace air, oil, fuel filters and inspect brakes",
    status: "Completed",
    due: "2026-11-25",
    preparedBy: "Foreman 01",
    assignedEmployee: "Mechanic A",
    approvedQuotationRef: "QT-2001",
    routedDepartments: ["Mechanical", "Brakes"],
    startDate: "2026-11-21",
    departmentProgress: [
      { department: "Mechanical", assignedMechanic: "Mechanic A", status: "Completed" },
      { department: "Brakes", assignedMechanic: "Mechanic C", status: "Completed" },
    ],
    stagnationMeta: {
      workCompletedSummary: "All filters replaced and brake system bled and tested",
      mechanicRemarks: "Road test passed",
      foremanVerified: true,
      foremanVerifiedBy: "Foreman 01",
      completionDate: "2026-11-22",
    },
  };
}

function makeVerifiedRequisition(vehicleId = "VR-2001"): Requisition {
  return {
    id: "REQ-2001",
    vehicleId,
    part: "Air filter, Oil filter",
    quantity: 2,
    department: "Mechanical",
    reason: "Scheduled 4x4 service",
    amount: 700,
    foreman: "Foreman 01",
    status: "Approved",
    date: "2026-11-21",
    partsCheck: {
      items: [
        { id: "p1", partName: "Air filter", requiredQty: 1, availableQty: 1, status: "Available" },
        { id: "p2", partName: "Oil filter", requiredQty: 1, availableQty: 1, status: "Available" },
      ],
      stockSummaryStatus: "Available",
      requisitionDetails: {
        partName: "",
        quantityRequired: 0,
        supplier: "",
        purchaseRequisitionRef: "",
        expectedDeliveryDate: "",
      },
      receiving: {
        quantityReceived: 0,
        dateReceived: "",
        receivedBy: "",
        stockUpdated: false,
      },
      verifiedForDispatch: true,
      status: "completed",
    },
  };
}

function makeApprovedDispatch(
  vehicleId = "VR-2001",
  jobNumber = "JC-2001",
): Record<string, unknown> {
  return {
    id: "DO-2001",
    dispatchNumber: "DO-2001",
    vehicleId,
    jobNumber,
    customerName: "John Mwale",
    vehicleRegistration: "BAK 6213",
    date: "2026-11-21",
    status: "APPROVED_AND_DISPATCHED",
    managerDecision: "Approve",
    storesConfirmation: {
      issuedBy: "Stores Officer",
      dateIssued: "2026-11-21",
      quantityIssued: 2,
      storesSignature: "Stores Officer",
    },
    acknowledgements: {
      customerSignature: "John Mwale",
      authorizedPersonSignature: "Manager",
      accountsAcknowledgement: "Accounts Verified",
    },
  };
}

test("defines exactly 7 workshop stages in strict order", () => {
  assert.equal(WORKSHOP_FLOW_STAGES.length, 7);
  assert.deepEqual(
    WORKSHOP_FLOW_STAGES.map((s) => s.stageNumber),
    [1, 2, 3, 4, 5, 6, 7],
  );
});

test("calculates quotation subtotal, 16% VAT, total, and 50% required deposit", () => {
  const totals = calculateQuotationTotals([
    { quantity: 1, unitPrice: 450 },
    { quantity: 1, unitPrice: 250 },
    { quantity: 1, unitPrice: 250 },
    { quantity: 1, unitPrice: 2000 },
  ]);
  assert.equal(totals.subtotal, 2950);
  assert.equal(totals.vat, 472);
  assert.equal(totals.total, 3422);
  assert.equal(totals.requiredDeposit, 1711);
});

test("blocks parts dispatch creation when required parts are out of stock without receiving update", () => {
  const items = [
    {
      id: "1",
      partName: "Air filter",
      requiredQty: 1,
      availableQty: 1,
      status: derivePartStockStatus(1, 1),
    },
    {
      id: "2",
      partName: "Brake booster",
      requiredQty: 1,
      availableQty: 0,
      status: derivePartStockStatus(1, 0),
    },
  ];
  assert.equal(deriveOverallStockStatus(items), "Out of stock");

  const blocked = canCreateDispatchFromParts(items);
  assert.equal(blocked.allowed, false);
  assert.ok(blocked.blockers[0]?.includes("Brake booster"));

  const unblockedAfterReceipt = canCreateDispatchFromParts(items, {
    quantityReceived: 1,
    dateReceived: "2026-11-21",
    receivedBy: "Stores",
    stockUpdated: true,
  });
  assert.equal(unblockedAfterReceipt.allowed, true);
});

test("enforces strict linear stage unlocking and disables Final Inspection until stages 1-6 + verification are complete", () => {
  const vehicle = makeCompleteVehicle();
  const quotation = makeApprovedQuotation();
  const job = makeCompleteJobCard();
  const requisition = makeVerifiedRequisition();
  const dispatch = makeApprovedDispatch();

  // Stage 1 only -> unlocks Stage 2 (index 1), Stage 7 locked, Final Inspection disabled
  const onlyStage1 = evaluateJobStageReadiness({
    vehicle,
    quotation: undefined,
    job: undefined,
    requisitions: [],
    dispatches: [],
  });
  assert.equal(onlyStage1.stages[1].complete, true);
  assert.equal(onlyStage1.stages[2].complete, false);
  assert.equal(onlyStage1.maxUnlockedStageIndex, 1);
  assert.equal(onlyStage1.stages1To6Complete, false);
  assert.equal(onlyStage1.canSubmitFinalInspection, false);

  // Stages 1-5 complete, Stage 6 Dispatch still PENDING_APPROVAL -> Final Inspection MUST remain disabled
  const pendingDispatch = { ...dispatch, status: "PENDING_APPROVAL" };
  const missingStage6 = evaluateJobStageReadiness({
    vehicle,
    quotation,
    job,
    requisitions: [requisition],
    dispatches: [pendingDispatch],
  });
  assert.equal(missingStage6.stages[5].complete, true);
  assert.equal(missingStage6.stages[6].complete, false);
  assert.equal(missingStage6.stages1To6Complete, false);
  assert.equal(missingStage6.canSubmitFinalInspection, false);

  // Stage 3 fails if 50% deposit is not paid
  const unpaidDepositQuotation: Quotation = {
    ...quotation,
    authorization: {
      ...quotation.authorization!,
      paymentStatus: "Unpaid",
    },
  };
  const unpaidDeposit = evaluateJobStageReadiness({
    vehicle,
    quotation: unpaidDepositQuotation,
    job,
    requisitions: [requisition],
    dispatches: [dispatch],
  });
  assert.equal(unpaidDeposit.stages[3].complete, false);
  assert.equal(unpaidDeposit.stages1To6Complete, false);
  assert.equal(unpaidDeposit.canSubmitFinalInspection, false);

  // Stages 1-6 all complete, but Stage 7 mechanic status still In Progress -> Final Inspection disabled
  const inProgressJob: JobCard = {
    ...job,
    departmentProgress: [
      { department: "Mechanical", assignedMechanic: "Mechanic A", status: "In Progress" },
      { department: "Brakes", assignedMechanic: "Mechanic C", status: "Completed" },
    ],
  };
  const stage7Incomplete = evaluateJobStageReadiness({
    vehicle,
    quotation,
    job: inProgressJob,
    requisitions: [requisition],
    dispatches: [dispatch],
  });
  assert.equal(stage7Incomplete.stages1To6Complete, true);
  assert.equal(stage7Incomplete.maxUnlockedStageIndex, 6);
  assert.equal(stage7Incomplete.canSubmitFinalInspection, false);

  // Stages 1-6 complete + Stage 7 Completed + Foreman verified -> Final Inspection ENABLED
  const allReady = evaluateJobStageReadiness({
    vehicle,
    quotation,
    job,
    requisitions: [requisition],
    dispatches: [dispatch],
  });
  assert.equal(allReady.stages1To6Complete, true);
  assert.equal(allReady.stages[7].complete, true);
  assert.equal(allReady.canSubmitFinalInspection, true);
  assert.deepEqual(allReady.blockingReasons, []);
});

test("tracks stagnation metrics: time in department, overdue jobs, waiting for parts, supervisor attention", () => {
  const now = Date.parse("2026-11-26T12:00:00Z");
  const stagnantJob: JobCard = {
    id: "JC-3001",
    vehicleId: "VR-3001",
    department: "Mechanical",
    work: "Engine overhaul",
    status: "In Progress",
    due: "2026-11-24",
    departmentProgress: [
      {
        department: "Mechanical",
        assignedMechanic: "Mechanic A",
        status: "Waiting for Parts",
        updatedAtMs: now - 30 * 3_600_000,
      },
    ],
  };

  const summary = calculateStagnationSummary(stagnantJob, now);
  assert.equal(summary.hoursInDepartment, 30);
  assert.equal(summary.isOverdue, true);
  assert.equal(summary.isWaitingForParts, true);
  assert.equal(summary.awaitingSupervisorAttention, true);
  assert.ok(summary.alerts.length >= 3);
});

test("builds Stage 4 parts sheet automatically from Stage 2 PART quotation items", () => {
  const quote = makeApprovedQuotation();
  const rows = buildPartsSheetFromQuotation(quote);
  assert.equal(rows.length, 3);
  assert.deepEqual(
    rows.map((r) => r.partName),
    ["Air filter", "Oil filter", "Fuel filter"],
  );
  assert.equal(
    rows.every((r) => r.quoted),
    true,
  );
});

test("validates Final Inspection & Vehicle Release completion and classifies workshop queue items", () => {
  const vehicle = makeCompleteVehicle();
  const quotation = makeApprovedQuotation();
  const job = makeCompleteJobCard();
  const requisition = makeVerifiedRequisition();
  const dispatch = makeApprovedDispatch();

  const readiness = evaluateJobStageReadiness({
    vehicle,
    quotation,
    job,
    requisitions: [requisition],
    dispatches: [dispatch],
  });

  const pendingInspection: Inspection = {
    id: "INS-301",
    vehicleId: vehicle.id,
    foreman: "Foreman 01",
    date: "2026-11-22",
    result: "Pending",
    notes: "Ready for road test",
  };
  assert.equal(
    isFinalInspectionAndReleaseComplete({ vehicle, inspection: pendingInspection }),
    false,
  );
  assert.equal(
    classifyWorkshopQueueItem({ vehicle, readiness, job, inspection: pendingInspection }).bucket,
    "final_release",
  );

  const releasedVehicle: Vehicle = {
    ...vehicle,
    released: true,
    intakeDetails: {
      ...vehicle.intakeDetails!,
      mileageOut: 120018,
      fuelLevelOut: "Full",
      collectedBy: "John Mwale",
      releasedBy: "Foreman 01",
    },
  };
  const passedInspection: Inspection = { ...pendingInspection, result: "Passed" };
  assert.equal(
    isFinalInspectionAndReleaseComplete({
      vehicle: releasedVehicle,
      inspection: passedInspection,
    }),
    true,
  );
  assert.equal(
    classifyWorkshopQueueItem({
      vehicle: releasedVehicle,
      readiness,
      job,
      inspection: passedInspection,
    }).badgeLabel,
    "Released",
  );
});

test("filters Active Workshop Queue items by plate number, vehicle make, or owner name", () => {
  const toyota = makeCompleteVehicle("VR-2001");
  const ford: Vehicle = {
    ...makeCompleteVehicle("VR-2002"),
    id: "VR-2002",
    plate: "AJB 4092",
    make: "Ford Ranger",
    customer: "Sarah Phiri",
  };

  assert.equal(matchesWorkshopQueueSearch(toyota, ""), true);
  assert.equal(matchesWorkshopQueueSearch(toyota, "   "), true);

  // Plate match (including spacing variations)
  assert.equal(matchesWorkshopQueueSearch(ford, "AJB 4092"), true);
  assert.equal(matchesWorkshopQueueSearch(ford, "ajb4092"), true);
  assert.equal(matchesWorkshopQueueSearch(toyota, "ajb"), false);

  // Make match
  assert.equal(matchesWorkshopQueueSearch(ford, "ford"), true);
  assert.equal(matchesWorkshopQueueSearch(toyota, "Toyota"), true);

  // Owner / customer name match
  assert.equal(matchesWorkshopQueueSearch(ford, "phiri"), true);
  assert.equal(matchesWorkshopQueueSearch(toyota, "mwale"), true);

  // Combined bucket + search filtering
  const items = [
    { vehicle: toyota, bucket: "in_bay" as const },
    { vehicle: ford, bucket: "quote_auth" as const },
  ];
  assert.equal(filterWorkshopQueueItems(items, "all", "").length, 2);
  assert.deepEqual(
    filterWorkshopQueueItems(items, "all", "sarah").map((i) => i.vehicle.id),
    ["VR-2002"],
  );
  assert.deepEqual(
    filterWorkshopQueueItems(items, "in_bay", "sarah").map((i) => i.vehicle.id),
    [],
  );
  assert.deepEqual(
    filterWorkshopQueueItems(items, "in_bay", "bak").map((i) => i.vehicle.id),
    ["VR-2001"],
  );
});

test("calculates job completion percentage (stages covered / total 8 stages) in background", () => {
  const vehicle = makeCompleteVehicle();
  const pct1 = calculateJobCompletionPercentage({ vehicle });
  assert.equal(pct1, 13); // Stage 1 of 8 = 12.5% -> rounded 13%

  const quotation = makeApprovedQuotation();
  const pct2 = calculateJobCompletionPercentage({ vehicle, quotation });
  assert.equal(pct2, 38); // 3 of 8 completed (Intake, Quotation, Authorization) = 37.5% -> 38%
});

test("derives color-coded department status badges for queue rows", () => {
  const vehicle = makeCompleteVehicle();
  const quotation = makeApprovedQuotation();
  const job = makeCompleteJobCard();
  const requisition = makeVerifiedRequisition();
  const dispatch = makeApprovedDispatch();

  // Intake stage (incomplete intake details)
  const incompleteVehicle: Vehicle = {
    ...vehicle,
    intakeDetails: { ...vehicle.intakeDetails!, status: "draft", customerSignature: "" },
  };
  const s0Readiness = evaluateJobStageReadiness({
    vehicle: incompleteVehicle,
    quotation: undefined,
    job: undefined,
    requisitions: [],
    dispatches: [],
  });
  const b0 = deriveQueueDepartmentBadge({ vehicle: incompleteVehicle, readiness: s0Readiness });
  assert.equal(b0.label, "Intake");

  // Stage 1 completed -> Quotation unlocked
  const s1Readiness = evaluateJobStageReadiness({
    vehicle,
    quotation: undefined,
    job: undefined,
    requisitions: [],
    dispatches: [],
  });
  const b1 = deriveQueueDepartmentBadge({ vehicle, readiness: s1Readiness });
  assert.equal(b1.label, "Quotation");

  // In workshop department (Mechanical - Stage 7 in progress)
  const inProgressJob: JobCard = {
    ...job,
    departmentProgress: [
      { department: "Mechanical", assignedMechanic: "Mechanic A", status: "In Progress" },
    ],
  };
  const s7Readiness = evaluateJobStageReadiness({
    vehicle,
    quotation,
    job: inProgressJob,
    requisitions: [requisition],
    dispatches: [dispatch],
  });
  const bMech = deriveQueueDepartmentBadge({ vehicle, readiness: s7Readiness, job: inProgressJob });
  assert.equal(bMech.label, "Mechanical");
  assert.ok(bMech.textClass.includes("blue"));

  // In Inspection
  const bInsp = deriveQueueDepartmentBadge({
    vehicle,
    readiness: s7Readiness,
    job,
    inspection: {
      id: "INS-1",
      vehicleId: vehicle.id,
      foreman: "F1",
      date: "2026-11-21",
      result: "Pending",
      notes: "",
    },
  });
  assert.equal(bInsp.label, "In Inspection");
  assert.ok(bInsp.textClass.includes("purple"));

  // Parts Awaiting
  const stagnantPartsJob: JobCard = {
    ...job,
    departmentProgress: [
      { department: "Mechanical", assignedMechanic: "Mech A", status: "Waiting for Parts" },
    ],
  };
  const bParts = deriveQueueDepartmentBadge({
    vehicle,
    readiness: s7Readiness,
    job: stagnantPartsJob,
  });
  assert.equal(bParts.label, "Parts Awaiting");
  assert.ok(bParts.textClass.includes("amber"));

  // Released
  const releasedVehicle: Vehicle = {
    ...vehicle,
    released: true,
    intakeDetails: {
      ...vehicle.intakeDetails!,
      mileageOut: 120018,
      fuelLevelOut: "Full",
      collectedBy: "John Mwale",
      releasedBy: "Foreman 01",
    },
  };
  const bReleased = deriveQueueDepartmentBadge({
    vehicle: releasedVehicle,
    readiness: s7Readiness,
    inspection: {
      id: "INS-1",
      vehicleId: vehicle.id,
      foreman: "F1",
      date: "2026-11-21",
      result: "Passed",
      notes: "",
    },
  });
  assert.equal(bReleased.label, "Released");
  assert.ok(bReleased.textClass.includes("emerald"));
});
