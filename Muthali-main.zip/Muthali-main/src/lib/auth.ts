import type { UserPreferences, WorkspaceRole } from "./workshop";
import { verifyUserCredentials, registerUserInDatabase } from "./database-sync";

export type AuthenticatedUser = {
  userId?: number | undefined;
  employeeId?: number | undefined;
  companyId?: number | undefined;
  workshopId?: number | undefined;
  companyName?: string | undefined;
  department?: string | undefined;
  preferences?: UserPreferences | undefined;
  displayName: string;
  email: string;
  authorities: string[];
  role?: WorkspaceRole | undefined;
};

const configuredApiUrl = import.meta.env["VITE_API_URL"]?.replace(/\/$/, "") ?? "";
const apiPrefix = import.meta.env.DEV ? "/backend-api" : configuredApiUrl;

export async function loginWithBackend(
  email: string,
  password: string,
): Promise<{
  success: boolean;
  user?: AuthenticatedUser | undefined;
  token?: string | undefined;
  error?: string | undefined;
}> {
  const cleanEmail = email.trim();
  const token = "Basic " + btoa(`${cleanEmail}:${password}`);

  if (configuredApiUrl || import.meta.env["VITE_COMPANY_ID"]) {
    try {
      const res = await fetch(`${apiPrefix}/api/auth/me`, {
        method: "GET",
        headers: {
          Authorization: token,
          Accept: "application/json",
        },
      });

      if (res.ok) {
        const data = await res.json();
        const authorities: string[] = Array.isArray(data.authorities) ? data.authorities : [];

        let role: WorkspaceRole = "Foreman";
        if (authorities.some((a) => a.includes("BOSS") || a.includes("DIRECTOR"))) {
          role = "Director";
        } else if (authorities.some((a) => a.includes("MANAGER") || a.includes("MANAGEMENT"))) {
          role = "Management";
        } else if (
          authorities.some(
            (a) =>
              a.includes("MECHANIC") ||
              a.includes("TECHNICIAN") ||
              a.includes("STAFF") ||
              a.includes("STORES") ||
              a.includes("EMPLOYEE"),
          )
        ) {
          role = "Employee";
        }

        return {
          success: true,
          token,
          user: {
            ...(data.userId !== undefined ? { userId: Number(data.userId) } : {}),
            ...(data.employeeId !== undefined ? { employeeId: Number(data.employeeId) } : {}),
            ...(data.companyId !== undefined ? { companyId: Number(data.companyId) } : {}),
            ...(data.workshopId !== undefined ? { workshopId: Number(data.workshopId) } : {}),
            companyName:
              typeof data.companyName === "string" && data.companyName.trim()
                ? data.companyName.trim()
                : "Hi Rider 4x4 World",
            ...(typeof data.department === "string" && data.department.trim()
              ? { department: data.department.trim() }
              : {}),
            displayName: data.displayName || cleanEmail.split("@")[0] || "Workshop User",
            email: cleanEmail,
            authorities,
            role,
          },
        };
      }
    } catch (err) {
      console.warn(
        "Backend /api/auth/me not available; falling back to centralized database verification:",
        err,
      );
    }
  }

  const result = verifyUserCredentials(cleanEmail, password);
  if (!result.success) {
    return { success: false, error: result.error || "Invalid email or password." };
  }

  return {
    success: true,
    token,
    ...(result.user ? { user: result.user } : {}),
  };
}

export async function registerWithBackend(
  email: string,
  password: string,
  fullName: string,
): Promise<{
  success: boolean;
  user?: AuthenticatedUser | undefined;
  token?: string | undefined;
  error?: string | undefined;
}> {
  const cleanEmail = email.trim();
  const cleanName = fullName.trim() || cleanEmail.split("@")[0] || "Workshop User";

  const result = registerUserInDatabase(cleanEmail, password, cleanName);
  if (!result.success) {
    return { success: false, error: result.error || "Registration failed." };
  }

  const token = "Basic " + btoa(`${cleanEmail}:${password}`);
  return {
    success: true,
    token,
    ...(result.user ? { user: result.user } : {}),
  };
}
