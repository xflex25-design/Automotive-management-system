import { z } from "zod";

export const intakeSchema = z.object({
  customerName: z.string().min(1, "Customer Name is required"),
  phone: z.string().min(1, "Phone Number is required"),
  plate: z.string().min(1, "Registration No. is required"),
  make: z.string().min(1, "Vehicle Make is required"),
  mileageIn: z.string().min(1, "Incoming Mileage is required"),
  complaints: z.string().min(1, "Customer's Reported Problem is required"),
  termsAccepted: z.literal(true, {
    errorMap: () => ({ message: "You must accept inspection conditions" }),
  }),
  customerSignature: z.string().min(1, "Customer Signature is required"),
});

export const quotationSchema = z.object({
  quotationNumber: z.string().min(1, "Quotation Number is required"),
  quotationDate: z.string().min(1, "Quotation Date is required"),
  preparedBy: z.string().min(1, "Prepared By is required"),
  signature: z.string().min(1, "Officer Signature is required"),
  itemsCount: z.number().min(1, "At least one quotation item is required"),
  total: z.number().min(0.01, "Quotation total must be greater than zero"),
});

export const authorizationSchema = z.object({
  customerAcceptance: z.enum(["Accepted", "Declined", "Pending"], {
    errorMap: () => ({ message: "Customer acceptance must be Accepted" }),
  }),
  paymentStatus: z.enum(["Unpaid", "Deposit Paid", "Paid in Full"]),
  depositAmount: z.number().min(0, "Deposit amount must be valid"),
  paymentReference: z.string().min(1, "Payment Reference is required"),
  customerName: z.string().min(1, "Customer Name is required"),
  customerSignature: z.string().min(1, "Customer Signature is required"),
});

export const jobCardSchema = z.object({
  jobNumber: z.string().min(1, "Job Number is required"),
  workToPerform: z.string().min(1, "Work to perform summary is required"),
  routedDepartments: z.array(z.string()).min(1, "Select at least one department"),
  assignedMechanic: z.string().min(1, "Assigned Mechanic is required"),
  expectedCompletionDate: z.string().min(1, "Expected completion date is required"),
});

export const partsCheckSchema = z.object({
  itemsCount: z.number().min(1, "At least one part line is required"),
});

export const dispatchSchema = z.object({
  dispatchNumber: z.string().min(1, "Dispatch Order No. is required"),
  issuedBy: z.string().min(1, "Issued By is required"),
  storesSignature: z.string().min(1, "Stores Signature is required"),
  authorizedSig: z.string().min(1, "Authorized Person Signature is required"),
  accountsAck: z.string().min(1, "Accounts Acknowledgement is required"),
});

export const monitorSchema = z.object({
  workCompletedSummary: z.string().min(1, "Work Completed Summary is required"),
  completionDate: z.string().min(1, "Completion Date is required"),
  foremanVerified: z.boolean().refine((val) => val === true, {
    message: "Foreman Verification checkbox must be checked",
  }),
});

export const finalReleaseSchema = z.object({
  qaResult: z.enum(["Passed", "Rework required"], {
    errorMap: () => ({ message: "Inspection result must be Passed" }),
  }),
  mileageOut: z.string().min(1, "Outgoing mileage is required"),
  fuelLevelOut: z.string().min(1, "Outgoing fuel level is required"),
  collectedBy: z.string().min(1, "Collected By name is required"),
  releasedBy: z.string().min(1, "Released By name is required"),
  releaseSignature: z.string().min(1, "Release Signature is required"),
});
