import type {
  ActivityRecord,
  DispatchOrder,
  HandoverRecord,
  Inspection,
  InventoryCard,
  JobCard,
  JobCardNotification,
  Quotation,
  Requisition,
  UserPreferences,
  Vehicle,
  WorkspaceRole,
} from "./workshop";
import type { AuthenticatedUser } from "./auth";
import { DEFAULT_RECENT_ACTIVITIES } from "./activity-feed";

export type DatabaseUser = {
  email: string;
  password: string;
  fullName: string;
  role?: WorkspaceRole | undefined;
  department?: string | undefined;
  userId?: number | undefined;
  employeeId?: number | undefined;
  companyId?: number | undefined;
  workshopId?: number | undefined;
  companyName?: string | undefined;
  preferences?: UserPreferences | undefined;
};

export interface DatabaseSchema {
  version: number;
  users: DatabaseUser[];
  vehicles: Vehicle[];
  quotations: Quotation[];
  inventory: InventoryCard[];
  jobs: JobCard[];
  requisitions: Requisition[];
  inspections: Inspection[];
  dispatches: DispatchOrder[];
  handovers: HandoverRecord[];
  invoices: Record<string, unknown>[];
  purchaseOrders: Record<string, unknown>[];
  activities: ActivityRecord[];
  notifications: JobCardNotification[];
  accountRoles: Record<string, { role: WorkspaceRole; department?: string }>;
}

const CURRENT_DB_VERSION = 2;
const DB_STORAGE_KEY = "hi_rider_central_db_v1";

function safeParseJson<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    const parsed = JSON.parse(raw) as T;
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}

function authoritiesForRole(role: WorkspaceRole): string[] {
  switch (role) {
    case "Director":
      return ["ROLE_BOSS"];
    case "Management":
      return ["ROLE_MANAGER"];
    case "Employee":
      return ["ROLE_MECHANIC"];
    default:
      return ["ROLE_FOREMAN"];
  }
}

function defaultPreferences(): UserPreferences {
  return {
    themeMode: "light",
    emailNotifications: true,
    smsAlerts: true,
    compactDensity: false,
  };
}

function toAuthenticatedUser(
  found: DatabaseUser,
  roleOverride?: { role?: WorkspaceRole; department?: string },
): AuthenticatedUser {
  const role: WorkspaceRole = roleOverride?.role ?? found.role ?? "Foreman";
  const department = roleOverride?.department ?? found.department;
  return {
    userId: found.userId ?? 1001,
    employeeId: found.employeeId ?? 101,
    companyId: found.companyId ?? 1,
    workshopId: found.workshopId ?? 1,
    companyName: found.companyName ?? "Hi Rider 4x4 World",
    ...(department ? { department } : {}),
    preferences: found.preferences ?? defaultPreferences(),
    displayName: found.fullName,
    email: found.email,
    authorities: authoritiesForRole(role),
    role,
  };
}

export function getCentralDatabase(): DatabaseSchema {
  if (typeof window === "undefined" || !window.localStorage) {
    return getDefaultDatabase();
  }
  try {
    const raw = localStorage.getItem(DB_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<DatabaseSchema> | null;
      if (parsed && typeof parsed === "object" && parsed.version === CURRENT_DB_VERSION) {
        return {
          ...getDefaultDatabase(),
          ...parsed,
          version: CURRENT_DB_VERSION,
          dispatches: Array.isArray(parsed.dispatches) ? parsed.dispatches : [],
          handovers: Array.isArray(parsed.handovers) ? parsed.handovers : [],
          invoices: Array.isArray(parsed.invoices) ? parsed.invoices : [],
          purchaseOrders: Array.isArray(parsed.purchaseOrders) ? parsed.purchaseOrders : [],
          activities: Array.isArray(parsed.activities) ? parsed.activities : [],
          notifications: Array.isArray(parsed.notifications) ? parsed.notifications : [],
        };
      }
    }
  } catch (err) {
    console.warn("Failed to load central database, falling back to migration:", err);
  }
  return migrateAndSaveDatabase();
}

export function saveCentralDatabase(db: Partial<DatabaseSchema>): DatabaseSchema {
  const current = getCentralDatabase();
  const updated: DatabaseSchema = {
    ...current,
    ...db,
    version: CURRENT_DB_VERSION,
  };

  if (typeof window !== "undefined" && window.localStorage) {
    try {
      localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(updated));
      localStorage.setItem("hi_rider_registered_users", JSON.stringify(updated.users));
      localStorage.setItem("hi_rider_vehicles", JSON.stringify(updated.vehicles));
      localStorage.setItem("hi_rider_quotations", JSON.stringify(updated.quotations));
      localStorage.setItem("hi_rider_inventory", JSON.stringify(updated.inventory));
      localStorage.setItem("hi_rider_jobs", JSON.stringify(updated.jobs));
      localStorage.setItem("hi_rider_requisitions", JSON.stringify(updated.requisitions));
      localStorage.setItem("hi_rider_inspections", JSON.stringify(updated.inspections));
      localStorage.setItem("hi_rider_dispatches", JSON.stringify(updated.dispatches));
      localStorage.setItem("hi_rider_handovers", JSON.stringify(updated.handovers));
      localStorage.setItem("hi_rider_invoices", JSON.stringify(updated.invoices));
      localStorage.setItem("hi_rider_purchase_orders", JSON.stringify(updated.purchaseOrders));
      localStorage.setItem("hi_rider_activities", JSON.stringify(updated.activities));
      localStorage.setItem("hi_rider_notifications", JSON.stringify(updated.notifications));
      localStorage.setItem("hi_rider_account_roles", JSON.stringify(updated.accountRoles));
    } catch (err) {
      console.warn("Failed to persist central database to localStorage:", err);
    }
  }
  return updated;
}

export function migrateAndSaveDatabase(): DatabaseSchema {
  const defaultDb = getDefaultDatabase();
  if (typeof window !== "undefined" && window.localStorage) {
    try {
      const existingRaw = safeParseJson<Partial<DatabaseSchema> | null>(
        localStorage.getItem(DB_STORAGE_KEY),
        null,
      );

      const legacyUsers = safeParseJson<DatabaseUser[]>(
        localStorage.getItem("hi_rider_registered_users"),
        [],
      );
      const legacyVehicles = safeParseJson<Vehicle[]>(
        localStorage.getItem("hi_rider_vehicles"),
        [],
      );
      const legacyQuotations = safeParseJson<Quotation[]>(
        localStorage.getItem("hi_rider_quotations"),
        [],
      );
      const legacyInventory = safeParseJson<InventoryCard[]>(
        localStorage.getItem("hi_rider_inventory"),
        [],
      );
      const legacyJobs = safeParseJson<JobCard[]>(localStorage.getItem("hi_rider_jobs"), []);
      const legacyRequisitions = safeParseJson<Requisition[]>(
        localStorage.getItem("hi_rider_requisitions"),
        [],
      );
      const legacyInspections = safeParseJson<Inspection[]>(
        localStorage.getItem("hi_rider_inspections"),
        [],
      );
      const legacyDispatches = safeParseJson<DispatchOrder[]>(
        localStorage.getItem("hi_rider_dispatches"),
        [],
      );
      const legacyHandovers = safeParseJson<HandoverRecord[]>(
        localStorage.getItem("hi_rider_handovers"),
        [],
      );
      const legacyInvoices = safeParseJson<Record<string, unknown>[]>(
        localStorage.getItem("hi_rider_invoices"),
        [],
      );
      const legacyPurchaseOrders = safeParseJson<Record<string, unknown>[]>(
        localStorage.getItem("hi_rider_purchase_orders"),
        [],
      );
      const legacyActivities = safeParseJson<ActivityRecord[]>(
        localStorage.getItem("hi_rider_activities"),
        [],
      );
      const legacyNotifications = safeParseJson<JobCardNotification[]>(
        localStorage.getItem("hi_rider_notifications"),
        [],
      );
      const legacyRoles = safeParseJson<
        Record<string, { role: WorkspaceRole; department?: string }>
      >(localStorage.getItem("hi_rider_account_roles"), {});

      const sourceUsers =
        Array.isArray(existingRaw?.users) && existingRaw.users.length > 0
          ? existingRaw.users
          : legacyUsers.length > 0
            ? legacyUsers
            : defaultDb.users;

      const normalizedUsers = sourceUsers.map((u, idx) => ({
        ...u,
        userId: u.userId ?? 1001 + idx,
        employeeId: u.employeeId ?? 101 + idx,
        companyId: u.companyId ?? 1,
        workshopId: u.workshopId ?? 1,
        companyName: u.companyName ?? "Hi Rider 4x4 World",
        preferences: u.preferences ?? defaultPreferences(),
      }));

      const pickArray = <T>(v1Items: T[] | undefined, legacyItems: T[], defaultItems: T[]): T[] => {
        if (Array.isArray(v1Items) && v1Items.length > 0) return v1Items;
        if (Array.isArray(legacyItems) && legacyItems.length > 0) return legacyItems;
        return defaultItems;
      };

      const migrated: DatabaseSchema = {
        version: CURRENT_DB_VERSION,
        users: normalizedUsers,
        vehicles: pickArray(existingRaw?.vehicles, legacyVehicles, defaultDb.vehicles),
        quotations: pickArray(existingRaw?.quotations, legacyQuotations, defaultDb.quotations),
        inventory: pickArray(existingRaw?.inventory, legacyInventory, defaultDb.inventory),
        jobs: pickArray(existingRaw?.jobs, legacyJobs, defaultDb.jobs),
        requisitions: pickArray(
          existingRaw?.requisitions,
          legacyRequisitions,
          defaultDb.requisitions,
        ),
        inspections: pickArray(existingRaw?.inspections, legacyInspections, defaultDb.inspections),
        dispatches: pickArray(existingRaw?.dispatches, legacyDispatches, defaultDb.dispatches),
        handovers: pickArray(existingRaw?.handovers, legacyHandovers, defaultDb.handovers),
        invoices: pickArray(existingRaw?.invoices, legacyInvoices, defaultDb.invoices),
        purchaseOrders: pickArray(
          existingRaw?.purchaseOrders,
          legacyPurchaseOrders,
          defaultDb.purchaseOrders,
        ),
        activities: pickArray(existingRaw?.activities, legacyActivities, defaultDb.activities),
        notifications: pickArray(
          existingRaw?.notifications,
          legacyNotifications,
          defaultDb.notifications,
        ),
        accountRoles:
          existingRaw?.accountRoles && Object.keys(existingRaw.accountRoles).length > 0
            ? existingRaw.accountRoles
            : Object.keys(legacyRoles).length > 0
              ? legacyRoles
              : defaultDb.accountRoles,
      };

      localStorage.setItem(DB_STORAGE_KEY, JSON.stringify(migrated));
      return migrated;
    } catch (err) {
      console.warn("Migration failed, using default database:", err);
    }
  }
  return defaultDb;
}

function getDefaultDatabase(): DatabaseSchema {
  return {
    version: CURRENT_DB_VERSION,
    users: [
      {
        email: "foreman@hirider.test",
        password: "Workshop123!",
        fullName: "Foreman 01",
        role: "Foreman",
        userId: 1001,
        employeeId: 101,
        companyId: 1,
        workshopId: 1,
        companyName: "Hi Rider 4x4 World",
        preferences: defaultPreferences(),
      },
      {
        email: "director@hirider.test",
        password: "Workshop123!",
        fullName: "Workshop Director",
        role: "Director",
        userId: 1002,
        employeeId: 102,
        companyId: 1,
        workshopId: 1,
        companyName: "Hi Rider 4x4 World",
        preferences: defaultPreferences(),
      },
      {
        email: "manager@hirider.test",
        password: "Workshop123!",
        fullName: "Operations Manager",
        role: "Management",
        userId: 1003,
        employeeId: 103,
        companyId: 1,
        workshopId: 1,
        companyName: "Hi Rider 4x4 World",
        preferences: defaultPreferences(),
      },
      {
        email: "employee@hirider.test",
        password: "Workshop123!",
        fullName: "Lead Mechanic",
        role: "Employee",
        department: "Mechanical",
        userId: 1004,
        employeeId: 104,
        companyId: 1,
        workshopId: 1,
        companyName: "Hi Rider 4x4 World",
        preferences: defaultPreferences(),
      },
    ],
    vehicles: [],
    quotations: [],
    inventory: [],
    jobs: [],
    requisitions: [],
    inspections: [],
    dispatches: [],
    handovers: [],
    invoices: [],
    purchaseOrders: [],
    activities: [...DEFAULT_RECENT_ACTIVITIES],
    notifications: [],
    accountRoles: {},
  };
}

export function verifyUserCredentials(
  email: string,
  pass: string,
): { success: boolean; user?: AuthenticatedUser | undefined; error?: string | undefined } {
  const db = getCentralDatabase();
  const cleanEmail = email.trim().toLowerCase();
  const found = db.users.find((u) => u.email.toLowerCase() === cleanEmail);

  if (!found) {
    return { success: false, error: "Account not found. Please register or check your email." };
  }

  if (found.password !== pass) {
    return { success: false, error: "Invalid password. Please try again." };
  }

  const roleOverride = db.accountRoles[cleanEmail];
  return { success: true, user: toAuthenticatedUser(found, roleOverride) };
}

export function registerUserInDatabase(
  email: string,
  pass: string,
  fullName: string,
): { success: boolean; user?: AuthenticatedUser | undefined; error?: string | undefined } {
  const db = getCentralDatabase();
  const cleanEmail = email.trim();
  const cleanName = fullName.trim() || cleanEmail.split("@")[0] || "Workshop User";

  if (!cleanEmail || !pass || pass.length < 4) {
    return {
      success: false,
      error: "Please provide a valid email and a password of at least 4 characters.",
    };
  }

  if (db.users.some((u) => u.email.toLowerCase() === cleanEmail.toLowerCase())) {
    return {
      success: false,
      error: "An account with this email already exists. Please login instead.",
    };
  }

  const nextUserId = db.users.reduce((max, u) => Math.max(max, u.userId ?? 1000), 1000) + 1;
  const nextEmployeeId = db.users.reduce((max, u) => Math.max(max, u.employeeId ?? 100), 100) + 1;

  const newUser: DatabaseUser = {
    email: cleanEmail,
    password: pass,
    fullName: cleanName,
    role: "Foreman",
    userId: nextUserId,
    employeeId: nextEmployeeId,
    companyId: 1,
    workshopId: 1,
    companyName: "Hi Rider 4x4 World",
    preferences: defaultPreferences(),
  };

  saveCentralDatabase({
    users: [...db.users, newUser],
  });

  return { success: true, user: toAuthenticatedUser(newUser) };
}

export function updateUserPasswordInDatabase(
  email: string,
  currentPassword: string,
  newPassword: string,
): { success: boolean; error?: string } {
  const cleanEmail = email.trim().toLowerCase();
  if (!cleanEmail) {
    return { success: false, error: "No authenticated user email available." };
  }
  if (!newPassword || newPassword.length < 4) {
    return { success: false, error: "Password must be at least 4 characters long." };
  }

  const db = getCentralDatabase();
  const index = db.users.findIndex((u) => u.email.toLowerCase() === cleanEmail);
  if (index === -1) {
    return { success: false, error: "User record not found in workshop database." };
  }

  const existing = db.users[index]!;
  if (existing.password !== currentPassword) {
    return { success: false, error: "Current password is incorrect." };
  }

  const updatedUsers = db.users.map((u, idx) =>
    idx === index ? { ...u, password: newPassword } : u,
  );
  saveCentralDatabase({ users: updatedUsers });
  return { success: true };
}

export function updateUserPreferencesInDatabase(
  email: string,
  patch: {
    department?: string | undefined;
    preferences?: Partial<UserPreferences> | undefined;
  },
): { success: boolean; user?: AuthenticatedUser | undefined } {
  const cleanEmail = email.trim().toLowerCase();
  const db = getCentralDatabase();
  const index = db.users.findIndex((u) => u.email.toLowerCase() === cleanEmail);
  if (index === -1) {
    return { success: false };
  }

  const existing = db.users[index]!;
  const mergedPreferences: UserPreferences = {
    ...(existing.preferences ?? defaultPreferences()),
    ...(patch.preferences ?? {}),
  };
  const nextDept = patch.department !== undefined ? patch.department : existing.department;

  const updatedUser: DatabaseUser = {
    ...existing,
    ...(nextDept ? { department: nextDept } : {}),
    preferences: mergedPreferences,
  };

  const updatedUsers = db.users.map((u, idx) => (idx === index ? updatedUser : u));
  const updatedAccountRoles = { ...db.accountRoles };
  if (nextDept) {
    updatedAccountRoles[cleanEmail] = {
      role: updatedAccountRoles[cleanEmail]?.role ?? existing.role ?? "Foreman",
      department: nextDept,
    };
  }

  saveCentralDatabase({
    users: updatedUsers,
    accountRoles: updatedAccountRoles,
  });

  if (typeof window !== "undefined" && window.localStorage) {
    localStorage.setItem("hi_rider_theme", mergedPreferences.themeMode);
    if (nextDept) {
      localStorage.setItem("hi_rider_department", nextDept);
    }
  }

  return {
    success: true,
    user: toAuthenticatedUser(updatedUser, updatedAccountRoles[cleanEmail]),
  };
}

export function updateUserRoleInDatabase(
  email: string,
  role: WorkspaceRole,
  department?: string,
): { success: boolean; user?: AuthenticatedUser | undefined } {
  const cleanEmail = email.trim().toLowerCase();
  const db = getCentralDatabase();

  const updatedAccountRoles = {
    ...db.accountRoles,
    [cleanEmail]: {
      role,
      ...(department ? { department } : {}),
    },
  };

  let matchedUser: DatabaseUser | undefined;
  const updatedUsers = db.users.map((u) => {
    if (u.email.toLowerCase() !== cleanEmail) return u;
    matchedUser = {
      ...u,
      role,
      ...(department ? { department } : {}),
    };
    return matchedUser;
  });

  saveCentralDatabase({
    users: updatedUsers,
    accountRoles: updatedAccountRoles,
  });

  return {
    success: true,
    ...(matchedUser
      ? { user: toAuthenticatedUser(matchedUser, updatedAccountRoles[cleanEmail]) }
      : {}),
  };
}
