import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

const isResizeObserverError = (msg: unknown) => {
  const str =
    typeof msg === "string" ? msg : msg instanceof Error ? msg.message : String(msg ?? "");
  return (
    str.includes("ResizeObserver loop completed with undelivered notifications") ||
    str.includes("ResizeObserver loop limit exceeded") ||
    str.includes("ResizeObserver loop")
  );
};

const prevOnError = window.onerror;
window.onerror = function (message, source, lineno, colno, error) {
  if (isResizeObserverError(message) || (error && isResizeObserverError(error.message))) {
    return true;
  }
  if (typeof prevOnError === "function") {
    return prevOnError.apply(this, [message, source, lineno, colno, error]);
  }
  return false;
};

window.addEventListener(
  "error",
  (e) => {
    if (isResizeObserverError(e.message) || (e.error && isResizeObserverError(e.error.message))) {
      e.stopImmediatePropagation();
      e.preventDefault();
    }
  },
  true,
);

window.addEventListener(
  "unhandledrejection",
  (e) => {
    if (isResizeObserverError(e.reason)) {
      e.stopImmediatePropagation();
      e.preventDefault();
    }
  },
  true,
);

createRoot(document.getElementById("root")!).render(<App />);
