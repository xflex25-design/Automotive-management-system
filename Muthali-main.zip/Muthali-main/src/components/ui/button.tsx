import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-[6px] text-sm font-[500] cursor-pointer transition-[background-color,border-color,color,box-shadow] duration-150 ease-in-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90 active:translate-y-px",
        secondary:
          "border border-[#d1d5db] bg-white text-[#1f2937] hover:bg-[#f8fafc] hover:text-[#111827] active:translate-y-px",
        ghost: "bg-transparent border-0 text-slate-700 hover:bg-slate-100 hover:text-slate-900",
        destructive: "bg-[#dc2626] text-white hover:bg-[#b91c1c] active:translate-y-px",
        success: "bg-[#16a34a] text-white hover:bg-[#15803d] active:translate-y-px",
        warning: "bg-[#d97706] text-white hover:bg-[#b45309] active:translate-y-px",
        outline:
          "border border-[#d1d5db] bg-white text-[#1f2937] hover:bg-[#f8fafc] hover:border-primary hover:text-primary",
        navigation: "text-slate-600 hover:text-primary hover:bg-slate-100",
        link: "text-primary font-[500] underline decoration-[1.5px] underline-offset-4 hover:text-primary/80",
      },
      size: {
        default: "h-10 px-4 py-2 text-sm", // Medium: 40px height, 16px padding, 14px font
        sm: "h-8 px-3 py-1.5 text-[13px]", // Small: 32px height, 12px padding, 13px font
        lg: "h-11 px-7 text-base",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
