import { useMemo, useState } from "react";
import {
  Car,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  FileText,
  Package,
  RotateCcw,
  Search,
  ShieldCheck,
  Wrench,
  X,
} from "./fa-icons";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useWorkspace } from "./workspace-context";
import {
  ACTIVITY_CATEGORIES,
  categorizeActivity,
  extractActivityEntityRef,
  filterActivities,
  formatActivityRelativeTime,
  getActivityCategoryMeta,
  type ActivityCategory,
} from "@/lib/activity-feed";
import type { ActivityRecord } from "@/lib/workshop";
import { cn } from "@/lib/utils";

export interface RecentActivityFeedProps {
  className?: string;
  maxHeight?: number | string;
  title?: string;
  subtitle?: string;
  showHeader?: boolean;
  showFilters?: boolean;
  showSearch?: boolean;
  limit?: number;
  emptyTitle?: string;
  emptyDescription?: string;
  onSelectActivity?: (activity: ActivityRecord) => void;
}

export function RecentActivityFeed({
  className,
  maxHeight = 420,
  title = "Recent Activity",
  subtitle = "Scrollable live feed of system actions and status changes",
  showHeader = true,
  showFilters = true,
  showSearch = true,
  limit,
  emptyTitle = "No recent workshop activity",
  emptyDescription = "System actions like vehicle registrations, job card updates, quotations, and parts releases will appear here in real time.",
  onSelectActivity,
}: RecentActivityFeedProps) {
  const { activities, addActivity } = useWorkspace();
  const [selectedCategory, setSelectedCategory] = useState<ActivityCategory>("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredList = useMemo(() => {
    const list = filterActivities(activities, {
      category: selectedCategory,
      query: searchQuery,
    });
    return typeof limit === "number" && limit > 0 ? list.slice(0, limit) : list;
  }, [activities, selectedCategory, searchQuery, limit]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { all: activities.length };
    for (const item of activities) {
      const cat = categorizeActivity(item.text, item.detail);
      counts[cat] = (counts[cat] ?? 0) + 1;
    }
    return counts;
  }, [activities]);

  const containerStyle = useMemo(() => {
    if (!maxHeight) return undefined;
    return {
      maxHeight: typeof maxHeight === "number" ? `${maxHeight}px` : maxHeight,
    };
  }, [maxHeight]);

  function renderCategoryIcon(category: ActivityCategory) {
    switch (category) {
      case "job_card":
        return <Wrench size={14} className="text-blue-600" />;
      case "vehicle":
        return <Car size={14} className="text-emerald-600" />;
      case "quotation":
        return <FileText size={14} className="text-purple-600" />;
      case "authorization":
        return <ShieldCheck size={14} className="text-amber-600" />;
      case "parts":
        return <Package size={14} className="text-orange-600" />;
      case "inspection":
        return <ClipboardCheck size={14} className="text-teal-600" />;
      default:
        return <Clock size={14} className="text-slate-500" />;
    }
  }

  return (
    <div
      className={cn(
        "rounded-xl border border-slate-200 bg-white p-5 shadow-xs transition-shadow hover:shadow-sm",
        className,
      )}
      data-testid="recent-activity-feed"
    >
      {/* Optional Header */}
      {showHeader && (
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2.5">
              <h3 className="text-base font-bold text-slate-900 tracking-tight">{title}</h3>
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Live Feed
              </span>
            </div>
            {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-xs font-semibold text-slate-600 tabular-nums">
              {filteredList.length} of {activities.length}{" "}
              {activities.length === 1 ? "action" : "actions"}
            </span>
          </div>
        </div>
      )}

      {/* Controls: Search and Categories */}
      {(showSearch || showFilters) && (
        <div className="pt-3.5 pb-2 space-y-2.5">
          {showSearch && (
            <div className="relative">
              <Search
                size={14}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
              />
              <Input
                aria-label="Filter recent actions"
                placeholder="Search actions (e.g. Job card, Hilux, BAK 6213, Peter)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-8 h-9 text-xs rounded-lg border-slate-200 bg-slate-50/60 focus:bg-white"
              />
              {searchQuery && (
                <button
                  type="button"
                  aria-label="Clear search"
                  onClick={() => setSearchQuery("")}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5"
                >
                  <X size={13} />
                </button>
              )}
            </div>
          )}

          {showFilters && (
            <div
              className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-slate-200 text-xs"
              role="tablist"
              aria-label="Activity Categories"
            >
              {ACTIVITY_CATEGORIES.map((cat) => {
                const count = categoryCounts[cat.id] ?? 0;
                const isSelected = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    role="tab"
                    aria-selected={isSelected}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={cn(
                      "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md font-medium text-xs whitespace-nowrap transition-colors cursor-pointer border",
                      isSelected
                        ? "bg-slate-900 text-white border-slate-900 shadow-xs"
                        : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:text-slate-900",
                    )}
                  >
                    <span>{cat.label}</span>
                    <span
                      className={cn(
                        "text-[10px] tabular-nums font-semibold px-1.5 py-0.2 rounded-full",
                        isSelected ? "bg-slate-800 text-slate-200" : "bg-slate-100 text-slate-600",
                      )}
                    >
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Scrollable Feed List */}
      <div
        className="mt-2 overflow-y-auto space-y-2.5 pr-1 focus:outline-hidden"
        style={containerStyle}
        role="feed"
        aria-label="Recent system activity list"
        data-testid="activity-feed-scroll-container"
      >
        {filteredList.length > 0 ? (
          filteredList.map((item, index) => {
            const category = categorizeActivity(item.text, item.detail);
            const meta = getActivityCategoryMeta(category);
            const relativeTime = formatActivityRelativeTime(
              item.createdAtMs,
              item.time || "Just now",
            );
            const entityRef = extractActivityEntityRef(item.text, item.detail);

            return (
              <article
                key={`${item.text}-${item.createdAtMs ?? index}-${index}`}
                role="article"
                aria-label={item.text}
                onClick={() => onSelectActivity?.(item)}
                className={cn(
                  "group relative flex items-start gap-3 p-3 rounded-lg border border-slate-200/80 bg-white transition-all duration-150 hover:border-slate-300 hover:bg-slate-50/70",
                  onSelectActivity && "cursor-pointer",
                )}
              >
                {/* Icon Column */}
                <div
                  className={cn(
                    "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border",
                    meta.badgeClass,
                  )}
                  aria-hidden="true"
                >
                  {renderCategoryIcon(category)}
                </div>

                {/* Content Column */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={cn(
                          "inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold border",
                          meta.badgeClass,
                        )}
                      >
                        <span className={cn("w-1 h-1 rounded-full", meta.dotClass)} />
                        {meta.label}
                      </span>

                      {entityRef.referenceId && (
                        <span className="font-mono text-[10px] font-semibold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                          {entityRef.referenceId}
                        </span>
                      )}
                    </div>

                    <time
                      dateTime={
                        item.createdAtMs ? new Date(item.createdAtMs).toISOString() : undefined
                      }
                      title={
                        item.createdAtMs
                          ? new Date(item.createdAtMs).toLocaleString("en-GB")
                          : item.time
                      }
                      className="text-[11px] font-medium text-slate-400 shrink-0 tabular-nums flex items-center gap-1"
                    >
                      <Clock size={11} className="text-slate-400" />
                      <span>{relativeTime}</span>
                    </time>
                  </div>

                  {/* Main Action Title */}
                  <h4 className="text-xs font-bold text-slate-900 mt-1 leading-snug group-hover:text-primary transition-colors">
                    {item.text}
                  </h4>

                  {/* Secondary Details */}
                  {item.detail && (
                    <p className="text-xs text-slate-600 mt-0.5 leading-relaxed break-words">
                      {item.detail}
                    </p>
                  )}
                </div>
              </article>
            );
          })
        ) : (
          <div className="py-8 px-4 text-center rounded-lg border border-dashed border-slate-200 bg-slate-50/50">
            <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-slate-100 text-slate-400 mb-2.5">
              <Search size={18} />
            </div>
            <h4 className="text-xs font-semibold text-slate-800">{emptyTitle}</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto leading-relaxed">
              {searchQuery || selectedCategory !== "all"
                ? "No activities matched your current search filters. Try clearing the filters to view all entries."
                : emptyDescription}
            </p>
            {(searchQuery || selectedCategory !== "all") && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="mt-3.5 h-8 text-xs"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory("all");
                }}
              >
                <RotateCcw size={12} className="mr-1.5" />
                Reset Filters
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Footer Summary / Quick Action */}
      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
        <span className="flex items-center gap-1.5">
          <CheckCircle2 size={12} className="text-emerald-600" />
          <span>Real-time event logging active</span>
        </span>
        <button
          type="button"
          onClick={() => {
            addActivity(
              "Job card updated: System manual check",
              "Foreman verified workshop activity stream integrity",
            );
          }}
          className="text-primary hover:underline font-medium cursor-pointer"
        >
          + Log Check Event
        </button>
      </div>
    </div>
  );
}
