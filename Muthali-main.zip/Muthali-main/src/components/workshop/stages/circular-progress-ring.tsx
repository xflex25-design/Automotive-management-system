import React from "react";

type CircularProgressRingProps = {
  percentage: number;
  size?: number;
  strokeWidth?: number;
  className?: string;
};

export function CircularProgressRing({
  percentage,
  size = 32,
  strokeWidth = 3,
  className = "",
}: CircularProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.min(100, Math.max(0, percentage));
  const strokeDashoffset = circumference - (clamped / 100) * circumference;

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 ${className}`}
      style={{ width: size, height: size }}
      aria-label={`${clamped}% completed`}
      title={`${clamped}% completed (${Math.round((clamped / 100) * 8)} of 8 stages completed)`}
    >
      <svg className="w-full h-full -rotate-95" viewBox={`0 0 ${size} ${size}`}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          className="stroke-slate-200 fill-none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="stroke-primary fill-none transition-all duration-300"
        />
      </svg>
      <span className="absolute text-[10px] font-bold tabular-nums text-slate-700">{clamped}%</span>
    </div>
  );
}
