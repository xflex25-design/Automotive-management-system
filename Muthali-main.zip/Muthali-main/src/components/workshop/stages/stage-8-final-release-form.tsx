import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, CheckCircle2, Lock } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import type { HandoverRecord, Inspection, IntakeDetails, JobCard, Vehicle } from "@/lib/workshop";
import { calculateStepWizardPercentage, type JobStageReadinessReport } from "@/lib/workshop-flow";
import { FormStepFooter, FormStepHeader, type FormStepItem } from "./form-step-wizard";

type Stage8FinalReleaseFormProps = {
  vehicle: Vehicle;
  job?: JobCard | undefined;
  inspection?: Inspection | undefined;
  readiness: JobStageReadinessReport;
  bannerExtra?: ReactNode;
  onBack?: () => void;
  onSendToRework?: () => void;
};

const FUEL_LEVELS = ["Empty", "1/4", "1/2", "3/4", "Full"] as const;
type ReleaseStepId = "qa" | "fuel_mileage" | "release";

export function Stage8FinalReleaseForm({
  vehicle,
  job,
  inspection,
  readiness,
  onBack,
  onSendToRework,
}: Stage8FinalReleaseFormProps) {
  const { setInspections, setVehicles, setJobs, setHandovers, foreman, addActivity } =
    useWorkspace();

  const todayIso = new Date().toISOString().slice(0, 10);

  const [activeStep, setActiveStep] = useState<ReleaseStepId>("qa");
  const [qaResult, setQaResult] = useState<Inspection["result"]>(
    inspection?.result === "Passed" || inspection?.result === "Rework required"
      ? inspection.result
      : "Passed",
  );
  const [qaNotes, setQaNotes] = useState(inspection?.notes ?? "");
  const [inspectorName, setInspectorName] = useState(inspection?.foreman ?? "");
  const [inspectionDate, setInspectionDate] = useState(inspection?.date ?? todayIso);

  const [fuelLevelOut, setFuelLevelOut] = useState<IntakeDetails["fuelLevelOut"]>(
    vehicle.intakeDetails?.fuelLevelOut || "",
  );
  const [mileageOut, setMileageOut] = useState(
    vehicle.intakeDetails?.mileageOut !== undefined ? String(vehicle.intakeDetails.mileageOut) : "",
  );

  const [collectedBy, setCollectedBy] = useState(vehicle.intakeDetails?.collectedBy ?? "");
  const [collectedCustomerName, setCollectedCustomerName] = useState(
    vehicle.intakeDetails?.collectedCustomerName ?? "",
  );
  const [collectedPhone, setCollectedPhone] = useState(vehicle.intakeDetails?.collectedPhone ?? "");
  const [timeOut, setTimeOut] = useState(vehicle.intakeDetails?.timeOut ?? "");
  const [releasedBy, setReleasedBy] = useState(vehicle.intakeDetails?.releasedBy ?? "");
  const [releaseSignature, setReleaseSignature] = useState(
    vehicle.intakeDetails?.releaseSignature ?? "",
  );

  useEffect(() => {
    setQaResult(
      inspection?.result === "Passed" || inspection?.result === "Rework required"
        ? inspection.result
        : "Passed",
    );
    setQaNotes(inspection?.notes ?? "");
    setInspectorName(inspection?.foreman ?? "");
    setInspectionDate(inspection?.date ?? todayIso);
    setFuelLevelOut(vehicle.intakeDetails?.fuelLevelOut || "");
    setMileageOut(
      vehicle.intakeDetails?.mileageOut !== undefined
        ? String(vehicle.intakeDetails.mileageOut)
        : "",
    );
    setCollectedBy(vehicle.intakeDetails?.collectedBy ?? "");
    setCollectedCustomerName(vehicle.intakeDetails?.collectedCustomerName ?? "");
    setCollectedPhone(vehicle.intakeDetails?.collectedPhone ?? "");
    setTimeOut(vehicle.intakeDetails?.timeOut ?? "");
    setReleasedBy(vehicle.intakeDetails?.releasedBy ?? "");
    setReleaseSignature(vehicle.intakeDetails?.releaseSignature ?? "");
  }, [vehicle, job, inspection, todayIso]);

  const mileageIn = vehicle.intakeDetails?.mileageIn ?? vehicle.odometer ?? 0;
  const parsedMileageOut = Number(mileageOut || 0);
  const mileageTooLow = mileageOut.trim() !== "" && parsedMileageOut < mileageIn;

  const blockers: string[] = [];
  if (!readiness.stages1To6Complete) {
    blockers.push("Stages 1–6 must remain complete.");
  }
  if (!inspection) {
    blockers.push("Submit Stage 7 for Final Inspection first.");
  }
  if (qaResult === "Rework required") {
    blockers.push("Vehicle flagged for rework — return to Stage 7 before releasing.");
  }
  if (!mileageOut.trim() || Number.isNaN(parsedMileageOut) || mileageTooLow) {
    blockers.push(`Outgoing mileage must be >= incoming mileage (${mileageIn} km).`);
  }
  if (!fuelLevelOut) blockers.push("Select outgoing Fuel Level (OUT).");
  if (!collectedBy.trim()) blockers.push("Enter Collected By name.");
  if (!releasedBy.trim() || !releaseSignature.trim()) {
    blockers.push("Released By and Release Signature are required.");
  }

  const canRelease = blockers.length === 0 && qaResult === "Passed";

  const step1Done = qaResult === "Passed" && inspectionDate.trim().length > 0;
  const step2Done =
    mileageOut.trim().length > 0 &&
    !Number.isNaN(parsedMileageOut) &&
    !mileageTooLow &&
    Boolean(fuelLevelOut);
  const step3Done = canRelease;

  const steps: readonly FormStepItem<ReleaseStepId>[] = [
    { id: "qa", stepNumber: 1, title: "Quality Inspection", done: step1Done },
    { id: "fuel_mileage", stepNumber: 2, title: "Fuel & Mileage Out", done: step2Done },
    { id: "release", stepNumber: 3, title: "Collection & Release", done: step3Done },
  ];

  const activeIdx = activeStep === "qa" ? 0 : activeStep === "fuel_mileage" ? 1 : 2;
  const progressPercentage = calculateStepWizardPercentage(activeIdx, 3, [
    step1Done,
    step2Done,
    step3Done,
  ]);

  function handleNextStep() {
    if (activeStep === "qa") {
      setActiveStep("fuel_mileage");
      return;
    }
    if (activeStep === "fuel_mileage") {
      if (!step2Done) {
        toast.error(
          `Enter outgoing Mileage (>= ${mileageIn} km) and select outgoing Fuel Level (OUT).`,
        );
        return;
      }
      setActiveStep("release");
    }
  }

  function handleFlagRework() {
    if (!inspection) return;
    setInspections((prev) =>
      prev.map((ins) =>
        ins.id === inspection.id
          ? {
              ...ins,
              result: "Rework required",
              notes: qaNotes.trim() || "Returned from Final Inspection for rework",
              foreman: inspectorName.trim() || foreman,
              date: inspectionDate,
            }
          : ins,
      ),
    );
    if (job) {
      setJobs((prev) =>
        prev.map((item) =>
          item.id === job.id
            ? {
                ...item,
                status: "Rework required",
                stagnationMeta: {
                  ...item.stagnationMeta,
                  awaitingSupervisorAttention: true,
                },
              }
            : item,
        ),
      );
    }
    addActivity(
      `Final Inspection flagged rework (${inspection.id})`,
      `${vehicle.plate} returned to Stage 7`,
    );
    toast.error(`${vehicle.plate} flagged for rework. Returning to Stage 7.`);
    onSendToRework?.();
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (qaResult === "Rework required") {
      handleFlagRework();
      return;
    }
    if (!canRelease || !inspection) {
      toast.error(blockers[0] ?? "Complete final inspection & release details.");
      return;
    }

    const resolvedInspector = inspectorName.trim() || foreman;
    setInspections((prev) =>
      prev.map((ins) =>
        ins.id === inspection.id
          ? {
              ...ins,
              result: "Passed",
              foreman: resolvedInspector,
              inspector: resolvedInspector,
              date: inspectionDate,
              notes: qaNotes.trim(),
            }
          : ins,
      ),
    );

    const resolvedFuelLevelOut: Exclude<IntakeDetails["fuelLevelOut"], undefined> =
      fuelLevelOut ?? "Full";

    setVehicles((prev) =>
      prev.map((v) =>
        v.id === vehicle.id
          ? {
              ...v,
              released: true,
              progress: 100,
              stage: 11,
              intakeDetails: {
                ...(v.intakeDetails ?? {
                  customerType: "Individual",
                  customerAddress: "",
                  driverName: v.customer,
                  model: v.model ?? "",
                  year: v.year ?? "",
                  engineNumber: "",
                  mileageIn: v.odometer ?? 0,
                  fuelLevelIn: "Full",
                  accessories: [],
                  damageTypes: [],
                  additionalRemarks: "",
                  requestedRepairs: "",
                  additionalInstructions: "",
                  termsAccepted: true,
                  customerSignature: v.customer,
                  intakeOfficer: foreman,
                  authorizationDate: todayIso,
                  status: "completed",
                }),
                mileageOut: parsedMileageOut,
                fuelLevelOut: resolvedFuelLevelOut,
                collectedBy: collectedBy.trim(),
                collectedCustomerName: collectedCustomerName.trim() || vehicle.customer,
                collectedPhone: collectedPhone.trim() || vehicle.phone,
                timeOut,
                releasedBy: releasedBy.trim(),
                releaseSignature: releaseSignature.trim(),
              },
            }
          : v,
      ),
    );

    setHandovers((prev) => {
      const nextEntry: HandoverRecord = {
        id: `HO-${vehicle.id}`,
        vehicleId: vehicle.id,
        jobId: job?.backendJobId ?? job?.id ?? vehicle.id,
        plate: vehicle.plate,
        customerName: collectedCustomerName.trim() || vehicle.customer,
        collectedBy: collectedBy.trim(),
        collectedPhone: collectedPhone.trim() || vehicle.phone,
        releasedBy: releasedBy.trim(),
        releaseSignature: releaseSignature.trim(),
        mileageOut: parsedMileageOut,
        fuelLevelOut: resolvedFuelLevelOut,
        date: inspectionDate,
        timeOut,
      };
      const exists = prev.some((item) => item.vehicleId === vehicle.id);
      return exists
        ? prev.map((item) => (item.vehicleId === vehicle.id ? nextEntry : item))
        : [nextEntry, ...prev];
    });

    addActivity(
      `Final Inspection passed & vehicle released (${vehicle.plate})`,
      `${releasedBy.trim()} -> Collected by ${collectedBy.trim()} (${parsedMileageOut} km)`,
    );
    toast.success(`${vehicle.plate} passed Final Inspection and has been released.`);
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="stage-form-stack">
      <FormStepHeader
        steps={steps}
        activeStepId={activeStep}
        onSelectStep={setActiveStep}
        progressPercentage={progressPercentage}
        ariaLabel="Stage 8 Final Release Sections"
      />

      {activeStep === "qa" && (
        <>
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Final Quality Inspection</h3>
                <p className="stage-card-subtitle">
                  Inspection {inspection?.id ?? "Pending Stage 7"} / {vehicle.plate}
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s8-qa-result">
                    <span className="text-red-600">*</span> Inspection Decision
                  </label>
                  <Select
                    value={qaResult}
                    onValueChange={(value) => setQaResult(value as Inspection["result"])}
                  >
                    <SelectTrigger id="s8-qa-result" className="stage-select-trigger">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Passed">Passed — Ready for Release</SelectItem>
                      <SelectItem value="Rework required">
                        Rework Required — Return to Stage 7
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s8-inspector">
                    Inspector / Foreman
                  </label>
                  <Input
                    id="s8-inspector"
                    className="stage-input"
                    placeholder="Inspector / foreman name"
                    value={inspectorName}
                    onChange={(e) => setInspectorName(e.target.value)}
                  />
                </div>
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s8-date">
                    Inspection Date
                  </label>
                  <Input
                    id="s8-date"
                    type="date"
                    className="stage-input"
                    value={inspectionDate}
                    onChange={(e) => setInspectionDate(e.target.value)}
                  />
                </div>
              </div>

              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s8-notes">
                  Road-Test &amp; QA Notes
                </label>
                <Textarea
                  id="s8-notes"
                  className="stage-textarea"
                  placeholder="Road-test findings and quality inspection notes"
                  value={qaNotes}
                  onChange={(e) => setQaNotes(e.target.value)}
                />
              </div>
            </div>
          </div>

          <FormStepFooter
            leftExtra={
              onBack && (
                <Button type="button" variant="outline" onClick={onBack}>
                  &larr; Back to Stage 7
                </Button>
              )
            }
            rightExtra={
              qaResult === "Rework required" && (
                <Button type="button" variant="destructive" onClick={handleFlagRework}>
                  Flag Rework &amp; Return to Stage 7
                </Button>
              )
            }
            onNext={qaResult === "Rework required" ? undefined : handleNextStep}
            nextLabel="Next: Fuel & Mileage Out"
          />
        </>
      )}

      {activeStep === "fuel_mileage" && (
        <>
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Outgoing Fuel &amp; Mileage Check</h3>
                <p className="stage-card-subtitle">
                  Incoming Fuel Level:{" "}
                  <strong>{vehicle.intakeDetails?.fuelLevelIn ?? "Full"}</strong> / Incoming
                  Odometer: <strong className="tabular-nums">{mileageIn} km</strong>
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-end">
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s8-mileage-out">
                  <span className="text-red-600">*</span> Mileage (OUT) km
                </label>
                <Input
                  id="s8-mileage-out"
                  type="number"
                  min={mileageIn}
                  placeholder={String(mileageIn || "0")}
                  className="stage-input tabular-nums"
                  value={mileageOut}
                  onChange={(e) => setMileageOut(e.target.value)}
                  required
                />
              </div>
              <div className="stage-field">
                <span className="stage-field-label">
                  <span className="text-red-600">*</span> Fuel Level (OUT)
                </span>
                <div className="flex flex-wrap items-center gap-3 min-h-[42px] px-3 rounded-md border border-slate-300 bg-white text-xs">
                  {FUEL_LEVELS.map((lvl) => (
                    <label key={lvl} className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="s8_fuel_out"
                        checked={fuelLevelOut === lvl}
                        onChange={() => setFuelLevelOut(lvl)}
                        className="accent-primary"
                      />
                      <span className="font-medium text-slate-700">{lvl}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <FormStepFooter
            onPrev={() => setActiveStep("qa")}
            prevLabel="Previous: Quality Inspection"
            statusHint={step2Done ? "Outgoing specs recorded" : `Enter >= ${mileageIn} km & fuel`}
            onNext={handleNextStep}
            nextLabel="Next: Collection & Release"
          />
        </>
      )}

      {activeStep === "release" && (
        <>
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Vehicle Collection &amp; Release Sign-Off</h3>
                <p className="stage-card-subtitle">
                  Confirm collector identity and final release signatures
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s8-collected-by">
                  <span className="text-red-600">*</span> Collected By
                </label>
                <Input
                  id="s8-collected-by"
                  className="stage-input"
                  placeholder="Collector full name"
                  value={collectedBy}
                  onChange={(e) => setCollectedBy(e.target.value)}
                  required
                />
              </div>
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s8-collected-name">
                  Customer Name
                </label>
                <Input
                  id="s8-collected-name"
                  className="stage-input"
                  placeholder="Customer name"
                  value={collectedCustomerName}
                  onChange={(e) => setCollectedCustomerName(e.target.value)}
                />
              </div>
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s8-collected-phone">
                  Phone Number
                </label>
                <Input
                  id="s8-collected-phone"
                  className="stage-input"
                  placeholder="0977 123 456"
                  value={collectedPhone}
                  onChange={(e) => setCollectedPhone(e.target.value)}
                />
              </div>
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s8-time-out">
                  Time Out
                </label>
                <Input
                  id="s8-time-out"
                  type="time"
                  className="stage-input"
                  value={timeOut}
                  onChange={(e) => setTimeOut(e.target.value)}
                />
              </div>
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s8-released-by">
                  <span className="text-red-600">*</span> Released By
                </label>
                <Input
                  id="s8-released-by"
                  className="stage-input"
                  placeholder="Releasing officer name"
                  value={releasedBy}
                  onChange={(e) => setReleasedBy(e.target.value)}
                  required
                />
              </div>
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s8-release-sig">
                  <span className="text-red-600">*</span> Customer / Collector Signature
                </label>
                <Input
                  id="s8-release-sig"
                  className="stage-input"
                  placeholder="Customer or collector signature"
                  value={releaseSignature}
                  onChange={(e) => setReleaseSignature(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="flex items-start gap-2.5 text-xs text-slate-500 mt-4">
              <Lock size={14} className="text-slate-400 shrink-0 mt-0.5" />
              <p>
                Completing vehicle release creates a permanent handover record and marks the repair
                order complete.
              </p>
            </div>

            {vehicle.released && inspection?.result === "Passed" && (
              <div className="mt-4 rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-900 flex items-center gap-2">
                <CheckCircle2 size={15} className="text-primary" />
                <span>
                  Vehicle <strong>{vehicle.plate}</strong> passed Final Inspection and has been
                  released to <strong>{collectedBy}</strong>.
                </span>
              </div>
            )}

            {!canRelease && qaResult !== "Rework required" && blockers.length > 0 && (
              <div className="mt-4 rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-900 flex items-start gap-2">
                <AlertCircle size={15} className="shrink-0 mt-0.5 text-primary" />
                <div>Remaining before release: {blockers.join(", ")}</div>
              </div>
            )}
          </div>

          <FormStepFooter
            onPrev={() => setActiveStep("fuel_mileage")}
            prevLabel="Previous: Fuel & Mileage Out"
            rightExtra={
              qaResult === "Rework required" ? (
                <Button type="button" variant="destructive" onClick={handleFlagRework}>
                  Flag Rework &amp; Return to Stage 7
                </Button>
              ) : (
                <Button type="submit" disabled={!canRelease} className="stage-primary-cta">
                  {vehicle.released
                    ? "Update Release Sign-Off"
                    : "Pass Inspection & Release Vehicle"}
                </Button>
              )
            }
          />
        </>
      )}
    </form>
  );
}
