import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Check, AlertCircle } from "../fa-icons";

export type FormStepItem<T extends string = string> = {
  id: T;
  stepNumber: number;
  title: string;
  done?: boolean;
};

type FormStepHeaderProps<T extends string> = {
  steps: readonly FormStepItem<T>[];
  activeStepId: T;
  onSelectStep: (stepId: T) => void;
  progressPercentage: number;
  ariaLabel: string;
};

export function FormStepHeader<T extends string>({
  steps,
  activeStepId,
  onSelectStep,
  progressPercentage,
  ariaLabel,
}: FormStepHeaderProps<T>) {
  const activeIndex = Math.max(
    0,
    steps.findIndex((s) => s.id === activeStepId),
  );
  const clampedPct = Math.min(100, Math.max(0, Math.round(progressPercentage)));

  return (
    <div className="rounded-xl border border-slate-200 bg-white px-4 py-4 shadow-xs">
      <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-100">
        <span className="text-xs font-semibold text-slate-600">
          Step {activeIndex + 1} of {steps.length}
        </span>
        <span className="text-xs font-bold text-primary tabular-nums">{clampedPct}% Complete</span>
      </div>

      {/* Clean Connected 1 — 2 — 3 Stepper (Solid Blue, No Gradients, No Dots) */}
      <div
        className="grid items-start"
        style={{ gridTemplateColumns: `repeat(${steps.length}, minmax(0, 1fr))` }}
        role="tablist"
        aria-label={ariaLabel}
      >
        {steps.map((step, idx) => {
          const isActive = step.id === activeStepId;
          const isCompleted = Boolean(step.done);
          const hasMissingInfo = !isCompleted;
          const leftFilled = idx <= activeIndex;
          const rightFilled = idx < activeIndex;

          return (
            <button
              key={step.id}
              type="button"
              role="tab"
              aria-selected={isActive}
              data-active={isActive}
              onClick={() => onSelectStep(step.id)}
              className="group relative flex flex-col items-center text-center px-1 cursor-pointer focus-visible:outline-none"
            >
              <div className="relative flex w-full items-center justify-center">
                {idx > 0 && (
                  <span
                    aria-hidden="true"
                    className={`absolute left-0 right-1/2 top-1/2 -translate-y-1/2 h-[2px] ${
                      leftFilled ? "bg-primary" : "bg-slate-200"
                    }`}
                  />
                )}
                {idx < steps.length - 1 && (
                  <span
                    aria-hidden="true"
                    className={`absolute left-1/2 right-0 top-1/2 -translate-y-1/2 h-[2px] ${
                      rightFilled ? "bg-primary" : "bg-slate-200"
                    }`}
                  />
                )}
                <span
                  aria-hidden="true"
                  className={`relative z-10 inline-flex h-8 w-8 items-center justify-center rounded-full border-2 text-xs font-bold transition-colors ${
                    isActive
                      ? "bg-primary text-primary-foreground border-primary"
                      : isCompleted
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-amber-50 text-amber-700 border-amber-400 group-hover:border-amber-500 group-hover:bg-amber-100"
                  }`}
                  title={hasMissingInfo ? "Missing required information" : undefined}
                >
                  {isCompleted && !isActive ? (
                    <Check size={13} />
                  ) : hasMissingInfo && !isActive ? (
                    <AlertCircle size={13} className="text-amber-600" />
                  ) : (
                    step.stepNumber
                  )}
                </span>
              </div>

              <span
                className={`mt-2 text-xs leading-tight max-w-[140px] flex items-center justify-center gap-1 ${
                  isActive
                    ? "font-bold text-slate-900"
                    : isCompleted
                      ? "font-semibold text-primary"
                      : "font-medium text-amber-700 group-hover:text-amber-900"
                }`}
                title={hasMissingInfo ? "Missing required information" : undefined}
              >
                {step.title}
                {hasMissingInfo && !isActive && (
                  <span
                    className="inline-block h-1.5 w-1.5 rounded-full bg-amber-500 shrink-0"
                    aria-label="Missing required information"
                  />
                )}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

type FormStepFooterProps = {
  onPrev?: (() => void) | undefined;
  prevLabel?: string | undefined;
  onNext?: (() => void) | undefined;
  nextLabel?: string | undefined;
  statusHint?: string | undefined;
  leftExtra?: ReactNode;
  rightExtra?: ReactNode;
};

export function FormStepFooter({
  onPrev,
  prevLabel = "Previous",
  onNext,
  nextLabel = "Next Step",
  statusHint,
  leftExtra,
  rightExtra,
}: FormStepFooterProps) {
  return (
    <div className="stage-cta-bar">
      <div className="flex items-center gap-2 flex-wrap">
        {onPrev && (
          <Button type="button" variant="outline" onClick={onPrev}>
            <ArrowLeft size={14} />
            {prevLabel}
          </Button>
        )}
        {leftExtra}
      </div>
      <div className="flex items-center gap-2.5 flex-wrap ml-auto">
        {statusHint && (
          <span className="text-xs text-slate-500 hidden sm:inline">{statusHint}</span>
        )}
        {rightExtra}
        {onNext && (
          <Button type="button" className="stage-primary-cta" onClick={onNext}>
            {nextLabel}
            <ArrowRight size={14} />
          </Button>
        )}
      </div>
    </div>
  );
}
