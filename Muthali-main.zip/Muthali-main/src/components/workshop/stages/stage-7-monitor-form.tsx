import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { AlertCircle, CheckCircle2, Lock } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import {
  appendJobCardAuditUpdate,
  type DepartmentProgressItem,
  type DepartmentWorkStatus,
  type Inspection,
  type JobCard,
  type Vehicle,
} from "@/lib/workshop";
import {
  areStage7DepartmentsComplete,
  calculateStagnationSummary,
  calculateStepWizardPercentage,
  evaluateJobStageReadiness,
  WORK_STATUS_OPTIONS,
  type JobStageReadinessReport,
} from "@/lib/workshop-flow";
import { FormStepFooter, FormStepHeader, type FormStepItem } from "./form-step-wizard";

type Stage7MonitorFormProps = {
  vehicle: Vehicle;
  job?: JobCard | undefined;
  readiness: JobStageReadinessReport;
  bannerExtra?: ReactNode;
  onBack?: () => void;
  onSubmitted?: (inspection: Inspection) => void;
};

type MonitorStepId = "departments" | "summary" | "signoff";

export function Stage7MonitorForm({ vehicle, job, onBack, onSubmitted }: Stage7MonitorFormProps) {
  const {
    quotations,
    requisitions,
    dispatches,
    inspections,
    setInspections,
    setJobs,
    setVehicles,
    foreman,
    addActivity,
  } = useWorkspace();

  const todayIso = new Date().toISOString().slice(0, 10);
  const quotation = quotations.find((q) => q.vehicleId === vehicle.id);

  const [activeStep, setActiveStep] = useState<MonitorStepId>("departments");
  const [workCompletedSummary, setWorkCompletedSummary] = useState(
    job?.stagnationMeta?.workCompletedSummary ?? "",
  );
  const [mechanicRemarks, setMechanicRemarks] = useState(
    job?.stagnationMeta?.mechanicRemarks ?? "",
  );
  const [completionDate, setCompletionDate] = useState(
    job?.stagnationMeta?.completionDate ?? todayIso,
  );
  const [foremanVerified, setForemanVerified] = useState(
    job?.stagnationMeta?.foremanVerified ?? false,
  );
  const [foremanName, setForemanName] = useState(
    job?.stagnationMeta?.foremanVerifiedBy ?? job?.preparedBy ?? "",
  );

  useEffect(() => {
    setActiveStep("departments");
  }, [vehicle.id]);

  useEffect(() => {
    setWorkCompletedSummary(job?.stagnationMeta?.workCompletedSummary ?? "");
    setMechanicRemarks(job?.stagnationMeta?.mechanicRemarks ?? "");
    setCompletionDate(job?.stagnationMeta?.completionDate ?? todayIso);
    setForemanVerified(job?.stagnationMeta?.foremanVerified ?? false);
    setForemanName(job?.stagnationMeta?.foremanVerifiedBy ?? job?.preparedBy ?? "");
  }, [job, todayIso]);

  const departmentRows = useMemo<DepartmentProgressItem[]>(() => {
    if (job?.departmentProgress && job.departmentProgress.length > 0) {
      return job.departmentProgress;
    }
    const depts =
      job?.routedDepartments && job.routedDepartments.length > 0
        ? job.routedDepartments
        : [job?.department && job.department !== "Unassigned" ? job.department : "Mechanical"];
    return depts.map((dept) => ({
      department: dept,
      assignedMechanic: job?.assignedEmployee || "",
      status: "Not Started" as const,
      updatedAtMs: Date.now(),
    }));
  }, [job]);

  const liveReadiness = useMemo(
    () =>
      evaluateJobStageReadiness({
        vehicle,
        quotation,
        job,
        requisitions,
        dispatches,
        foremanVerified,
        workCompletedSummary,
        completionDate,
      }),
    [
      vehicle,
      quotation,
      job,
      requisitions,
      dispatches,
      foremanVerified,
      workCompletedSummary,
      completionDate,
    ],
  );

  const stagnation = useMemo(() => calculateStagnationSummary(job), [job]);

  const step1Done = areStage7DepartmentsComplete(job);
  const step2Done = workCompletedSummary.trim().length > 0;
  const step3Done = liveReadiness.canSubmitFinalInspection;

  const steps: readonly FormStepItem<MonitorStepId>[] = [
    { id: "departments", stepNumber: 1, title: "Department Progress", done: step1Done },
    { id: "summary", stepNumber: 2, title: "Work Summary & Notes", done: step2Done },
    { id: "signoff", stepNumber: 3, title: "Gate Check & Sign-Off", done: step3Done },
  ];

  const activeIdx = activeStep === "departments" ? 0 : activeStep === "summary" ? 1 : 2;
  const progressPercentage = calculateStepWizardPercentage(activeIdx, 3, [
    step1Done,
    step2Done,
    step3Done,
  ]);

  function handleDepartmentStatusChange(deptName: string, patch: Partial<DepartmentProgressItem>) {
    if (!job) {
      toast.error("Create Stage 4 Job Card before updating department progress.");
      return;
    }
    const nowMs = Date.now();
    const updatedProgress = departmentRows.map((row) =>
      row.department === deptName ? { ...row, ...patch, updatedAtMs: nowMs } : row,
    );
    const allCompleted = updatedProgress.every((row) => row.status === "Completed");
    const anyWaiting = updatedProgress.some((row) => row.status === "Waiting for Parts");
    const anyInProgress = updatedProgress.some((row) => row.status === "In Progress");
    const completedCount = updatedProgress.filter((row) => row.status === "Completed").length;
    const progressPct = Math.round((completedCount / Math.max(1, updatedProgress.length)) * 100);

    const nextOverallStatus = allCompleted
      ? "Completed"
      : anyWaiting
        ? "Awaiting parts"
        : anyInProgress
          ? "In progress"
          : "Pending";

    const resolvedEmployee =
      patch.assignedMechanic ??
      updatedProgress.find((d) => d.department === deptName)?.assignedMechanic;
    const resolvedNote = patch.status
      ? `${deptName} status updated to ${patch.status}`
      : patch.notes?.trim() || undefined;

    const updatedWithAudit = appendJobCardAuditUpdate(
      {
        ...job,
        departmentProgress: updatedProgress,
        progress: progressPct,
      },
      {
        status: nextOverallStatus,
        department: deptName,
        ...(resolvedEmployee ? { assignedEmployee: resolvedEmployee } : {}),
        progress: progressPct,
        ...(resolvedNote ? { note: resolvedNote } : {}),
        actor: foremanName || foreman,
        actorRole: "Foreman",
      },
    );

    setJobs((prev) => prev.map((item) => (item.id === job.id ? updatedWithAudit : item)));
    setVehicles((prev) =>
      prev.map((v) => (v.id === vehicle.id ? { ...v, progress: progressPct } : v)),
    );
  }

  function toggleSupervisorAttention(flagged: boolean) {
    if (!job) return;
    setJobs((prev) =>
      prev.map((item) =>
        item.id === job.id
          ? {
              ...item,
              stagnationMeta: {
                ...item.stagnationMeta,
                awaitingSupervisorAttention: flagged,
              },
            }
          : item,
      ),
    );
  }

  function handleNextStep() {
    if (activeStep === "departments") {
      setActiveStep("summary");
      return;
    }
    if (activeStep === "summary") {
      if (!step2Done) {
        toast.error("Enter a Work Completed Summary before Foreman Sign-Off.");
        return;
      }
      setActiveStep("signoff");
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!liveReadiness.canSubmitFinalInspection || !job) {
      toast.error(
        liveReadiness.blockingReasons[0] ??
          "Complete Stages 1 through 6 and verify all department work before Final Inspection.",
      );
      return;
    }

    const updatedJob: JobCard = {
      ...job,
      status: "Completed",
      progress: 100,
      stagnationMeta: {
        ...job.stagnationMeta,
        workCompletedSummary: workCompletedSummary.trim(),
        mechanicRemarks: mechanicRemarks.trim(),
        foremanVerified: true,
        foremanVerifiedBy: foremanName.trim() || foreman,
        completionDate,
      },
    };

    setJobs((prev) => prev.map((item) => (item.id === job.id ? updatedJob : item)));

    const existingInspection = inspections.find((ins) => ins.vehicleId === vehicle.id);
    const maxInsNum = inspections.reduce((max, ins) => {
      const m = ins.id.match(/^INS-(\d+)$/);
      return m ? Math.max(max, Number(m[1])) : max;
    }, 300);

    const inspectorDisplay = foremanName.trim() || foreman;
    const nextInspection: Inspection = {
      id: existingInspection?.id ?? `INS-${maxInsNum + 1}`,
      vehicleId: vehicle.id,
      jobId: job.id,
      plate: vehicle.plate,
      foreman: inspectorDisplay,
      inspector: inspectorDisplay,
      date: completionDate,
      result: "Pending",
      notes: `${workCompletedSummary.trim()}${mechanicRemarks.trim() ? ` / Remarks: ${mechanicRemarks.trim()}` : ""}`,
    };

    setInspections((prev) => {
      const exists = prev.some((ins) => ins.vehicleId === vehicle.id);
      if (exists) {
        return prev.map((ins) => (ins.vehicleId === vehicle.id ? nextInspection : ins));
      }
      return [nextInspection, ...prev];
    });

    setVehicles((prev) =>
      prev.map((v) =>
        v.id === vehicle.id ? { ...v, progress: 100, stage: Math.max(v.stage, 10) } : v,
      ),
    );

    addActivity(
      `Stage 7 Submitted for Final Inspection (${nextInspection.id})`,
      `${vehicle.plate} / Verified by ${foremanName.trim() || foreman}`,
    );
    toast.success(`${vehicle.plate} submitted for Final Inspection (${nextInspection.id}).`);
    onSubmitted?.(nextInspection);
  }

  const stageChecklist = [
    liveReadiness.stages[1],
    liveReadiness.stages[2],
    liveReadiness.stages[3],
    liveReadiness.stages[4],
    liveReadiness.stages[5],
    liveReadiness.stages[6],
  ];

  const existingInspection = inspections.find((ins) => ins.vehicleId === vehicle.id);

  return (
    <form onSubmit={handleSubmit} noValidate className="stage-form-stack">
      <FormStepHeader
        steps={steps}
        activeStepId={activeStep}
        onSelectStep={setActiveStep}
        progressPercentage={progressPercentage}
        ariaLabel="Stage 7 Workshop Monitor Sections"
      />

      {activeStep === "departments" && (
        <>
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Department Work Progress</h3>
                <p className="stage-card-subtitle">
                  Job {job?.id ?? "-"} / Time in bay: {stagnation.hoursInDepartment} hrs /{" "}
                  <span
                    className={
                      stagnation.isOverdue
                        ? "text-red-700 font-semibold"
                        : "text-emerald-700 font-semibold"
                    }
                  >
                    {stagnation.isOverdue ? "Exceeded Due Time" : "Within Schedule"}
                  </span>
                </p>
              </div>
              <label className="flex items-center gap-2 text-xs font-medium cursor-pointer text-slate-700">
                <input
                  type="checkbox"
                  checked={Boolean(job?.stagnationMeta?.awaitingSupervisorAttention)}
                  onChange={(e) => toggleSupervisorAttention(e.target.checked)}
                  className="accent-primary h-4 w-4"
                />
                <span>Flag awaiting supervisor attention</span>
              </label>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b bg-slate-50 text-slate-600">
                    <th className="py-2.5 px-2 font-semibold">Department</th>
                    <th className="py-2.5 px-2 font-semibold">Assigned Mechanic</th>
                    <th className="py-2.5 px-2 font-semibold w-44">Work Status</th>
                    <th className="py-2.5 px-2 font-semibold w-52">Quick Actions</th>
                    <th className="py-2.5 px-2 font-semibold">Department Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {departmentRows.map((row) => (
                    <tr key={row.department}>
                      <td className="py-2 px-2 font-semibold text-slate-900">{row.department}</td>
                      <td className="py-1.5 px-2">
                        <Input
                          className="h-9 text-xs border-slate-300"
                          aria-label={`${row.department} assigned mechanic`}
                          placeholder="Mechanic Name"
                          value={row.assignedMechanic}
                          onChange={(e) =>
                            handleDepartmentStatusChange(row.department, {
                              assignedMechanic: e.target.value,
                            })
                          }
                        />
                      </td>
                      <td className="py-1.5 px-2">
                        <Select
                          value={row.status}
                          onValueChange={(value) =>
                            handleDepartmentStatusChange(row.department, {
                              status: value as DepartmentWorkStatus,
                            })
                          }
                        >
                          <SelectTrigger
                            className="h-9 text-xs border-slate-300"
                            aria-label={`${row.department} work status`}
                          >
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {WORK_STATUS_OPTIONS.map((st) => (
                              <SelectItem key={st} value={st}>
                                {st}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="py-1.5 px-2">
                        <div className="flex items-center gap-1">
                          <Button
                            type="button"
                            size="sm"
                            variant={row.status === "In Progress" ? "default" : "outline"}
                            className="h-7 px-2 text-[11px]"
                            onClick={() =>
                              handleDepartmentStatusChange(row.department, {
                                status: "In Progress",
                              })
                            }
                          >
                            Start
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant={row.status === "Waiting for Parts" ? "default" : "outline"}
                            className="h-7 px-2 text-[11px]"
                            onClick={() =>
                              handleDepartmentStatusChange(row.department, {
                                status: "Waiting for Parts",
                              })
                            }
                          >
                            Parts Hold
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant={row.status === "Completed" ? "default" : "outline"}
                            className="h-7 px-2 text-[11px]"
                            onClick={() =>
                              handleDepartmentStatusChange(row.department, { status: "Completed" })
                            }
                          >
                            Done
                          </Button>
                        </div>
                      </td>
                      <td className="py-1.5 px-2">
                        <Input
                          className="h-9 text-xs border-slate-300"
                          aria-label={`${row.department} notes`}
                          placeholder="Mechanic bay notes"
                          value={row.notes ?? ""}
                          onChange={(e) =>
                            handleDepartmentStatusChange(row.department, { notes: e.target.value })
                          }
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {stagnation.alerts.length > 0 && (
              <div className="mt-4 rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-900 space-y-1">
                {stagnation.alerts.map((alertText) => (
                  <div key={alertText} className="flex items-center gap-1.5">
                    <AlertCircle size={13} className="text-primary" />
                    <span>{alertText}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <FormStepFooter
            leftExtra={
              onBack && (
                <Button type="button" variant="outline" onClick={onBack}>
                  &larr; Back to Stage 6
                </Button>
              )
            }
            statusHint={
              step1Done ? "All routed bays marked Completed" : "Mark bays Done when work finishes"
            }
            onNext={handleNextStep}
            nextLabel="Next: Work Summary & Notes"
          />
        </>
      )}

      {activeStep === "summary" && (
        <>
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Work Summary &amp; Mechanic Notes</h3>
                <p className="stage-card-subtitle">
                  Document all repairs completed and road-test findings before Foreman sign-off
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s7-work-summary">
                  <span className="text-red-600">*</span> Work Completed Summary
                </label>
                <Textarea
                  id="s7-work-summary"
                  className="stage-textarea"
                  placeholder="Summarize all repairs completed and road-test results"
                  value={workCompletedSummary}
                  onChange={(e) => setWorkCompletedSummary(e.target.value)}
                  required
                />
              </div>

              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s7-mechanic-remarks">
                  Mechanic Remarks
                </label>
                <Input
                  id="s7-mechanic-remarks"
                  className="stage-input"
                  placeholder="Optional technician notes or follow-up recommendations"
                  value={mechanicRemarks}
                  onChange={(e) => setMechanicRemarks(e.target.value)}
                />
              </div>
            </div>
          </div>

          <FormStepFooter
            onPrev={() => setActiveStep("departments")}
            prevLabel="Previous: Department Progress"
            statusHint={step2Done ? "Work summary entered" : "Enter work completed summary"}
            onNext={handleNextStep}
            nextLabel="Next: Gate Check & Sign-Off"
          />
        </>
      )}

      {activeStep === "signoff" && (
        <>
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Gate Check &amp; Foreman Sign-Off</h3>
                <p className="stage-card-subtitle">
                  Confirm Stages 1–6 completion gate and submit vehicle for Final Inspection
                </p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Compact Stages 1–6 Completion Gate Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {stageChecklist.map((entry) => (
                  <div
                    key={entry.stageNumber}
                    className={`flex items-center justify-between rounded-md border px-2.5 py-1.5 ${
                      entry.complete
                        ? "border-blue-200 bg-blue-50 text-blue-900"
                        : "border-slate-200 bg-slate-50 text-slate-700"
                    }`}
                  >
                    <span className="font-medium truncate">
                      {entry.stageNumber}. {entry.label}
                    </span>
                    <span className="inline-flex items-center gap-1 font-semibold shrink-0 ml-2">
                      {entry.complete ? (
                        <>
                          <CheckCircle2 size={12} className="text-primary" />
                          Done
                        </>
                      ) : (
                        <>
                          <Lock size={11} />
                          Pending
                        </>
                      )}
                    </span>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s7-completion-date">
                    <span className="text-red-600">*</span> Completion Date
                  </label>
                  <Input
                    id="s7-completion-date"
                    type="date"
                    className="stage-input"
                    value={completionDate}
                    onChange={(e) => setCompletionDate(e.target.value)}
                    required
                  />
                </div>
                <div className="stage-field">
                  <label className="stage-field-label" htmlFor="s7-foreman-name">
                    Foreman Verification By
                  </label>
                  <Input
                    id="s7-foreman-name"
                    className="stage-input"
                    placeholder="Foreman / verifier name"
                    value={foremanName}
                    onChange={(e) => setForemanName(e.target.value)}
                  />
                </div>
              </div>

              <label className="flex items-start gap-2.5 text-xs font-semibold cursor-pointer text-slate-800 pt-1">
                <input
                  type="checkbox"
                  checked={foremanVerified}
                  onChange={(e) => setForemanVerified(e.target.checked)}
                  className="accent-primary mt-0.5 h-4 w-4"
                />
                <span>
                  Foreman Verification: I confirm Stages 1–6 records and all department repairs are
                  complete. <span className="text-red-600">*</span>
                </span>
              </label>

              {existingInspection && (
                <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-900">
                  Final Inspection record created: <strong>{existingInspection.id}</strong> (
                  {existingInspection.result})
                </div>
              )}

              {liveReadiness.blockingReasons.length > 0 &&
                !liveReadiness.canSubmitFinalInspection && (
                  <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-xs text-blue-900 space-y-1">
                    {liveReadiness.blockingReasons.map((reason) => (
                      <div key={reason}>{reason}</div>
                    ))}
                  </div>
                )}
            </div>
          </div>

          <FormStepFooter
            onPrev={() => setActiveStep("summary")}
            prevLabel="Previous: Work Summary & Notes"
            rightExtra={
              <Button
                type="submit"
                disabled={!liveReadiness.canSubmitFinalInspection}
                title={
                  !liveReadiness.canSubmitFinalInspection
                    ? (liveReadiness.blockingReasons[0] ??
                      "Complete Stages 1 through 6 and Foreman verification first.")
                    : "Submit vehicle for Final Inspection"
                }
                className="stage-primary-cta"
              >
                Submit for Final Inspection
              </Button>
            }
          />
        </>
      )}
    </form>
  );
}
