import type { JobCardStageProgressSummary } from "@/lib/workshop-flow";

type JobCardStageProgressBarProps = {
  progress: JobCardStageProgressSummary;
  variant?: "default" | "compact";
  viewedStageNumber?: number;
  onSelectStage?: (stageIndex: number) => void;
  className?: string;
};

export function JobCardStageProgressBar({
  progress,
  variant = "default",
  viewedStageNumber,
  onSelectStage,
  className = "",
}: JobCardStageProgressBarProps) {
  const clampedPct = Math.min(100, Math.max(0, Math.round(progress.percentage)));

  if (variant === "compact") {
    return (
      <div
        className={`min-w-[138px] ${className}`.trim()}
        data-testid="job-card-stage-progress-compact"
      >
        <div className="flex items-center justify-between gap-2 text-[11px] leading-tight mb-1 tabular-nums">
          <span className="font-semibold text-slate-700 truncate">
            Stage {progress.currentStageNumber}/8: {progress.currentStageLabel}
          </span>
          <span className="font-bold text-primary shrink-0">{clampedPct}%</span>
        </div>
        <div
          className="grid grid-cols-8 gap-0.5 h-2 w-full rounded bg-blue-50 p-0.5 border border-blue-200"
          role="progressbar"
          aria-label={`${progress.jobRef} stage progress: Stage ${progress.currentStageNumber} of 8 (${progress.currentStageLabel})`}
          aria-valuenow={clampedPct}
          aria-valuemin={0}
          aria-valuemax={100}
        >
          {progress.segments.map((seg) => {
            const bgClass =
              seg.state === "completed"
                ? "bg-primary"
                : seg.state === "current"
                  ? "bg-blue-400"
                  : seg.state === "unlocked"
                    ? "bg-blue-200"
                    : "bg-slate-200";
            return (
              <span
                key={seg.stageNumber}
                title={`Stage ${seg.stageNumber}: ${seg.shortLabel} (${seg.state})`}
                className={`h-full rounded-[2px] transition-colors ${bgClass}`}
              />
            );
          })}
        </div>
      </div>
    );
  }

  const isViewingDifferentStage =
    typeof viewedStageNumber === "number" && viewedStageNumber !== progress.currentStageNumber;

  return (
    <div
      className={`rounded-lg border border-blue-200 bg-blue-50 px-3 py-2.5 ${className}`.trim()}
      data-testid="job-card-stage-progress-bar"
    >
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2 text-xs">
        <div className="flex flex-wrap items-center gap-2 min-w-0">
          <span className="inline-flex items-center px-2 py-0.5 rounded bg-primary text-primary-foreground text-[11px] font-bold shrink-0">
            {progress.jobRef}
          </span>
          <span className="font-semibold text-slate-900 truncate">
            Current Stage {progress.currentStageNumber} of {progress.totalStages}:{" "}
            <span className="text-primary">{progress.currentStageLabel}</span>
          </span>
          {isViewingDifferentStage && (
            <span className="inline-flex items-center px-1.5 py-0.5 rounded border border-blue-300 bg-white text-[11px] font-medium text-blue-900">
              Viewing Stage {viewedStageNumber}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2.5 tabular-nums shrink-0">
          <span className="text-[11px] font-medium text-slate-600">
            {progress.completedStages} of {progress.totalStages} stages done
          </span>
          <span className="font-bold text-primary">{clampedPct}%</span>
        </div>
      </div>

      {/* 8-Stage Segmented Solid-Blue Progress Bar */}
      <div
        className="grid grid-cols-8 gap-1.5"
        role="progressbar"
        aria-label="Workshop job card stage progress"
        aria-valuenow={clampedPct}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        {progress.segments.map((seg) => {
          const isViewed = viewedStageNumber === seg.stageNumber;
          const barClass =
            seg.state === "completed"
              ? "bg-primary border-primary"
              : seg.state === "current"
                ? "bg-blue-400 border-primary"
                : seg.state === "unlocked"
                  ? "bg-blue-200 border-blue-300"
                  : "bg-white border-blue-200";

          const interactive = Boolean(onSelectStage && seg.unlocked);

          return (
            <button
              key={seg.stageNumber}
              type="button"
              disabled={!interactive}
              onClick={() => interactive && onSelectStage?.(seg.stageNumber - 1)}
              title={`Stage ${seg.stageNumber}: ${seg.shortLabel} (${seg.state})`}
              aria-label={`Stage ${seg.stageNumber} ${seg.shortLabel}: ${seg.state}`}
              className={`group flex flex-col gap-1 text-left ${
                interactive ? "cursor-pointer" : "cursor-default"
              }`}
            >
              <span
                className={`block h-2.5 w-full rounded-sm border transition-all ${barClass} ${
                  isViewed ? "ring-2 ring-primary ring-offset-1 ring-offset-blue-50" : ""
                }`}
              />
              <span
                className={`hidden sm:block text-[10px] leading-none truncate ${
                  seg.state === "completed" || seg.state === "current"
                    ? "font-semibold text-blue-950"
                    : "font-medium text-slate-500"
                }`}
              >
                {seg.stageNumber}. {seg.shortLabel}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
