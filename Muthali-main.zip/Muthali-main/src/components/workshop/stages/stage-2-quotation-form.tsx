import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Save, Trash2 } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import { money, type JobCard, type Quotation, type Vehicle } from "@/lib/workshop";
import {
  calculateQuotationTotals,
  calculateStepWizardPercentage,
  QUOTATION_SERVICE_PRESETS,
} from "@/lib/workshop-flow";
import { FormStepFooter, FormStepHeader, type FormStepItem } from "./form-step-wizard";

type QuotationLineDraft = {
  id: string;
  itemType: "PART" | "LABOUR" | "SERVICE" | "OTHER";
  item: string;
  description: string;
  quantity: number;
  unitPrice: number;
};

type Stage2QuotationFormProps = {
  vehicle: Vehicle;
  quotation?: Quotation | undefined;
  job?: JobCard | undefined;
  bannerExtra?: ReactNode;
  onSaved?: (quotation: Quotation, advanceToAuthorization: boolean) => void;
  onBack?: () => void;
};

type QuotationStepId = "details" | "items" | "review";

export function Stage2QuotationForm({
  vehicle,
  quotation,
  job,
  onSaved,
  onBack,
}: Stage2QuotationFormProps) {
  const { quotations, setQuotations, updateVehicleStage, addActivity } = useWorkspace();

  const todayIso = new Date().toISOString().slice(0, 10);
  const nextQuotationNumber = useMemo(() => {
    if (quotation?.id) return quotation.id;
    const maxNum = quotations.reduce((max, item) => {
      const m = item.id.match(/^QT-(\d+)$/);
      return m ? Math.max(max, Number(m[1])) : max;
    }, 1020);
    return `QT-${maxNum + 1}`;
  }, [quotation?.id, quotations]);

  const [activeStep, setActiveStep] = useState<QuotationStepId>("details");
  const [quotationNumber, setQuotationNumber] = useState(nextQuotationNumber);
  const [quotationDate, setQuotationDate] = useState(quotation?.quotationDate ?? todayIso);
  const [salesperson, setSalesperson] = useState(quotation?.paperFields?.["salesperson"] ?? "");
  const [preparedBy, setPreparedBy] = useState(quotation?.preparedByName ?? "");
  const [signature, setSignature] = useState(quotation?.paperFields?.["signature"] ?? "");

  const [items, setItems] = useState<QuotationLineDraft[]>(() => {
    if (quotation?.items && quotation.items.length > 0) {
      return quotation.items.map((line, index) => ({
        id: `qline-${index}`,
        itemType: line.itemType,
        item: line.item,
        description: line.description,
        quantity: line.quantity,
        unitPrice: line.unitPrice,
      }));
    }
    return [];
  });

  useEffect(() => {
    setActiveStep("details");
  }, [vehicle.id]);

  useEffect(() => {
    setQuotationNumber(nextQuotationNumber);
    setQuotationDate(quotation?.quotationDate ?? todayIso);
    setSalesperson(quotation?.paperFields?.["salesperson"] ?? "");
    setPreparedBy(quotation?.preparedByName ?? "");
    setSignature(quotation?.paperFields?.["signature"] ?? "");
    if (quotation?.items && quotation.items.length > 0) {
      setItems(
        quotation.items.map((line, index) => ({
          id: `qline-${index}`,
          itemType: line.itemType,
          item: line.item,
          description: line.description,
          quantity: line.quantity,
          unitPrice: line.unitPrice,
        })),
      );
    } else {
      setItems([]);
    }
  }, [quotation, nextQuotationNumber, todayIso]);

  const totals = useMemo(() => calculateQuotationTotals(items), [items]);

  const step1Done =
    quotationNumber.trim().length > 0 &&
    quotationDate.trim().length > 0 &&
    preparedBy.trim().length > 0 &&
    signature.trim().length > 0;

  const validItems = useMemo(
    () =>
      items.filter((line) => (line.item.trim() || line.description.trim()) && line.quantity > 0),
    [items],
  );
  const step2Done = validItems.length > 0 && totals.total > 0;
  const step3Done = step1Done && step2Done;

  const steps: readonly FormStepItem<QuotationStepId>[] = [
    { id: "details", stepNumber: 1, title: "Quotation Details", done: step1Done },
    { id: "items", stepNumber: 2, title: "Parts & Labour Items", done: step2Done },
    { id: "review", stepNumber: 3, title: "Totals Review & Issue", done: step3Done },
  ];

  const activeIdx = activeStep === "details" ? 0 : activeStep === "items" ? 1 : 2;
  const progressPercentage = calculateStepWizardPercentage(activeIdx, 3, [
    step1Done,
    step2Done,
    step3Done,
  ]);

  function addRow() {
    setItems((prev) => [
      ...prev,
      {
        id: `qline-${Date.now()}-${prev.length}`,
        itemType: "PART",
        item: "",
        description: "",
        quantity: 1,
        unitPrice: 0,
      },
    ]);
  }

  function removeRow(id: string) {
    if (items.length <= 1) {
      toast.error("At least one quotation line item is required.");
      return;
    }
    setItems((prev) => prev.filter((row) => row.id !== id));
  }

  function updateRow(id: string, patch: Partial<QuotationLineDraft>) {
    setItems((prev) => prev.map((row) => (row.id === id ? { ...row, ...patch } : row)));
  }

  function applyPreset(presetId: string) {
    const preset = QUOTATION_SERVICE_PRESETS.find((item) => item.id === presetId);
    if (!preset) return;
    setItems(
      preset.items.map((line, index) => ({
        ...line,
        id: `qline-preset-${Date.now()}-${index}`,
      })),
    );
    toast.success(`Applied "${preset.label}" quotation template.`);
  }

  function saveQuotation(issueAndProceed: boolean) {
    if (validItems.length === 0) {
      setActiveStep("items");
      toast.error("Add at least one quotation item with quantity greater than 0.");
      return;
    }
    if (issueAndProceed && totals.total <= 0) {
      setActiveStep("items");
      toast.error("Quotation total amount must be greater than zero before issuing.");
      return;
    }
    if (issueAndProceed && (!preparedBy.trim() || !signature.trim())) {
      setActiveStep("details");
      toast.error("Prepared by and signature are required to issue the quotation.");
      return;
    }

    const mappedItems = validItems.map((line) => ({
      itemType: line.itemType,
      item: line.item.trim() || line.description.trim(),
      description: line.description.trim() || line.item.trim(),
      quantity: Number(line.quantity),
      unitPrice: Number(line.unitPrice),
      lineTotal: Number(line.quantity) * Number(line.unitPrice),
    }));

    const nextStatus: Quotation["status"] =
      quotation?.status === "Approved"
        ? "Approved"
        : issueAndProceed
          ? "Awaiting approval"
          : "Draft";

    const savedQuotation: Quotation = {
      ...(quotation ?? {
        id: quotationNumber.trim() || nextQuotationNumber,
        vehicleId: vehicle.id,
        description: vehicle.complaints || "Workshop repair quotation",
        amount: totals.total,
        status: nextStatus,
      }),
      id: quotationNumber.trim() || nextQuotationNumber,
      vehicleId: vehicle.id,
      amount: totals.total,
      subtotal: totals.subtotal,
      taxAmount: totals.vat,
      quotationDate,
      preparedByName: preparedBy.trim(),
      description:
        mappedItems.map((i) => `${i.item} (${i.quantity})`).join(", ") || vehicle.complaints,
      status: nextStatus,
      items: mappedItems,
      paperFields: {
        salesperson: salesperson.trim(),
        signature: signature.trim(),
        jobNumber: job?.id ?? vehicle.id,
      },
    };

    setQuotations((prev) => {
      const exists = prev.some(
        (q) => q.id === savedQuotation.id || q.vehicleId === savedQuotation.vehicleId,
      );
      if (exists) {
        return prev.map((q) =>
          q.id === savedQuotation.id || q.vehicleId === savedQuotation.vehicleId
            ? savedQuotation
            : q,
        );
      }
      return [savedQuotation, ...prev];
    });

    if (issueAndProceed) {
      updateVehicleStage(vehicle.id, 2);
      addActivity(
        `Quotation ${savedQuotation.id} issued (${money(totals.total)})`,
        `${vehicle.plate} / Sent to Stage 3 Customer Authorization`,
      );
      toast.success(`Quotation ${savedQuotation.id} issued. Proceeding to Customer Authorization.`);
    } else {
      toast.success(`Quotation draft ${savedQuotation.id} saved.`);
    }

    onSaved?.(savedQuotation, issueAndProceed);
  }

  function handleNextStep() {
    if (activeStep === "details") {
      if (!step1Done) {
        toast.error("Please enter Quotation Number, Date, Prepared By, and Officer Signature.");
        return;
      }
      setActiveStep("items");
      return;
    }
    if (activeStep === "items") {
      if (!step2Done) {
        toast.error(
          "Add at least one item with a quantity and price above zero before reviewing totals.",
        );
        return;
      }
      setActiveStep("review");
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    saveQuotation(true);
  }

  const missingSummary: string[] = [];
  if (!preparedBy.trim()) missingSummary.push("Prepared By");
  if (!signature.trim()) missingSummary.push("Officer Signature");
  if (validItems.length === 0) missingSummary.push("At least 1 quotation item");
  if (validItems.length > 0 && totals.total <= 0) missingSummary.push("Unit price above zero");

  return (
    <form onSubmit={handleSubmit} noValidate className="stage-form-stack">
      <FormStepHeader
        steps={steps}
        activeStepId={activeStep}
        onSelectStep={setActiveStep}
        progressPercentage={progressPercentage}
        ariaLabel="Stage 2 Quotation Sections"
      />

      {activeStep === "details" && (
        <>
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Quotation Details</h3>
                <p className="stage-card-subtitle">
                  Reference details for {vehicle.customer} / {vehicle.plate} ({vehicle.make})
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s2-quote-no">
                  <span className="text-red-600">*</span> Quotation Number
                </label>
                <Input
                  id="s2-quote-no"
                  className="stage-input font-mono"
                  placeholder="QT-1021"
                  value={quotationNumber}
                  onChange={(e) => setQuotationNumber(e.target.value)}
                  required
                />
              </div>
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s2-quote-date">
                  <span className="text-red-600">*</span> Date
                </label>
                <Input
                  id="s2-quote-date"
                  type="date"
                  className="stage-input"
                  value={quotationDate}
                  onChange={(e) => setQuotationDate(e.target.value)}
                  required
                />
              </div>
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s2-salesperson">
                  Salesperson
                </label>
                <Input
                  id="s2-salesperson"
                  className="stage-input"
                  placeholder="Salesperson Name"
                  value={salesperson}
                  onChange={(e) => setSalesperson(e.target.value)}
                />
              </div>
              <div className="stage-field">
                <label className="stage-field-label" htmlFor="s2-prepared-by">
                  <span className="text-red-600">*</span> Prepared By
                </label>
                <Input
                  id="s2-prepared-by"
                  className="stage-input"
                  placeholder="Prepared By Name"
                  value={preparedBy}
                  onChange={(e) => setPreparedBy(e.target.value)}
                  required
                />
              </div>
              <div className="stage-field sm:col-span-2">
                <label className="stage-field-label" htmlFor="s2-signature">
                  <span className="text-red-600">*</span> Officer Signature
                </label>
                <Input
                  id="s2-signature"
                  className="stage-input"
                  placeholder="Officer Signature"
                  value={signature}
                  onChange={(e) => setSignature(e.target.value)}
                  required
                />
              </div>
            </div>
          </div>

          <FormStepFooter
            leftExtra={
              onBack && (
                <Button type="button" variant="outline" onClick={onBack}>
                  &larr; Back to Stage 1
                </Button>
              )
            }
            statusHint={step1Done ? "Quotation details ready" : "Fill Prepared By & Signature"}
            onNext={handleNextStep}
            nextLabel="Next: Parts & Labour Items"
          />
        </>
      )}

      {activeStep === "items" && (
        <>
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Parts &amp; Labour Items</h3>
                <p className="stage-card-subtitle">
                  Choose a quick template or add custom parts and labour rows
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                {QUOTATION_SERVICE_PRESETS.map((preset) => (
                  <Button
                    key={preset.id}
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={() => applyPreset(preset.id)}
                  >
                    {preset.label}
                  </Button>
                ))}
                <Button type="button" size="sm" variant="outline" onClick={addRow}>
                  <Plus size={14} />
                  Add Item
                </Button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b bg-slate-50 text-slate-600">
                    <th className="py-2.5 px-1.5 font-semibold w-7">#</th>
                    <th className="py-2.5 px-1.5 font-semibold w-24">Type</th>
                    <th className="py-2.5 px-1.5 font-semibold min-w-[130px]">Item</th>
                    <th className="py-2.5 px-1.5 font-semibold min-w-[150px]">Description</th>
                    <th className="py-2.5 px-1.5 font-semibold w-16 text-right">Qty</th>
                    <th className="py-2.5 px-1.5 font-semibold w-24 text-right">Unit Price</th>
                    <th className="py-2.5 px-1.5 font-semibold w-24 text-right">Total</th>
                    <th className="py-2.5 px-1.5 font-semibold w-10 text-center">Del</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {items.map((row, idx) => {
                    const lineTotal =
                      (Number.isFinite(row.quantity) ? row.quantity : 0) *
                      (Number.isFinite(row.unitPrice) ? row.unitPrice : 0);
                    return (
                      <tr key={row.id}>
                        <td className="py-2 px-2 font-medium text-muted-foreground">{idx + 1}</td>
                        <td className="py-1.5 px-2">
                          <Select
                            value={row.itemType}
                            onValueChange={(value) =>
                              updateRow(row.id, {
                                itemType: value as QuotationLineDraft["itemType"],
                              })
                            }
                          >
                            <SelectTrigger
                              className="h-9 text-xs border-slate-300"
                              aria-label={`Line ${idx + 1} type`}
                            >
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="PART">Part</SelectItem>
                              <SelectItem value="LABOUR">Labour</SelectItem>
                              <SelectItem value="SERVICE">Service</SelectItem>
                              <SelectItem value="OTHER">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="py-1.5 px-2">
                          <Input
                            className="h-9 text-xs border-slate-300"
                            aria-label={`Line ${idx + 1} item`}
                            placeholder="Air filter"
                            value={row.item}
                            onChange={(e) => updateRow(row.id, { item: e.target.value })}
                          />
                        </td>
                        <td className="py-1.5 px-2">
                          <Input
                            className="h-9 text-xs border-slate-300"
                            aria-label={`Line ${idx + 1} description`}
                            placeholder="Part or labour description"
                            value={row.description}
                            onChange={(e) => updateRow(row.id, { description: e.target.value })}
                          />
                        </td>
                        <td className="py-1.5 px-2">
                          <Input
                            type="number"
                            min={1}
                            step={1}
                            placeholder="1"
                            className="h-9 text-xs text-right border-slate-300"
                            aria-label={`Line ${idx + 1} quantity`}
                            value={row.quantity}
                            onChange={(e) =>
                              updateRow(row.id, { quantity: Number(e.target.value || 0) })
                            }
                          />
                        </td>
                        <td className="py-1.5 px-2">
                          <Input
                            type="number"
                            min={0}
                            step="0.01"
                            placeholder="0.00"
                            className="h-9 text-xs text-right border-slate-300"
                            aria-label={`Line ${idx + 1} unit price`}
                            value={row.unitPrice}
                            onChange={(e) =>
                              updateRow(row.id, { unitPrice: Number(e.target.value || 0) })
                            }
                          />
                        </td>
                        <td className="py-2 px-2 text-right font-semibold tabular-nums whitespace-nowrap">
                          {money(lineTotal)}
                        </td>
                        <td className="py-1.5 px-2 text-center">
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            aria-label={`Remove quotation item ${row.item || idx + 1}`}
                            onClick={() => removeRow(row.id)}
                          >
                            <Trash2 size={14} />
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {items.length === 0 && (
              <div className="mt-3 rounded-lg border border-blue-200 bg-blue-50 px-3.5 py-2.5 text-xs text-blue-900">
                Select a service template above or click <strong>Add Item</strong> to begin building
                this quotation.
              </div>
            )}

            <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4 text-xs tabular-nums">
              <div className="flex flex-wrap items-center gap-6 text-slate-600">
                <span>
                  Subtotal: <strong className="text-slate-900">{money(totals.subtotal)}</strong>
                </span>
                <span>
                  VAT (16%): <strong className="text-slate-900">{money(totals.vat)}</strong>
                </span>
                <span>
                  50% Deposit:{" "}
                  <strong className="text-slate-900">{money(totals.requiredDeposit)}</strong>
                </span>
              </div>
              <div className="text-sm font-bold text-slate-900">Total: {money(totals.total)}</div>
            </div>
          </div>

          <FormStepFooter
            onPrev={() => setActiveStep("details")}
            prevLabel="Previous: Quotation Details"
            leftExtra={
              <Button type="button" variant="outline" onClick={() => saveQuotation(false)}>
                <Save size={14} />
                Save Draft
              </Button>
            }
            statusHint={
              step2Done
                ? `${validItems.length} item(s) · ${money(totals.total)}`
                : "Add at least 1 priced item"
            }
            onNext={handleNextStep}
            nextLabel="Next: Totals Review & Issue"
          />
        </>
      )}

      {activeStep === "review" && (
        <>
          <div className="stage-card">
            <div className="stage-card-head">
              <div>
                <h3 className="stage-card-title">Totals Review &amp; Issue Quotation</h3>
                <p className="stage-card-subtitle">
                  Verify breakdown and totals before sending {quotationNumber} to Customer
                  Authorization
                </p>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded border border-blue-200 bg-blue-50 text-primary">
                {validItems.length} Line {validItems.length === 1 ? "Item" : "Items"}
              </span>
            </div>

            <div className="space-y-4">
              {/* Compact Reference Strip */}
              <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                <div className="flex items-center justify-between gap-2 bg-white rounded-md border border-blue-200 px-3 py-2">
                  <div className="min-w-0">
                    <div className="text-[11px] text-slate-500 font-semibold">Quotation</div>
                    <div className="font-mono font-bold text-slate-900 truncate">
                      {quotationNumber}
                    </div>
                    <div className="text-slate-600 truncate">{quotationDate}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveStep("details")}
                    className="text-[11px] font-semibold text-primary hover:underline shrink-0 cursor-pointer"
                  >
                    Edit
                  </button>
                </div>
                <div className="flex items-center justify-between gap-2 bg-white rounded-md border border-blue-200 px-3 py-2">
                  <div className="min-w-0">
                    <div className="text-[11px] text-slate-500 font-semibold">
                      Customer &amp; Vehicle
                    </div>
                    <div className="font-bold text-slate-900 truncate">
                      {vehicle.customer || "Customer"}
                    </div>
                    <div className="text-slate-600 font-mono truncate">{vehicle.plate}</div>
                  </div>
                </div>
                <div className="flex items-center justify-between gap-2 bg-white rounded-md border border-blue-200 px-3 py-2">
                  <div className="min-w-0">
                    <div className="text-[11px] text-slate-500 font-semibold">Prepared By</div>
                    <div className="font-bold text-slate-900 truncate">
                      {preparedBy.trim() || "Missing"}
                    </div>
                    <div className="text-slate-600 truncate">
                      Sig: {signature.trim() || "Missing"}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveStep("details")}
                    className="text-[11px] font-semibold text-primary hover:underline shrink-0 cursor-pointer"
                  >
                    Edit
                  </button>
                </div>
              </div>

              {/* Read-Only Line Item Verification */}
              {validItems.length > 0 && (
                <div className="overflow-x-auto border border-slate-200 rounded-lg">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b bg-slate-50 text-slate-600">
                        <th className="py-2 px-3 font-semibold">Type</th>
                        <th className="py-2 px-3 font-semibold">Item / Description</th>
                        <th className="py-2 px-3 font-semibold text-right">Qty</th>
                        <th className="py-2 px-3 font-semibold text-right">Unit Price</th>
                        <th className="py-2 px-3 font-semibold text-right">Line Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {validItems.map((line) => (
                        <tr key={line.id}>
                          <td className="py-2 px-3 font-medium text-slate-600">{line.itemType}</td>
                          <td className="py-2 px-3 text-slate-900">
                            <span className="font-semibold">
                              {line.item.trim() || line.description}
                            </span>
                            {line.description.trim() &&
                              line.description.trim() !== line.item.trim() && (
                                <span className="text-slate-500"> — {line.description.trim()}</span>
                              )}
                          </td>
                          <td className="py-2 px-3 text-right tabular-nums">{line.quantity}</td>
                          <td className="py-2 px-3 text-right tabular-nums">
                            {money(line.unitPrice)}
                          </td>
                          <td className="py-2 px-3 text-right font-semibold tabular-nums">
                            {money(line.quantity * line.unitPrice)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Totals Breakdown */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs tabular-nums">
                <div className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5">
                  <div className="text-[11px] font-medium text-slate-500">Subtotal</div>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">
                    {money(totals.subtotal)}
                  </div>
                </div>
                <div className="rounded-lg border border-slate-200 bg-slate-50 px-3.5 py-2.5">
                  <div className="text-[11px] font-medium text-slate-500">VAT (16%)</div>
                  <div className="text-sm font-bold text-slate-900 mt-0.5">{money(totals.vat)}</div>
                </div>
                <div className="rounded-lg border border-blue-200 bg-blue-50 px-3.5 py-2.5">
                  <div className="text-[11px] font-medium text-blue-800">50% Min. Deposit</div>
                  <div className="text-sm font-bold text-primary mt-0.5">
                    {money(totals.requiredDeposit)}
                  </div>
                </div>
                <div className="rounded-lg border border-primary bg-primary px-3.5 py-2.5 text-primary-foreground">
                  <div className="text-[11px] font-medium opacity-90">Grand Total</div>
                  <div className="text-base font-bold mt-0.5">{money(totals.total)}</div>
                </div>
              </div>

              {missingSummary.length > 0 && (
                <div className="rounded-lg border border-blue-200 bg-blue-50 px-3.5 py-2.5 text-xs text-blue-900">
                  <strong>Required before issuing quotation:</strong> {missingSummary.join(", ")}
                </div>
              )}
            </div>
          </div>

          <FormStepFooter
            onPrev={() => setActiveStep("items")}
            prevLabel="Previous: Parts & Labour Items"
            rightExtra={
              <>
                <Button type="button" variant="outline" onClick={() => saveQuotation(false)}>
                  <Save size={14} />
                  Save Draft
                </Button>
                <Button type="submit" disabled={!step3Done} className="stage-primary-cta">
                  Generate &amp; Issue Quotation
                </Button>
              </>
            }
          />
        </>
      )}
    </form>
  );
}
