import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Check, Lock, Plus } from "../fa-icons";
import { useWorkspace } from "../workspace-context";
import {
  buildJobCardStageProgress,
  evaluateJobStageReadiness,
  isFinalInspectionAndReleaseComplete,
  WORKSHOP_FLOW_STAGES,
} from "@/lib/workshop-flow";
import { JobCardStageProgressBar } from "./job-card-stage-progress-bar";
import { Stage1IntakeForm } from "./stage-1-intake-form";
import { Stage2QuotationForm } from "./stage-2-quotation-form";
import { Stage3AuthorizationForm } from "./stage-3-authorization-form";
import { Stage4JobCardForm } from "./stage-4-job-card-form";
import { Stage5PartsForm } from "./stage-5-parts-form";
import { Stage6DispatchForm } from "./stage-6-dispatch-form";
import { Stage7MonitorForm } from "./stage-7-monitor-form";
import { Stage8FinalReleaseForm } from "./stage-8-final-release-form";

export function WorkshopStagesFlow() {
  const { vehicles, quotations, jobs, requisitions, dispatches, inspections } = useWorkspace();

  const [creatingNew, setCreatingNew] = useState(vehicles.length === 0);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>(vehicles[0]?.id ?? "");
  const [activeStageIndex, setActiveStageIndex] = useState<number>(0);

  useEffect(() => {
    if (!creatingNew && !vehicles.some((v) => v.id === selectedVehicleId)) {
      if (vehicles.length > 0) {
        setSelectedVehicleId(vehicles[0]!.id);
      } else {
        setCreatingNew(true);
        setActiveStageIndex(0);
      }
    }
  }, [vehicles, selectedVehicleId, creatingNew]);

  const activeVehicle = creatingNew
    ? undefined
    : (vehicles.find((v) => v.id === selectedVehicleId) ?? vehicles[0]);

  const activeQuotation = activeVehicle
    ? quotations.find((q) => q.vehicleId === activeVehicle.id)
    : undefined;
  const activeJob = activeVehicle ? jobs.find((j) => j.vehicleId === activeVehicle.id) : undefined;
  const activeRequisition = activeVehicle
    ? requisitions.find((r) => r.vehicleId === activeVehicle.id)
    : undefined;
  const activeInspection = activeVehicle
    ? inspections.find((ins) => ins.vehicleId === activeVehicle.id)
    : undefined;

  const readiness = useMemo(
    () =>
      evaluateJobStageReadiness({
        vehicle: activeVehicle,
        quotation: activeQuotation,
        job: activeJob,
        requisitions,
        dispatches,
      }),
    [activeVehicle, activeQuotation, activeJob, requisitions, dispatches],
  );

  const stage8Unlocked = !creatingNew && readiness.stages1To6Complete && Boolean(activeInspection);
  const stage8Completed = isFinalInspectionAndReleaseComplete({
    vehicle: activeVehicle,
    inspection: activeInspection,
  });
  const maxAllowedStageIndex = stage8Unlocked ? 7 : readiness.maxUnlockedStageIndex;

  const activeJobStageProgress = useMemo(
    () =>
      buildJobCardStageProgress({
        creatingNew,
        readiness,
        stage8Unlocked,
        stage8Completed,
        vehicle: activeVehicle,
        job: activeJob,
      }),
    [creatingNew, readiness, stage8Unlocked, stage8Completed, activeVehicle, activeJob],
  );

  useEffect(() => {
    if (creatingNew) {
      if (activeStageIndex !== 0) setActiveStageIndex(0);
      return;
    }
    if (activeStageIndex > maxAllowedStageIndex) {
      setActiveStageIndex(maxAllowedStageIndex);
    }
  }, [creatingNew, activeStageIndex, maxAllowedStageIndex]);

  function handleSelectVehicle(vehicleId: string) {
    setCreatingNew(false);
    setSelectedVehicleId(vehicleId);
    const v = vehicles.find((item) => item.id === vehicleId);
    if (v) {
      const q = quotations.find((item) => item.vehicleId === v.id);
      const j = jobs.find((item) => item.vehicleId === v.id);
      const ins = inspections.find((item) => item.vehicleId === v.id);
      const nextReadiness = evaluateJobStageReadiness({
        vehicle: v,
        quotation: q,
        job: j,
        requisitions,
        dispatches,
      });
      const nextMax =
        nextReadiness.stages1To6Complete && Boolean(ins) ? 7 : nextReadiness.maxUnlockedStageIndex;
      setActiveStageIndex(nextMax);
    }
  }

  function startNewIntake() {
    setCreatingNew(true);
    setSelectedVehicleId("");
    setActiveStageIndex(0);
  }

  const activeStageTitle =
    activeStageIndex === 7
      ? "Stage 8: Final Inspection & Vehicle Release"
      : (WORKSHOP_FLOW_STAGES[activeStageIndex]?.title ?? "Stage 1: Intake & Inspection");

  const activeStageSubtitle =
    activeStageIndex === 7
      ? "Complete road-test sign-off, outgoing mileage & fuel, and customer release"
      : (WORKSHOP_FLOW_STAGES[activeStageIndex]?.subtitle ?? "");

  return (
    <div className="workshop-flow-shell" data-testid="foreman-7-stage-flow">
      {/* Slim Header + Stage Progress + 8-Stage Switcher */}
      <div className="workshop-stepper-card">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-3 border-b border-border">
          <div className="min-w-0">
            {activeStageIndex > 0 ? (
              <button
                type="button"
                className="text-xs font-semibold text-slate-700 hover:text-primary cursor-pointer mb-1 inline-flex items-center gap-1"
                onClick={() => setActiveStageIndex(activeStageIndex - 1)}
              >
                &lt; Back to Stage {activeStageIndex}
              </button>
            ) : (
              <div className="text-xs font-medium text-muted-foreground mb-1">
                Workshop Forms / Stage {activeStageIndex + 1} of 8
              </div>
            )}
            <h2 className="text-lg font-bold text-slate-900 leading-tight">{activeStageTitle}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{activeStageSubtitle}</p>
          </div>

          {/* Slim 1-Line Vehicle Switcher + New Intake CTA */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 w-full sm:w-auto min-w-0 sm:ml-auto">
            {vehicles.length > 0 && (
              <Select
                value={creatingNew ? "__new__" : (activeVehicle?.id ?? "")}
                onValueChange={(value) => {
                  if (value === "__new__") {
                    startNewIntake();
                  } else {
                    handleSelectVehicle(value);
                  }
                }}
              >
                <SelectTrigger
                  aria-label="Select active workshop vehicle"
                  className="h-9 flex-1 min-w-0 max-w-full sm:flex-none sm:w-[240px] bg-white text-slate-900 border-slate-300 text-xs font-medium"
                >
                  <SelectValue placeholder="Switch vehicle..." />
                </SelectTrigger>
                <SelectContent>
                  {vehicles.map((v) => (
                    <SelectItem key={v.id} value={v.id}>
                      {v.plate} · {v.customer || v.make} ({v.id})
                    </SelectItem>
                  ))}
                  <SelectItem value="__new__">+ New Vehicle Intake</SelectItem>
                </SelectContent>
              </Select>
            )}
            <Button
              type="button"
              size="sm"
              onClick={startNewIntake}
              className="h-9 px-3 text-xs bg-primary hover:bg-[var(--sidebar-royal-deep)] text-primary-foreground whitespace-nowrap shrink-0"
            >
              <Plus size={13} />
              New Vehicle
            </Button>
          </div>
        </div>

        <JobCardStageProgressBar
          progress={activeJobStageProgress}
          viewedStageNumber={activeStageIndex + 1}
          onSelectStage={(idx) => setActiveStageIndex(idx)}
          className="mb-3"
        />

        <div className="workshop-stepper-track" role="tablist" aria-label="8-Stage Workshop Flow">
          {WORKSHOP_FLOW_STAGES.map((stage) => {
            const stageReadiness = readiness.stages[stage.stageNumber];
            const isUnlocked = creatingNew
              ? stage.index === 0
              : stage.index <= readiness.maxUnlockedStageIndex;
            const isActive = activeStageIndex === stage.index;
            const isCompleted = !creatingNew && stageReadiness.complete;
            const state = isActive ? "active" : isCompleted ? "completed" : "locked";

            return (
              <button
                key={stage.key}
                type="button"
                role="tab"
                aria-selected={isActive}
                aria-label={`Stage ${stage.stageNumber}: ${stage.shortLabel}`}
                disabled={!isUnlocked}
                data-state={state}
                title={
                  !isUnlocked
                    ? `Complete Stage ${stage.stageNumber - 1} first to unlock ${stage.shortLabel}`
                    : stage.title
                }
                className="workshop-step-btn"
                onClick={() => isUnlocked && setActiveStageIndex(stage.index)}
              >
                <div className="workshop-step-line">
                  <span className="workshop-step-circle">
                    {isCompleted && !isActive ? (
                      <Check size={14} />
                    ) : !isUnlocked ? (
                      <Lock size={12} />
                    ) : (
                      stage.stageNumber
                    )}
                  </span>
                </div>
                <span className="workshop-step-label">{stage.shortLabel}</span>
              </button>
            );
          })}

          <button
            type="button"
            role="tab"
            aria-selected={activeStageIndex === 7}
            aria-label="Stage 8: Final Release"
            disabled={!stage8Unlocked}
            data-state={
              activeStageIndex === 7 ? "active" : stage8Completed ? "completed" : "locked"
            }
            title={
              !stage8Unlocked
                ? "Submit Stage 7 for Final Inspection first to unlock Final Release"
                : "Stage 8: Final Inspection & Vehicle Release"
            }
            className="workshop-step-btn"
            onClick={() => stage8Unlocked && setActiveStageIndex(7)}
          >
            <div className="workshop-step-line">
              <span className="workshop-step-circle">
                {stage8Completed && activeStageIndex !== 7 ? (
                  <Check size={14} />
                ) : !stage8Unlocked ? (
                  <Lock size={12} />
                ) : (
                  8
                )}
              </span>
            </div>
            <span className="workshop-step-label">Final Release</span>
          </button>
        </div>
      </div>

      {/* Focused Single-Column Form Area */}
      <div className="workshop-stage-split">
        <div className="min-w-0">
          {(activeStageIndex === 0 || !activeVehicle) && (
            <Stage1IntakeForm
              vehicle={creatingNew ? undefined : activeVehicle}
              onSaved={(savedVehicle, advance) => {
                setCreatingNew(false);
                setSelectedVehicleId(savedVehicle.id);
                if (advance) {
                  setActiveStageIndex(1);
                }
              }}
            />
          )}

          {activeStageIndex === 1 && activeVehicle && (
            <Stage2QuotationForm
              vehicle={activeVehicle}
              quotation={activeQuotation}
              job={activeJob}
              onBack={() => setActiveStageIndex(0)}
              onSaved={(_savedQuote, advance) => {
                if (advance) {
                  setActiveStageIndex(2);
                }
              }}
            />
          )}

          {activeStageIndex === 2 && activeVehicle && (
            <Stage3AuthorizationForm
              vehicle={activeVehicle}
              quotation={activeQuotation}
              onBack={() => setActiveStageIndex(1)}
              onAuthorized={() => {
                setActiveStageIndex(3);
              }}
            />
          )}

          {activeStageIndex === 3 && activeVehicle && (
            <Stage4JobCardForm
              vehicle={activeVehicle}
              quotation={activeQuotation}
              job={activeJob}
              onBack={() => setActiveStageIndex(2)}
              onSaved={() => {
                setActiveStageIndex(4);
              }}
            />
          )}

          {activeStageIndex === 4 && activeVehicle && (
            <Stage5PartsForm
              vehicle={activeVehicle}
              job={activeJob}
              quotation={activeQuotation}
              requisitions={requisitions}
              onBack={() => setActiveStageIndex(3)}
              onVerified={() => {
                setActiveStageIndex(5);
              }}
            />
          )}

          {activeStageIndex === 5 && activeVehicle && (
            <Stage6DispatchForm
              vehicle={activeVehicle}
              job={activeJob}
              requisition={activeRequisition}
              dispatches={dispatches}
              onBack={() => setActiveStageIndex(4)}
              onDispatched={() => {
                setActiveStageIndex(6);
              }}
            />
          )}

          {activeStageIndex === 6 && activeVehicle && (
            <Stage7MonitorForm
              vehicle={activeVehicle}
              job={activeJob}
              readiness={readiness}
              onBack={() => setActiveStageIndex(5)}
              onSubmitted={() => {
                setActiveStageIndex(7);
              }}
            />
          )}

          {activeStageIndex === 7 && activeVehicle && (
            <Stage8FinalReleaseForm
              vehicle={activeVehicle}
              job={activeJob}
              inspection={activeInspection}
              readiness={readiness}
              onBack={() => setActiveStageIndex(6)}
              onSendToRework={() => {
                setActiveStageIndex(6);
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
}
